package com.daynilgroup.vendormanagement.model.response;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class EducationListResponse {
	
	static final long serialVersionUID = 1L;

	Long id;

	String schoolName;

	String degree;

	String specialization;

	Integer fromYear;

	Integer fromMonth;

	Integer toYear;

	Integer toMonth;

	String description;
	
	String educationPhoto;

}
