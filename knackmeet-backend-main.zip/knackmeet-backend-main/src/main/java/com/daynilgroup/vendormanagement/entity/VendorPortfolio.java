package com.daynilgroup.vendormanagement.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "vendor_portfolio")
@FieldDefaults(level = AccessLevel.PRIVATE)
public class VendorPortfolio extends BaseEntity{

	/**
	 * 
	 */
	static final long serialVersionUID = 1L;
	
	@JoinColumn(name = "portfolio_id", referencedColumnName = "id", nullable = false)
	@ManyToOne(fetch = FetchType.LAZY)
	Media media;
	
	@Column(name ="vendor_id")
	Long vendor;
	
}
