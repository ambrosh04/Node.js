/**
 * 
 */
package com.daynilgroup.vendormanagement.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.daynilgroup.vendormanagement.entity.CodeLookupType;

/**
 * @author Prerana
 *
 */
@Repository
public interface CodeLookupTypeRepository extends JpaRepository<CodeLookupType, Long> {

	@Query("Select c FROM CodeLookupType c where c.code=:code and (c.deleted=false or c.deleted IS NULL) ")
	CodeLookupType findByCode(@Param("code") String code);

	@Query("Select c FROM CodeLookupType c where c.code=:code and c.id<>:id and (c.deleted=false or c.deleted IS NULL) ")
	CodeLookupType findByCodeAndId(@Param("code") String code, @Param("id") Long id);

	@Query("Select c FROM CodeLookupType c where c.name=:name and (c.deleted=false or c.deleted IS NULL) ")
	CodeLookupType findByName(@Param("name") String name);

	@Query("Select c FROM CodeLookupType c where c.name=:name and c.id !=:id and (c.deleted=false or c.deleted IS NULL) ")
	CodeLookupType findByNameAndId(@Param("name") String name, @Param("id") Long id);

	Page<CodeLookupType> findByDeletedFalseOrDeletedIsNull(Pageable pageable);

	@Query("SELECT i FROM CodeLookupType i INNER JOIN CodeLookup li ON i.id=li.type.id WHERE li.name LIKE %:searchValue%")
	List<CodeLookupType> findByNameAndCode(String searchValue, Pageable pageable);

	@Modifying
	@Transactional
	@Query("Update CodeLookupType o set o.deleted=true where o.id=:id ")
	void delete(Long id);
	
	 Page<CodeLookupType> findByNameContainsAndDeletedFalseOrDeletedIsNull(String name, Pageable pageable);

	 List<CodeLookupType> findAllByDeletedFalse();
}
