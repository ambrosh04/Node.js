package com.daynilgroup.vendormanagement.model.response;

import java.util.List;

import com.daynilgroup.vendormanagement.constants.Gender;

import lombok.AccessLevel;
import lombok.Builder;
import lombok.Data;
import lombok.experimental.FieldDefaults;


@Builder
@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
public class ResourceJobsListResponse {
	
	static final long serialVersionUID = 1L;

	Long id;

	String firstname;

	String lastname;

	String category;

	String  availabilityType;

	String base64MediaString;

	List<String> skills;

	String designation;

	String rate;

	String experience;

	String address;
	
	Gender gender;

}
