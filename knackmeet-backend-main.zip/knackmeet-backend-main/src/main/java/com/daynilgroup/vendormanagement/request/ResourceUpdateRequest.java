package com.daynilgroup.vendormanagement.request;

import java.io.Serializable;
import java.math.BigDecimal;

import com.daynilgroup.vendormanagement.constants.CurrencyTypeEnum;
import com.daynilgroup.vendormanagement.constants.DeploymentTypeEnum;
import com.daynilgroup.vendormanagement.constants.Gender;
import com.daynilgroup.vendormanagement.constants.RateTypeEnum;
import com.daynilgroup.vendormanagement.constants.ResourceStatusEnum;
import com.daynilgroup.vendormanagement.model.response.AdvanceSearchDropdownModel;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
@AllArgsConstructor
@NoArgsConstructor
public class ResourceUpdateRequest implements Serializable {

	private static final long serialVersionUID = 1L;

	Long id;

	String firstname;

	String middleName;

	String lastname;

	Gender gender;

	AdvanceSearchDropdownModel designation;

	DeploymentTypeEnum deploymenType;

	Long availabilityId;

	Long countryId;

	Long stateId;

	Long categoryId;

	BigDecimal rate;

	String base64resume;

	ResourceStatusEnum resourceStatus;

	String deletedImage;

	String deletedResume;

	String base64profilePhoto;

	CurrencyTypeEnum currencyType;

	RateTypeEnum rateTypeEnum;

	// String description;

	String resumeName;

	BigDecimal usdRate;

	RateTypeEnum usdRateType;
	
    String location;
	
	BigDecimal latitude;
	
	BigDecimal longitude;

}
