/**
 * 
 */
package com.daynilgroup.vendormanagement.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.daynilgroup.vendormanagement.constants.UserType;
import com.daynilgroup.vendormanagement.entity.User;

/**
 * @author Prerana
 *
 */
@Repository
public interface UserRepository extends JpaRepository<User, Long> {

	User findByEmailIdOrMobile(String emailId, String mobile);

	@Query("SELECT u FROM User u WHERE (u.emailId = ?1 OR u.mobile =?2) AND u.userType = ?3 ")
	User findByEmailIdOrMobileAndUserType(String emailId, String mobile, UserType userType);

	@Query("SELECT COUNT(u.id)>0 FROM User u  where (u.deleted=false or u.deleted IS NULL) and u.mobile=?1 and u.userType=?2 and (?3 IS NULL OR u.id<>?3)")
	Boolean existsByMobileNumberAndUserTypeAndIdNot(String mobileNumber, UserType userType, Long Id);

	@Query("SELECT COUNT(u.id)>0 FROM User u  where (u.deleted=false or u.deleted IS NULL) and u.emailId=?1 and u.userType=?2 and (?3 IS NULL OR u.id<>?3)")
	Boolean existsByEmailIdAndUserTypeAndIdNot(String emailId, UserType userType, Long Id);

	User findByIdAndActiveTrue(Long userId);

	@Modifying
	@Query("UPDATE User u SET u.password = ?1 WHERE u.id = ?2")
	void changePassword(String encode, Long userId);

	User findByEmailIdAndActiveTrue(String emailId);

	Boolean existsByEmailId(String emailId);

	Boolean existsByMobile(String mobileNumber);

	User findActiveUserByForgotPasswordToken(String token);

	@Query("SELECT COUNT(u.id)>0 FROM User u  where (u.deleted=false or u.deleted IS NULL) and u.mobile=?1  and (?2 IS NULL OR u.id<>?2)")
	Boolean existsByMobileNumberAndIdNot(String mobileNumber, Long Id);

	@Query("SELECT COUNT(u.id)>0 FROM User u  where (u.deleted=false or u.deleted IS NULL) and u.emailId=?1 and (?2 IS NULL OR u.id<>?2)")
	Boolean existsByEmailIdAndIdNot(String emailId, Long Id);
	
	@Query("SELECT u FROM User u INNER JOIN Vendor v  ON u.id=v.user.id where (u.deleted=false or u.deleted IS NULL) and (v.deleted=false or v.deleted IS NULL) and v.statusEnum='VERIFIED' ")
	List<User> sendJobDetailsMailToAllVerifiedUser();


}
