package com.daynilgroup.vendormanagement.model.request;

import java.io.Serializable;

import com.daynilgroup.vendormanagement.constants.TimeZoneEnum;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
@AllArgsConstructor
@NoArgsConstructor
public class RegistrationEnquiryRequest implements Serializable {

	private static final long serialVersionUID = 1L;
	
	Long id;
	
	String firstName;
	
	String lastName;
	
	String emailId;
	
	String mobileNumber;
	
	TimeZoneEnum timeZone;
	
	Long phoneCodeId;

}
