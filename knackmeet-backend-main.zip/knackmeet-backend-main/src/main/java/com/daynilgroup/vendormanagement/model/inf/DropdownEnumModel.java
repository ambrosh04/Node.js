package com.daynilgroup.vendormanagement.model.inf;

import java.io.Serializable;

import lombok.Value;

/**
 * 
 * @author Manish
 *
 */
@Value
public class DropdownEnumModel implements Serializable {

	static final long serialVersionUID = 1L;

	String label;

	String value;

}
