package com.daynilgroup.vendormanagement.constants;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
*
* @author Manish
*
*/
@Getter
@AllArgsConstructor
public enum MenuEnum {

	DASHBOARD("Dashboard"),
	MASTER("Master"),
	CODE_LOOKUP("Code Lookup"),
	CODE_LOOKUP_TYPE("Code Lookup Type"),
	USER("User"),
	ROLE("Role");
	
	
    String displayName;
}