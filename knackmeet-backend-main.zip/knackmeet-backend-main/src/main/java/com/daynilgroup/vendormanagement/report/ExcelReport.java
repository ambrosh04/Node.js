package com.daynilgroup.vendormanagement.report;

import java.io.IOException;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.daynilgroup.vendormanagement.constants.StatusEnum;
import com.daynilgroup.vendormanagement.model.request.RegistrationEnquiryResponse;
import com.daynilgroup.vendormanagement.model.response.VendorListResponse;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;

@FieldDefaults(level = AccessLevel.PRIVATE)
public class ExcelReport implements Serializable {

	private static final long serialVersionUID = 1L;

	final String[] VENDORS_COLUMN_NAMES = { "Sr No.", "Name", "Agency Name ", "Email", "Mobile Number", "Status",
			"Created On" };

	final String[] VENDORS_PARTIAL_COLUMN_NAMES = { "Sr No.", "Name", "Email", "Mobile Number", "Created On" };

	XSSFWorkbook workbook;
	XSSFSheet sheet;
	List<?> list;

	public ExcelReport(List<?> list) {
		this.list = (List<?>) list;
		workbook = new XSSFWorkbook();
	}

	private void createCell(Row row, int columnCount, Object value, CellStyle style) {
		Cell cell = row.createCell(columnCount);
		if (value instanceof Integer) {
			cell.setCellValue((Integer) value);
		} else if (value instanceof Boolean) {
			cell.setCellValue((Boolean) value);
		} else if (value instanceof BigDecimal) {
			cell.setCellValue(((BigDecimal) value).doubleValue());
		} else if (value instanceof Long) {
			cell.setCellValue((Long) value);
		} else if (value instanceof LocalDateTime) {
			LocalDateTime localDateTime = (LocalDateTime) value;

			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMMM d, yyyy h:mm a");
			String formattedDateTime = localDateTime.format(formatter);

			cell.setCellValue(formattedDateTime);
		} else if (value instanceof Enum) {
			cell.setCellValue(((Enum<?>) value).name());
		} else {
			cell.setCellValue((String) value);
		}

		cell.setCellStyle(style);
	}

	public void setVendorDataColumnWidth() {
		sheet.setColumnWidth(0, 15 * 256);
		sheet.setColumnWidth(1, 30 * 256);
		sheet.setColumnWidth(2, 40 * 256);
		sheet.setColumnWidth(3, 35 * 256);
		sheet.setColumnWidth(4, 25 * 256);
		sheet.setColumnWidth(5, 25 * 256);
		sheet.setColumnWidth(6, 35 * 256);
	}

	public void setVendorsPartialDataColumnWidth() {
		sheet.setColumnWidth(0, 15 * 256);
		sheet.setColumnWidth(1, 30 * 256);
		sheet.setColumnWidth(2, 25 * 256);
		sheet.setColumnWidth(3, 25 * 256);

	}

	public String getStatus(StatusEnum statusEnum) {
		String status = null;
		if (statusEnum.equals(StatusEnum.EMAIL_PENDING)) {
			status = "EMAIL PENDING";
		} else if (statusEnum.equals(StatusEnum.UNVERIFIED)) {
			status = "PENDING";
		} else if (statusEnum.equals(StatusEnum.VERIFIED)) {
			status = "VERIFIED";
		} else if (statusEnum.equals(StatusEnum.REJECTED)) {
			status = "REJECTED";
		}
		return status;

	}

	private void writeVendorDataLines() {
		int rowCount = 1;
		CellStyle style = workbook.createCellStyle();
		style.setAlignment(HorizontalAlignment.GENERAL);
		XSSFFont font = workbook.createFont();
		font.setFontHeight(11);
		style.setFont(font);
		int srNumber = 1;
		for (Object object : list) {
			VendorListResponse vendoResponse = (VendorListResponse) object;
			Row row = sheet.createRow(rowCount++);
			int columnCount = 0;
			createCell(row, columnCount++, srNumber, style);
			createCell(row, columnCount++, vendoResponse.getFirstName() + " " + vendoResponse.getLastName(), style);
			createCell(row, columnCount++, vendoResponse.getAgencyName(), style);
			createCell(row, columnCount++, vendoResponse.getEmailId(), style);
			createCell(row, columnCount++, vendoResponse.getUserCountryCode() + " " + vendoResponse.getMobile(), style);
			createCell(row, columnCount++, getStatus(vendoResponse.getStatus()), style);
			createCell(row, columnCount++, vendoResponse.getCreatedOn(), style);
			srNumber++;
		}
	}

	private void writeVendorPartialDataLines() {
		int rowCount = 1;
		CellStyle style = workbook.createCellStyle();
		style.setAlignment(HorizontalAlignment.GENERAL);
		XSSFFont font = workbook.createFont();
		font.setFontHeight(11);
		style.setFont(font);
		int srNumber = 1;
		for (Object object : list) {
			RegistrationEnquiryResponse registrationEnquiryResponse = (RegistrationEnquiryResponse) object;
			Row row = sheet.createRow(rowCount++);
			int columnCount = 0;
			createCell(row, columnCount++, srNumber, style);
			createCell(row, columnCount++,
					registrationEnquiryResponse.getFirstName() + " " + registrationEnquiryResponse.getLastName(),
					style);
			createCell(row, columnCount++, registrationEnquiryResponse.getEmailId(), style);
			createCell(row, columnCount++, registrationEnquiryResponse.getMobileNumber(), style);
			createCell(row, columnCount++, registrationEnquiryResponse.getCreatedOn(), style);
			srNumber++;
		}
	}

	private void writeVendorsHeaderLine() {
		sheet = workbook.createSheet();

		sheet.createRow(0);

		CellStyle style = workbook.createCellStyle();
		style.setAlignment(HorizontalAlignment.LEFT);
		style.setWrapText(true);

		XSSFFont font = workbook.createFont();
		font.setFontHeight(14);

		style.setFont(font);
		Row row = sheet.createRow(1);
		sheet.autoSizeColumn(0);
		row = sheet.createRow(0);
		for (int i = 0; i < VENDORS_COLUMN_NAMES.length; i++) {
			createCell(row, i, VENDORS_COLUMN_NAMES[i], style);
		}
		setVendorDataColumnWidth();

	}

	private void writeVendorSPartialHeaderLine() {
		sheet = workbook.createSheet();

		sheet.createRow(0);

		CellStyle style = workbook.createCellStyle();
		style.setAlignment(HorizontalAlignment.LEFT);
		style.setWrapText(true);

		XSSFFont font = workbook.createFont();
		font.setFontHeight(14);

		style.setFont(font);

		Row row = sheet.createRow(1);
		sheet.autoSizeColumn(0);
		row = sheet.createRow(0);
		for (int i = 0; i < VENDORS_PARTIAL_COLUMN_NAMES.length; i++) {
			createCell(row, i, VENDORS_PARTIAL_COLUMN_NAMES[i], style);
		}
		setVendorDataColumnWidth();

	}

	public void exportVendorsData(HttpServletResponse response) throws IOException {
		writeVendorsHeaderLine();
		writeVendorDataLines();
		ServletOutputStream outputStream = response.getOutputStream();
		workbook.write(outputStream);
		workbook.close();
		outputStream.close();

	}

	public void exportVendorsPartialData(HttpServletResponse response) throws IOException {
		writeVendorSPartialHeaderLine();
		writeVendorPartialDataLines();
		ServletOutputStream outputStream = response.getOutputStream();
		workbook.write(outputStream);
		workbook.close();
		outputStream.close();

	}
}
