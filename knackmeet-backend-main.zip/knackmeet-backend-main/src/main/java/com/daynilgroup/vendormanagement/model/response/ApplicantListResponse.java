/**
 * 
 */
package com.daynilgroup.vendormanagement.model.response;

import java.io.Serializable;
import java.util.List;

import com.daynilgroup.vendormanagement.constants.ResourceStatusEnum;
import com.daynilgroup.vendormanagement.constants.StatusEnum;
import com.daynilgroup.vendormanagement.constants.UserType;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

/**
 * @author Prerana
 *
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class ApplicantListResponse implements Serializable {

	static final long serialVersionUID = 1L;

	Long resourceId;

	String resourceName;

	String designation;
	
	UserType appliedBy;

	ResourceStatusEnum status;

	String availabilityType;

	String base64MediaString;

	List<String> skills;

	String rate;

	String experience;

	String state;

	String country;

	String gender;

	Boolean active;

	String higherEducation;

	Long passingYear;

	StatusEnum statusEnum;

	Integer appliedJobCount;

	String deploymentType;
	
	String usdRate;
	
	String location;
}
