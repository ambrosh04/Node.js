/**
 * 
 */
package com.daynilgroup.vendormanagement.constants;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author Prerana
 *
 */
@Getter
@AllArgsConstructor
public enum RateTypeEnum {
	
	MONTHLY("Monthly"),HOURLY("Hourly");

	String displayName;

}
