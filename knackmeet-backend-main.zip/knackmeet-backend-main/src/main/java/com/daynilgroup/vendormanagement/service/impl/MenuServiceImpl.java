package com.daynilgroup.vendormanagement.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;

import com.daynilgroup.vendormanagement.entity.Menu;
import com.daynilgroup.vendormanagement.repository.MenuRepository;
import com.daynilgroup.vendormanagement.service.MenuService;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;

@Service
@FieldDefaults(level = AccessLevel.PRIVATE)
public class MenuServiceImpl implements MenuService {

	@Autowired
	MenuRepository menuRepository;

	@Override
	public JpaRepository<Menu, Long> getJpaRepository() {

		return menuRepository;
	}

	@Override
	public List<Long> getParentIds(List<Long> ids) {

		return menuRepository.getParentIds(ids);
		
	}

}
