package com.daynilgroup.vendormanagement.admin.rest.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.daynilgroup.commons.events.util.PaginationUtil;
import com.daynilgroup.commons.events.wrapper.PageModel;
import com.daynilgroup.commons.events.wrapper.PaginationRequestWrapper;
import com.daynilgroup.vendormanagement.constants.UrlConstants;
import com.daynilgroup.vendormanagement.entity.SubscribedUsers;
import com.daynilgroup.vendormanagement.helper.SubscribedUsersHelper;
import com.daynilgroup.vendormanagement.service.SubscribedUsersService;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;

@FieldDefaults(level = AccessLevel.PRIVATE)
@RestController
@RequestMapping(UrlConstants.ADMIN_SUBSCRIBED_USERS_BASE_URL)
@Slf4j
public class AdminSubscribedUsersRestController {

	@Autowired
	SubscribedUsersService subscribedUsersService;

	@Autowired
	SubscribedUsersHelper subscribedUsersHelper;

	@GetMapping(UrlConstants.LIST)
	public ResponseEntity<Object> getUserSubcriptionList(PaginationRequestWrapper paginationRequestWrapper) {
		try {
			Pageable pageable = PaginationUtil.getPageable(paginationRequestWrapper);
			Page<SubscribedUsers> userSubcriptionList = subscribedUsersService.findAll(pageable);
			PageModel.PageModelBuilder builder = PageModel.builder()
					.data(subscribedUsersHelper.getListResponse(userSubcriptionList.getContent()))
					.pageCount(Long.valueOf(userSubcriptionList.getTotalPages()))
					.totalCount(userSubcriptionList.getTotalElements());
			return new ResponseEntity<>(builder.build(), HttpStatus.OK);
		} catch (Exception e) {
			log.error(e.getMessage());
			return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}
