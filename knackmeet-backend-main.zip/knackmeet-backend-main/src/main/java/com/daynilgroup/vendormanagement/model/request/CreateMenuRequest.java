package com.daynilgroup.vendormanagement.model.request;

import com.daynilgroup.vendormanagement.annotation.CreateRequestValidator;
import com.daynilgroup.vendormanagement.constants.MenuEnum;
import com.daynilgroup.vendormanagement.request.inf.RequestInf;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 *
 * @author Manish
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@CreateRequestValidator
public class CreateMenuRequest implements RequestInf {

	static final long serialVersionUID = 1L;

	private Long id;
	private String title;
	private String path;
	private String icon;
	private Integer displayOrder;
	private Long parentId;
	private Boolean active;
	private Boolean masterMenu;
	private MenuEnum code;
}
