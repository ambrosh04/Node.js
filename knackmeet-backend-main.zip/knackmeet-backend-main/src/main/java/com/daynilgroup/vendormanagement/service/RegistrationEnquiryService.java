package com.daynilgroup.vendormanagement.service;

import java.util.List;

import com.daynilgroup.vendormanagement.entity.RegistrationEnquiry;

public interface RegistrationEnquiryService extends AbstractService<RegistrationEnquiry> {

	void deleteById(Long id);
	
	List<RegistrationEnquiry> findByEmailOrMobileNumberAndPhoneCode(String email,String mobileNumber,Long phoneCodeId);
	
}
