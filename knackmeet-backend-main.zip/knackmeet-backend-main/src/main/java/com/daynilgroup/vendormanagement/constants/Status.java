package com.daynilgroup.vendormanagement.constants;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.experimental.FieldDefaults;

/**
*
* @author prerana
*/
@Getter
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public enum Status {

	PENDING_OTP("Pending OTP"),
	VERIFIED("Verified"),
	UNVERIFIED("Unverified");

	String displayName;

}