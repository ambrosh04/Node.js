package com.daynilgroup.vendormanagement.model.response;

import lombok.AccessLevel;
import lombok.Builder;
import lombok.Data;
import lombok.experimental.FieldDefaults;

@Data
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
public class SearchHistoryDropDownResponse {
	Long searcHistoryId;
	String  label;

}

