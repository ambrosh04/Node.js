package com.daynilgroup.vendormanagement.model.response;

import com.daynilgroup.vendormanagement.constants.JobSearchInTypeEnum;
import com.daynilgroup.vendormanagement.constants.ResourceSearchInEnum;

import lombok.AccessLevel;
import lombok.Builder;
import lombok.Data;
import lombok.experimental.FieldDefaults;

@Data
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
public class RecentSearchHistoryResponse {

	static final long serialVersionUID = 1L;

	Long id;

	String date;
	
	String searchType;
	
	DropdownResponse[] KeywordsArray;
	
	ResourceSearchInEnum resourceSearchInEnum;
	
	JobSearchInTypeEnum jobSearchInTypeEnum;

	Integer minExperience;

	Integer maxExperience;
	
	Long cityId;

	Long stateId;

	Long countryId;


}
