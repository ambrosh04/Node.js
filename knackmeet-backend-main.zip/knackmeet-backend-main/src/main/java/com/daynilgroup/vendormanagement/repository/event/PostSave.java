package com.daynilgroup.vendormanagement.repository.event;
/**
*
* @author Manish
*/
public interface PostSave<E, R> {

    public Boolean postSaveAction(E entity, R Request) throws Exception;
}
