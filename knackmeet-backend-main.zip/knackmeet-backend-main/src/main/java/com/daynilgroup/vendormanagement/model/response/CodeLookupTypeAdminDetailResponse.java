package com.daynilgroup.vendormanagement.model.response;

import java.io.Serializable;

import lombok.AccessLevel;
import lombok.Builder;
import lombok.Data;
import lombok.experimental.FieldDefaults;

@Data
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
public class CodeLookupTypeAdminDetailResponse implements Serializable {
	
	static final long serialVersionUID = 1L;

	Long id;

	String code;

	String name;

	Long parentId;

	String parentName;

	Boolean active;
	
	Boolean coverImgRequire;

}