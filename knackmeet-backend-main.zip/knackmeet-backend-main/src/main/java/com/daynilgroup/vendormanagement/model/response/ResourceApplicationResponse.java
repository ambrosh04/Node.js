package com.daynilgroup.vendormanagement.model.response;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

import com.daynilgroup.vendormanagement.constants.CurrencyTypeEnum;
import com.daynilgroup.vendormanagement.constants.RateTypeEnum;
import com.daynilgroup.vendormanagement.constants.UserType;

import lombok.AccessLevel;
import lombok.Builder;
import lombok.Data;
import lombok.experimental.FieldDefaults;

@Builder
@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
public class ResourceApplicationResponse {
	String firstName;
	String lastName;
	List<String> resourceSkill;
	String jobTitle;
	String city;
	String country;
	String state;
	LocalDateTime joiningDate;
	String rate;
	Integer minExperience;
	Integer maxExperience;
	LocalDateTime date;
	Long resourceId;
	Long jobId;
	String appliedAt;
	String resourceNo;
	String resourceStatus;
	
	String designation;
	
	String resourceExperience; 
	
	String resourceCity;
	
	String resourceState;
	
	String resourceCountry;
	
	String availability;
	
	String workFrom;
	
	String deploymentType;
	
	String duration;
	
	RateTypeEnum rateTypeEnum;
	
	BigDecimal minRate;
	
	BigDecimal maxRate;
	
	String usdRate;

	CurrencyTypeEnum currencyType;
	
	String gender;
	
	String jobLocation;
	
	String resourceLocation;
	
	UserType appliedBy;

}
