package com.daynilgroup.vendormanagement.request;

import java.io.Serializable;

import com.daynilgroup.vendormanagement.constants.ResultTypeEnum;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.FieldDefaults;

@Getter
@Setter
@FieldDefaults(level = AccessLevel.PRIVATE)
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class EmailLogRequest implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	Long id;
	
	ResultTypeEnum resultType;
	
	String email;
	
	String subject;
	
	String logMsg;
	
	Long vendorId;
	
}
