package com.daynilgroup.vendormanagement.model.response;

import lombok.AccessLevel;
import lombok.Builder;
import lombok.Data;
import lombok.experimental.FieldDefaults;

@Data
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
public class AddressResponse {
	Long id;

	String address;

	String pinCode;

	Long stateId;

	Long countryId;

	Long cityId;
}
