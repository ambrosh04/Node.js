/**
 * 
 */
package com.daynilgroup.vendormanagement.helper;

import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.UUID;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;

import com.daynilgroup.commons.events.exception.BusinessException;
import com.daynilgroup.vendormanagement.constants.Constants;
import com.daynilgroup.vendormanagement.constants.MediaTypeEnum;
import com.daynilgroup.vendormanagement.constants.StaticConfigurationEnum;
import com.daynilgroup.vendormanagement.constants.StatusEnum;
import com.daynilgroup.vendormanagement.constants.UserType;
import com.daynilgroup.vendormanagement.entity.CodeLookup;
import com.daynilgroup.vendormanagement.entity.Company;
import com.daynilgroup.vendormanagement.entity.Media;
import com.daynilgroup.vendormanagement.entity.User;
import com.daynilgroup.vendormanagement.entity.Vendor;
import com.daynilgroup.vendormanagement.entity.VendorPortfolio;
import com.daynilgroup.vendormanagement.entity.VerifyEmail;
import com.daynilgroup.vendormanagement.exception.SaveRestException;
import com.daynilgroup.vendormanagement.model.request.ProofIdentityRegistrationReq;
import com.daynilgroup.vendormanagement.model.request.VendorRequest;
import com.daynilgroup.vendormanagement.model.response.BannerResponse;
import com.daynilgroup.vendormanagement.model.response.PortfolioResponse;
import com.daynilgroup.vendormanagement.model.response.ProofIdentityRegistrationResponse;
import com.daynilgroup.vendormanagement.model.response.TimeZomeDropdown;
import com.daynilgroup.vendormanagement.model.response.UserVendorResponse;
import com.daynilgroup.vendormanagement.model.response.VendorListResponse;
import com.daynilgroup.vendormanagement.model.response.VendorPortfolioResponse;
import com.daynilgroup.vendormanagement.model.response.VendorResponse;
import com.daynilgroup.vendormanagement.request.BannerRequest;
import com.daynilgroup.vendormanagement.service.CodeLookupService;
import com.daynilgroup.vendormanagement.service.CompanyService;
import com.daynilgroup.vendormanagement.service.MediaService;
import com.daynilgroup.vendormanagement.service.RegistrationEnquiryService;
import com.daynilgroup.vendormanagement.service.StaticConfigurationService;
import com.daynilgroup.vendormanagement.service.UserService;
import com.daynilgroup.vendormanagement.service.VendorPortfolioService;
import com.daynilgroup.vendormanagement.service.VendorService;
import com.daynilgroup.vendormanagement.service.VerifyEmailService;
import com.daynilgroup.vendormanagement.util.CommonUtil;
import com.daynilgroup.vendormanagement.util.EmailSenderUtil;
import com.daynilgroup.vendormanagement.util.EntityUtil;
import com.daynilgroup.vendormanagement.util.FileUpload;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;

/**
 * @author Prerana
 *
 */
@Slf4j
@Component
@FieldDefaults(level = AccessLevel.PRIVATE)
public class VendorHelper extends AbstractHelper<Vendor, VendorRequest, VendorListResponse, Object, VendorResponse> {

	@Autowired
	VendorService vendorService;

	@Autowired
	UserService userService;

	@Autowired
	UserHelper userHelper;

	@Autowired
	AttributeMediaUploadHelper attributeMediaUploadHelper;

	@Autowired
	FileUpload fileUpload;

	@Autowired
	MediaService imageService;

	@Autowired
	VendorPortfolioService portfolioService;

	@Autowired
	EntityUtil entityUtil;
	
	@Autowired
	CodeLookupService codeLookupService;

	@Value("${aws.s3.url}")
	private String awsS3Url;

	@Autowired
	CompanyService companyService;
	
	@Autowired
	EmailSenderUtil emailSenderUtil;
	
	@Autowired
	VerifyEmailService verifyEmailService;
	
	@Autowired
	RegistrationEnquiryService registrationEnquiryService;
	
	@Autowired
	StaticConfigurationService staticConfigurationService;
	
	
	@Override
	@Transactional
	public Vendor getEntity(VendorRequest request) throws Exception {

		Vendor vendor = null;
		Company company=null;
		
		if (request.getId() != null) {
			request.setUpdate(true);
			vendor = vendorService.findById(request.getId());
			company = companyService.findByVendorId(vendor.getId());
		}
		if (vendor == null) {
			vendor = new Vendor();
			vendor.setStatusEnum(StatusEnum.EMAIL_PENDING);
		}

		User user = vendor.getUser();
		log.info("--------");

		UserType userType = user != null ? user.getUserType() : null;
		if (user == null) {
			user = new User();
			userType = UserType.VENDOR;
		}
		if (user.getId() == null) {
			if (userService.existsByMobileNumber(request.getMobile())) {
				throw new Exception("Account already exists with the given mobile number.");
			} else if (userService.existsByEmailId(request.getEmailId())) {
				throw new Exception("Account already exists with the given email id.");
			}
		}

		else {
			if (userService.existsByMobileNumberAndIdNot(request.getMobile(), user.getId())) {
				throw new Exception("Account already exists with the given mobile number.");
			} else if (userService.existsByEmailIdNumberAndIdNot(request.getEmailId(), user.getId())) {
				throw new Exception("Account already exists with the given email id.");
			}

		}
		userHelper.populateEntity(user, request, userType);
		if (UserType.ADMIN.equals(user.getUserType())) {
			vendor.setStatusEnum(StatusEnum.VERIFIED);
		}

		if (!CommonUtil.isEmpty(request.getAbout())) {
			if (request.getAbout().length() >= 501) {
				throw new Exception("About company must be in 500 character");
			}
			vendor.setAbout(request.getAbout());
		} else {
			vendor.setAbout(null);
		}

		vendor.setUser(user);
		vendor.setAgencyName(request.getAgencyName());
		vendor.setIncorparationDate(request.getIncorparationDate());
		vendor.setTeamStrength(request.getTeamStrength());
		vendor.setWebsite(request.getWebsite());
		if (company != null) {
			company.setWebsite(request.getWebsite());
		}
		vendor.setGstNumber(request.getGstNumber());
		vendor.setDirectorName(request.getDirectorName());
		vendor.setLocation(request.getLocation() != null ? request.getLocation() : "");
		vendor.setTagline(request.getTagline());
		if (vendor.getId() == null) {
			if (vendorService.existsByCompanyPrimaryNumber(request.getCompanyPrimaryNumber())) {
				throw new Exception("Account already exists with the given company primary number.");
			} else if (vendorService.existsByCompanyPrimaryEmail(request.getCompanyPrimaryEmail())) {
				throw new Exception("Account already exists with the given company email id.");
			}
		} else {
			if (vendorService.existsByCompanyPrimaryNumberAndIdNot(request.getCompanyPrimaryNumber(), vendor.getId())) {
				throw new Exception("Account already exists with the given company primary number.");
			} else if (vendorService.existsByCompanyPrimaryEmailAndIdNot(request.getCompanyPrimaryEmail(),
					vendor.getId())) {
				throw new Exception("Account already exists with the given company email id.");
			}
		}
		vendor.setCompanyPrimaryNumber(request.getCompanyPrimaryNumber());
		vendor.setCompanyPrimaryEmail(request.getCompanyPrimaryEmail());
		vendor.setCompanyDescription(request.getCompanyDescription()!=null?request.getCompanyDescription():null);
		if (CommonUtil.isValid(request.getCountryCodeId())) {
			CodeLookup countryCode = codeLookupService.findById(request.getCountryCodeId());
			vendor.setCountryCode(countryCode);
		}
		if (!ObjectUtils.isEmpty(request.getBase64profilePhoto()) && request.getId() != null) {

			Media media = attributeMediaUploadHelper.setMedia(
					CommonUtil.getFolderStructure(request.getId(), "ProfilePhoto"), vendor.getVendorLogo(),
					request.getBase64profilePhoto(), MediaTypeEnum.IMAGE);
			vendor.setVendorLogo(media);
			if (company != null) {
				company.setMedia(media);
			}
			
		}

		if (!ObjectUtils.isEmpty(request.getDeletedImage())) {
			String deletedImages = request.getDeletedImage();
			String oldPath = StringUtils.substringBetween(deletedImages, "com/", "?X");
			imageService.deleteMedia(oldPath);
			fileUpload.deleteFileByS3(oldPath);
		}
		String fileExtension = "";
		String fileName = "";
		if (request.getBase64ProofOfRegistrationName() != null){
			int indexOf = request.getBase64ProofOfRegistrationName().indexOf(".");
			fileExtension = request.getBase64ProofOfRegistrationName().substring(indexOf).toLowerCase();
			fileName = request.getBase64ProofOfRegistrationName().substring(0, indexOf);
		}
		
		if (!ObjectUtils.isEmpty(request.getBase64ProofOfRegistrationName())
				&& !(fileExtension.contains(".png")
						|| fileExtension.contains(".jpg")
						|| fileExtension.contains(".jpeg")
						|| fileExtension.contains(".pdf"))) {
			throw new BusinessException("Please upload pdf /png / jpg / jpeg formated file only.");
		}
		

		if (!ObjectUtils.isEmpty(request.getBase64ProofOfRegistrationName()) && request.getId() != null) {
			if (request.getBase64ProofOfRegistrationName().contains(".png")
					|| request.getBase64ProofOfRegistrationName().contains(".jpg")
					|| request.getBase64ProofOfRegistrationName().contains(".jpeg")) {

				

				Media media = attributeMediaUploadHelper.setMediaWithFileName(
						CommonUtil.getFolderStructure(vendor.getId(), Constants.PROOF_OF_DOCUMENT_REGISTRATION),
						vendor.getProofOfRegistration(), request.getBase64ProofOfRegistration(), fileName,
						MediaTypeEnum.IMAGE);
				vendor.setProofOfRegistration(media);
			} else if (request.getBase64ProofOfRegistrationName().contains(".pdf")) {

				Media media = attributeMediaUploadHelper.setMediaWithFileName(
						CommonUtil.getFolderStructure(vendor.getId(), Constants.PROOF_OF_DOCUMENT_REGISTRATION),
						vendor.getProofOfRegistration(), request.getBase64ProofOfRegistration(), fileName,
						MediaTypeEnum.DOCUMENT);
				vendor.setProofOfRegistration(media);
			}
			else {
				throw new BusinessException(
						"Please upload pdf /png / jpg / jpeg formated file only.");
			}

		}
		if (company != null) {
			companyService.save(company);
		}
		return vendor;
	}

	public Vendor uploadProofOfIdentityAndRegistration(ProofIdentityRegistrationReq request) {

		Vendor vendor = vendorService.findById(request.getId());

		if (!ObjectUtils.isEmpty(request.getBase64proofOfIdentityName())) {
			
			int indexOf = request.getBase64proofOfIdentityName().indexOf(".");
			String fileExtension = request.getBase64proofOfIdentityName().substring(indexOf).toLowerCase();
			String fileName = request.getBase64proofOfIdentityName().substring(0, indexOf);
			
			if (fileExtension.contains(".png")
					|| fileExtension.contains(".jpg")
					|| fileExtension.contains(".jpeg")) {

				Media media = attributeMediaUploadHelper.setMediaWithFileName(
						CommonUtil.getFolderStructure(vendor.getId(), Constants.PROOF_OF_DOCUMENT_IDENTITY),
						vendor.getProofOfIdentity(), request.getBase64proofOfIdentity(), fileName, MediaTypeEnum.IMAGE);
				vendor.setProofOfIdentity(media);
			} else if (fileExtension.contains(".pdf")) {

				Media media = attributeMediaUploadHelper.setMediaWithFileName(
						CommonUtil.getFolderStructure(vendor.getId(), Constants.PROOF_OF_DOCUMENT_IDENTITY),
						vendor.getProofOfIdentity(), request.getBase64proofOfIdentity(), fileName,
						MediaTypeEnum.DOCUMENT);
				vendor.setProofOfIdentity(media);
			}
			
			else {
				throw new BusinessException(
						"Please upload pdf /png / jpg / jpeg formated file only.");
			}

		}
		if (!ObjectUtils.isEmpty(request.getBase64proofOfRegistrationName())) {
			int indexOf = request.getBase64proofOfRegistrationName().indexOf(".");
			String fileExtension = request.getBase64proofOfRegistrationName().substring(indexOf).toLowerCase();
			String fileName = request.getBase64proofOfRegistrationName().substring(0, indexOf);
			
			if (fileExtension.contains(".png")
					|| fileExtension.contains(".jpg")
					|| fileExtension.contains(".jpeg")) {

				Media media = attributeMediaUploadHelper.setMediaWithFileName(
						CommonUtil.getFolderStructure(vendor.getId(), Constants.PROOF_OF_DOCUMENT_REGISTRATION),
						vendor.getProofOfRegistration(), request.getBase64proofOfRegistration(), fileName,
						MediaTypeEnum.IMAGE);
				vendor.setProofOfRegistration(media);
			} else if (fileExtension.contains(".pdf")) {

				Media media = attributeMediaUploadHelper.setMediaWithFileName(
						CommonUtil.getFolderStructure(vendor.getId(), Constants.PROOF_OF_DOCUMENT_REGISTRATION),
						vendor.getProofOfRegistration(), request.getBase64proofOfRegistration(), fileName,
						MediaTypeEnum.DOCUMENT);
				vendor.setProofOfRegistration(media);
			}
			else {
				throw new BusinessException(
						"Please upload pdf /png / jpg / jpeg formated file only.");
			}

		}

		return vendor;
	}

	@Override
	public List<VendorListResponse> getListResponse(List<Vendor> vendors) {
		List<VendorListResponse> vendorListResponses = new ArrayList<>();
		vendors.forEach(vendor -> {
			vendorListResponses.add(VendorListResponse.builder().id(vendor.getId()).agencyName(vendor.getAgencyName())
					.website(vendor.getWebsite()).incorparationDate(vendor.getIncorparationDate())
					.teamStrength(vendor.getTeamStrength()).gstNumber(vendor.getGstNumber())
					.firstName(vendor.getUser() != null && vendor.getUser().getFirstName() != null
							? vendor.getUser().getFirstName()
							: null)
					.lastName(vendor.getUser() != null && vendor.getUser().getLastName() != null
							? vendor.getUser().getLastName()
							: null)
					.user(vendor.getUser() != null ? vendor.getUser().getId() : null).active(vendor.getActive())
					.directorName(vendor.getDirectorName()).location(vendor.getLocation())
					.status(vendor.getStatusEnum()).emailId(vendor.getUser().getEmailId())
					.mobile(vendor.getUser().getMobile())
					.userCountryCode(vendor.getUser().getPhoneCode() !=null ?vendor.getUser().getPhoneCode().getName().replaceAll(Constants.REMOVE_COUNTRY_NAME_FROM_PHONE_CODE, ""):"")
					.createdOn(vendor.getCreatedOn())
					.companyPrimaryNumber(vendor.getCompanyPrimaryNumber())
					.companyPrimaryEmail(vendor.getCompanyPrimaryEmail())
					.companyDescription(vendor.getCompanyDescription()).build());
		});
		return vendorListResponses;
	}

	@Override
	public Object getDetailResponse(Vendor entity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public VendorResponse getDetailForAdminResponse(Vendor vendor) {
		VendorResponse vendorResponse = new VendorResponse();
		vendorResponse.setId(vendor.getId());
		vendorResponse.setAgencyName(vendor.getAgencyName());
		vendorResponse.setWebsite(vendor.getWebsite());
		vendorResponse.setGstNumber(vendor.getGstNumber());
		vendorResponse.setIncorparationDate(vendor.getIncorparationDate());
		vendorResponse.setTeamStrength(vendor.getTeamStrength());
		vendorResponse.setStatus(vendor.getStatusEnum());
		vendorResponse.setLocation(vendor.getLocation());
		vendorResponse.setDirectorName(vendor.getDirectorName());

		vendorResponse.setProfilePhotoPath(vendor.getVendorLogo() != null ? vendor.getVendorLogo().getPath() : null);

		vendorResponse.setBase64MediaString(vendor.getVendorLogo() != null
				? fileUpload.generatePresignedURL(vendor.getVendorLogo().getPath())
				: null);
		if (vendor.getProofOfIdentity() != null) {
			if (vendor.getProofOfIdentity().getMediaType() == MediaTypeEnum.IMAGE) {

				vendorResponse.setBase64MediaProofOfIdentity(fileUpload
						.generatePresignedURL(vendor.getProofOfIdentity().getPath()));
			} else if (vendor.getProofOfIdentity().getMediaType() == MediaTypeEnum.DOCUMENT) {

				vendorResponse.setBase64MediaProofOfIdentity(awsS3Url + vendor.getProofOfIdentity().getPath());
			}
		}
		if (vendor.getProofOfRegistration() != null) {
			if (vendor.getProofOfRegistration().getMediaType() == MediaTypeEnum.IMAGE) {

				vendorResponse.setBase64MediaProofOfRegistration(fileUpload
						.generatePresignedURL(vendor.getProofOfRegistration().getPath()));
			} else if (vendor.getProofOfRegistration().getMediaType() == MediaTypeEnum.DOCUMENT) {

				vendorResponse.setBase64MediaProofOfRegistration(awsS3Url + vendor.getProofOfRegistration().getPath());
			}
		}
		vendorResponse.setCompanyPrimaryNumber(vendor.getCompanyPrimaryNumber());
		vendorResponse.setCompanyPrimaryEmail(vendor.getCompanyPrimaryEmail());
		vendorResponse.setCompanyDescription(vendor.getCompanyDescription());
		return vendorResponse;
	}

	public UserVendorResponse registrationDetails(Long userId) {
		Vendor vendor = vendorService.findByUserId(userId);
		User user = vendor.getUser();

		UserVendorResponse userVendorResponse = new UserVendorResponse();
		userVendorResponse.setFirstName(user.getFirstName());
		userVendorResponse.setLastName(user.getLastName());
		userVendorResponse.setEmailId(user.getEmailId());
		userVendorResponse.setStatus(vendor.getStatusEnum());
		userVendorResponse.setMobile(user.getMobile());
		userVendorResponse.setAgencyName(vendor.getAgencyName());
		userVendorResponse.setIncorparationDate(vendor.getIncorparationDate());
		userVendorResponse.setWebsite(vendor.getWebsite());
		userVendorResponse.setGstNumber(vendor.getGstNumber());
		userVendorResponse.setDirectorName(vendor.getDirectorName());
		userVendorResponse.setPhoneCodeId(user.getPhoneCode() != null ? user.getPhoneCode().getId() : null);
		userVendorResponse.setBase64MediaString(vendor.getVendorLogo() != null
				? fileUpload.generatePresignedURL(vendor.getVendorLogo().getPath())
				: null);
		userVendorResponse
				.setProfilePhotoPath(vendor.getVendorLogo() != null ? vendor.getVendorLogo().getPath() : null);
		userVendorResponse.setPhoneCodeName(user.getPhoneCode() != null ? user.getPhoneCode().getName().replaceAll(Constants.REMOVE_COUNTRY_NAME_FROM_PHONE_CODE, "") : null);
		userVendorResponse.setLocation(vendor.getLocation());
		userVendorResponse.setTeamStrength(vendor.getTeamStrength());
		userVendorResponse.setVendorId(vendor.getId());
		userVendorResponse.setAbout(vendor.getAbout());
		userVendorResponse.setCreatedOn(vendor.getCreatedOn());
		userVendorResponse.setReason(vendor.getReason());
		userVendorResponse.setCompanyPrimaryEmail(vendor.getCompanyPrimaryEmail()!=null?vendor.getCompanyPrimaryEmail():null);
		userVendorResponse.setCompanyPrimaryNumber(vendor.getCompanyPrimaryNumber()!=null?vendor.getCompanyPrimaryNumber():null);
		userVendorResponse.setCompanyDescription(vendor.getCompanyDescription()!=null?vendor.getCompanyDescription():null);
		userVendorResponse.setTimeZone(user.getTimeZone() != null
				? new TimeZomeDropdown(user.getTimeZone(), user.getTimeZone().getDisplayName())
				: null);

		userVendorResponse.setCountryCodeId(vendor.getCountryCode()!=null?vendor.getCountryCode().getId():null);
		userVendorResponse.setCountryCodeName(vendor.getCountryCode()!=null?vendor.getCountryCode().getName().replaceAll(Constants.REMOVE_COUNTRY_NAME_FROM_PHONE_CODE , ""):null);
		userVendorResponse.setTagline(vendor.getTagline()!=null?vendor.getTagline():null);
		userVendorResponse.setCountryName(vendor.getCountryCode()!=null?vendor.getCountryCode().getName():null);
		return userVendorResponse;
	}

	public ProofIdentityRegistrationResponse getProofOfIdentityAndRegistration(Long userId) {
		Vendor vendor = vendorService.findByUserId(userId);

		ProofIdentityRegistrationResponse userVendorResponse = new ProofIdentityRegistrationResponse();
		if (vendor.getProofOfIdentity() != null) {
			if (vendor.getProofOfIdentity().getMediaType() == MediaTypeEnum.IMAGE) {

				userVendorResponse.setBase64proofOfIdentity(getByteArrayFromImageURL(fileUpload
						.generatePresignedURL(vendor.getProofOfIdentity().getPath())));
			} else if (vendor.getProofOfIdentity().getMediaType() == MediaTypeEnum.DOCUMENT) {

				userVendorResponse.setBase64proofOfIdentity(awsS3Url + vendor.getProofOfIdentity().getPath());
			}
			userVendorResponse.setBase64proofOfIdentityPath(vendor.getProofOfIdentity().getPath());

		}

		if (vendor.getProofOfRegistration() != null) {
			if (vendor.getProofOfRegistration().getMediaType() == MediaTypeEnum.IMAGE) {

				userVendorResponse.setBase64proofOfRegistration(getByteArrayFromImageURL(fileUpload
						.generatePresignedURL(vendor.getProofOfRegistration().getPath())));
			} else if (vendor.getProofOfRegistration().getMediaType() == MediaTypeEnum.DOCUMENT) {

				userVendorResponse.setBase64proofOfRegistration(awsS3Url + vendor.getProofOfRegistration().getPath());
			}

			userVendorResponse.setBase64proofOfRegistrationPath(vendor.getProofOfRegistration().getPath());

		}
		return userVendorResponse;
	}

	public static String getByteArrayFromImageURL(String url) {

		try {
			URL imageUrl = new URL(url);
			URLConnection ucon = imageUrl.openConnection();
			InputStream is = ucon.getInputStream();
			byte[] buffer = IOUtils.toByteArray(is);
			return Constants.BASE64.concat(Base64.getEncoder().encodeToString(buffer));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * 
	 * @param vendorRequest
	 * @return set vendor portfolio
	 * @throws Exception
	 */
	public Vendor setUploadPortfolio(VendorRequest vendorRequest) {
		try {
			Vendor vendor;
			if (CommonUtil.isValid(vendorRequest.getId())) {
				vendor = vendorService.findById(vendorRequest.getId());
			} else {
				throw new Exception("Vendor not found");
			}
			vendor.setIncorparationDate(vendorRequest.getIncorparationDate());
			List<VendorPortfolio> portfolios = new ArrayList<>();
			if (CommonUtil.isEmpty(vendorRequest.getPortfolioRequests())) {
				return null;
			}
			vendorRequest.getPortfolioRequests().forEach(portfolioRequest -> {

				VendorPortfolio portfolio;

				if (CommonUtil.isValid(portfolioRequest.getId())) {
					portfolio = portfolioService.findById(portfolioRequest.getId());
				} else {
					portfolio = new VendorPortfolio();
				}
				portfolio.setVendor(entityUtil.getCurrentVendorId());
				if (!ObjectUtils.isEmpty(portfolioRequest.getBase64Portfolio()) && vendor.getId() != null) {
					if (portfolioRequest.getBase64PortfolioName().contains(".png")
							|| portfolioRequest.getBase64PortfolioName().contains(".jpg")
							|| portfolioRequest.getBase64PortfolioName().contains(".jpeg")) {

						Media media = attributeMediaUploadHelper.setMedia(
								CommonUtil.getFolderStructure(vendor.getId(), "portfolio"), portfolio.getMedia(),
								portfolioRequest.getBase64Portfolio(), MediaTypeEnum.IMAGE);
						portfolio.setMedia(media);
					} else if (portfolioRequest.getBase64PortfolioName().contains(".pdf")
							|| portfolioRequest.getBase64PortfolioName().contains(".pptx")
							|| portfolioRequest.getBase64PortfolioName().contains(".ppt")) {

						int indexOf = portfolioRequest.getBase64PortfolioName().indexOf(".");
						String resumeName = portfolioRequest.getBase64PortfolioName().substring(0, indexOf)
								.replaceAll("[^a-zA-Z0-9.' ']", "");
						log.info("resumeName : {} ", resumeName);
						Media media = attributeMediaUploadHelper.setMediaWithFileName(
								CommonUtil.getFolderStructure(vendor.getId(), Constants.PORTFOLIO),
								portfolio.getMedia(), portfolioRequest.getBase64Portfolio(), resumeName,
								MediaTypeEnum.DOCUMENT);
						portfolio.setMedia(media);
					} else {
						throw new BusinessException(
								"Please upload pdf / pptx / ppt / png / jpg / jpeg formated file only.");
					}
					portfolioService.save(portfolio);
				}
				List<Long> deletePortfolio = portfolioRequest.getDeletePortfolio();
				portfolioService.deleteByInId(deletePortfolio);
				portfolios.add(portfolio);

			});
			return vendor;
		} catch (Exception e) {
			log.error("BusinessException in saveEvent :{}", ExceptionUtils.getStackTrace(e));
			throw new BusinessException(e.getMessage());
		}

	}

	/**
	 * 
	 * @param vendorId
	 * @return get vendor portfolio by vendor id
	 */
	public VendorPortfolioResponse getportfolioListByVendorId(Long vendorId) {

		VendorPortfolioResponse vendorPortfolioResponse = new VendorPortfolioResponse();

		Vendor vendor = vendorService.findById(vendorId);

		vendorPortfolioResponse.setId(vendor.getId());

		vendorPortfolioResponse.setPortfolioResponses(getportfolios(vendor.getPortfolios()));

		return vendorPortfolioResponse;
	}

	/**
	 * 
	 * @param vendor
	 * @return get portfolio for particular vendor.
	 */
	private List<PortfolioResponse> getportfolios(List<VendorPortfolio> portfolios) {
		portfolios = portfolioService.findByVendorAndDeletedFalse();

		List<PortfolioResponse> portfolioResponses = new ArrayList<>();

		portfolios.forEach(portfolio -> {
			String[] split = portfolio.getMedia().getPath().split("/");
			portfolioResponses.add(PortfolioResponse.builder()
					.base64Portfolio(portfolio.getMedia() != null ? awsS3Url + portfolio.getMedia().getPath() : null)
					.id(portfolio.getId()).base64PortfolioName(portfolio.getMedia().getPath()
							.substring(portfolio.getMedia().getPath().lastIndexOf("/") + 1))
					.build());
		});

		return portfolioResponses;
	}

	public void updateBanner(BannerRequest request) throws Exception {
		Vendor vendor = vendorService.findById(request.getVendorId());
		if (vendor == null) {
			throw new Exception("Vendor not found for id " + request.getVendorId());
		}
		if (!ObjectUtils.isEmpty(request.getBase64Banner())) {

			Media media = attributeMediaUploadHelper.setMedia(
					CommonUtil.getFolderStructure(request.getVendorId(), "Banner Logo"), vendor.getBanner(),
					request.getBase64Banner(), MediaTypeEnum.IMAGE);
			vendor.setBanner(media);
			vendorService.save(vendor);
		}
	}

	public BannerResponse getBanner(Long id) throws Exception {
		Vendor vendor = vendorService.findById(id);
		if (vendor == null) {
			throw new Exception("Vendor not found for id " + id);
		}
		Media media = vendor.getBanner();
		return new BannerResponse(id, media == null ? null : fileUpload.generatePresignedURL(media.getPath()));
	}
	
	
	public Vendor getVendor(VendorRequest vendorRequest) {
		try {
			Vendor vendor = getEntity(vendorRequest);
			vendor = vendorService.save(vendor);

			if (!ObjectUtils.isEmpty(vendorRequest.getBase64ProofOfRegistrationName())
					&& vendorRequest.getId() == null) {
				if (vendorRequest.getBase64ProofOfRegistrationName().contains(".png")
						|| vendorRequest.getBase64ProofOfRegistrationName().contains(".jpg")
						|| vendorRequest.getBase64ProofOfRegistrationName().contains(".jpeg")) {

					int indexOf = vendorRequest.getBase64ProofOfRegistrationName().indexOf(".");
					String fileName = vendorRequest.getBase64ProofOfRegistrationName().substring(0, indexOf);

					Media media = attributeMediaUploadHelper.setMediaWithFileName(
							CommonUtil.getFolderStructure(vendor.getId(),
									Constants.PROOF_OF_DOCUMENT_REGISTRATION),
							vendor.getProofOfRegistration(), vendorRequest.getBase64ProofOfRegistration(),
							fileName, MediaTypeEnum.IMAGE);
					vendor.setProofOfRegistration(media);
					vendorService.save(vendor);
				} else if (vendorRequest.getBase64ProofOfRegistrationName().contains(".pdf")) {

					int indexOf = vendorRequest.getBase64ProofOfRegistrationName().indexOf(".");
					String fileName = vendorRequest.getBase64ProofOfRegistrationName().substring(0, indexOf);

					Media media = attributeMediaUploadHelper.setMediaWithFileName(
							CommonUtil.getFolderStructure(vendor.getId(),
									Constants.PROOF_OF_DOCUMENT_REGISTRATION),
							vendor.getProofOfRegistration(), vendorRequest.getBase64ProofOfRegistration(),
							fileName, MediaTypeEnum.DOCUMENT);
					vendor.setProofOfRegistration(media);
					vendorService.save(vendor);
				} else {
					throw new BusinessException("Please upload pdf /png / jpg / jpeg formated file only.");
				}

			}
			// upload vendor logo 
			if (!ObjectUtils.isEmpty(vendorRequest.getBase64profilePhoto())) {
				Media media = attributeMediaUploadHelper.setMedia(
						CommonUtil.getFolderStructure(vendor.getId(), "ProfilePhoto"), vendor.getVendorLogo(),
						vendorRequest.getBase64profilePhoto(), MediaTypeEnum.IMAGE);
				vendor.setVendorLogo(media);
				vendor.setDeleted(Boolean.TRUE);
				vendorService.save(vendor);
			}
			if (vendorRequest.getId() == null) {
				String randomString = UUID.randomUUID().toString();
				emailSenderUtil.sendMail(randomString, vendorRequest.getCompanyPrimaryEmail(), Constants.VERIFY_EMAIL,
						Constants.VERIFY_EMAIL_SUBJECT);
				emailSenderUtil.sendMail(vendorRequest.getAgencyName(), Constants.REGISTRATION_MESSAGE,
						vendorRequest.getCompanyPrimaryEmail(), Constants.WITHOUT_URL, Constants.REGISTRATION_SUBJECT);

				emailSenderUtil.sendMail(Constants.ADMIN_NAME,
						vendorRequest.getAgencyName() + Constants.ADMIN_MESSAGE_VENDOR_CREATE,
						staticConfigurationService.findByName(StaticConfigurationEnum.NOTIFICATION_EMAIL).getValue(),
						Constants.ADMIN_MAIL_TEMPLATE, Constants.ADMIN_VENDOR_VERIFY_SUBJECT);

				verifyEmailService.save(VerifyEmail.builder().randomNumber(randomString).vendor(vendor)
						.statusEnum(StatusEnum.EMAIL_PENDING).build());
			}
			return vendor;
		} catch (Exception e) {
			e.printStackTrace();
			log.error(e.getMessage(), e);
		throw new RuntimeException(e.getMessage());
		}
	}
	
}
