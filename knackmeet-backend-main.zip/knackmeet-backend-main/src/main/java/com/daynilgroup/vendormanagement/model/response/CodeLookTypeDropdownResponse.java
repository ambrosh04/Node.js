package com.daynilgroup.vendormanagement.model.response;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Value;

@Value
public class CodeLookTypeDropdownResponse  implements Serializable {
	
	static final long serialVersionUID = 1L;

	@JsonProperty(value = "value")
	Object id;

	@JsonProperty(value = "label")
	String name;
	
	@JsonProperty(value="hasImage")
	Boolean coverImgRequire;
}
