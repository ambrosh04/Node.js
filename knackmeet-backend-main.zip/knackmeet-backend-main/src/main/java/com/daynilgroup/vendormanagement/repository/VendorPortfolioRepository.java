package com.daynilgroup.vendormanagement.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.daynilgroup.vendormanagement.entity.VendorPortfolio;

@Repository
public interface VendorPortfolioRepository extends JpaRepository<VendorPortfolio, Long> {

	List<VendorPortfolio> findByVendorAndDeletedFalse(Long vendorId);

	@Modifying
	@Transactional
	@Query("update VendorPortfolio p set p.deleted=true where p.id in :porfolioId")
	void softDeleteByInId(@Param("porfolioId") List<Long> porfolioId);

}
