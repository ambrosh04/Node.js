/**
 * 
 */
package com.daynilgroup.vendormanagement.entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * @author Prerana
 *
 */
@Entity
@Table(name = "skills_code_lookup")
@NoArgsConstructor
@Getter
@Setter
public class SkillsCodeLookup extends BaseEntity {

	static final long serialVersionUID = 1L;

	@JoinColumn(name = "job_id",nullable = false)
	@ManyToOne(optional = false)
	Job job;

	@JoinColumn(name = "codeLookup_id", referencedColumnName = "id", nullable = false)
	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	CodeLookup codeLookup;
}
