package com.daynilgroup.vendormanagement.model.request;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@Getter
@Setter
@FieldDefaults(level = AccessLevel.PRIVATE)
public class SupportRequest {
	static final long serialVersionUID = 1L;

	Long id;

	String heading;

	String description;

	String base64attachment;

	String base64attachmentName;
}
