/**
 * 
 */
package com.daynilgroup.vendormanagement.constants;

/**
 * @author Manish
 *
 */
public class UrlConstants {

	// Common
	public static final String API_CREATE = "/create";

	public static final String UPDATE = "/update";

	public static final String API_FIND_BY_ID = "/findById/{id}";
	public static final String VERIFY_STATUS = "/verify/status";
	public static final String FORGET_PASSWORD = "/forget-password";
	public static final String LIST = "/list";
	public static final String DELETE_BY_ID = "/{id}";
	public static final String DETAIL_BY_ID = "/detailById/{id}";
	public static final String UPDATE_STATUS = "/update/status";
	public static final String FILTER_LIST = "/filter/list";
	public static final String SEARCH_BY_NAME = "/search/byName";
	public static final String VERIFY_RESOURCE = "/verify";
	public static final String UPDATE_STATUS_ON_HOLD = "/update/status/on-hold";

	// codeLookup
	public static final String CODELOOKUP_BASE_URL = "/rest/codeLookup";
	public static final String FIND_BY_TYPE_CODE = "/findByTypeCode";

	// codeLookupType
	public static final String CODELOOKUPTYPE_BASE_URL = "/rest/codeLookupType";

	// address
	public static final String ADDRESS_BASE_URL = "/rest/address";

	// user
	public static final String PUBLIC_USER_BASE_URL = "/public/user";
	public static final String USER_BASE_URL = "/rest/user";
	public static final String USER_RESET_PASSWORD = "/reset-password";
	public static final String UPDATE_PAGE_SIZE="/update-page-size";

	// vendor
	public static final String VENDOR_BASE_URL = "/rest/vendor";
	public static final String VENDOR_DETAILS = "/details";
	public static final String REGISTRATION_DETAILS = "/detail/{userId}";
	public static final String PROOF_OF_IDENTITY_AND_REGISTRATION = "/proof/identity-registration";
	public static final String PROOF_OF_IDENTITY_AND_REGISTRATION_DETAILS = "/detail/proof/identity-registration/{userId}";

	// Vendor Portfolio
	public static final String UPLOAD_PORTFOLIO = "/upload-portfolio";
	public static final String PORTFOLIO_LIST_VENDOR_ID = "/portfolio-list/{vendorId}";
	public static final String DELETE_VENDOR_PORTFOLIO_ID = "delete-portfolio/{id}";

	// resource
	public static final String RESOURCE_BASE_URL = "/rest/resource";
	public static final String RESOURCE_STATUS_COUNT = "/count/by-status";
	public static final String DESCRIPTION = "/description";
	public static final String SEARCH = "/search";
	public static final String JOB_SEARCH = "/list/job-search";
	public static final String ELIGIBLE_APPLICANT_LIST = "/applicant/list";

	// admin-resource
	public static final String ADMIN_RESOURCE_BASE_URL = "/rest/admin/resource";
	public static final String RESOURCE_VERIFICATION_COUNT = "/all-count";

	// job
	public static final String JOB_BASE_URL = "/rest/job";
	public static final String JOB_STATUS_COUNT = "/count/by-status";
	public static final String LIST_BY_VENDOR_ID = "/list/By-VendorId";
	public static final String JOB_DETAIL_BY_ID = "/detailById/{id}";
	public static final String JOB_LIST_NOTIFICATION = "/list/notification";

	// admin-job
	public static final String ADMIN_JOB_BASE_URL = "/rest/admin/job";

	public static final String JOB_VERIFICATION_COUNT = "/all-count";

	// ResourceJobs
	public static final String RESOURCE_JOBS_BASE_URL = "/rest/resource-jobs";
	public static final String RESOURCE_FILTER_LIST_BY_JOB_ID = "/resources/filter/list";
	public static final String JOBS_FILTER_LIST_BY_RESOURCE_ID = "/jobs/filter/list";

	public static final String RESOURCE_APPLICATION_LIST = "/application/list";
	public static final String RESOURCE_APPLICATION_COUNT = "/resource/count";
	public static final String RESOURCE_JOB_COUNT = "/job/count";
	public static final String RESOURCE_STATUS_COUNT_BY_JOB_ID = "/resource/count/{id}";
	public static final String RESOURCE_STATUS_COUNT_BY_RESOURCE_ID = "/jobs/Count/{id}";

	public static final String JOBS_ALL_LIST_BY_VENDOR_ID = "job/list/{vendorId}";
	public static final String RESOURCE_JOB_BY_STATUS = "/job/status/list";

	public static final String UNDER_CRITERIA_MATCHING_JOB_RESOURCE = "/matching/job-resource/under/criteria";
	public static final String INVITE = "/invite";
	public static final String MATCHING_JOB_RESOURCE = "/matching/job-resource";
	public static final String INVITATION_SENT_COUNT = "/invitation-sent/count";
	public static final String INVITATION_RECEIVED_COUNT = "/invitation-received/count";

	// dashboard
	public static final String DASHBOARD_BASE_URL = "/rest/vendor/dashboard";
	public static final String COUNT = "/count";
	public static final String JOBS_LIST = "/jobs/list";
	public static final String NOTIFICATION = "/notification";

	// vendor dropdown
	public static final String DROP_DOWN_BASE_URL = "/rest/dropdown";
	public static final String PUBLIC_DROP_DOWN_BASE_URL = "/public/dropdown";
	public static final String GENDER = "/gender";
	public static final String CURRENCY = "/currency";
	public static final String RATE_TYPE = "/rate-type";
	public static final String RESOURCE_STATUS = "/resource-status";
	public static final String DEPLOYMENT = "/deployment";
	public static final String JOB_TYPE = "/job-type";
	public static final String ADVANCE_SEARCH = "/advance-search";
	public static final String CODE_LOOK_TYPE = "/codeLookUpType";
	public static final String ADDRESS = "/address";
	public static final String STATUS = "/Status";
	public static final String RESOURCE_SEARCH_IN = "/resource-search-in";
	public static final String SKILLS_DESIGNATION = "/skills-designation";
	public static final String JOB_ADVANCED_SEARCH = "/job-advanced-search";
	public static final String CODE_LOOKUP_BY_CODE_AND_PARENT_ID = "/findByTypeCodeAndParentId";
	public static final String SEARCH_TYPE = "/search-type";
	public static final String JOB_TITLE_DROPW_DOWN = "/getJobTitleDropDown";
	public static final String COUNTRY_STATE_DROP_DOWN = "/country-state";

	// public url
	public static final String PUBLIC_BASE_URL = "/public";
	public static final String PUBLIC_VENDOR_URL = "/vendor";
	public static final String FORGOT_PASSWORD = "/forgotPassword";
	public static final String VERIFY_TOKEN = "/token/password";
	public static final String VERIFY_EMAIL = "/verify-email";
	
	public static final String JOB_POST_AND_VENDOR_REGISTRATION = "/jobPost-vendorRegistration";

	public static final String EXIST_BY_USER_MOBILE_NUMBER_AND_VENDOR_COMPANY_PRIMARY_NUMBER ="/exist-by-user-mobileNo-And-vondor-companyPrimaryNo";

	public static final String EXIST_BY_USER_EMAIL_AND_VENDOR_COMPANY_PRIMARY_EMAIL ="/exist-by-user-emailId-And-companyEmailId";

	// admin dashboard
	public static final String ADMIN_DASHBOARD_BASE_URL = "/rest/admin/dashboard";
	public static final String ADMIN_DASHBOARD_COUNT = "/count";

	// Advance Search
	public static final String ADVANCE_SEARCH_BASE_URL = "/rest/advanceSearch";

	// Role
	public static final String ROLE_BASE_URL = "/rest/role";

	// menu
	public static final String MENU_BASE_URL = "/rest/menu";

	// resource advance search
	public static final String RESOURCE_ADVANCED_SEARCH = "/resource-advanced-search";

	public static final String SEARCH_HISTORY_BASE_URL = "/rest/search/history";
	public static final String RECENT_SEARCH = "/recent";
	public static final String RECENT_SEARCH_FOR_HIRE_DEVELOPER = "/recent/hire/developer";
	public static final String RECENT_SEARCH_FOR_JOB_PROJECT = "/recent/job/project";

	// support
	public static final String SUPPORT_BASE_URL = "/rest/support";

	// notification
	public static final String NOTIFICATION_BASE_URL = "/rest/notification";
	public static final String ALL_NOTIFICATIONS = "/all";

	public static final String COUNT_NOTIFICATION = "/count";

	public static final String INVITATIONS_RECIVED = "/invitations-recived";

	public static final String INVITATIONS_SEND = "/invitations-send";

	public static final String UPDATE_INVITATION_STATUS = "/update/invitation/status";
	

	public static final String INVITATION_STATUS = "/invitationStatusByJobIdAndResourceId/{jobId}/{resourceId}";
	
	public static final String VERIFY_JOB = "/verify";
	
	public static final String RESOURCE_ALL_LIST_BY_VENDOR_ID = "resource/list/{vendorId}";

	public static final String EMPLOYMENT_TYPE = "/employee-type";

	public static final String TYPE_CODE = "/getByTypeCode";
	
	public static final String REJECT_VENDOR_STATUS = "/reject/status";

	public static final String STATIC_CONFIGURATION_BASE_URL = "/rest/static-configuaration";

	public static final String GET_SKILLS = "/get-skills-by-resource-id/{resourceId}";
	
	public static final String UPDATE_PERSIONAL_DETAIL = "/update-persional-detail";
	
	public static final String UPDATE_SKILLS = "/update-skills";
	
	public static final String EDUCATION_BASE_URL = "/rest/education";
	
	public static final String EXPERIENCE_BASE_URL = "/rest/experience";
	
	public static final String DELETE = "/delete/{id}";

	public static final String EXIST_BY_MOBILE_NUMBER = "/existByMobileNo";
	
	public static final String EXIST_BY_EMAIL_ID = "/existByEmailId";
	
	public static final String JOBS_BY_RESOURCE_CURRENCY="jobs-by-resource-currency";
	
	public static final String DEPLOYMENT_TYPE = "/deployment-type";
	
	public static final String RATE_WITH_COMMISSION = "/rate-with-commission/{rate}";

	public static final String REGISTRATION_ENQUIRY_BASE_URL = "/rest/registration-enquiry";

	public static final String REGISTRATION_ENQUIRY = "/registration-enquiry";

	public static final String DROPDOWN_TIMEZONE = "/dropdown-timezone";
	
	public static final String ADMIN_SEND_MAIL_VERIFIED_JOB_DETAILS = "/detail-send-mail";
	
	public static final String JOB_DETAILS = "/job-details";
	
	public static final String VENDOR_COUNT = "/all-vendor-count";

	public static final String EXIST_BY_COMPANY_EMAIL_ID = "/existByCompanyEmailId";

	public static final String EXIST_BY_COMPANY_PRIMARY_NUMBER = "/existByCompanyPrimaryNo";

	public static final String JOB_CLOSE_REASON = "/job-close-reason";
	
	public static final String UPDATE_PERSONAL_DETAIL = "/update-personal-details";

	public static final String UPDATE_OTHER_DETAIL = "/update-other-details";

	public static final String REF_TYPE = "/ref-type";

	public static final String CODE_LOOK_UP_RELATION_TYPE = "/codeLookUp-relation-type";
	
	public static final String MATCHING_RESOURCE = "/matching-resource";
	
	public static final String CODELOOKUPRELATION_BASE_URL= "/rest/CodeLookUpRelation";
	
	public static final String SUBSCRIBED_USERS_BASE_URL = "/public/user-subscription";

	public static final String ADMIN_SUBSCRIBED_USERS_BASE_URL = "/rest/admin/user-subscription";

	public static final String COMPANY_BASE_URL = "/rest/company";

	public static final String JOB_LIST = "/job-list";

	public static final String RESOURCE_LIST = "/resource-list";
	
    public static final String SUBSCRIBE_EMAIL_NOTIFICATION = "/subscribe-email-notification";
	
	public static final String SUBSCRIBE_EMAIL_NOTIFICATION_TYPE_CODE = "/findByTypeCode";
	
	public static final String UPDATE_DESCRIPTION = "/update-description";
	
	public static final String UPDATE_BANNER = "/update/banner";

	public static final String GET_BANNER = "/get/banner";
	
	public static final String Excel_Export = "/excel-export";
	
	public static final String EXIST_BY_COMPANY_NAME = "/existByCompanyName";
	
	public static final String COMPANY_LIST = "/company-list";
	
	public static final String EMAIL_BASE_URL = "/rest/email/log";

}