package com.daynilgroup.vendormanagement.model.request;

import java.util.List;

import lombok.AccessLevel;
import lombok.Data;
import lombok.experimental.FieldDefaults;

@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
public class ResourceJobsRequest {

	List<Long> resourceIds;
	
	List<RemoveResourceRequest> removedResources;

	Long jobsId;
	

}
