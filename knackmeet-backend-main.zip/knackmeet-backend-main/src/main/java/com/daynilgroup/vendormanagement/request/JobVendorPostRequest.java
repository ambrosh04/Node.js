package com.daynilgroup.vendormanagement.request;

import java.io.Serializable;

import com.daynilgroup.vendormanagement.model.request.JobRequest;
import com.daynilgroup.vendormanagement.model.request.VendorRequest;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.FieldDefaults;

@Getter
@Setter
@FieldDefaults(level = AccessLevel.PRIVATE)
@ToString
public class JobVendorPostRequest implements Serializable{
	 
	private static final long serialVersionUID = 1L;
	
	VendorRequest vendorRequest;
	
	JobRequest jobRequest;
	
	
	
}
