package com.daynilgroup.vendormanagement.rest.controller.inf.embedded;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.daynilgroup.vendormanagement.constants.UrlConstants;
import com.daynilgroup.vendormanagement.entity.BaseEntity;
import com.daynilgroup.vendormanagement.exception.DeleteRestException;

import io.swagger.annotations.ApiOperation;
/**
 * @author Prerana
 *
 */
public interface DeleteByIdRestInf extends BaseRestInf {

	@DeleteMapping(path = UrlConstants.DELETE_BY_ID)
	@ApiOperation(value = "Delete the record based on id")
	default ResponseEntity<Object> deleteById(@PathVariable Long id) {
		try {
			Object entity = getService().findById(id);
			entity = getService().softDelete(entity);
			return new ResponseEntity<>(((BaseEntity) entity).getDeleted(),HttpStatus.OK);
		} catch (Exception e) {
			BASE_LOGGER.error(e.getMessage(), e);
			return new ResponseEntity<>(new DeleteRestException(e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}