package com.daynilgroup.vendormanagement.helper;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.ObjectUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.daynilgroup.vendormanagement.entity.Address;
import com.daynilgroup.vendormanagement.entity.CodeLookup;
import com.daynilgroup.vendormanagement.entity.CodeLookupType;
import com.daynilgroup.vendormanagement.model.request.AddressRequest;
import com.daynilgroup.vendormanagement.model.response.AddressAdminDetailResponse;
import com.daynilgroup.vendormanagement.model.response.AddressListResponse;
import com.daynilgroup.vendormanagement.service.AddressService;
import com.daynilgroup.vendormanagement.service.CodeLookupService;
import com.daynilgroup.vendormanagement.service.CodeLookupTypeService;
import com.daynilgroup.vendormanagement.util.CommonUtil;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;

@Component
@FieldDefaults(level = AccessLevel.PRIVATE)
public class AddressHelper
		extends AbstractHelper<Address, AddressRequest, AddressListResponse, Object, AddressAdminDetailResponse> {
	@Autowired
	AddressService addressService;

	@Autowired
	CodeLookupService codeLookupService;

	@Autowired
	CodeLookupTypeService codeLookupTypeService;

	@Override
	public Address getEntity(AddressRequest request) throws Exception {
		Address address = addressService.findByCountryIdAndStateId(request.getCountryId(),
				request.getStateId());

		if (ObjectUtils.isEmpty(address)) {
			CodeLookup state = codeLookupService.findById(request.getStateId());
			address = new Address();
			address.setCountry(codeLookupService.findById(request.getCountryId()));
			address.setState(state);

//			CodeLookup city;
//			if (CommonUtil.isValid(request.getCity().getValue())) {
//				city = codeLookupService.findById(request.getCity().getValue());
//			} else {
//				city = new CodeLookup();
//				city.setActive(true);
//				city.setDescription(request.getCity().getDescription());
//				city.setName(request.getCity().getLabel());
//				city.setParentId(state);
//
//				CodeLookupType codeLookupType = codeLookupTypeService.findByCode("CITY");
//				city.setType(codeLookupType);
//
//				codeLookupService.save(city);
//			}
//
//			address.setCity(city);
		}
		addressService.save(address);
		return address;
	}

	@Override
	public List<AddressListResponse> getListResponse(List<Address> addresses) {
		List<AddressListResponse> addressListResponses = new ArrayList<>();
		addresses.forEach(address -> {
			addressListResponses.add(AddressListResponse.builder().id(address.getId())
					.stateId(address.getState() != null ? address.getState().getId() : null)
					.countryId(address.getCountry() != null ? address.getCountry().getId() : null)
					.cityId(address.getState() != null ? address.getState().getId() : null).build());
		});
		return addressListResponses;
	}

	@Override
	public Object getDetailResponse(Address entity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public AddressAdminDetailResponse getDetailForAdminResponse(Address address) {

		AddressAdminDetailResponse.AddressAdminDetailResponseBuilder builder = AddressAdminDetailResponse.builder()
				.id(address.getId()).stateId(address.getState() != null ? address.getState().getId() : null)
				.countryId(address.getCountry() != null ? address.getCountry().getId() : null)
				.cityId(address.getState() != null ? address.getState().getId() : null);

		return builder.build();
	}

}
