/**
 * 
 */
package com.daynilgroup.vendormanagement.helper;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.daynilgroup.vendormanagement.entity.CodeLookup;
import com.daynilgroup.vendormanagement.model.request.CreateCodeLookupRequest;
import com.daynilgroup.vendormanagement.model.response.CodeLookupDetailAdminResponse;
import com.daynilgroup.vendormanagement.model.response.CodeLookupDetailResponse;
import com.daynilgroup.vendormanagement.model.response.CodeLookupListResponse;
import com.daynilgroup.vendormanagement.service.CodeLookupService;
import com.daynilgroup.vendormanagement.service.CodeLookupTypeService;
import com.daynilgroup.vendormanagement.util.CommonUtil;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;

/**
 * @author Prerana
 *
 */
@Component
@FieldDefaults(level = AccessLevel.PRIVATE)
public class CodeLookupHelper extends AbstractHelper<CodeLookup, CreateCodeLookupRequest,CodeLookupListResponse, CodeLookupDetailResponse, CodeLookupDetailAdminResponse>{

	@Autowired
	CodeLookupService codeLookupService;
	
	@Autowired
	CodeLookupTypeService codeLookupTypeService;
	
	@Override
	public CodeLookup getEntity(CreateCodeLookupRequest codeLookupRequest) throws Exception {
        CodeLookup codeLookup;
        if (CommonUtil.isValid(codeLookupRequest.getId())) {
            codeLookup = codeLookupService.findById(codeLookupRequest.getId());
            if (codeLookupService.existsByNameAndTypeIdAndIdNot(codeLookupRequest.getName(), codeLookupRequest.getTypeId(), codeLookupRequest.getId())) {
                throw new Exception("Sorry..!, This record already exist. ");
            }
        } else {
            codeLookup = new CodeLookup();
            if (codeLookupService.existsByNameAndTypeIdAndIdNot(codeLookupRequest.getName(), codeLookupRequest.getTypeId(), null)) {
                throw new Exception("Sorry..!, This record already exist. ");
            }
        }
        codeLookup.setName(codeLookupRequest.getName());
        codeLookup.setDescription(codeLookupRequest.getDescription());
        codeLookup.setStatusEnum(codeLookupRequest.getStatus());
        codeLookup.setActive(codeLookupRequest.getActive());
        codeLookup.setDisplayOrder(codeLookupRequest.getDisplayOrder());
        if (CommonUtil.isValid(codeLookupRequest.getParentId())) {
            CodeLookup parentCodeLookup = codeLookupService.findById(codeLookupRequest.getParentId());
            if (parentCodeLookup != null) {
                codeLookup.setParentId(parentCodeLookup);
            }
        }
        if (codeLookupRequest.getTypeId() != null) {
            codeLookup.setType(codeLookupTypeService.findById(codeLookupRequest.getTypeId()));
        }
        return codeLookup;
	}

	@Override
	public List<CodeLookupListResponse> getListResponse(List<CodeLookup> entityList) {
		List<CodeLookupListResponse> codeokupListResponses = new ArrayList<>();
		entityList.forEach(codeLookup -> {
			codeokupListResponses.add(CodeLookupListResponse.builder().id(codeLookup.getId()).name(codeLookup.getName())
					.description(codeLookup.getDescription()).active(codeLookup.getActive())
					.typeId(codeLookup.getType() != null ? codeLookup.getType().getId() : null)
					.coverImage(codeLookup.getImageId() != null ? codeLookup.getImageId().getPath() : null)
					.displayOrder(codeLookup.getDisplayOrder())
					.parentId(codeLookup.getParentId() != null ? codeLookup.getParentId().getId() : null)
					.displayOrder(codeLookup.getDisplayOrder())
					.status(codeLookup.getStatusEnum() != null ? codeLookup.getStatusEnum() : null)
					.typeParentName(
							codeLookup.getType().getParentId() != null ? codeLookup.getType().getParentId().getName()
									: "")
					.build());
		});
		return codeokupListResponses;
	}

	@Override
	public CodeLookupDetailResponse getDetailResponse(CodeLookup entity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public CodeLookupDetailAdminResponse getDetailForAdminResponse(CodeLookup codeLookup) {
		return CodeLookupDetailAdminResponse.builder()
				.name(codeLookup.getName())
				.id(codeLookup.getId())
				.description(codeLookup.getDescription())
				.status(codeLookup.getStatusEnum())
				.active(codeLookup.getActive())
				.typeId(codeLookup.getType() != null ? codeLookup.getType().getId() : null)
				.displayOrder(codeLookup.getDisplayOrder())
				.image(codeLookup.getImageId() != null ? codeLookup.getImageId().getPath() : null)
				.parentId(codeLookup.getParentId() != null ? codeLookup.getParentId().getId() : null)
				.build();
	}

	public List<CodeLookupListResponse> getListItemTypeResponse(List<CodeLookup> codeLookupsList) {
		List<CodeLookupListResponse> listCodeLookupResponses = new ArrayList<>();
		codeLookupsList.forEach(codeLookup -> {
			listCodeLookupResponses
					.add(CodeLookupListResponse.builder().id(codeLookup.getId()).name(codeLookup.getName())
							.description(codeLookup.getDescription()).active(codeLookup.getActive())
							.typeId(codeLookup.getType() != null ? codeLookup.getType().getId() : null)
							.type(codeLookup.getType() != null ? codeLookup.getType().getName() : null)
							.coverImage(codeLookup.getImageId() != null ? codeLookup.getImageId().getPath() : null)
							.displayOrder(codeLookup.getDisplayOrder())
							.parentId(codeLookup.getParentId() != null ? codeLookup.getParentId().getId() : null)
							.typeParentName(codeLookup.getType().getParentId() != null
									? codeLookup.getType().getParentId().getName()
									: "")
							.build());
		});
		return listCodeLookupResponses;
	}
}
