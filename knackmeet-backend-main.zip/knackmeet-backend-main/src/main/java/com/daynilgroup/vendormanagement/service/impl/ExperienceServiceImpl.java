package com.daynilgroup.vendormanagement.service.impl;

import java.time.LocalDate;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.daynilgroup.vendormanagement.entity.Experience;
import com.daynilgroup.vendormanagement.entity.Resource;
import com.daynilgroup.vendormanagement.helper.ExperienceHelper;
import com.daynilgroup.vendormanagement.helper.ResourceHelper;
import com.daynilgroup.vendormanagement.repository.ExperienceRepository;
import com.daynilgroup.vendormanagement.request.ExperienceRequest;
import com.daynilgroup.vendormanagement.service.ExperienceService;
import com.daynilgroup.vendormanagement.service.ResourceService;

@Service
public class ExperienceServiceImpl implements ExperienceService {

	@Autowired
	ExperienceRepository experienceRepository;
	
	@Autowired
	ExperienceHelper experienceHelper;
	
	@Autowired
	ResourceService resourceService;
	
	@Override
	public JpaRepository<Experience, Long> getJpaRepository() {
		return experienceRepository;
	}

	@Override
	public void softDeleteByInId(List<Long> deleteExperiences) {
		experienceRepository.softDeleteByInId(deleteExperiences);
		
	}

	@Override
	public List<Experience> findAllByDeleteFalse(Long resourceId) {
		return experienceRepository.findAllByDeleteFalse(resourceId);
	}

	@Override
	public List<Integer> getToYearByDeleteFalse(Long resourceId) {
		return experienceRepository.getToYearByDeleteFalse(resourceId);
	}

	@Override
	public List<Integer> getFromYearByDeleteFalse(Long resourceId) {
		return experienceRepository.getFromYearByDeleteFalse(resourceId);
	}

	@Override
	public void create(ExperienceRequest experienceRequest) throws Exception {
		Experience experience = experienceHelper.getEntity(experienceRequest);
		save(experience);
		resourceService.updateTotalExperience(experience.getResource().getId());
	}

}
