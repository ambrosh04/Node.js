package com.daynilgroup.vendormanagement.helper;

import java.io.InputStream;
import java.math.BigDecimal;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.compare.ComparableUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.daynilgroup.commons.events.enums.EventType;
import com.daynilgroup.commons.events.service.EventService;
import com.daynilgroup.commons.events.util.EventPublisher;
import com.daynilgroup.commons.events.wrapper.EventCreateWrapper;
import com.daynilgroup.vendormanagement.constants.CodeLookUpRelationTypeEnum;
import com.daynilgroup.vendormanagement.constants.Constants;
import com.daynilgroup.vendormanagement.constants.CurrencyTypeEnum;
import com.daynilgroup.vendormanagement.constants.DeploymentTypeEnum;
import com.daynilgroup.vendormanagement.constants.MatchingCriteria;
import com.daynilgroup.vendormanagement.constants.RateTypeEnum;
import com.daynilgroup.vendormanagement.constants.RefTypeEnum;
import com.daynilgroup.vendormanagement.constants.ResourceStatusEnum;
import com.daynilgroup.vendormanagement.constants.StaticConfigurationEnum;
import com.daynilgroup.vendormanagement.entity.Job;
import com.daynilgroup.vendormanagement.entity.Resource;
import com.daynilgroup.vendormanagement.entity.ResourceJobs;
import com.daynilgroup.vendormanagement.entity.ResourceSkillsCodeLookup;
import com.daynilgroup.vendormanagement.entity.SkillsCodeLookup;
import com.daynilgroup.vendormanagement.entity.StaticConfiguration;
import com.daynilgroup.vendormanagement.model.request.CodeLookUpRelationRequest;
import com.daynilgroup.vendormanagement.model.request.MatchingJobResourceUnderCriteriaRequest;
import com.daynilgroup.vendormanagement.model.request.ResourceJobsRequest;
import com.daynilgroup.vendormanagement.model.response.JobResponse;
import com.daynilgroup.vendormanagement.model.response.ResourceApplicationResponse;
import com.daynilgroup.vendormanagement.model.response.ResourceJobCountResponse;
import com.daynilgroup.vendormanagement.model.response.ResourceJobResponse;
import com.daynilgroup.vendormanagement.model.response.ResourceJobsAdminResponse;
import com.daynilgroup.vendormanagement.model.response.ResourceJobsListResponse;
import com.daynilgroup.vendormanagement.model.response.ResourceResponse;
import com.daynilgroup.vendormanagement.repository.VendorRepository;
import com.daynilgroup.vendormanagement.service.CodeLookUpRelationService;
import com.daynilgroup.vendormanagement.service.JobService;
import com.daynilgroup.vendormanagement.service.ResourceJobsService;
import com.daynilgroup.vendormanagement.service.ResourceService;
import com.daynilgroup.vendormanagement.service.StaticConfigurationService;
import com.daynilgroup.vendormanagement.util.CommonUtil;
import com.daynilgroup.vendormanagement.util.EmailSenderUtil;
import com.daynilgroup.vendormanagement.util.EntityUtil;
import com.daynilgroup.vendormanagement.util.FileUpload;
import com.google.gson.Gson;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
@FieldDefaults(level = AccessLevel.PRIVATE)

public class ResourceJobsHelper
		extends AbstractHelper<ResourceJobs, ResourceJobsRequest, Object, Object, ResourceJobsAdminResponse> {

	@Autowired
	ResourceJobsService resourceJobsService;

	@Autowired
	ResourceService resourceService;

	@Autowired
	JobService jobsService;

	@Autowired
	EventPublisher eventPublisher;

	@Autowired
	EventService eventService;

	@Autowired
	EntityUtil entityUtil;

	@Autowired
	FileUpload fileUpload;

	@Autowired
	EmailSenderUtil emailSenderUtil;
	
	@Autowired
	StaticConfigurationService staticConfigurationService;
	
	@Autowired
	CodeLookUpRelationHelper codeLookUpRelationHelper;

	@Value("${aws.s3.url}")
	private String awsS3Url;
	
	@Autowired
	VendorRepository vendorRepository;
	
	@Autowired
	CodeLookUpRelationService codeLookUpRelationService;


	@Override
	public ResourceJobs getEntity(ResourceJobsRequest request) throws Exception {
		return null;
	}

	@Transactional
	public void saveResourceJobs(ResourceJobsRequest request) throws Exception {

		if (!CollectionUtils.isEmpty(request.getRemovedResources())) {
			
			Job job = jobsService.findById(request.getJobsId());
			request.getRemovedResources().stream().forEach(resource -> {
				ResourceJobs resourceJobs = resourceJobsService
						.findByJobIdAndResourceIdAndDeletedFalse(request.getJobsId(), resource.getRemovedResourceId());
				if (!ObjectUtils.isEmpty(resourceJobs)) {
					codeLookUpRelationService.hardDeleteByRefIdAndRefTypeAndType(resourceJobs.getId(),
							RefTypeEnum.RESOURCE_JOBS, CodeLookUpRelationTypeEnum.RESOURCE_JOBS_WITHDROW_REASON);
					CodeLookUpRelationRequest codeLookUpRelationRequests = resource.getCodeLookUpRelationRequests();
					codeLookUpRelationRequests.setRefId(resourceJobs.getId());
					resourceJobs.setCodeLookUpRelation(codeLookUpRelationHelper.setEntity(codeLookUpRelationRequests));
					resourceJobsService.save(resourceJobs);
					resourceJobsService.resourceJobsSoftDelete(request.getJobsId(), resource.getRemovedResourceId());
					notificationForJobAppliedAndWithDrawn(request, job, resource.getRemovedResourceId(),
							resourceService.findById(resource.getRemovedResourceId()), Constants.WITHDRAW_CAPS);
					
					List<String> reasons = new LinkedList<>();
					resourceJobs.getCodeLookUpRelation().forEach(getReason -> {
						String reason = getReason.getCodeLookup().getName();
						reasons.add(reason);
					});
					String convert=String.join(", ", reasons);
					
					emailSenderUtil.sendMail(job.getVendor().getAgencyName(),resourceJobs.getResource().getFirstName() + " " + Constants.JOB_WITHDRAW_MESSAGE + convert,
							Constants.APPLIED_OR_WITHDRAW_URL + request.getJobsId(),
							job.getVendor().getCompanyPrimaryEmail(), Constants.MESSAGE_WITH_URL,
							Constants.WITHDRAW_CAPS);
				}
			});
		}
		if (!CollectionUtils.isEmpty(request.getResourceIds())) {
			Job job = jobsService.findById(request.getJobsId());
			for (Long resourceId : request.getResourceIds()) {

				save(resourceId, request.getJobsId());

				Resource resource = resourceService.findById(resourceId);

				notificationForJobAppliedAndWithDrawn(request, job, resourceId, resource, Constants.APPLIED_CAPS);

				emailSenderUtil.sendMail(job.getVendor().getAgencyName(),
						resource.getFirstName() + " " + Constants.APPLIED_MESSAGE,
						Constants.APPLIED_OR_WITHDRAW_URL+request.getJobsId()+"&status=APPLIED", job.getVendor().getCompanyPrimaryEmail(),
						Constants.MESSAGE_WITH_URL, Constants.APPLIED_CAPS);
				log.info("after sendMail method");
			}
		}
	}

	private void notificationForJobAppliedAndWithDrawn(ResourceJobsRequest request, Job job, Long resourceId,
			Resource resource, String notificationType) {
		try {
			EventCreateWrapper wrapper = new EventCreateWrapper();

			Map<String, Object> jsonDataMap = new HashMap<>();
			jsonDataMap.put(Constants.RESOURCE_SMALL_CASE, resource.getFirstName());
			jsonDataMap.put(Constants.JOB_SMALL_CASE, job.getTitle());

			wrapper.setEventType(EventType.IN_APP);
			wrapper.setJsonData(jsonDataMap);
			wrapper.setMetaData(entityUtil.setMetaDataInNotification(request.getJobsId(), resourceId, job, resource));
			wrapper.setVisibleToAll(false);
			wrapper.setUsersToNotify(Arrays.asList(job.getVendor().getUser().getEmailId()));
			wrapper.setMessageTemplateType(notificationType);
			log.info("wrapper to publish : {}", new Gson().toJson(wrapper));
			eventPublisher.publishEvent(wrapper);
		} catch (Exception e) {
			e.printStackTrace();
			log.error(e.getMessage(), e);
		}
	}

	private void save(Long resourceId, Long jobId) throws Exception {
		if (resourceJobsService.existsByJobIdAndResourceIdAndDeletedFalse(jobId, resourceId)) {
			ResourceJobs existsByJobIdAndResourceId = resourceJobsService.existsByJobIdAndResourceId(jobId, resourceId);
			throw new Exception(existsByJobIdAndResourceId.getResource().getFirstName() + " already "
					+ existsByJobIdAndResourceId.getResourceStatus() + " for this Job");
		} else {
			persistResourceJob(resourceId, jobId, ResourceStatusEnum.APPLIED);
		}
	}

	private void updateDeletedResourceJob(Long resourceId, Long jobId, ResourceStatusEnum resourceStatusEnum) {
		log.info("inside updateDeletedResourceJob with resourceId : {} , jobId : {} , resourceStatusEnum : {}",
				resourceId, jobId, resourceStatusEnum);

		ResourceJobs resourceJobs = resourceJobsService.existsByJobIdAndResourceId(jobId, resourceId);
		resourceJobs.setDeleted(Boolean.FALSE);
		Resource resource = resourceService.findById(resourceId);
		Job job = jobsService.findById(jobId);
		resourceJobs.setResourceStatus(resourceStatusEnum);
		if (resourceStatusEnum == ResourceStatusEnum.APPLIED) {
			resource.setAppliedJobCount(resource.getAppliedJobCount() + 1);
			job.setApplicantsCount(job.getApplicantsCount() + 1);
		}
		resourceJobs.setResourceInrRate(resource.getRate()!=null?CommonUtil.resourceRateWithCommission(resource.getRate(),staticConfigurationService.findByName(StaticConfigurationEnum.RESOURCE_COMMISSION).getValue()):null);
		resourceJobs.setResourceUsdRate(resource.getUsdRate()!=null?CommonUtil.resourceRateWithCommission(resource.getUsdRate(),staticConfigurationService.findByName(StaticConfigurationEnum.RESOURCE_COMMISSION).getValue()):null);
		resourceJobs.setResource(resource);
		resourceJobs.setJob(job);
		resourceJobs.setReasonMessage(null);
		resourceJobsService.save(resourceJobs);
	}

	public void persistResourceJob(Long resourceId, Long jobId, ResourceStatusEnum resourceStatusEnum) throws Exception {
		log.info("inside persistResourceJob with resourceId : {} , jobId : {} , resourceStatusEnum : {}", resourceId,
				jobId, resourceStatusEnum);

		if (resourceJobsService.existsByJobIdAndResourceIdAndDeletedTrue(jobId, resourceId)) {

			updateDeletedResourceJob(resourceId, jobId, resourceStatusEnum);
			ResourceJobs resourceJobs = resourceJobsService.findByJobIdAndResourceIdAndDeletedFalse(jobId, resourceId);
			resourceJobs.setAppliedBy(entityUtil.getCurrentUser());
		}else if(resourceJobsService.existsByJobIdAndResourceIdAndDeleted(jobId, resourceId,Boolean.FALSE))
		{
		throw new Exception("Already Invited");
		}	
		else 
		{
			createResourceJob(resourceId, jobId, resourceStatusEnum);
			ResourceJobs resourceJobs = resourceJobsService.findByJobIdAndResourceIdAndDeletedFalse(jobId, resourceId);
			resourceJobs.setAppliedBy(entityUtil.getCurrentUser());
		}
	}

	private void createResourceJob(Long resourceId, Long jobId, ResourceStatusEnum resourStatusEnum) {
		log.info("inside createResourceJob with resourceId : {} , jobId : {} , resourceStatusEnum : {}", resourceId,
				jobId, resourStatusEnum);

		ResourceJobs resourceJobs = resourceJobsService.findByJobIdAndResourceIdAndDeletedFalse(jobId, resourceId);
		if (resourceJobs == null)
			resourceJobs = new ResourceJobs();
		resourceJobs.setAppliedBy(entityUtil.getCurrentUser());
		Resource resource = resourceService.findById(resourceId);
		Job job = jobsService.findById(jobId);
		if (resourStatusEnum == ResourceStatusEnum.APPLIED) {
			resource.setAppliedJobCount(resource.getAppliedJobCount() + 1);
			job.setApplicantsCount(job.getApplicantsCount() + 1);
		}
		resourceJobs.setResourceInrRate(resource.getRate()!=null?CommonUtil.resourceRateWithCommission(resource.getRate(),staticConfigurationService.findByName(StaticConfigurationEnum.RESOURCE_COMMISSION).getValue()):null);
		resourceJobs.setResourceUsdRate(resource.getUsdRate()!=null?CommonUtil.resourceRateWithCommission(resource.getUsdRate(),staticConfigurationService.findByName(StaticConfigurationEnum.RESOURCE_COMMISSION).getValue()):null);
		resourceJobs.setResourceInrRateType(resource.getRateTypeEnum() != null ?resource.getRateTypeEnum() : null);
		resourceJobs.setResourceUsdRateType(resource.getUsdRateType() != null ? resource.getUsdRateType() : null);
		resourceJobs.setJob(job);
		resourceJobs.setResource(resource);
		resourceJobs.setResourceStatus(resourStatusEnum);
		resourceJobs.setStatusEnum(resource.getStatusEnum());
		resourceJobs.setAppliedBy(entityUtil.getCurrentUser());
		resourceJobsService.save(resourceJobs);

	}

	@Override
	public List<Object> getListResponse(List<ResourceJobs> resourceJobsList) {
		return null;
	}

	@Override
	public Object getDetailResponse(ResourceJobs entity) {
		return null;
	}

	@Override
	public ResourceJobsAdminResponse getDetailForAdminResponse(ResourceJobs entity) {
		return null;
	}

	private List<String> getSkillIdList(List<ResourceSkillsCodeLookup> resourceSkillsCodeLookups) {
		List<String> resourseIdList = new ArrayList<>();
		resourceSkillsCodeLookups.forEach(skill -> {
			resourseIdList.add(skill.getCodeLookup().getName());
		});
		return resourseIdList;
	}

	private List<String> getSkills(List<SkillsCodeLookup> skillsCodeLookup) {
		List<String> jobSkills = new ArrayList<>();
		skillsCodeLookup.forEach(skill -> {
			jobSkills.add(skill.getCodeLookup().getName());
		});
		return jobSkills;
	}

	private List<String> getResourceSkills(List<ResourceSkillsCodeLookup> skillsCodeLookup) {
		List<String> jobSkills = new ArrayList<>();
		skillsCodeLookup.forEach(skill -> {
			jobSkills.add(skill.getCodeLookup().getName());
		});
		return jobSkills;
	}

	private List<ResourceJobsListResponse> getJobsList(List<ResourceJobs> resourceJobs) {

		List<ResourceJobsListResponse> jobsList = new ArrayList<>();

		resourceJobs.forEach(resourceJob -> {

			Resource resource = resourceJob.getResource();

			jobsList.add(ResourceJobsListResponse.builder().id(resource.getId()).firstname(resource.getFirstName())
					.lastname(resource.getLastName())
					.availabilityType(resource.getAvailability().getName())
					.skills(getSkillIdList(resource.getResourceSkillsCodeLookups()))
					.rate(CommonUtil.getRateStr(resource.getCurrencyType().getDisplayName(), resource.getRate(),
							resource.getRateTypeEnum().getDisplayName()))
					.designation(resource.getDesignation().getName()).gender(resource.getGender())
					.experience(CommonUtil.getExperience(resource.getYearsExperience(), resource.getMonthsExperience()))
					.build());
		});

		return jobsList;

	}

	public List<ResourceJobResponse> getJobApplicationList(List<ResourceJobs> resourceJobs) {

		List<ResourceJobResponse> jobResponseList = new ArrayList<>();
		resourceJobs.forEach(resourceJob -> {

			Resource resource = resourceJob.getResource();
			Job job = resourceJob.getJob();

			ResourceJobResponse resourceJobResponse = ResourceJobResponse.builder().jobId(job.getId()).title(job.getTitle())
					.resourceId(resource.getId()).firstname(resource.getFirstName()).lastname(resource.getLastName())
					.state(job.getAddress() != null ? (job.getAddress().getState() != null ? job.getAddress().getState().getName() : null) : null)
				
					.resourceStatus(resourceJob.getResourceStatus().getDisplayName())
					.skills(getSkills(job.getSkillsCodeLookup()))
					.state(resource.getAddress() != null ? (resource.getAddress().getState() != null ? resource.getAddress().getState().getName() : null) : null)
					.country(resource.getCountry() != null ? resource.getCountry().getName(): null).date(resourceJob.getUpdatedOn())
					.rate(resource.getRate()!=null ? CommonUtil.getRateStr(resource.getCurrencyType().getDisplayName(), resource.getRate(),
							resource.getRateTypeEnum().getDisplayName()) :null)
					.designation(resource.getDesignation().getName()).gender(resource.getGender().getDisplayName())
					.experience(CommonUtil.getExperience(resource.getYearsExperience(), resource.getMonthsExperience()))
					.jobTitle(job.getTitle()).jobMinExperience(job.getMinExperience())
					.jobMaxExperience(job.getMaxExperience())
					.jobState(job.getAddress() != null ? (job.getAddress().getState() != null ? job.getAddress().getState().getName() : null) : null)
					.jobCountry(job.getCountry() != null ? job.getCountry().getName(): null)
					.jobStartDate(job.getStartDate()).deploymentType(resource.getDeploymenType().getDisplayName())
					.workFrom(job.getWorkFrom().getDisplayName()).resourceAvailability(resource.getAvailability().getName())
					.duration(job.getDuration().getName())
					.jobCurrency(job.getCurrencyType())
					.usdRate(resource.getUsdRate()!=null?CommonUtil.getRateStr(CurrencyTypeEnum.USD.getDisplayName(), resource.getUsdRate(),
							resource.getUsdRateType().getDisplayName()):null)
					.resourceLocation(resource.getLocation()!=null?resource.getLocation():null)
					.jobLocation(job.getLocation()!=null?job.getLocation():null)
					.appliedBy(resourceJob.getAppliedBy() != null ? resourceJob.getAppliedBy().getUserType() : null)
					.build();

			if (!resourceJob.getResourceStatus().equals(ResourceStatusEnum.INVITED)) {
				resourceJobResponse
						.setRate(resourceJob.getResourceInrRate() != null
								? CommonUtil.getRateStr(CurrencyTypeEnum.INR.getDisplayName(),
										resourceJob.getResourceInrRate(),
										resourceJob.getResourceInrRateType() != null
												? resourceJob.getResourceInrRateType().getDisplayName()
												: resource.getRateTypeEnum() != null
														? resource.getRateTypeEnum().getDisplayName()
														: "")
								: null);
				resourceJobResponse
						.setUsdRate(resourceJob.getResourceUsdRate() != null
								? CommonUtil.getRateStr(CurrencyTypeEnum.USD.getDisplayName(),
										resourceJob.getResourceUsdRate(),
										resourceJob.getResourceUsdRateType() != null
												? resourceJob.getResourceUsdRateType().getDisplayName()
												: resource.getUsdRateType().getDisplayName())
								: null);
			} else {
				resourceJobResponse
						.setRate(resource.getRate() != null
								? CommonUtil.getRateStr(resource.getCurrencyType().getDisplayName(),
										CommonUtil.resourceRateWithCommission(resource.getRate(),
												staticConfigurationService
														.findByName(StaticConfigurationEnum.RESOURCE_COMMISSION)
														.getValue()),
										resource.getRateTypeEnum().getDisplayName())
								: null);
				resourceJobResponse
						.setUsdRate(resource.getUsdRate() != null
								? CommonUtil.getRateStr(CurrencyTypeEnum.USD.getDisplayName(),
										CommonUtil.resourceRateWithCommission(resource.getUsdRate(),
												staticConfigurationService
														.findByName(StaticConfigurationEnum.RESOURCE_COMMISSION)
														.getValue()),
										resource.getUsdRateType().getDisplayName())
								: null);
			}
			jobResponseList.add(resourceJobResponse);
		});

		return jobResponseList;
	}
	
	public List<JobResponse> getJobList(List<Job> jobs, List<String> skills,
			MatchingJobResourceUnderCriteriaRequest matchingJobResourceRequest) {
		Set<JobResponse> jobResponseList = new HashSet<>();

		jobs.forEach(job -> {
			Set<String> set = new HashSet<>(getSkills(job.getSkillsCodeLookup()));
			set.retainAll(skills);
			int numMatchingSkills = set.size();

			double percentageMatchingSkills = ((double) numMatchingSkills / skills.size()) * 100.0;
			Integer keySkillsTotalPersentage = Integer.valueOf((int) percentageMatchingSkills);

			Integer keySkillsPersentage = (keySkillsTotalPersentage * 25) / 100;

			Integer designation = 0;

			if (StringUtils.equalsIgnoreCase(matchingJobResourceRequest.getDesignation().replaceAll(" ", ""),
					job.getTitle().replaceAll(" ", ""))) {

				designation = 25;

			}

			Integer rate = 0;
			StaticConfiguration staticConfiguration = staticConfigurationService
					.findByName(StaticConfigurationEnum.RESOURCE_COMMISSION);
			if (matchingJobResourceRequest.getRate() != null && job.getCurrencyType().equals(CurrencyTypeEnum.INR)) {
				BigDecimal resourceRateWithCommission = CommonUtil.resourceRateWithCommission(
						matchingJobResourceRequest.getRate(), staticConfiguration.getValue());
				if (ComparableUtils.is(resourceRateWithCommission).greaterThanOrEqualTo(job.getMinRate()) == true
						&& ComparableUtils.is(resourceRateWithCommission).lessThanOrEqualTo(job.getMaxRate()) == true)
					rate = 30;
			} else if (matchingJobResourceRequest.getUsdRate() != null
					&& job.getCurrencyType().equals(CurrencyTypeEnum.USD)) {
				BigDecimal resourceUsdRateWithCommission = CommonUtil.resourceRateWithCommission(
						matchingJobResourceRequest.getUsdRate(), staticConfiguration.getValue());
				if (ComparableUtils.is(resourceUsdRateWithCommission).greaterThanOrEqualTo(job.getMinRate()) == true
						&& ComparableUtils.is(resourceUsdRateWithCommission)
								.lessThanOrEqualTo(job.getMaxRate()) == true)
					rate=30;
			}else {
				rate=-55;
			}
			
			Integer minExpInMonthsJob = job.getMinExperience() * 12;
			Integer maxExpInMonthsJob = job.getMaxExperience() * 12;

			Integer expInMonthsResource = matchingJobResourceRequest.getExpInYear() * 12
					+ matchingJobResourceRequest.getExpInMonths();

			Integer exp = 0;
			if (expInMonthsResource >= minExpInMonthsJob && expInMonthsResource <= maxExpInMonthsJob) {
				exp = 15;
			}
			Integer workFrom = 0;
			
			if (matchingJobResourceRequest.getWorkFrom() != null
					&& matchingJobResourceRequest.getWorkFrom().equals(DeploymentTypeEnum.ONSITE.getDisplayName())
					&& (job.getWorkFrom().equals(DeploymentTypeEnum.ONSITE)
							&& matchingJobResourceRequest.getLocation() != null
							&& matchingJobResourceRequest.getLocation().equals(job.getLocation()))) {
				workFrom = 5;
			} else if (matchingJobResourceRequest.getWorkFrom() != null
					&& matchingJobResourceRequest.getWorkFrom().equals(DeploymentTypeEnum.REMOTE.getDisplayName())
					&& (job.getWorkFrom().equals(DeploymentTypeEnum.REMOTE))) {
				workFrom = 5;
			} else if (matchingJobResourceRequest.getWorkFrom() != null
					&& matchingJobResourceRequest
							.getWorkFrom().equals(DeploymentTypeEnum.REMOTE_AND_ONSITE.getDisplayName())
					&& job.getWorkFrom() != null
					&& (job.getWorkFrom().equals(DeploymentTypeEnum.REMOTE)
							|| (job.getWorkFrom().equals(DeploymentTypeEnum.ONSITE)
									&& matchingJobResourceRequest.getLocation() != null
									&& matchingJobResourceRequest.getLocation().equals(job.getLocation())))) {
				workFrom = 5;
			} else if (matchingJobResourceRequest.getWorkFrom() != null
					&& matchingJobResourceRequest.getWorkFrom().equals(DeploymentTypeEnum.HYBRID.getDisplayName())
					&& job.getWorkFrom() != null
					&& (job.getWorkFrom().equals(DeploymentTypeEnum.HYBRID)
							&& matchingJobResourceRequest.getLocation() != null
							&& matchingJobResourceRequest.getLocation().equals(job.getLocation()))) {
				workFrom = 5;
			} else {
				workFrom = -55;
			}
			
			ResourceJobs resourceJobs = resourceJobsService
					.findByJobIdAndResourceIdAndDeletedFalse(matchingJobResourceRequest.getId(), job.getId());
			Integer totalPercentage = workFrom + exp + rate + designation + keySkillsPersentage;

			if (totalPercentage == 100
					&& matchingJobResourceRequest.getMatchingCriteria() == MatchingCriteria.UNDER_CRITERIA)
				jobResponseList.add(getJob(job, totalPercentage, resourceJobs));
			else if (totalPercentage >= 50 && totalPercentage < 100
					&& matchingJobResourceRequest.getMatchingCriteria() == MatchingCriteria.SUGGESTION)
				jobResponseList.add(getJob(job, totalPercentage, resourceJobs));

		});
		
		return jobResponseList.stream().sorted(Comparator.comparingDouble(JobResponse::getPercentage).reversed())
				.collect(Collectors.toList());		
	}

	public List<JobResponse> getJobList(List<Job> jobs, List<String> skills) {
		Set<JobResponse> jobResponseList = new HashSet<>();

		jobs.forEach(job -> {
			Set<String> set = new HashSet<>(getSkills(job.getSkillsCodeLookup()));
			set.retainAll(skills);
			int numMatchingSkills = set.size();

			double percentageMatchingSkills = ((double) numMatchingSkills / skills.size()) * 100.0;

			jobResponseList.add(JobResponse.builder().title(job.getTitle()).jobId(job.getId())
					.country(job.getCountry() != null ? job.getCountry().getName(): null)
					.title(job.getTitle()).workFrom(job.getWorkFrom().getDisplayName())
					.rateType(job.getRateTypeEnum().getDisplayName()).minRate(job.getMinRate())
					.maxRate(job.getMaxRate()).noOfResource(job.getNoOfResources())
					.minExperience(job.getMinExperience()).maxExperience(job.getMaxExperience())
					.startDate(job.getStartDate()).postedDate(job.getCreatedOn())
					.currencyType(job.getCurrencyType().getDisplayName()).status(job.getStatusEnum().getDisplayName())
					.active(job.getActive()).title(job.getTitle())
					.percentage(Integer.valueOf((int) percentageMatchingSkills)).jobId(job.getId())
					.skills(getSkills(job.getSkillsCodeLookup())).build());
		});

		return jobResponseList.stream().sorted(Comparator.comparingDouble(JobResponse::getPercentage).reversed())
				.collect(Collectors.toList());
	}

	public List<ResourceResponse> getResourceList(List<Resource> resources,
			MatchingJobResourceUnderCriteriaRequest matchingJobResourceRequest) {
		Set<ResourceResponse> resourceResponseList = new HashSet<>();

		resources.forEach(resource -> {
			Set<String> set = new HashSet<>(getResourceSkills(resource.getResourceSkillsCodeLookups()));

			set.retainAll(matchingJobResourceRequest.getSkills());
			int numMatchingSkills = set.size();
			double percentageMatchingSkills = ((double) numMatchingSkills
					/ matchingJobResourceRequest.getSkills().size()) * 100.0;
			Integer keySkillsTotalPersentage = Integer.valueOf((int) percentageMatchingSkills);

			Integer keySkillsPersentage = (keySkillsTotalPersentage * 25) / 100;

			Integer designation = 0;

			if (StringUtils.equalsIgnoreCase(matchingJobResourceRequest.getJobTitle().replaceAll(" ", ""),
					resource.getDesignation().getName().replaceAll(" ", ""))) {
				designation = 25;

			}
			ResourceJobs resourceJobs = resourceJobsService
					.findByJobIdAndResourceIdAndDeletedFalse(matchingJobResourceRequest.getId(), resource.getId());
			Integer rate = 0;
			if(resourceJobs!=null&&(!resourceJobs.getResourceStatus().equals(ResourceStatusEnum.INVITED))) {
			rate = getResourceRate(matchingJobResourceRequest.getCurrencyType(),
					matchingJobResourceRequest.getMinRate(), matchingJobResourceRequest.getMaxRate(),
					resourceJobs.getResourceInrRate()!=null?resourceJobs.getResourceInrRate():null, resourceJobs.getResourceUsdRate()!=null? resourceJobs.getResourceUsdRate():null);
			}else {
				rate = getResourceRate(matchingJobResourceRequest.getCurrencyType(),
						matchingJobResourceRequest.getMinRate(), matchingJobResourceRequest.getMaxRate(),
						resource.getRate() !=null?CommonUtil.resourceRateWithCommission(resource.getRate(), staticConfigurationService.findByName(StaticConfigurationEnum.RESOURCE_COMMISSION).getValue()):null,resource.getUsdRate()!=null? CommonUtil.resourceRateWithCommission(resource.getUsdRate(), staticConfigurationService.findByName(StaticConfigurationEnum.RESOURCE_COMMISSION).getValue()):null);

			}
			Integer minExpInMonthsJob = matchingJobResourceRequest.getMinExp() * 12;
			Integer maxExpInMonthsJob = matchingJobResourceRequest.getMaxExp() * 12;
			Integer expInMonthsResource = resource.getYearsExperience() * 12 + resource.getMonthsExperience();

			Integer exp = 0;
			if (expInMonthsResource >= minExpInMonthsJob && expInMonthsResource <= maxExpInMonthsJob) {
				exp = 15;
			}
			Integer workFrom = 0;

			if ((matchingJobResourceRequest.getWorkFrom().equals(resource.getDeploymenType().getDisplayName())
					|| ((matchingJobResourceRequest.getWorkFrom().equals(DeploymentTypeEnum.REMOTE.getDisplayName())
							|| matchingJobResourceRequest.getWorkFrom()
									.equals(DeploymentTypeEnum.ONSITE.getDisplayName()))
							&& resource.getDeploymenType().equals(DeploymentTypeEnum.REMOTE_AND_ONSITE)))
					&& matchingJobResourceRequest.getLocation()!=null
					&& matchingJobResourceRequest.getLocation().equals(resource.getLocation())) {
				workFrom = 5;
			}

			Integer totalPercentage = workFrom + exp + rate + designation + keySkillsPersentage;
			if (totalPercentage == 100
					&& matchingJobResourceRequest.getMatchingCriteria() == MatchingCriteria.UNDER_CRITERIA)
				resourceResponseList.add(getResource(resource, totalPercentage, resourceJobs));
			else if (totalPercentage >= 50 && totalPercentage < 100
					&& matchingJobResourceRequest.getMatchingCriteria() == MatchingCriteria.SUGGESTION)
				resourceResponseList.add(getResource(resource, totalPercentage, resourceJobs));
		});

		return resourceResponseList.stream()
				.sorted(Comparator.comparingDouble(ResourceResponse::getPercentage).reversed() .thenComparingLong(ResourceResponse::getId))
				.collect(Collectors.toList());
	}

	/**
	 * 
	 * @param resource
	 * @param totalPercentage
	 * @param resourceJobs
	 * @return get resource
	 */
	private ResourceResponse getResource(Resource resource, Integer totalPercentage, ResourceJobs resourceJobs) {
	ResourceResponse resourceResponse = ResourceResponse.builder().resourceId(resource.getId()).percentage(totalPercentage)
				.designation(resource.getDesignation().getName())
				.name(resource.getFirstName() + " " + resource.getLastName())
				.skills(getResourceSkills(resource.getResourceSkillsCodeLookups()))
				.status(resourceJobs != null ? resourceJobs.getResourceStatus() : null).active(resource.getActive())
				.availabilityType(
						resource.getAvailability().getName() != null ? resource.getAvailability().getName() : null)
				.base64MediaString(getByteArrayFromImageURL(
						fileUpload.generatePresignedURL(resource.getProfilePhoto().getPath())))
				.country(resource.getCountry() != null ? resource.getCountry().getName(): null)
				.state(resource.getAddress() != null ? (resource.getAddress().getState() != null ? resource.getAddress().getState().getName() : null) : null)
				.deploymentType(resource.getDeploymenType().getDisplayName())
				.experience(CommonUtil.getExperience(resource.getYearsExperience(), resource.getMonthsExperience()))
				.gender(resource.getGender().getDisplayName()).passingYear(resource.getPassingYear())
				.statusEnum(resource.getStatusEnum()).appliedJobCount(resource.getAppliedJobCount())
				.higherEducation(resource.getHigherEducation())
				.resume(resource.getResume() != null ? awsS3Url + resource.getResume().getPath() : null)
				.location(resource.getLocation()!=null?resource.getLocation():null)
				.id(resource.getId())
				.build();
	
	if (resourceJobs != null&&(!resourceJobs.getResourceStatus().equals(ResourceStatusEnum.INVITED))) {
		resourceResponse
				.setRate(resourceJobs.getResourceInrRate() != null
						? CommonUtil.getRateStr(CurrencyTypeEnum.INR.getDisplayName(),
								resourceJobs.getResourceInrRate(), resourceJobs.getResource().getRateTypeEnum().getDisplayName())
						: null);

		resourceResponse
				.setUsdRate(resourceJobs.getResourceUsdRate() != null
						? CommonUtil.getRateStr(CurrencyTypeEnum.USD.getDisplayName(),
								resourceJobs.getResourceUsdRate(), resourceJobs.getResource().getUsdRateType().getDisplayName())
						: null);
	} else {
		resourceResponse.setRate(resource.getRate() != null
				? CommonUtil.getRateStr(CurrencyTypeEnum.INR.getDisplayName(),
						CommonUtil.resourceRateWithCommission(resource.getRate(),
								staticConfigurationService
										.findByName(StaticConfigurationEnum.RESOURCE_COMMISSION).getValue()),
						resource.getRateTypeEnum().getDisplayName())
				: null);

		resourceResponse.setUsdRate(resource.getUsdRate()!= null
				? CommonUtil.getRateStr(CurrencyTypeEnum.USD.getDisplayName(),
						CommonUtil.resourceRateWithCommission(resource.getUsdRate(),
								staticConfigurationService
										.findByName(StaticConfigurationEnum.RESOURCE_COMMISSION).getValue()),
						resource.getUsdRateType().getDisplayName())
				: null);
	}
	return resourceResponse;
	}

	private JobResponse getJob(Job job, Integer totalPercentage, ResourceJobs resourceJobs) {
		return JobResponse.builder().title(job.getTitle()).jobId(job.getId())
				.state(job.getAddress() != null ? (job.getAddress().getState() != null ? job.getAddress().getState().getName() : null) : null)
				.statusEnum(resourceJobs != null ? resourceJobs.getResourceStatus() : null)
				.country(job.getCountry() != null ? job.getCountry().getName(): null)
				.title(job.getTitle()).workFrom(job.getWorkFrom().getDisplayName()).rateType(job.getRateTypeEnum().getDisplayName())
				.minRate(job.getMinRate()).maxRate(job.getMaxRate()).noOfResource(job.getNoOfResources())
				.minExperience(job.getMinExperience()).maxExperience(job.getMaxExperience())
				.startDate(job.getStartDate()).postedDate(job.getCreatedOn())
				.currencyType(job.getCurrencyType().getDisplayName()).status(job.getStatusEnum().getDisplayName())
				.active(job.getActive()).title(job.getTitle()).percentage(Integer.valueOf((int) totalPercentage))
				.jobId(job.getId()).skills(getSkills(job.getSkillsCodeLookup()))
				.location(job.getLocation()!=null?job.getLocation():null)
				.build();

	}

	public static String getByteArrayFromImageURL(String url) {

		try {
			URL imageUrl = new URL(url);
			URLConnection ucon = imageUrl.openConnection();
			InputStream is = ucon.getInputStream();
			byte[] buffer = IOUtils.toByteArray(is);
			return Constants.BASE64.concat(Base64.getEncoder().encodeToString(buffer));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public ResourceJobCountResponse getResourceJobCount(List<ResourceJobs> resourceJobs) {

		Long appliedCount = resourceJobs.stream().filter(res -> ResourceStatusEnum.APPLIED == res.getResourceStatus())
				.count();
		Long shortlistedCount = resourceJobs.stream()
				.filter(res -> ResourceStatusEnum.SHORTLISTED == res.getResourceStatus()).count();
		Long rejectedCount = resourceJobs.stream().filter(res -> ResourceStatusEnum.REJECTED == res.getResourceStatus())
				.count();
		Long hiredCount = resourceJobs.stream().filter(res -> ResourceStatusEnum.HIRED == res.getResourceStatus())
				.count();

		return ResourceJobCountResponse.builder().applied(appliedCount).hired(hiredCount).shortlisted(shortlistedCount)

				.all(CommonUtil.getCountOrZero(appliedCount) + CommonUtil.getCountOrZero(hiredCount)
						+ CommonUtil.getCountOrZero(rejectedCount) + CommonUtil.getCountOrZero(shortlistedCount))
				.rejected(rejectedCount).build();
	}

	public Map<ResourceStatusEnum, Long> getResourceStatusList(Long id) {
		List<ResourceJobs> resourceStatusList = resourceJobsService.getResourceStatusList(id);
		Map<ResourceStatusEnum, Long> resourceStatusMap = resourceStatusList.stream()
				.collect(Collectors.groupingBy(ResourceJobs::getResourceStatus, Collectors.counting()));

		return resourceStatusMap;

	}

	public List<ResourceApplicationResponse> getResourceApplicationResponse(List<ResourceJobs> resourceJobs) {

		List<ResourceApplicationResponse> resourceApplicationList = new ArrayList<>();
		resourceJobs.forEach(resourceJob -> {
			Resource resource = resourceJob.getResource();
			Job job = resourceJob.getJob();
			ResourceApplicationResponse resourceApplicationResponse = ResourceApplicationResponse.builder().firstName(resource.getFirstName())
					.lastName(resource.getLastName())
					.resourceSkill(getSkillIdList(resource.getResourceSkillsCodeLookups())).jobTitle(job.getTitle())
					.resourceNo(resource.getRId())
					.state(job.getAddress() != null ? (job.getAddress().getState() != null ? job.getAddress().getState().getName() : null) : null)
					.country(job.getCountry() != null ? job.getCountry().getName() :null)
					.minExperience(job.getMinExperience()).maxExperience(job.getMaxExperience())
					.date(resourceJob.getUpdatedOn()).appliedAt(job.getVendor().getAgencyName())
					.resourceId(resource.getId()).jobId(job.getId()).minExperience(job.getMinExperience())
					.maxExperience(job.getMaxExperience()).resourceId(resource.getId()).jobId(job.getId())
					.joiningDate(job.getStartDate()).resourceStatus(resourceJob.getResourceStatus().getDisplayName())
					.rate(resource.getRate() != null ? CommonUtil.getRateStr(CurrencyTypeEnum.INR.getDisplayName(),
							CommonUtil.resourceRateWithCommission(resource.getRate(),
									staticConfigurationService.findByName(StaticConfigurationEnum.RESOURCE_COMMISSION)
											.getValue()),
							resource.getRateTypeEnum()!=null?resource.getRateTypeEnum().getDisplayName():null) : null)

					.usdRate(
							resource.getUsdRate() != null
									? CommonUtil.getRateStr(CurrencyTypeEnum.USD.getDisplayName(),
											CommonUtil.resourceRateWithCommission(resource.getUsdRate(),
													staticConfigurationService
															.findByName(StaticConfigurationEnum.RESOURCE_COMMISSION)
															.getValue()),
										resource.getRateTypeEnum()!=null? resource.getRateTypeEnum().getDisplayName():null)
									: null)				
					.designation(resource.getDesignation().getName())
					.resourceExperience(
							CommonUtil.getExperience(resource.getYearsExperience(), resource.getMonthsExperience()))
					.resourceState(resource.getAddress() != null ?  resource.getAddress().getState().getName() : null)
					.resourceCountry(resource.getCountry() != null ? resource.getCountry().getName() :null)
					.availability(resource.getAvailability().getName()).workFrom(job.getWorkFrom().getDisplayName())
					.deploymentType(resource.getDeploymenType().getDisplayName()).duration(job.getDuration().getName())
					.minRate(job.getMinRate()).maxRate(job.getMaxRate()).rateTypeEnum(job.getRateTypeEnum())
					.currencyType(job.getCurrencyType())
					.gender(resource.getGender().getDisplayName())
					.resourceLocation(resource.getLocation()!=null?resource.getLocation():null)
					.jobLocation(job.getLocation()!=null?job.getLocation():null)
					.appliedBy(resourceJob.getAppliedBy() != null ? resourceJob.getAppliedBy().getUserType() : null)
					.build();
			if (!resourceJob.getResourceStatus().equals(ResourceStatusEnum.INVITED)) {
				resourceApplicationResponse
						.setRate(resourceJob.getResourceInrRate() != null
								? CommonUtil.getRateStr(CurrencyTypeEnum.INR.getDisplayName(),
										resourceJob.getResourceInrRate(), resourceJob.getResourceInrRateType() != null
												? resourceJob.getResourceInrRateType().getDisplayName()
												:resource.getRateTypeEnum()!=null? resource.getRateTypeEnum().getDisplayName():null)
								: null);
				resourceApplicationResponse
						.setUsdRate(resourceJob.getResourceUsdRate() != null
								? CommonUtil.getRateStr(CurrencyTypeEnum.USD.getDisplayName(),
										resourceJob.getResourceUsdRate(),resourceJob.getResourceUsdRateType() != null
												? resourceJob.getResourceUsdRateType().getDisplayName()
												: resource.getUsdRateType()!=null? resource.getUsdRateType().getDisplayName():null)
								: null);
			}

			resourceApplicationList.add(resourceApplicationResponse);

		});

		return resourceApplicationList;
	}

	public List<ResourceResponse> getResourceListUnderNoCriteria(List<Resource> resources, List<String> skills) {

		Set<ResourceResponse> resourceResponseList = new HashSet<>();

		resources.forEach(resource -> {
			Set<String> set = new HashSet<>(getResourceSkills(resource.getResourceSkillsCodeLookups()));
			set.retainAll(skills);
			int numMatchingSkills = set.size();
			double percentageMatchingSkills = ((double) numMatchingSkills / skills.size()) * 100.0;

			resourceResponseList.add(ResourceResponse.builder().resourceId(resource.getId())
					.percentage(Integer.valueOf((int) percentageMatchingSkills))
					.designation(resource.getDesignation().getName())
					.name(resource.getFirstName() + " " + resource.getLastName())
					.skills(getResourceSkills(resource.getResourceSkillsCodeLookups())).build());

		});

		return resourceResponseList.stream()
				.sorted(Comparator.comparingDouble(ResourceResponse::getPercentage).reversed())
				.collect(Collectors.toList());
	}

	public List<ResourceResponse> getResourceList(List<Resource> resources, List<String> skills) {

		Set<ResourceResponse> resourceResponseList = new HashSet<>();

		resources.forEach(resource -> {
			Set<String> set = new HashSet<>(getResourceSkills(resource.getResourceSkillsCodeLookups()));
			set.retainAll(skills);
			int numMatchingSkills = set.size();
			double percentageMatchingSkills = ((double) numMatchingSkills / skills.size()) * 100.0;

			resourceResponseList.add(ResourceResponse.builder().resourceId(resource.getId())
					.percentage(Integer.valueOf((int) percentageMatchingSkills))
					.designation(resource.getDesignation().getName())
					.name(resource.getFirstName() + " " + resource.getLastName())
					.skills(getResourceSkills(resource.getResourceSkillsCodeLookups())).build());

		});

		return resourceResponseList.stream()
				.sorted(Comparator.comparingDouble(ResourceResponse::getPercentage).reversed())
				.collect(Collectors.toList());
	}

//	public InvitationCountResponse getInvitationCountResponse(List<ResourceJobs> resourceJobs) {
//		if (resourceJobs != null) {
//			
//			Map<ResourceStatusEnum, List<ResourceJobs>> resourceJobsMap = resourceJobs.stream()
//					.collect(Collectors.groupingBy(ResourceJobs::getResourceStatus));
//			return InvitationCountResponse.builder()
//					.invitationReceivedOrSendCount(resourceJobs != null ? resourceJobs.size() : 0)
//					.invitationAcceptedCount(resourceJobsMap.get(ResourceStatusEnum.INVITED) != null
//							? resourceJobsMap.get(ResourceStatusEnum.INVITED).size()
//							: 0)
//					
//					.build();
//
//		}
//		return null;
//
//	}
      
	private Integer getResourceRate(CurrencyTypeEnum jobCurrencyType,BigDecimal jobMinRate,BigDecimal jobMaxRate,BigDecimal resourceInrRate,BigDecimal resourceUsdRate)
	{ 
		Integer rate =0;
		if (jobCurrencyType!=null&&jobCurrencyType.equals(CurrencyTypeEnum.INR) &&resourceInrRate!=null) {
			if(ComparableUtils.is(resourceInrRate)
				.greaterThanOrEqualTo(jobMinRate) == true
				&& ComparableUtils.is(resourceInrRate)
						.lessThanOrEqualTo(jobMaxRate) == true)
			rate = 30;
		}
		else if (jobCurrencyType!=null&&jobCurrencyType.equals(CurrencyTypeEnum.USD) &&resourceUsdRate!=null) {
			if(ComparableUtils.is(resourceUsdRate)
				.greaterThanOrEqualTo(jobMinRate) == true
				&& ComparableUtils.is(resourceUsdRate)
						.lessThanOrEqualTo(jobMaxRate) == true)
			rate = 30;
		}
		else {
			rate=-55;
		}
		return rate;
	}
}

