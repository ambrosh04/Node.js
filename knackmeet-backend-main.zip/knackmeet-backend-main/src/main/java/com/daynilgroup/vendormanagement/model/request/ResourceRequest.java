package com.daynilgroup.vendormanagement.model.request;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;

import com.daynilgroup.vendormanagement.constants.CurrencyTypeEnum;
import com.daynilgroup.vendormanagement.constants.DeploymentTypeEnum;
import com.daynilgroup.vendormanagement.constants.Gender;
import com.daynilgroup.vendormanagement.constants.RateTypeEnum;
import com.daynilgroup.vendormanagement.constants.ResourceStatusEnum;
import com.daynilgroup.vendormanagement.model.response.AdvanceSearchDropdownModel;
import com.daynilgroup.vendormanagement.request.EducationRequest;
import com.daynilgroup.vendormanagement.request.ExperienceRequest;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@Getter
@Setter
@FieldDefaults(level = AccessLevel.PRIVATE)
public class ResourceRequest implements Serializable {

	static final long serialVersionUID = 1L;

	Long id;

	String firstname;

	String middleName;

	String lastname;

	Gender gender;
	
	AdvanceSearchDropdownModel designation;

//	Integer monthsExperience;

//	Integer yearsExperience;

	DeploymentTypeEnum deploymenType;

	Long availabilityId;

	Long countryId;

	Long stateId;

	AdvanceSearchDropdownModel city;

	Long categoryId;

	BigDecimal rate;

	String base64resume;

	ResourceStatusEnum resourceStatus;

	String deletedImage;
	
	String deletedResume;

	List<AdvanceSearchDropdownModel> skillsCodeLookups;

	String base64profilePhoto;

	CurrencyTypeEnum currencyType;

	RateTypeEnum rateTypeEnum;

	String higherEducation;

	Long passingYear;

	//String description;
	
	String resumeName;
	
	List<EducationRequest> educationRequests;
	
	List<ExperienceRequest> experienceRequests;
	
	RateTypeEnum usdRateType;
	
	BigDecimal usdRate;
	
	String location;
	
	BigDecimal latitude;
	
	BigDecimal longitude;
}
