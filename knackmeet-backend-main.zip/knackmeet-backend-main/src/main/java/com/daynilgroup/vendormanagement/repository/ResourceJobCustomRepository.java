/**
 * 
 */
package com.daynilgroup.vendormanagement.repository;

import com.daynilgroup.vendormanagement.model.filter.JobsFilterModel;
import com.daynilgroup.vendormanagement.model.filter.ResourceFilterModel;
import com.daynilgroup.vendormanagement.model.pag.PageModel;
import com.daynilgroup.vendormanagement.model.request.ResourceJobFilterRequest;
import com.daynilgroup.vendormanagement.request.InvitationsSendRequest;

/**
 * @author Prerana
 *
 */
public interface ResourceJobCustomRepository {

	PageModel getResourceListByStatus(ResourceFilterModel resourceJobFilterModel);
	
	PageModel findAllInvitationsRecived(ResourceJobFilterRequest resourceJobFilterModel);

	PageModel getJobListByResourceId(JobsFilterModel jobsFilterModel);

	PageModel findAllInvitationsSend(InvitationsSendRequest resourceJobFilterRequest);

}
