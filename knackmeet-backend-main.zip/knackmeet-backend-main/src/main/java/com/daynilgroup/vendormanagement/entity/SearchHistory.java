package com.daynilgroup.vendormanagement.entity;

import java.io.Serializable;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.ColumnDefault;

import com.daynilgroup.vendormanagement.constants.JobSearchInTypeEnum;
import com.daynilgroup.vendormanagement.constants.ResourceSearchInEnum;
import com.daynilgroup.vendormanagement.constants.SearchType;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

/**
 * @author Manish
 *
 *
 */

@Getter
@Setter
@Entity
@Table(name = "search_history")
@FieldDefaults(level = AccessLevel.PRIVATE)
public class SearchHistory implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	Long id;

	@Column(name = "search_in")
	String searchIn;

	@Column(name = "min_exp")
	Integer minExp;

	@Column(name = "max_exp")
	Integer maxExp;

	@Column(name = "date")
	LocalDateTime date;

	@Column(name = "search_type")
	@Enumerated(EnumType.STRING)
	SearchType searchType;

	@Column(name = "job_search_in_type_enum")
	@Enumerated(EnumType.STRING)
	JobSearchInTypeEnum jobSearchInTypeEnum;

	@Column(name = "resource_search_in_enum")
	@Enumerated(EnumType.STRING)
	ResourceSearchInEnum resourceSearchInEnum;

	@Column(name = "deleted")
	@ColumnDefault(value = "0")
	Boolean deleted;

	@JoinColumn(name = "vendor_id", referencedColumnName = "id", nullable = false)
	@ManyToOne(fetch = FetchType.LAZY)
	Vendor vendor;

	@Column(name = "city_id")
	Long cityId;

	@Column(name = "state_id")
	Long stateId;

	@Column(name = "country_id")
	Long countryId;

	@Column( name = "keyword")
	String keyword;
}
