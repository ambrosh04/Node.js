package com.daynilgroup.vendormanagement.helper;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

import com.daynilgroup.vendormanagement.entity.StaticConfiguration;
import com.daynilgroup.vendormanagement.exception.response.StaticConfiguarationResponse;
import com.daynilgroup.vendormanagement.model.request.StaticConfiguarationRequest;
import com.daynilgroup.vendormanagement.service.StaticConfigurationService;
import com.daynilgroup.vendormanagement.util.CommonUtil;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;

@Component
@Lazy
@FieldDefaults(level = AccessLevel.PRIVATE)
public class StaticConfigurationHelper extends
		AbstractHelper<StaticConfiguration, StaticConfiguarationRequest, StaticConfiguarationResponse, StaticConfiguarationResponse, StaticConfiguarationResponse> {

	@Autowired
	StaticConfigurationService staticConfigurationService;

	@Override
	@Transactional
	public StaticConfiguration getEntity(StaticConfiguarationRequest request) throws Exception {
		StaticConfiguration staticConfiguration;
		if (CommonUtil.isValid(request.getId())) {
			staticConfiguration = staticConfigurationService.findById(request.getId());
			staticConfiguration.setValue(request.getValue());
		} else {
			throw new Exception("Invalid Id");
		}

		return staticConfiguration;
	}

	@Override
	public List<StaticConfiguarationResponse> getListResponse(List<StaticConfiguration> entityList) {
		List<StaticConfiguarationResponse> staticConfiguarationResponseList = new ArrayList<>();
		entityList.forEach(staticConfiguration -> {
			staticConfiguarationResponseList.add(StaticConfiguarationResponse.builder().id(staticConfiguration.getId())
					.label(staticConfiguration.getName().getDisplayName()).value(staticConfiguration.getValue()).code(staticConfiguration.getName())
					.build());
		});
		return staticConfiguarationResponseList;
	}

	@Override
	public StaticConfiguarationResponse getDetailResponse(StaticConfiguration entity) {
		return StaticConfiguarationResponse.builder().id(entity.getId()).label(entity.getName().getDisplayName()).code(entity.getName())
				.value(entity.getValue()).build();

	}

	@Override
	public StaticConfiguarationResponse getDetailForAdminResponse(StaticConfiguration entity) {
		return StaticConfiguarationResponse.builder().id(entity.getId()).label(entity.getName().getDisplayName()).code(entity.getName())
				.value(entity.getValue()).build();
	}

}
