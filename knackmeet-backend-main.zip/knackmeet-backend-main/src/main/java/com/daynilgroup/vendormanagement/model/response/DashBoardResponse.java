package com.daynilgroup.vendormanagement.model.response;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class DashBoardResponse implements Serializable {
	
	static final long serialVersionUID = 1L;
	
	Long myJobOrProjects;

	Long myBenchOrResource;

	Long jobApplication;

	Long benchApplication;

	Long invitationReceived;

	Long invitationSent;

}
