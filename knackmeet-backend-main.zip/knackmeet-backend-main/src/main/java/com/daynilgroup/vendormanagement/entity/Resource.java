package com.daynilgroup.vendormanagement.entity;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.ColumnDefault;

import com.daynilgroup.vendormanagement.constants.CurrencyTypeEnum;
import com.daynilgroup.vendormanagement.constants.DeploymentTypeEnum;
import com.daynilgroup.vendormanagement.constants.Gender;
import com.daynilgroup.vendormanagement.constants.RateTypeEnum;
import com.daynilgroup.vendormanagement.constants.ResourceStatusEnum;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

/**
 *
 * @author manish
 */
@Getter
@Setter
@Entity
@Table(name = "resource")
@FieldDefaults(level = AccessLevel.PRIVATE)
public class Resource extends BaseEntity {

	static final long serialVersionUID = 1L;

	@Column(name = "first_name")
	String firstName;

	@Column(name = "middle_name")
	String middleName;

	@Column(name = "last_name")
	String lastName;

	@Column(name = "r_Id")
	String rId;

	@Enumerated(EnumType.STRING)
	@Column(name = "gender", nullable = false)
	Gender gender;

	@JoinColumn(name = "designation_id", referencedColumnName = "id", nullable = false)
	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	CodeLookup designation;

	@Column(name = "months_experience")
	Integer monthsExperience;

	@Column(name = "years_experience")
	Integer yearsExperience;

	@Enumerated(EnumType.STRING)
	@Column(name = "deploymen_type", nullable = false)
	DeploymentTypeEnum deploymenType;

	@JoinColumn(name = "availability_id", referencedColumnName = "id", nullable = false)
	@ManyToOne(fetch = FetchType.LAZY)
	CodeLookup availability;

	@JoinColumn(name = "address_id")
	@ManyToOne(fetch = FetchType.LAZY, targetEntity = Address.class)
	Address address;

	@OneToMany(mappedBy = "resource", fetch = FetchType.LAZY)
	List<ResourceSkillsCodeLookup> resourceSkillsCodeLookups;

	@JoinColumn(name = "profile_photo_id", referencedColumnName = "id")
	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	Media profilePhoto;

	@Enumerated(EnumType.STRING)
	@Column(name = "currency_type")
	CurrencyTypeEnum currencyType;

	@Enumerated(EnumType.STRING)
	@Column(name = "rate_type")
	RateTypeEnum rateTypeEnum;

	@Column(name = "rate")
	BigDecimal rate = BigDecimal.ZERO;

	@JoinColumn(name = "resume_id", referencedColumnName = "id", nullable = true)
	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	Media resume;

	@Enumerated(EnumType.STRING)
	@Column(name = "resource_status")
	ResourceStatusEnum resourceStatus;

	@JoinColumn(name = "vendor_id", referencedColumnName = "id", nullable = false)
	@ManyToOne(fetch = FetchType.LAZY)
	Vendor vendor;

	@Column(name = "higher_education")
	String higherEducation;

	@Column(name = "passing_year")
	Long passingYear;

	@Column(name = "description")
	@Lob
	String description;

	@Column(name = "applied_job_count", nullable = false)
	@ColumnDefault("0")
	Integer appliedJobCount = 0;

	@Column(name = "name")
	String name;

	@Column(name = "reason")
	@Lob
	String reason;
	
	@Enumerated(EnumType.STRING)
	@Column(name = "usd_rate_type")
	RateTypeEnum usdRateType;
	
	@Column(name = "usd_rate")
	BigDecimal usdRate = BigDecimal.ZERO;
	
	@OneToMany(cascade = CascadeType.ALL, mappedBy = "resource", fetch = FetchType.LAZY)
	List<Education> educations;
	
	@OneToMany(cascade = CascadeType.ALL, mappedBy = "resource", fetch = FetchType.LAZY)
	List<Experience> experiences;
	
	@Column(name="location")
	String location;
	
	@Column(name="latitude")
	BigDecimal latitude;
	
	@Column(name="longitude")
	BigDecimal longitude;
	
	@JoinColumn(name = "country_id", referencedColumnName = "id")
	@ManyToOne(fetch = FetchType.LAZY)
	CodeLookup country;
	
	@OneToMany(mappedBy = "refId", cascade = CascadeType.ALL,fetch = FetchType.LAZY)
	List<CodeLookUpRelation> codeLookUpRelation;
	
	@Column(name = "last_modified_date")
	LocalDateTime lastModifiedDate;
	
}
