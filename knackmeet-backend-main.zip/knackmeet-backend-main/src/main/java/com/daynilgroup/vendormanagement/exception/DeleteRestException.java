package com.daynilgroup.vendormanagement.exception;

import lombok.Getter;
import lombok.NoArgsConstructor;
/**
 * @author Prerana
 *
 */
@Getter
@NoArgsConstructor
public class DeleteRestException extends RestExecption {

    public final String errorCode = RestExceptionCode.DELETE_ERROR_CODE;
    public String message = "Unable To Delete. ";

    public DeleteRestException(String message) {
        this.message += message;
    }

}
