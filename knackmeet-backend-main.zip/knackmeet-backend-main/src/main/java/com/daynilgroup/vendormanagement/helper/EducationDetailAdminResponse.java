package com.daynilgroup.vendormanagement.helper;

import java.io.Serializable;

import com.daynilgroup.vendormanagement.model.response.AdvanceSearchDropdownModel;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class EducationDetailAdminResponse implements Serializable {
	
	static final long serialVersionUID = 1L;

	Long id;

	String schoolName;

	AdvanceSearchDropdownModel degree;

	AdvanceSearchDropdownModel specialization;

	Integer fromYear;

	Integer fromMonth;

	Integer toYear;

	Integer toMonth;

	String description;
	
}
