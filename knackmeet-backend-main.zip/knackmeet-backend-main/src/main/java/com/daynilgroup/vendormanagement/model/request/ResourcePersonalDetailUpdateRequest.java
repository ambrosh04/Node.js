package com.daynilgroup.vendormanagement.model.request;

import java.io.Serializable;

import com.daynilgroup.vendormanagement.constants.Gender;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

@Data
@AllArgsConstructor
@NoArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class ResourcePersonalDetailUpdateRequest implements Serializable {

	private static final long serialVersionUID = 1L;

	Long id;

	String firstname;

	String middleName;

	String lastname;

	Gender gender;

	String base64resume;

	String deletedImage;

	String deletedResume;

	String base64profilePhoto;

	String resumeName;

}
