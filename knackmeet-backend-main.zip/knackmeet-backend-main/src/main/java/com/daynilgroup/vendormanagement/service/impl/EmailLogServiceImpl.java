package com.daynilgroup.vendormanagement.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;

import com.daynilgroup.vendormanagement.entity.EmailLog;
import com.daynilgroup.vendormanagement.repository.EmailLogRepository;
import com.daynilgroup.vendormanagement.service.EmailLogService;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;

@Service
@FieldDefaults(level = AccessLevel.PRIVATE)
public class EmailLogServiceImpl implements EmailLogService{

	@Autowired
	EmailLogRepository emailLogRepository;
	
	@Override
	public JpaRepository<EmailLog, Long> getJpaRepository() {
		return emailLogRepository;
	}

	@Override
	public Page<EmailLog> getList(Pageable pageable) {
		return emailLogRepository.findAll(pageable);
	}

}
