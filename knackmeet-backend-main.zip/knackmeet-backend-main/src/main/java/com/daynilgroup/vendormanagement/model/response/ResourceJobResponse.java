package com.daynilgroup.vendormanagement.model.response;

import java.time.LocalDateTime;
import java.util.List;

import com.daynilgroup.vendormanagement.constants.CurrencyTypeEnum;
import com.daynilgroup.vendormanagement.constants.UserType;

import lombok.AccessLevel;
import lombok.Builder;
import lombok.Data;
import lombok.experimental.FieldDefaults;

@Builder
@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
public class ResourceJobResponse {

	String jobNo;

	Long jobId;
	
	String title;

	Long resourceId;

	String firstname;

	String lastname;

	String category;

	List<String> skills;

	String designation;

	String rate;

	String experience;

	String city;
	
	String country;
	
	String state;

	String gender;
	
	LocalDateTime date;
	
	String resourceStatus;
	
	String jobTitle;
	
	Integer jobMinExperience;
	
	Integer jobMaxExperience;
	
	String jobCity;
	
	String jobState;
	
	String jobCountry;
	
	LocalDateTime jobStartDate;
	
	String workFrom;
	
	String deploymentType;
	
	String resourceAvailability; 
	
	String duration;
	
	String usdRate;
	
	CurrencyTypeEnum jobCurrency;
	
    String jobLocation;
	
	String resourceLocation;
	
	UserType appliedBy;

}
