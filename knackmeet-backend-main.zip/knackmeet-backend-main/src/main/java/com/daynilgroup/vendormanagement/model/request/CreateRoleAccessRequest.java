package com.daynilgroup.vendormanagement.model.request;

import com.daynilgroup.vendormanagement.request.inf.RequestInf;
import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AccessLevel;
import lombok.Builder;
import lombok.Getter;
import lombok.experimental.FieldDefaults;

/**
 *
 * @author Manish
 */
@Getter
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
public class CreateRoleAccessRequest implements RequestInf {
	static final long serialVersionUID = 1L;
	@JsonIgnore
	Long id;

	String access;

}