package com.daynilgroup.vendormanagement.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.ColumnDefault;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 *
 * @author manish
 */
@Entity
@Table(name = "code_lookup_type")
@NoArgsConstructor
@Getter
@Setter
public class CodeLookupType extends BaseEntity {

	private static final long serialVersionUID = 1L;
	@Column(name = "code", unique = true)
	private String code;

	@Column(name = "name", unique = true)
	private String name;

	@ColumnDefault(value = "1")
	@Column(name = "editable", nullable = false)
	private Boolean editable = Boolean.TRUE;

	@ColumnDefault(value = "0")
	@Column(name = "cover_img_require", nullable = false)
	private Boolean coverImgRequire = Boolean.FALSE;

	@JoinColumn(name = "parent_id", referencedColumnName = "id")
	@OneToOne
	private CodeLookupType parentId;

	@ColumnDefault(value = "1")
	@Column(name = "deletable", nullable = false)
	private Boolean deletable = Boolean.TRUE;
}
