package com.daynilgroup.vendormanagement.entity.inf;

import java.util.List;

import com.daynilgroup.vendormanagement.entity.Media;

/**
 *
 * @author Manish
 */
public interface ImageList {

	List<Media> getImages();

	void setImages(List<Media> imageList);
}
