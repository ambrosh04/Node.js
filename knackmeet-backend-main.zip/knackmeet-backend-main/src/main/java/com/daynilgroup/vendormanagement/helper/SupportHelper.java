package com.daynilgroup.vendormanagement.helper;

import java.util.List;

import org.apache.commons.lang3.ObjectUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.daynilgroup.vendormanagement.constants.MediaTypeEnum;
import com.daynilgroup.vendormanagement.constants.SupportStatus;
import com.daynilgroup.vendormanagement.entity.Media;
import com.daynilgroup.vendormanagement.entity.Support;
import com.daynilgroup.vendormanagement.model.request.SupportRequest;
import com.daynilgroup.vendormanagement.model.response.SupportAdminDetailResponse;
import com.daynilgroup.vendormanagement.model.response.SupportListResponse;
import com.daynilgroup.vendormanagement.service.SupportService;
import com.daynilgroup.vendormanagement.util.CommonUtil;
import com.daynilgroup.vendormanagement.util.EntityUtil;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;

@Component
@FieldDefaults(level = AccessLevel.PRIVATE)
public class SupportHelper
		extends AbstractHelper<Support, SupportRequest, SupportListResponse, Object, SupportAdminDetailResponse> {

	@Autowired
	SupportService supportService;
	@Autowired
	AttributeMediaUploadHelper attributeMediaUploadHelper;

	@Autowired
	EntityUtil entityUtil;

	@Override
	public Support getEntity(SupportRequest request) throws Exception {
		Support support;
		if (CommonUtil.isValid(request.getId())) {
			support = supportService.findById(request.getId());
		} else {
			support = new Support();
			support.setTicketId(CommonUtil.getAlphaNumericString());
		}
		support.setVendorId(entityUtil.getCurrentVendorId());
		support.setHeading(request.getHeading());
		support.setDescription(request.getDescription());
		support.setStatus(SupportStatus.PENDING);

		if (!ObjectUtils.isEmpty(request.getBase64attachmentName())) {
			if (request.getBase64attachmentName().contains(".png") || request.getBase64attachmentName().contains(".jpg")
					|| request.getBase64attachmentName().contains(".jpeg")) {

				Media media = attributeMediaUploadHelper.uploadMedia(request.getBase64attachmentName(),
						support.getBase64attachment(), request.getBase64attachment(), MediaTypeEnum.IMAGE);
				support.setBase64attachment(media);
			} else if (request.getBase64attachmentName().contains(".pdf")
					|| request.getBase64attachmentName().contains(".docx")) {

				int indexOf = request.getBase64attachmentName().indexOf(".");
				String resumeName = request.getBase64attachmentName().substring(0, indexOf);
				Media media = attributeMediaUploadHelper.uploadMediaForResume(request.getBase64attachmentName(),
						support.getBase64attachment(), request.getBase64attachment(), resumeName,
						MediaTypeEnum.DOCUMENT);
				support.setBase64attachment(media);
			}
		}
		return support;
	}

	@Override
	public List<SupportListResponse> getListResponse(List<Support> entityList) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object getDetailResponse(Support entity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public SupportAdminDetailResponse getDetailForAdminResponse(Support entity) {
		// TODO Auto-generated method stub
		return null;
	}

}
