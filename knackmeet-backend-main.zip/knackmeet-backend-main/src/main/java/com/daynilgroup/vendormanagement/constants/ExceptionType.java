package com.daynilgroup.vendormanagement.constants;

public enum ExceptionType {
	INFO,
	DEBUG,
	ERROR
}
