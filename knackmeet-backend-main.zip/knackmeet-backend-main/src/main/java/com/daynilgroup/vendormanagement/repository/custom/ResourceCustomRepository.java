
package com.daynilgroup.vendormanagement.repository.custom;

import com.daynilgroup.vendormanagement.model.pag.PageModel;
import com.daynilgroup.vendormanagement.model.request.ResourceFilterRequest;

public interface ResourceCustomRepository {
	
	PageModel getResourceFilterList(ResourceFilterRequest resourceFilterRequest);
}
