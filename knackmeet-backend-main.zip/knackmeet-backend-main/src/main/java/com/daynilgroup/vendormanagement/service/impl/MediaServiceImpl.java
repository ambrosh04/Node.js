package com.daynilgroup.vendormanagement.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;

import com.daynilgroup.vendormanagement.repository.MediaRepository;
import com.daynilgroup.vendormanagement.service.MediaService;

/**
 *
 * @author Manish
 */
@Service("mediaService")
public class MediaServiceImpl implements MediaService {

	@Autowired
	private MediaRepository mediaRepository;

	@Override
	public JpaRepository getJpaRepository() {
		return mediaRepository;
	}

	@Override
	public void deleteMedia(String path) {
		mediaRepository.deleteMedia(path);
	}

	@Override
	public Boolean doesExists(String path) {
		return mediaRepository.isExist(path);
	}

}