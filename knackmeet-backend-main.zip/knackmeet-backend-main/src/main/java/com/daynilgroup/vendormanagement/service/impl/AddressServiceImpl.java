package com.daynilgroup.vendormanagement.service.impl;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.daynilgroup.vendormanagement.entity.Address;
import com.daynilgroup.vendormanagement.model.response.DropdownResponse;
import com.daynilgroup.vendormanagement.repository.AddressRepository;
import com.daynilgroup.vendormanagement.service.AddressService;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;

@Service
@FieldDefaults(level = AccessLevel.PRIVATE)
public class AddressServiceImpl implements AddressService {

	@Autowired
	AddressRepository addressRepository;

	@Override
	public JpaRepository<Address, Long> getJpaRepository() {
		return addressRepository;
	}

	@Override
	public Page<Address> findAll(Pageable pageable) {
		return addressRepository.findAllByDeletedFalse(pageable);
	}

	@Override
	public Address findByCountryIdAndStateId(Long countryId, Long stateId) {
		return addressRepository.findByCountryIdAndStateId(countryId, stateId);
	}

	@Override
	public Set<DropdownResponse> getAddressDropdown() {
		Set<DropdownResponse> dropdownResponses = new HashSet<>();
		Set<Address> addresses = addressRepository.findAllByDeletedFalse();
		if (!CollectionUtils.isEmpty(addresses)) {
			addresses.stream().forEach(address -> {
				dropdownResponses.add(new DropdownResponse(address.getId(), address.getState().getName() + ", " + address.getCountry().getName()));
			});
		}
		return dropdownResponses;
	}

	@Override
	public Set<DropdownResponse> getCountryAndStateDropdown() {
		Set<DropdownResponse> dropdownResponses = new HashSet<>();
		Set<Address> addresses = addressRepository.findAllByDeletedFalse();
		if (!CollectionUtils.isEmpty(addresses)) {

			addresses.stream().forEach(address -> {
				dropdownResponses
						.add(new DropdownResponse(address.getCountry().getId() + "-" + address.getState().getId(),
								address.getCountry().getName() + ", " + address.getState().getName()));
			});
		}
		
		return dropdownResponses;
	}

}
