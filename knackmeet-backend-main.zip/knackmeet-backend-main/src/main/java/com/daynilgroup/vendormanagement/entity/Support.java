package com.daynilgroup.vendormanagement.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.daynilgroup.vendormanagement.constants.SupportStatus;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

/**
 *
 * @author manish
 */
@Getter
@Setter
@Entity
@Table(name = "support")
@FieldDefaults(level = AccessLevel.PRIVATE)
public class Support extends BaseEntity {

	static final long serialVersionUID = 1L;

	@Column(name = "ticket_id")
	String ticketId;

	@Column(name = "heading", nullable = false)
	@Lob
	String heading;

	@Column(name = "description", nullable = false)
	@Lob
	String description;

	@Enumerated(EnumType.STRING)
	@Column(name = "support_status", nullable = false)
	SupportStatus status;

	@JoinColumn(name = "attachment_id", referencedColumnName = "id")
	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	Media base64attachment;

	@Column(name = "vendor_id")
	Long vendorId;

}
