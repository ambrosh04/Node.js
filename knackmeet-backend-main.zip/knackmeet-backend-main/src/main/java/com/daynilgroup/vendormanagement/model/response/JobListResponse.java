package com.daynilgroup.vendormanagement.model.response;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

import com.daynilgroup.vendormanagement.constants.CurrencyTypeEnum;
import com.daynilgroup.vendormanagement.constants.DeploymentTypeEnum;
import com.daynilgroup.vendormanagement.constants.RateTypeEnum;
import com.daynilgroup.vendormanagement.constants.ResourceStatusEnum;
import com.daynilgroup.vendormanagement.constants.StatusEnum;
import com.daynilgroup.vendormanagement.constants.TimeZoneEnum;
import com.daynilgroup.vendormanagement.constants.UserType;
import com.daynilgroup.vendormanagement.entity.CodeLookup;
import com.daynilgroup.vendormanagement.entity.User;
import com.daynilgroup.vendormanagement.model.inf.DateUtil;
import com.daynilgroup.vendormanagement.util.CommonUtil;

import lombok.AccessLevel;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

@Data
@NoArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class JobListResponse implements Serializable {

	static final long serialVersionUID = 1L;

	Long id;

	Long jobId;

	List<String> skills;

	String state;

	String country;

	String title;

	String workFrom;

	String rateType;

	BigDecimal minRate;

	BigDecimal maxRate;

	Integer noOfResource;

	Integer minExperience;

	Integer maxExperience;

	LocalDateTime startDate;

	LocalDateTime postedDate;

	String currencyType;

	String status;

	LocalDateTime updatedOn;

	String agencyName;

	Long applicantsCount;

	Boolean active;

	Long userId;

	String resourceStatus;

	String duration;

	Long vendorId;
	
	LocalDateTime closedOn;
	
	String usdRate;
	
	String rate;
	
	String location;
	
	UserType appliedBy;
	
	String timeZoneEnum;

	String startTime;

	String endTime;


	// RESOURCE_FILTER_LIST_BY_resourceId
	public JobListResponse(Long id, Long jobId, String countryName, String title,
			DeploymentTypeEnum workFrom, RateTypeEnum rateType, BigDecimal minRate, BigDecimal maxRate,
			Integer noOfResource, Integer minExperience, Integer maxExperience, LocalDateTime startDate,
			LocalDateTime postedDate, CurrencyTypeEnum currencyType, StatusEnum status,
			ResourceStatusEnum resourceStatus, String duration, String agencyName, Long vendorId,BigDecimal usdRate,BigDecimal rate,String location,User user,Long userId) {
		super();
		this.id = id;
		this.jobId = jobId;
		this.country = countryName;
		this.title = title;
		this.workFrom = workFrom.getDisplayName();
		this.rateType = rateType.getDisplayName();
		this.minRate = minRate;
		this.maxRate = maxRate;
		this.noOfResource = noOfResource;
		this.minExperience = minExperience;
		this.maxExperience = maxExperience;
		this.startDate = DateUtil.getUTCToUserTimezone(startDate);
		this.postedDate = DateUtil.getUTCToUserTimezone(postedDate);
		this.currencyType = currencyType.getDisplayName();
		this.status = status.getDisplayName();
		this.resourceStatus = resourceStatus.getDisplayName();
		this.duration = duration;
		this.agencyName = agencyName;
		this.vendorId = vendorId;
		this.usdRate=usdRate!=null?CommonUtil.getRateStr(CurrencyTypeEnum.USD.getDisplayName(), usdRate,rateType.getDisplayName()):null;
		this.rate=rate!=null?CommonUtil.getRateStr(CurrencyTypeEnum.INR.getDisplayName(), rate,rateType.getDisplayName()):null;
        this.location=location;
        this.appliedBy=user!=null? user.getUserType():null;
		this.userId=userId;
	}

	public JobListResponse(Long id, String countryName, String title, DeploymentTypeEnum workFrom,
			RateTypeEnum rateType, BigDecimal minRate, BigDecimal maxRate, Integer noOfResource, Integer minExperience,
			Integer maxExperience, LocalDateTime startDate, LocalDateTime postedDate, CurrencyTypeEnum currencyType,
			StatusEnum status,String location) {
		super();
		this.id = id;
		this.country = countryName;
		this.title = title;
		this.workFrom = workFrom.getDisplayName();
		this.rateType = rateType.getDisplayName();
		this.minRate = minRate;
		this.maxRate = maxRate;
		this.noOfResource = noOfResource;
		this.minExperience = minExperience;
		this.maxExperience = maxExperience;
		this.startDate = DateUtil.getUTCToUserTimezone(startDate);
		this.postedDate = DateUtil.getUTCToUserTimezone(postedDate);
		this.currencyType = currencyType.getDisplayName();
		this.status = status != null ? status.getDisplayName() : null;
		this.location=location;

	}

	// /advanceSearch/search
	public JobListResponse(Long id,  String countryName, String title, DeploymentTypeEnum workFrom,
			RateTypeEnum rateType, BigDecimal minRate, BigDecimal maxRate, Integer noOfResource, Integer minExperience,
			Integer maxExperience, LocalDateTime startDate, LocalDateTime postedDate, CurrencyTypeEnum currencyType,
			LocalDateTime updatedOn, StatusEnum status,String location,CodeLookup duration) {
		super();
		this.id = id;
		this.country = countryName;
		this.title = title;
		this.workFrom = workFrom.getDisplayName();
		this.rateType = rateType.getDisplayName();
		this.minRate = minRate;
		this.maxRate = maxRate;
		this.noOfResource = noOfResource;
		this.minExperience = minExperience;
		this.maxExperience = maxExperience;
		this.startDate = DateUtil.getUTCToUserTimezone(startDate);
		this.postedDate = DateUtil.getUTCToUserTimezone(postedDate);
		this.currencyType = currencyType.getDisplayName();
		this.updatedOn = DateUtil.getUTCToUserTimezone(updatedOn);
		this.status = status != null ? status.getDisplayName() : null;
		this.location=location;
		this.duration= duration !=null?duration.getName():null;
	}

	// used in getFilterJobs method of JobRestController
	public JobListResponse(Long id, String countryName, String title, DeploymentTypeEnum workFrom,
			RateTypeEnum rateType, BigDecimal minRate, BigDecimal maxRate, Integer noOfResource, Integer minExperience,
			Integer maxExperience, LocalDateTime startDate, LocalDateTime postedDate, CurrencyTypeEnum currencyType,
			StatusEnum status,Boolean active,LocalDateTime closedOn,String location,CodeLookup duration) {
		super();
		this.id = id;
		this.country = countryName;
		this.title = title;
		this.workFrom = workFrom.getDisplayName();
		this.rateType = rateType.getDisplayName();
		this.minRate = minRate;
		this.maxRate = maxRate;
		this.noOfResource = noOfResource;
		this.minExperience = minExperience;
		this.maxExperience = maxExperience;
		this.startDate = DateUtil.getUTCToUserTimezone(startDate);
		this.postedDate = DateUtil.getUTCToUserTimezone(postedDate);
		this.currencyType = currencyType.getDisplayName();
		this.status = status != null ? status.getDisplayName() : null;
		this.active = active;
		this.closedOn=DateUtil.getUTCToUserTimezone(closedOn);
		this.location=location;
		this.duration= duration !=null?duration.getName():null;
	}

}
