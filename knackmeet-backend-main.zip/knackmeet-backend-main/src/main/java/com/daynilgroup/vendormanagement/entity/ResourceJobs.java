/**
 * 
 */
package com.daynilgroup.vendormanagement.entity;

import java.math.BigDecimal;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.daynilgroup.vendormanagement.constants.RateTypeEnum;
import com.daynilgroup.vendormanagement.constants.ResourceStatusEnum;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

/**
 * @author Prerana
 *
 */
@Getter
@Setter
@Entity
@Table(name = "resource_jobs")
@FieldDefaults(level = AccessLevel.PRIVATE)
public class ResourceJobs extends BaseEntity {

	static final long serialVersionUID = 1L;

	@JoinColumn(name = "resource_id", referencedColumnName = "id", nullable = false)
	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	Resource resource;

	@JoinColumn(name = "job_id", referencedColumnName = "id", nullable = false)
	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	Job job;

	@Enumerated(EnumType.STRING)
	@Column(name = "resource_status",nullable = false)
	ResourceStatusEnum resourceStatus;

	@Column(name = "reason_message")
	String reasonMessage;
	
	@Column(name="resource_inr_rate")
	BigDecimal resourceInrRate;
	
	@Column(name="resource_usd_rate")
	BigDecimal resourceUsdRate;
	
	@OneToMany(mappedBy = "refId", cascade = CascadeType.ALL,fetch = FetchType.LAZY)
	List<CodeLookUpRelation> codeLookUpRelation;
	
	@JoinColumn(name = "applied_by", referencedColumnName = "id")
	@ManyToOne(fetch = FetchType.LAZY)
	User appliedBy;
	
	@Enumerated(EnumType.STRING)
	@Column(name="resource_inr_rate_type")
	RateTypeEnum resourceInrRateType;
	
	@Enumerated(EnumType.STRING)
	@Column(name="resource_usd_rate_type")
	RateTypeEnum resourceUsdRateType;
}
