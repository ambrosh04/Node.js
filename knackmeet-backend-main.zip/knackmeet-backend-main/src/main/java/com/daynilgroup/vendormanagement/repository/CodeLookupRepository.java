
/**
* 
*/
package com.daynilgroup.vendormanagement.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.daynilgroup.vendormanagement.entity.CodeLookup;

/**
 * @author Prerana
 *
 */
@Repository
public interface CodeLookupRepository extends JpaRepository<CodeLookup, Long> {

	@Query("Select COUNT(c.id) > 0 FROM CodeLookup c  where (c.deleted=false or c.deleted IS NULL) and c.name=?1 and c.type.id=?2 and (?3 IS NULL OR c.id<>?3)")
	Boolean existsByNameAndTypeIdAndIdNot(String name, Long typeId, Long id);

	Page<CodeLookup> findByDeletedFalseOrDeletedIsNull(Pageable pageable);

	@Modifying
	@Transactional
	@Query("Update CodeLookup o set o.deleted=true where o.id=:id ")
	void delete(Long id);

	List<CodeLookup> getByType_codeAndActiveTrueAndDeletedFalseOrDeletedIsNull(String code);
	
	Page<CodeLookup> getByType_codeAndActiveTrueAndDeletedFalseOrDeletedIsNull(String code, Pageable pageable);


	Page<CodeLookup> findByNameContainsAndDeletedFalseOrDeletedIsNull(String name, Pageable pageable);

	Page<CodeLookup> findByNameContainsAndTypeIdAndDeletedFalseOrDeletedIsNull(String name, Long typeId,
			Pageable pageable);

	List<CodeLookup> findByTypeIdAndDeletedFalseOrDeletedIsNull(Long typeId);
	
	@Query("Select c FROM CodeLookup c  where (c.deleted=false or c.deleted IS NULL) and c.type.code in (:code1,:code2)")
	List<CodeLookup> getByType_codeAndType_codeAndActiveTrueAndDeletedFalseOrDeletedIsNull(String code1,String code2);
	

	@Query("SELECT c FROM CodeLookup c  WHERE (c.deleted=false OR c.deleted IS NULL) AND c.type.code=:code AND c.parentId.id =:parentId")
	List<CodeLookup> findAllByCodeAndParentId(String code, Long parentId);
	
	@Query("Select c FROM CodeLookup c  where (c.deleted=false or c.deleted IS NULL) and c.type.code=:code")
	List<CodeLookup> getByTypeCodeAndDeletedFalseOrDeletedIsNull(String code);
	
	@Query("Select c FROM CodeLookup c  WHERE (c.deleted=false OR c.deleted IS NULL) AND c.type.code=:code AND (:name IS NULL OR c.name LIKE %:name%) ORDER BY c.name ASC")
	List<CodeLookup> getByType_codeAndNameLikeOrNameIsNullAndActiveTrueAndDeletedFalseOrDeletedIsNull(String code,String name);
	
	@Query("Select c FROM CodeLookup c  where (c.deleted=false or c.deleted IS NULL) and (:name IS NULL OR  REPLACE(c.name, ' ', '') LIKE %:name%) and (c.type.code=:code)")
	List<CodeLookup> getByTypeCodeAndDeletedFalseOrDeletedIsNull(String code,String name);
}
