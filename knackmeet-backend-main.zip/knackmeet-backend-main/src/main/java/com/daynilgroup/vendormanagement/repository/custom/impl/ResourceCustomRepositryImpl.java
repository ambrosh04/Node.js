/**
 * 
 */
package com.daynilgroup.vendormanagement.repository.custom.impl;

import java.math.BigDecimal;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Order;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.persistence.criteria.Selection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.daynilgroup.vendormanagement.constants.CurrencyTypeEnum;
import com.daynilgroup.vendormanagement.constants.StaticConfigurationEnum;
import com.daynilgroup.vendormanagement.constants.StatusEnum;
import com.daynilgroup.vendormanagement.entity.CodeLookup;
import com.daynilgroup.vendormanagement.entity.CodeLookup_;
import com.daynilgroup.vendormanagement.entity.Job_;
import com.daynilgroup.vendormanagement.entity.Resource;
import com.daynilgroup.vendormanagement.entity.ResourceSkillsCodeLookup;
import com.daynilgroup.vendormanagement.entity.ResourceSkillsCodeLookup_;
import com.daynilgroup.vendormanagement.entity.Resource_;
import com.daynilgroup.vendormanagement.entity.Vendor;
import com.daynilgroup.vendormanagement.entity.Vendor_;
import com.daynilgroup.vendormanagement.model.pag.PageModel;
import com.daynilgroup.vendormanagement.model.request.ResourceFilterRequest;
import com.daynilgroup.vendormanagement.model.response.ResourceListResponse;
import com.daynilgroup.vendormanagement.repository.custom.ResourceCustomRepository;
import com.daynilgroup.vendormanagement.service.StaticConfigurationService;
import com.daynilgroup.vendormanagement.util.CommonUtil;
import com.daynilgroup.vendormanagement.util.CriteriaUtil;
import com.daynilgroup.vendormanagement.util.EntityUtil;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;

/**
 * @author Prerana
 *
 */
@Repository
@FieldDefaults(level = AccessLevel.PRIVATE)
public class ResourceCustomRepositryImpl implements ResourceCustomRepository {

	@PersistenceContext
	EntityManager entityManager;

	@Autowired
	CriteriaUtil criteriaUtil;

	@Autowired
	EntityUtil entityUtil;
	
	@Autowired
	private StaticConfigurationService staticConfigurationService;

	@Override
	public PageModel getResourceFilterList(ResourceFilterRequest resourceFilterRequest) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
//		CriteriaQuery<Resource> cq = criteriaBuilder.createQuery(Resource.class);
//		Root<Resource> root = cq.from(Resource.class);
//		cq.orderBy(criteriaBuilder.desc(root.get(Resource_.CREATED_ON)));

		CriteriaQuery<ResourceListResponse> listQuery = criteriaBuilder.createQuery(ResourceListResponse.class);
		populateQuery(criteriaBuilder, listQuery, resourceFilterRequest, false);

		CriteriaQuery<Long> countQuery = criteriaBuilder.createQuery(Long.class);
		populateQuery(criteriaBuilder, countQuery, resourceFilterRequest, true);

		return criteriaUtil.getPageModel(listQuery, countQuery, resourceFilterRequest.getPaginationRequestModel());
	}

	private void populateQuery(CriteriaBuilder criteriaBuilder, CriteriaQuery<?> criteriaQuery,
			ResourceFilterRequest resourceFilterRequest, boolean isCount) {

		Root<Resource> resource = criteriaQuery.from(Resource.class);
		Join<Resource, Vendor> vendor = resource.join(Resource_.vendor);
		Join<Resource, CodeLookup> availability = resource.join(Resource_.availability);
		Join<Resource, CodeLookup> designation = resource.join(Resource_.designation);
		Join<Resource, CodeLookup> country = resource.join(Resource_.COUNTRY,JoinType.LEFT);

		List<Predicate> predicates = criteriaUtil.getDefaultPredicates(criteriaBuilder, resource);
		criteriaUtil.addPredicates(criteriaBuilder, predicates, vendor.get(Vendor_.ID),
				resourceFilterRequest.getVendorId() != null ? resourceFilterRequest.getVendorId()
						: entityUtil.getCurrentVendorId());
		criteriaUtil.addPredicates(criteriaBuilder, predicates, resource.get(Resource_.NAME),
				resourceFilterRequest.getNameOrCategory());
		

		if (!CommonUtil.isEmpty(resourceFilterRequest.getSkillsCodeLookups())) {
			for (Long id : resourceFilterRequest.getSkillsCodeLookups()) {
				Join<Resource, ResourceSkillsCodeLookup> resourceSkills = resource
						.join(Resource_.resourceSkillsCodeLookups, JoinType.LEFT);
				Join<ResourceSkillsCodeLookup, CodeLookup> skills = resourceSkills
						.join(ResourceSkillsCodeLookup_.CODE_LOOKUP, JoinType.LEFT);
				predicates.add(criteriaBuilder.equal(skills.get(CodeLookup_.ID), id));
			}

		}
		criteriaUtil.addPredicates(criteriaBuilder, predicates, designation.get(CodeLookup_.NAME),
				resourceFilterRequest.getDesignation());
		criteriaUtil.addPredicates(criteriaBuilder, predicates, resource.get(Resource_.GENDER),
				resourceFilterRequest.getGender());
		criteriaUtil.addPredicates(criteriaBuilder, predicates, availability.get(CodeLookup_.ID),
				resourceFilterRequest.getAvailabilityId());
		criteriaUtil.addPredicates(criteriaBuilder, predicates, country.get(CodeLookup_.ID),
				resourceFilterRequest.getCountryId());
		criteriaUtil.addPredicates(criteriaBuilder, predicates, resource.get(Resource_.DEPLOYMEN_TYPE),
				resourceFilterRequest.getDeploymenType());

		if (resourceFilterRequest.getStatus() != null && StatusEnum.ON_HOLD.equals(resourceFilterRequest.getStatus())) {
			predicates.add(criteriaBuilder.notEqual(resource.get(Job_.STATUS_ENUM), StatusEnum.REJECTED));
			criteriaUtil.addPredicates(criteriaBuilder, predicates, resource.get(Resource_.ACTIVE), Boolean.FALSE);
		} else if (resourceFilterRequest.getStatus() != null
				&& (StatusEnum.VERIFIED.equals(resourceFilterRequest.getStatus())
						|| StatusEnum.UNVERIFIED.equals(resourceFilterRequest.getStatus()))) {
			criteriaUtil.addPredicates(criteriaBuilder, predicates, resource.get(Resource_.STATUS_ENUM),
					resourceFilterRequest.getStatus());
			criteriaUtil.addPredicates(criteriaBuilder, predicates, resource.get(Resource_.ACTIVE), Boolean.TRUE);

		} else if (resourceFilterRequest.getStatus() != null
				&& StatusEnum.REJECTED.equals(resourceFilterRequest.getStatus())) {
			criteriaUtil.addPredicates(criteriaBuilder, predicates, resource.get(Resource_.STATUS_ENUM),
					resourceFilterRequest.getStatus());
		}

		Expression<Integer> sum = criteriaBuilder.sum(resource.get(Resource_.MONTHS_EXPERIENCE),
				criteriaBuilder.prod(resource.get(Resource_.YEARS_EXPERIENCE), criteriaBuilder.literal(12)));
		if (CommonUtil.isValid(resourceFilterRequest.getMinExp())
				&& CommonUtil.isValid(resourceFilterRequest.getMaxExp())) {
			criteriaUtil.addPredicates(criteriaBuilder, predicates, sum, resourceFilterRequest.getMinExp() * 12,
					resourceFilterRequest.getMaxExp() * 12);
		} else if (CommonUtil.isValid(resourceFilterRequest.getMinExp())
				&& !CommonUtil.isValid(resourceFilterRequest.getMaxExp())) {
			criteriaUtil.addPredicatesGreaterThenOrEqualTo(criteriaBuilder, predicates, sum,
					resourceFilterRequest.getMinExp() * 12);
		} else if (!CommonUtil.isValid(resourceFilterRequest.getMinExp())
				&& CommonUtil.isValid(resourceFilterRequest.getMaxExp())) {
			criteriaUtil.addPredicatesLessThenOrEqualTo(criteriaBuilder, predicates, sum,
					resourceFilterRequest.getMaxExp() * 12);
		}

		BigDecimal percentageValue = new BigDecimal(staticConfigurationService.findByName(StaticConfigurationEnum.RESOURCE_COMMISSION).getValue()).divide(new BigDecimal(100));

		if (resourceFilterRequest.getCurrencyTypeEnum()!=null&& resourceFilterRequest.getCurrencyTypeEnum().equals(CurrencyTypeEnum.INR)) {
			if(resourceFilterRequest.getMinRate() != null&&resourceFilterRequest.getMaxRate() != null)
			{
				Expression<BigDecimal> rateAfterCommission = criteriaBuilder.sum(resource.get(Resource_.RATE),
						criteriaBuilder.prod(resource.get(Resource_.RATE), criteriaBuilder.literal(percentageValue))).as(BigDecimal.class);
			criteriaUtil.addPredicatesGreaterThenOrEqualTo(criteriaBuilder, predicates,rateAfterCommission,
					resourceFilterRequest.getMinRate());
			criteriaUtil.addPredicatesLessThenOrEqualTo(criteriaBuilder, predicates, rateAfterCommission,
					resourceFilterRequest.getMaxRate());
			}
			predicates.add(criteriaBuilder.isNotNull(resource.get(Resource_.RATE)));
			criteriaUtil.addPredicates(criteriaBuilder, predicates, resource.get(Resource_.RATE_TYPE_ENUM), 
					resourceFilterRequest.getRateType());
			
		}
		else if (resourceFilterRequest.getCurrencyTypeEnum()!=null && resourceFilterRequest.getCurrencyTypeEnum().equals(CurrencyTypeEnum.USD)) {
			if(resourceFilterRequest.getMinRate() != null&&resourceFilterRequest.getMaxRate() != null)
			{
				Expression<BigDecimal> rateAfterCommission = criteriaBuilder.sum(resource.get(Resource_.USD_RATE),
						criteriaBuilder.prod(resource.get(Resource_.USD_RATE), criteriaBuilder.literal(percentageValue))).as(BigDecimal.class);
			criteriaUtil.addPredicatesGreaterThenOrEqualTo(criteriaBuilder, predicates, rateAfterCommission,
					resourceFilterRequest.getMinRate());
			criteriaUtil.addPredicatesLessThenOrEqualTo(criteriaBuilder, predicates, rateAfterCommission,
					resourceFilterRequest.getMaxRate());
			}
			predicates.add(criteriaBuilder.isNotNull(resource.get(Resource_.USD_RATE)));
			criteriaUtil.addPredicates(criteriaBuilder, predicates, resource.get(Resource_.USD_RATE_TYPE), 
					resourceFilterRequest.getUsdRateType());
		}
		
		//clause added for rateType and USD rateType
		if (resourceFilterRequest.getRateTypeWithoutCT() != null) {
			Predicate rateTypePredicate = criteriaBuilder.equal(resource.get(Resource_.RATE_TYPE_ENUM),
					resourceFilterRequest.getRateTypeWithoutCT());
			Predicate usdRateTypePredicate = criteriaBuilder.equal(resource.get(Resource_.USD_RATE_TYPE),
					resourceFilterRequest.getRateTypeWithoutCT());
			predicates.add(criteriaBuilder.or(criteriaBuilder.and(criteriaBuilder.isNotNull(resource.get(Resource_.RATE)),rateTypePredicate),
			        criteriaBuilder.and(criteriaBuilder.isNotNull(resource.get(Resource_.USD_RATE)), usdRateTypePredicate)));
		}
		
		Selection<?> selection;
		if (isCount) {
			selection = criteriaBuilder.countDistinct(resource);
		} else {
			
			criteriaQuery.groupBy(resource.get(Resource_.ID));
			selection = criteriaBuilder.construct(ResourceListResponse.class, resource.get(Resource_.ID),
					resource.get(Resource_.FIRST_NAME), resource.get(Resource_.LAST_NAME),
					availability.get(CodeLookup_.NAME),
					designation.get(CodeLookup_.NAME), resource.get(Resource_.RATE),
					resource.get(Resource_.CURRENCY_TYPE), resource.get(Resource_.RATE_TYPE_ENUM),
					resource.get(Resource_.YEARS_EXPERIENCE), resource.get(Resource_.MONTHS_EXPERIENCE),
					country.get(CodeLookup_.NAME),
					resource.get(Resource_.GENDER), resource.get(Resource_.ACTIVE),
					resource.get(Resource_.HIGHER_EDUCATION), resource.get(Resource_.PASSING_YEAR),
					resource.get(Resource_.STATUS_ENUM),
					resource.get(Resource_.DEPLOYMEN_TYPE),resource.get(Resource_.CREATED_ON),
					resource.get(Resource_.USD_RATE), resource.get(Resource_.USD_RATE_TYPE),resource.get(Resource_.LOCATION));					
		}
		Order order = criteriaBuilder.desc(resource.get(Resource_.LAST_MODIFIED_DATE));
		criteriaUtil.populateCriteriaQuery(criteriaQuery, selection, predicates, order);


	}
}
