package com.daynilgroup.vendormanagement.model.request;

import java.util.List;

import com.daynilgroup.vendormanagement.constants.RoleTypeEnum;
import com.daynilgroup.vendormanagement.request.inf.RequestInf;

import lombok.AccessLevel;
import lombok.Builder;
import lombok.Getter;
import lombok.experimental.FieldDefaults;

/**
 *
 * @author Manish
 */
@Getter
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
public class CreateRoleRequest implements RequestInf {

	static final long serialVersionUID = 1L;

	Long id;

	String name;

	Boolean active;

	RoleTypeEnum type;

	List<String> access;

}