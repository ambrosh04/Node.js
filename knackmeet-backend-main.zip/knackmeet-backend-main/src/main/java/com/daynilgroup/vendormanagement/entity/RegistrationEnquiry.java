package com.daynilgroup.vendormanagement.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.daynilgroup.vendormanagement.constants.TimeZoneEnum;

import lombok.AccessLevel;
import lombok.Data;
import lombok.experimental.FieldDefaults;

@Data
@Entity
@Table(name="registration_enquiry")
@FieldDefaults(level = AccessLevel.PRIVATE)
public class RegistrationEnquiry extends BaseEntity{

	private static final long serialVersionUID = 1L;
	
	@Column(name = "first_name",nullable = false)
	String firstName;
	
	@Column(name="last_name",nullable = false)
	String lastName;
	
	@Column(name="email_id",nullable = false)
	String emailId;
	
	@Column(name="mobile_number",nullable = false)
	String mobileNumber;
	
	@Enumerated(EnumType.STRING)
	@Column(name = "time_zone", nullable = false)
	TimeZoneEnum timeZone;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "country_code_id", referencedColumnName = "id")
	CodeLookup countryCode;

}
