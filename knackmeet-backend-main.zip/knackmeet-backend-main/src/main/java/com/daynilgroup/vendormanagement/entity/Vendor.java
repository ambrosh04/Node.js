/**
 * 
 */
package com.daynilgroup.vendormanagement.entity;

import java.time.LocalDateTime;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

/**
 * @author Prerana
 *
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "vendor")
@FieldDefaults(level = AccessLevel.PRIVATE)
public class Vendor extends BaseEntity {

	static final long serialVersionUID = 1L;

	@Column(name = "agency_name", nullable = false)
	String agencyName;

	@Column(name = "website")
	String website;

	@Column(name = "incorparation_date")
	LocalDateTime incorparationDate;

	@Column(name = "team_strength")
	Long teamStrength;

	@OneToOne(targetEntity = User.class, fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "user_id", nullable = false)
	User user;

	@OneToMany(mappedBy = "vendor", fetch = FetchType.LAZY)
	List<Resource> resources;

	@OneToMany(mappedBy = "vendor", fetch = FetchType.LAZY)
	List<Job> job;

	@Column(name = "gst_number")
	String gstNumber;
	
	public String getFullName() {
		String fullName = null;
		if (this.user != null) {
			fullName = this.user.getFirstName() + " " + this.user.getLastName();
		}
		return fullName;
	}

	@JoinColumn(name = "vendor_logo", referencedColumnName = "id")
	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	Media vendorLogo;

	@JoinColumn(name = "proof_of_identity", referencedColumnName = "id")
	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	Media proofOfIdentity;

	@JoinColumn(name = "Proof_of_registration", referencedColumnName = "id")
	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	Media proofOfRegistration;

	@Column(name = "director_name")
	String directorName;

	@Column(name = "location")
	String location;
	
	
	@Column(name = "about")
	String about;
	
	@OneToMany(fetch = FetchType.LAZY,cascade = CascadeType.ALL, mappedBy = "vendor")
	List<VendorPortfolio> portfolios;

	@Column(name = "reason")
	@Lob
	String reason;
	
	@Column(name="company_primary_number", nullable = false)
	String companyPrimaryNumber;

	@Column(name="company_primary_email", nullable = false)
	String companyPrimaryEmail;
	
	@Column(name="company_description")
	@Lob
	String companyDescription;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "country_code_id", referencedColumnName = "id")
	CodeLookup countryCode;
	
	@OneToMany(mappedBy = "refId", cascade = CascadeType.ALL,fetch = FetchType.LAZY)
	List<CodeLookUpRelation> codeLookUpRelation;
	
	@Column(name = "tagline")
	String tagline;
	
	@JoinColumn(name = "banner_id", referencedColumnName = "id")
	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	Media banner;

	@OneToOne(mappedBy = "vendor", fetch = FetchType.LAZY)
	Company company;
}
