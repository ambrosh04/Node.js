package com.daynilgroup.vendormanagement.constants;

public class CodeLookUpConstant {
	
	public static final String DESIGNATION_CODELOOKUP_CODE = "DESIGNATION";
	public static final String AVABILITY_CODELOOKUP_CODE = "AVAILABILITY";
	public static final String CATAGEORY_CODELOOKUP_CODE = "CATEGORY";
	public static final String SKILLS_CODELOOKUP_CODE = "SKILLS";
	public static final String CITY_CODELOOKUP_CODE = "CITY";
	public static final String DURATION_CODELOOKUP_CODE = "DURATION";
	public static final String DEGREE_CODELOOKUP_CODE = "DEGREE";
	public static final String SPECIALIZATION_CODELOOKUP_CODE = "SPECIALIZATION";
	public static final String INDUSTRY_CODELOOKUP_CODE = "INDUSTRY";
	public static final String COMPANY_CODELOOKUP_CODE = "COMPANY";
	public static final String RESOURCE_REJECT_REASON="RESOURCE_REJECT_REASON";
	public static final String JOB_REJECT_REASON ="JOB_REJECT_REASON";
	public static final String RESOURCE_JOBS_WITHDRAW_REASON="RESOURCE_JOBS_WITHDRAW_REASON";
	
}