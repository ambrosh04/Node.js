package com.daynilgroup.vendormanagement.model.response;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.daynilgroup.vendormanagement.constants.CurrencyTypeEnum;
import com.daynilgroup.vendormanagement.constants.DeploymentTypeEnum;
import com.daynilgroup.vendormanagement.constants.Gender;
import com.daynilgroup.vendormanagement.constants.RateTypeEnum;
import com.daynilgroup.vendormanagement.constants.ResourceStatusEnum;
import com.daynilgroup.vendormanagement.constants.StatusEnum;
import com.daynilgroup.vendormanagement.constants.UserType;
import com.daynilgroup.vendormanagement.entity.User;
import com.daynilgroup.vendormanagement.model.inf.DateUtil;
import com.daynilgroup.vendormanagement.service.StaticConfigurationService;
import com.daynilgroup.vendormanagement.util.CommonUtil;

import lombok.AccessLevel;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

@Data
@NoArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class ResourceListResponse {
	
	@Autowired
	StaticConfigurationService staticConfigurationService;

	static final long serialVersionUID = 1L;

	Long id;

	Long resourceId;

	String firstname;

	String lastname;

	String availabilityType;

	String base64MediaString;

	List<String> skills;

	String designation;

	String rate;

	String experience;

	String state;

	String country;

	String gender;

	Boolean active;

	String higherEducation;

	Long passingYear;

	StatusEnum statusEnum;

	String agencyName;

	Long appliedJobCount;

	Long userId;

	LocalDateTime date;

	LocalDateTime updatedOn;

	LocalDateTime createdOn;
	
	String resourceStatus;

	String deploymentType;
	
	Long vendorId;
	
	String usdRate;
	
	String location;
	
	UserType appliedBy;
	
	//RESOURCE_FILTER_LIST_BY_JOB_ID
	public ResourceListResponse(Long id, Long resourceId, String firstname, String lastname, 
			String availabilityType, String designation, BigDecimal rate, CurrencyTypeEnum currencyTypeEnum,
			RateTypeEnum rateTypeEnum, Integer yearExperience, Integer monthExperience, 
			String countryName, Gender gender, Boolean active, String higherEducation,
			Long passingYear, StatusEnum statusEnum, LocalDateTime date,ResourceStatusEnum resourceStatus, DeploymentTypeEnum deploymentType,String agencyName,Long vendorId
            , BigDecimal usdRate,RateTypeEnum usdRateType,String location, User user,Long userId) {
		super();
		this.id = id;
		this.resourceId = resourceId;
		this.firstname = firstname;
		this.lastname = lastname;
		this.availabilityType = availabilityType;
		this.designation = designation;
		this.rate = rate!=null?CommonUtil.getRateStr(CurrencyTypeEnum.INR.getDisplayName(), rate, rateTypeEnum.getDisplayName()):null;
		this.experience = CommonUtil.getExperience(yearExperience, monthExperience);
		this.country = countryName;
		this.gender = gender.getDisplayName();
		this.active = active;
		this.higherEducation = higherEducation;
		this.passingYear = passingYear;
		this.statusEnum = statusEnum;
		this.date = DateUtil.getUTCToUserTimezone(date);
		this.resourceStatus=resourceStatus.getDisplayName();
		this.deploymentType= deploymentType.getDisplayName();
		this.agencyName =agencyName;
		this.vendorId=vendorId;
		this.usdRate=usdRate!=null?CommonUtil.getRateStr(CurrencyTypeEnum.USD.getDisplayName(), usdRate,usdRateType.getDisplayName()):null;
		this.location=location;
		this.appliedBy=user!=null? user.getUserType():null;
		this.userId=userId;
	}

	
	//Used in getResourceList method of AdvanceSearchRestController.
	public ResourceListResponse(Long id, String firstname, String lastname, String availabilityType,
			String designation, BigDecimal rate, CurrencyTypeEnum currencyTypeEnum, RateTypeEnum rateTypeEnum,
			Integer yearExperience, Integer monthExperience,  String countryName,
			Gender gender, Boolean active, String higherEducation, Long passingYear, StatusEnum statusEnum,LocalDateTime createdOn, LocalDateTime updatedOn,
			String agencyName, BigDecimal usdRate,RateTypeEnum usdRateType,DeploymentTypeEnum deploymentType,String location) {
		super();
		this.id = id;
		this.firstname = firstname;
		this.lastname = lastname;
		this.availabilityType = availabilityType;
		this.designation = designation;
		this.rate = rate!=null?CommonUtil.getRateStr(CurrencyTypeEnum.INR.getDisplayName(),rate, rateTypeEnum.getDisplayName()):null;		
		this.experience = CommonUtil.getExperience(yearExperience, monthExperience);
		this.country = countryName;
		this.gender = gender.getDisplayName();
		this.active = active;
		this.higherEducation = higherEducation;
		this.passingYear = passingYear;
		this.statusEnum = statusEnum;
		this.createdOn = DateUtil.getUTCToUserTimezone(createdOn);
		this.updatedOn = DateUtil.getUTCToUserTimezone(updatedOn);
		this.agencyName = agencyName;
		this.usdRate=usdRate!=null?CommonUtil.getRateStr(CurrencyTypeEnum.USD.getDisplayName(),usdRate , usdRateType.getDisplayName()):null;
		this.deploymentType=deploymentType.getDisplayName();
		this.location=location;
	}
	
	

	public ResourceListResponse(Long id, String firstname, String lastname, String availabilityType,
			String base64MediaString, String designation, BigDecimal rate, CurrencyTypeEnum currencyTypeEnum,
			RateTypeEnum rateTypeEnum, Integer yearExperience, Integer monthExperience,	String stateName, String countryName, Gender gender, Boolean active, String higherEducation,
			Long passingYear, StatusEnum statusEnum) {
		super();
		this.id = id;
		this.firstname = firstname;
		this.lastname = lastname;
		this.availabilityType = availabilityType;
		this.base64MediaString = base64MediaString;
		this.designation = designation;
		this.rate = CommonUtil.getRateStr(currencyTypeEnum.getDisplayName(), rate, rateTypeEnum.getDisplayName());
		this.experience = CommonUtil.getExperience(yearExperience, monthExperience);
		this.state = stateName;
		this.country = countryName;
		this.gender = gender.getDisplayName();
		this.active = active;
		this.higherEducation = higherEducation;
		this.passingYear = passingYear;
		this.statusEnum = statusEnum;
		
	}

	// used in getFilteResource method of ResourceController 
	public ResourceListResponse(Long id, String firstname, String lastname, String availabilityType,
			String designation, BigDecimal rate, CurrencyTypeEnum currencyTypeEnum, RateTypeEnum rateTypeEnum,
			Integer yearExperience, Integer monthExperience, String countryName,
			Gender gender, Boolean active, String higherEducation, Long passingYear, StatusEnum statusEnum,
			DeploymentTypeEnum deploymentType,LocalDateTime createdOn,BigDecimal usdRate,RateTypeEnum usdRateType,String location) {
		super();
		this.id = id;
		this.firstname = firstname;
		this.lastname = lastname;
		this.availabilityType = availabilityType;
		this.designation = designation;
		this.rate = CommonUtil.getRateStr(currencyTypeEnum != null ? currencyTypeEnum.getDisplayName() : null,
				rate != null ? rate : null,rateTypeEnum!=null? rateTypeEnum.getDisplayName():null);
		this.experience = CommonUtil.getExperience(yearExperience, monthExperience);
		this.country = countryName;
		this.gender = gender.getDisplayName();
		this.active = active;
		this.higherEducation = higherEducation;
		this.passingYear = passingYear;
		this.statusEnum = statusEnum;
		this.deploymentType = deploymentType.getDisplayName();
		this.createdOn = DateUtil.getUTCToUserTimezone(createdOn);
		this.usdRate = CommonUtil.getRateString("USD", usdRate != null ? usdRate : null,
				usdRateType != null ? usdRateType.getDisplayName() : null);
		this.location=location;
	}

}
