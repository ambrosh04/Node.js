package com.daynilgroup.vendormanagement.model.response;

import lombok.Data;

@Data
public class ProofIdentityRegistrationResponse {
	
	String base64proofOfIdentity;

	String base64proofOfIdentityPath;

	String base64proofOfRegistration;

	String base64proofOfRegistrationPath;
}
