package com.daynilgroup.vendormanagement.pdf.content.extractor;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class PdfContentExtractor {

	public String extractContent(final MultipartFile multipartFile) {
		String text;
		try (final PDDocument document = PDDocument.load(multipartFile.getInputStream())) {
			final PDFTextStripper pdfStripper = new PDFTextStripper();
			pdfStripper.setSortByPosition(true);
			pdfStripper.setShouldSeparateByBeads(true);
			pdfStripper.setStartPage(0);
			pdfStripper.setEndPage(document.getNumberOfPages());
			text = pdfStripper.getText(document);
		} catch (final Exception ex) {
			log.error("Error parsing PDF", ex);
			text = "Error parsing PDF";
		}
		String value = text.replaceAll("(\r\n)", "");

		String seperateLine = value.trim().replaceAll("[\n]{2,}", "\n");

		return seperateLine;
	}
	
	
}