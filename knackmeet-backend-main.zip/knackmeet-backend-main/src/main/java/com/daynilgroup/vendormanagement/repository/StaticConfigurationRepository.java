package com.daynilgroup.vendormanagement.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.daynilgroup.vendormanagement.constants.StaticConfigurationEnum;
import com.daynilgroup.vendormanagement.entity.StaticConfiguration;

@Repository
public interface StaticConfigurationRepository extends  JpaRepository<StaticConfiguration, Long> {
	
	Page<StaticConfiguration> findByDeletedFalse(Pageable pageable);
	
	StaticConfiguration findByNameAndDeletedFalse(StaticConfigurationEnum name);
}
