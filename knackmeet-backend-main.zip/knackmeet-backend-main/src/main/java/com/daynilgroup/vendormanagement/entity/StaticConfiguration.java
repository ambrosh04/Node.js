package com.daynilgroup.vendormanagement.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Table;

import org.hibernate.annotations.ColumnDefault;

import com.daynilgroup.vendormanagement.constants.StaticConfigurationEnum;

import lombok.AccessLevel;
import lombok.Data;
import lombok.experimental.FieldDefaults;

@Data
@Entity
@Table(name = "static_configuration")
@FieldDefaults(level = AccessLevel.PRIVATE)
public class StaticConfiguration extends BaseEntity {

	private static final long serialVersionUID = 1L;

	@Enumerated(EnumType.STRING)
	@Column(name = "name", nullable = false)
	StaticConfigurationEnum name;

	@Column(name = "value", nullable = false)
	@ColumnDefault(value = "0")
	String value;

}
