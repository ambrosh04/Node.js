package com.daynilgroup.vendormanagement.util;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.List;

import javax.activation.MimetypesFileTypeMap;

import org.apache.commons.io.FileUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.amazonaws.AmazonServiceException;
import com.amazonaws.HttpMethod;
import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.AWSCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.CannedAccessControlList;
import com.amazonaws.services.s3.model.DeleteObjectRequest;
import com.amazonaws.services.s3.model.DeleteObjectsRequest;
import com.amazonaws.services.s3.model.GeneratePresignedUrlRequest;
import com.amazonaws.services.s3.model.ObjectListing;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectInputStream;
import com.amazonaws.services.s3.model.S3ObjectSummary;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
@SuppressWarnings({ "rawtypes", "deprecation", "unused" })
public class FileUpload {

	private static final Logger LOGGER = LogManager.getLogger(FileUpload.class);
	// TODO : add CRED to work
	private final String awsS3AccessKeyId = "AKIAWF6XGRJTBZY64J7H";// System.getenv("AWS_S3_ACCESS_ID");

	private final String awsS3SecrectAccessKey = "E+aoHhz6MjEymjfRA4Yc9JboG6qyAMgBoYT4wAWM";// System.getenv("AWS_S3_SECRET_ACCESS_KEY");//

	@Value("${aws.s3.bucket}")
	private String awsS3BucketName;

	private final String awsClientRegion = "ap-south-1";

	private final int expiryTimeInMin = 10;

	boolean bDebug = true;

	private final String SUFFIX = "/";

	private final String S3_BUCKET_URL_PREFIX = "https://s3." + awsClientRegion + ".amazonaws.com/";

	public String getImageUrlPrefix() {
		return S3_BUCKET_URL_PREFIX + awsS3BucketName;
	}

	public String getRegisterBusinessImageUrl() {
		return "others/list_your_business_banner.png";
	}

	@Autowired
	private Base64Util base64Util;

	public AmazonS3Client getS3Client(String AWS_S3__ACCESS_KEY_ID, String AWS_S3_SECRET_ACCESS_KEY) {
		try {
			AWSCredentials credentials = new BasicAWSCredentials(AWS_S3__ACCESS_KEY_ID, AWS_S3_SECRET_ACCESS_KEY);
			// create a client connection based on credentials
			AmazonS3Client s3client = new AmazonS3Client(credentials);
			return s3client;
		} catch (Exception e) {
			// throw new CustomException(StatusCode.AWS_CLIENT_CRT_FAILED, null);
			LOGGER.error(e);
			return null;
		}
	}

	public void createFolderForS3(String bucketName, String folderName, AmazonS3 client) {
		try {
			// create meta-data for your folder and set content-length to 0
			ObjectMetadata metadata = new ObjectMetadata();
			metadata.setContentLength(0);
			// create empty content
			InputStream emptyContent = new ByteArrayInputStream(new byte[0]);
			// create a PutObjectRequest passing the folder name suffixed by /
			PutObjectRequest putObjectRequest = new PutObjectRequest(bucketName, folderName + SUFFIX, emptyContent,
					metadata);
			// send request to S3 to create folder
			client.putObject(putObjectRequest);
		} catch (Exception e) {
			// throw new CustomException(StatusCode.AWS_FLDR_CRAT_FAILED, null);
			LOGGER.error(e);
		}
	}

	public String uploadFileToPrivateBucket(String folderName, String fileName, File file)
			throws RuntimeException, IOException {
		// create a client connection based on credentials
		AmazonS3Client s3Client = getS3Client(awsS3AccessKeyId, awsS3SecrectAccessKey);
		createFolderForS3(awsS3BucketName, folderName, s3Client);
		try {
			// upload file to folder and set it to Private
			String filePath = folderName + SUFFIX + fileName;
			s3Client.putObject(new PutObjectRequest(awsS3BucketName, filePath, file)
					.withCannedAcl(CannedAccessControlList.Private));
//            String url = s3Client.getResourceUrl(awsS3BucketName, finalFileName);
//            if (url != null && !url.equals("")) {
//                return url;
//            }
			return filePath;
		} catch (Exception e) {
			LOGGER.error(e);
			return null;
		}
	}

	public File retriveFileFromS3(String filePath, String fileOriginalName) {
		AmazonS3Client s3Client = getS3Client(awsS3AccessKeyId, awsS3SecrectAccessKey);
		S3Object s3object = s3Client.getObject(awsS3BucketName, filePath);
		S3ObjectInputStream inputStream = s3object.getObjectContent();
		File file = new File(fileOriginalName);
		try {
			FileUtils.copyInputStreamToFile(inputStream, file);
		} catch (IOException ex) {
			LOGGER.error(ex);
		}
		return file;
	}

	public String generatePresignedURL(String filepath) {
		try {
			AWSCredentialsProvider awsCredentialsProvider = new AWSCredentialsProvider() {
				@Override
				public void refresh() {
					// TODO Auto-generated method stub
				}

				@Override
				public AWSCredentials getCredentials() {
					return new BasicAWSCredentials(awsS3AccessKeyId, awsS3SecrectAccessKey);
				}
			};
			// Assuming that us-east-1 defaults to v4, couldn't find a way to set it
			// explicitly
			AmazonS3 s3Client = AmazonS3ClientBuilder.standard().withRegion(awsClientRegion)
					.withCredentials(awsCredentialsProvider).withPathStyleAccessEnabled(true).build();

			// Set the presigned URL to expire after 10 minutes.
			java.util.Date expiration = new java.util.Date();
			long expTimeMillis = expiration.getTime();
			expTimeMillis += 1000 * 60 * expiryTimeInMin;
			expiration.setTime(expTimeMillis);

			// Generate the presigned URL.
			GeneratePresignedUrlRequest generatePresignedUrlRequest = new GeneratePresignedUrlRequest(awsS3BucketName,
					filepath).withMethod(HttpMethod.GET).withExpiration(expiration);
			URL url = s3Client.generatePresignedUrl(generatePresignedUrlRequest);
			return url.toString();
		} catch (AmazonServiceException e) {
			LOGGER.error(e);
		}
		return null;
	}

	public String generatePresignedURL(String filepath, int expiryTimeInHours) {
		try {
			AWSCredentialsProvider awsCredentialsProvider = new AWSCredentialsProvider() {
				@Override
				public void refresh() {
					// TODO Auto-generated method stub
				}

				@Override
				public AWSCredentials getCredentials() {
					return new BasicAWSCredentials(awsS3AccessKeyId, awsS3SecrectAccessKey);
				}
			};
			// Assuming that us-east-1 defaults to v4, couldn't find a way to set it
			// explicitly
			AmazonS3 s3Client = AmazonS3ClientBuilder.standard().withRegion(awsClientRegion)
					.withCredentials(awsCredentialsProvider).build();

			// Set the presigned URL to expire after 10 minutes.
			java.util.Date expiration = new java.util.Date();
			long expTimeMillis = expiration.getTime();
			expTimeMillis += 1000 * 60 * 60 * expiryTimeInHours;
			expiration.setTime(expTimeMillis);

			// Generate the presigned URL.
			GeneratePresignedUrlRequest generatePresignedUrlRequest = new GeneratePresignedUrlRequest(awsS3BucketName,
					filepath).withMethod(HttpMethod.GET).withExpiration(expiration);
			URL url = s3Client.generatePresignedUrl(generatePresignedUrlRequest);

			return url.toString();
		} catch (AmazonServiceException e) {
			LOGGER.error(e);
		}
		return null;
	}

	public Boolean deleteFileByS3(String filePath) throws RuntimeException, IOException {
		try {
			String fileName = filePath.substring(1);
			DeleteObjectRequest request = new DeleteObjectRequest("dev-image.mycityonclick.in", filePath);
			AmazonS3Client s3Client = getS3Client(awsS3AccessKeyId, awsS3SecrectAccessKey);
			s3Client.deleteObject(request);
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}

	public void deleteDirectory(String prefix) {
		AmazonS3Client s3Client = getS3Client(awsS3AccessKeyId, awsS3SecrectAccessKey);
		ObjectListing objectList = s3Client.listObjects(awsS3BucketName, prefix);
		List<S3ObjectSummary> objectSummeryList = objectList.getObjectSummaries();
		String[] keysList = new String[objectSummeryList.size()];
		int count = 0;
		for (S3ObjectSummary summery : objectSummeryList) {
			keysList[count++] = summery.getKey();
		}
		DeleteObjectsRequest deleteObjectsRequest = new DeleteObjectsRequest(awsS3BucketName).withKeys(keysList);
		s3Client.deleteObjects(deleteObjectsRequest);
	}

	/**
	 * Upload file to folder and set it to Private
	 *
	 * @param folderName
	 * @param fileNameWithoutExtension
	 * @param base64String
	 * @return
	 * @throws RuntimeException
	 * @throws IOException
	 */
	public String uploadBase64StringFileToPublicBucket(String folderName, String fileNameWithoutExtension,
			String base64String) throws RuntimeException, IOException {
		log.info(
				"inside uploadBase64StringFileToPublicBucket- folderName : {} , fileNameWithoutExtension : {} , base64String : {}",
				folderName, fileNameWithoutExtension, base64String);
		String fileExtension = base64Util.getExtension(base64String);
		String fileName = fileNameWithoutExtension + "." + fileExtension;

//        String filePath1 = "C:\\Users\\Uday\\Pictures\\Capture.JPG";
//        byte[] file = Files.toByteArray(FileUtils.getFile(filePath1));
		byte[] file = base64Util.convert(base64String);

		// create a client connection based on credentials
		AmazonS3Client s3Client = getS3Client(awsS3AccessKeyId, awsS3SecrectAccessKey);

		createFolderForS3(awsS3BucketName, folderName, s3Client);

		ObjectMetadata objectMetadata = new ObjectMetadata();
		if (fileExtension.equalsIgnoreCase("svg")) {
			objectMetadata.setContentType("image/svg+xml");
		} else if (fileExtension.equalsIgnoreCase("pdf")) {
			objectMetadata.setContentType("application/pdf");
		} else if (fileExtension.equalsIgnoreCase("doc")) {
			objectMetadata.setContentType("application/msword");
		} else if (fileExtension.equalsIgnoreCase("docx")) {
			objectMetadata.setContentType("application/vnd.openxmlformats-officedocument.wordprocessingml.document");
		} else {
			MimetypesFileTypeMap fileTypeMap = new MimetypesFileTypeMap();
			objectMetadata.setContentType(fileTypeMap.getContentType(fileName));
//            objectMetadata.setContentType(URLConnection.guessContentTypeFromName(fileName));
		}
		objectMetadata.setContentDisposition("inline; filename=" + fileName);
		objectMetadata.setContentLength(file.length);

		InputStream targetStream = new ByteArrayInputStream(file);
		try {
			String filePath = folderName + SUFFIX + fileName;
			log.info("filepath : " + filePath);
			s3Client.putObject(new PutObjectRequest(awsS3BucketName, filePath, targetStream, objectMetadata)
					.withCannedAcl(CannedAccessControlList.PublicReadWrite));
			// NOTE : Below code is for if the bucket is public we will get URL (no need for
			// generatePresignedURL() )
			String url = s3Client.getUrl(awsS3BucketName, filePath).getPath();
//            if (url != null && !url.equals("")) {
//                url = awsS3BucketName + url;
			return url;
//            }
		} catch (Exception e) {
			LOGGER.error(e);
		}
		return null;
	}

//    public static void main(String[] args) throws Exception {
//        FileUpload file = new FileUpload();
////        file.deleteDirectory("comp-2/429");
////        file.uploadFileByS3("user-profile-2", "laptop-user-1-1179329.jpeg", new File("C:\\Users\\Uday\\Pictures\\Capture.JPG"));
////        Base64Util base64Util = new Base64Util();
////        String base64String = base64Util.fileToBase64String("C:\\Users\\Uday\\Pictures\\Capture.JPG");
////        file.uploadBase64StringFileToPublicBucket("user-profile-4", "laptop-user-1-1179329", base64String);
//
////        file.retriveFileFromS3(awsS3BucketName, "user-profile-2/laptop-user-1-1179329.jpeg", "laptop-user-1-1179329.jpeg");
//    }

	public String uploadBase64StringFileToPrivateBucket(String folderName, String fileNameWithoutExtension,
			String base64String) throws RuntimeException, IOException {
		log.info(
				"inside uploadBase64StringFileToPrivateBucket- folderName : {} , fileNameWithoutExtension : {} , base64String : {}",
				folderName, fileNameWithoutExtension, base64String);
		String fileExtension = base64Util.getExtension(base64String);
		byte[] file = base64Util.convert(base64String);
		String fileName = fileNameWithoutExtension;

		// create a client connection based on credentials
		AmazonS3Client s3Client = getS3Client(awsS3AccessKeyId, awsS3SecrectAccessKey);

		createFolderForS3(awsS3BucketName, folderName, s3Client);

		ObjectMetadata objectMetadata = new ObjectMetadata();
		if (fileExtension.equalsIgnoreCase("svg")) {
			objectMetadata.setContentType("image/svg+xml");
		} else if (fileExtension.equalsIgnoreCase("pdf")) {
			objectMetadata.setContentType("application/pdf");
		} else if (fileExtension.equalsIgnoreCase("doc")) {
			objectMetadata.setContentType("application/msword");
		} else if (fileExtension.equalsIgnoreCase("docx")) {
			objectMetadata.setContentType("application/vnd.openxmlformats-officedocument.wordprocessingml.document");
		} else if (fileExtension.equalsIgnoreCase("pptx")) {
			objectMetadata.setContentType("application/vnd.openxmlformats-officedocument.presentationml.presentation");
		} else if (fileExtension.equalsIgnoreCase("ppt")) {
			objectMetadata.setContentType("application/vnd.ms-powerpoint");
		} else {
//          MimetypesFileTypeMap fileTypeMap = new MimetypesFileTypeMap();
//          objectMetadata.setContentType(fileTypeMap.getContentType(fileName));
		}
		objectMetadata.setContentDisposition("inline; filename=" + fileName);
		objectMetadata.setContentLength(file.length);

		InputStream targetStream = new ByteArrayInputStream(file);
		try {
			String filePath = folderName + SUFFIX + fileName;
			s3Client.putObject(new PutObjectRequest(awsS3BucketName, filePath, targetStream, objectMetadata)
					.withCannedAcl(CannedAccessControlList.Private));
			return filePath;
		} catch (Exception e) {
			LOGGER.error(e);
		}
		return null;
	}

	public String uploadBase64StringToPrivateBucket(String folderName, String fileNameWithoutExtension,
			String base64String) throws RuntimeException, IOException {
		String fileExtension = base64Util.getExtension(base64String);
		String fileName = fileNameWithoutExtension + "." + fileExtension;
		byte[] file = base64Util.convert(base64String);

		// create a client connection based on credentials
		AmazonS3Client s3Client = getS3Client(awsS3AccessKeyId, awsS3SecrectAccessKey);

		createFolderForS3(awsS3BucketName, folderName, s3Client);

		ObjectMetadata objectMetadata = new ObjectMetadata();
		if (fileExtension.equalsIgnoreCase("svg")) {
			objectMetadata.setContentType("image/svg+xml");
		} else if (fileExtension.equalsIgnoreCase("pdf")) {
			objectMetadata.setContentType("application/pdf");
		} else if (fileExtension.equalsIgnoreCase("doc")) {
			objectMetadata.setContentType("application/msword");
		} else if (fileExtension.equalsIgnoreCase("docx")) {
			objectMetadata.setContentType("application/vnd.openxmlformats-officedocument.wordprocessingml.document");
		} else {
			MimetypesFileTypeMap fileTypeMap = new MimetypesFileTypeMap();
			objectMetadata.setContentType(fileTypeMap.getContentType(fileName));
		}
		objectMetadata.setContentDisposition("inline; filename=" + fileName);
		objectMetadata.setContentLength(file.length);

		InputStream targetStream = new ByteArrayInputStream(file);
		try {
			String filePath = folderName + SUFFIX + fileName;
			log.info("filepath : " + filePath);

			s3Client.putObject(new PutObjectRequest(awsS3BucketName, filePath, targetStream, objectMetadata)
					.withCannedAcl(CannedAccessControlList.Private));

			return filePath;

		} catch (Exception e) {
			LOGGER.error(e);
		}
		return null;
	}
}
