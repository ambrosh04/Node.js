package com.daynilgroup.vendormanagement.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.daynilgroup.vendormanagement.constants.DeploymentTypeEnum;
import com.daynilgroup.vendormanagement.constants.RateTypeEnum;
import com.daynilgroup.vendormanagement.constants.StatusEnum;
import com.daynilgroup.vendormanagement.entity.Job;
import com.daynilgroup.vendormanagement.repository.custom.JobCustomRepository;

public interface JobRepository extends JpaRepository<Job, Long>, JobCustomRepository {

	Page<Job> findByDeletedFalseOrderByUpdatedOnDesc(Pageable pageable);

	Page<Job> findByVendorId(Long id, Pageable pageable);

	@Query("SELECT COUNT(*)  FROM Job j INNER JOIN ResourceJobs rj ON  j.id= rj.job.id Where j.vendor.id =:vendorId")
	Long getCountJobApllication(Long vendorId);

	Long countByVendorIdAndDeletedFalse(Long id);

	List<Job> findByVendorId(Long id);

	List<Job> findByDeletedFalse();

	@Query("SELECT j FROM Job j WHERE j.vendor.id<>?1 and j.active=true and j.statusEnum='VERIFIED' ORDER BY createdOn DESC ")
	Page<Job> getJobListExceptVendorId(Long vendorId, Pageable pageable);

	List<Job> findByVendorNotAndDeletedFalseAndVendorNotNullOrderByCreatedOnDesc(Long vendorId);

	Page<Job> findByDeletedFalseAndStatusEnumOrderByUpdatedOnDesc(Pageable pageable, StatusEnum status);

	Long countByDeletedFalse();

	@Query("select distinct j from Job j Inner join SkillsCodeLookup sk ON j.id=sk.job.id Inner JOIN CodeLookup c ON c.id=sk.codeLookup.id Where c.name IN (:skills) and j.vendor.id <> :vendorId and j.id <> :id and j.statusEnum=:statusEnum and j.active=true")
	Page<Job> findByJobBySkills(List<String> skills, Long vendorId, Long id, Pageable pageable, StatusEnum statusEnum);
	
	@Query("select distinct j from Job j Inner join SkillsCodeLookup sk ON j.id=sk.job.id Inner JOIN CodeLookup c ON c.id=sk.codeLookup.id Where c.name IN (:skills) and j.vendor.id <> :vendorId and j.id <> :id and j.statusEnum=:statusEnum and j.active=true")
	List<Job> findByJobBySkills(List<String> skills, Long vendorId, Long id,  StatusEnum statusEnum);


	@Query("select distinct j from Job j Inner join SkillsCodeLookup sk ON j.id=sk.job.id Inner JOIN CodeLookup c ON c.id=sk.codeLookup.id Where c.name IN (:skills) and j.vendor.id <> :vendorId and j.statusEnum=:statusEnum and j.active=true")
	Page<Job> findByJobBySkills(List<String> skills, Long vendorId, Pageable pageable, StatusEnum statusEnum);
	
	@Query("select distinct j from Job j Inner join SkillsCodeLookup sk ON j.id=sk.job.id Inner JOIN CodeLookup c ON c.id=sk.codeLookup.id Where c.name IN (:skills) and j.vendor.id <> :vendorId and j.statusEnum=:statusEnum and j.active=true")
	List<Job> findByJobBySkills(List<String> skills, Long vendorId, StatusEnum statusEnum);


	@Query("select j from Job j Inner join SkillsCodeLookup sk ON j.id=sk.job.id Inner JOIN CodeLookup c ON c.id=sk.codeLookup.id Where c.name IN (:skills) and j.vendor.id <> :vendorId")
	Page<Job> findByJobBySkills(List<String> skills, Long vendorId, Pageable pageable);

	@Query("SELECT j FROM Job j WHERE j.vendor.id=:vendorId and j.statusEnum='VERIFIED' and j.active=true")
	List<Job> getCurrentVenodorId(Long vendorId);
	
	Page<Job> findByVendorIdAndDeletedFalse(Long id, Pageable pageable);
	
	@Query(value = "SELECT * FROM job j  WHERE j.status='VERIFIED' AND j.vendor_id <> :vendorId ORDER BY created_on DESC LIMIT 10;", nativeQuery = true)
	List<Job> getJobContracts(Long vendorId);
	
	@Query("SELECT j FROM Job j INNER JOIN Vendor v ON v.id=j.vendor.id where j.statusEnum='VERIFIED' and (j.deleted=false or j.deleted IS NULL)")	
	List<Job> getJobDetails();
	
	@Query("SELECT j FROM Job j WHERE (:jobStatus IS NULL OR j.statusEnum = :jobStatus) AND (:title IS NULL OR j.title LIKE (%:title%)) AND (:agencyName IS NULL or j.vendor.agencyName LIKE (%:agencyName%)) AND (j.deleted=false or j.deleted IS NULL) ORDER BY j.updatedOn DESC ")
	Page<Job> getJobList(Pageable pageable, StatusEnum jobStatus, String title,String agencyName);
	
	
	@Query("select distinct j from Job j Inner join SkillsCodeLookup sk ON j.id=sk.job.id Inner JOIN CodeLookup c ON c.id=sk.codeLookup.id Where c.name IN (:skills) "
			+ "and j.vendor.id <> :vendorId and j.id <> :id and j.statusEnum=:statusEnum and "
			+ "((:rateType IS NOT NULL and j.rateTypeEnum=:rateType and j.currencyType='INR') or (:usdRateType IS NOT NULL and j.rateTypeEnum=:usdRateType and j.currencyType='USD')) and j.active=true")
	List<Job> findByMatchingIdJobBySkills(List<String> skills,
			Long vendorId, Long id, StatusEnum statusEnum, RateTypeEnum rateType , RateTypeEnum usdRateType);
	
	@Query("select distinct j from Job j Inner join SkillsCodeLookup sk ON j.id=sk.job.id Inner JOIN CodeLookup c ON c.id=sk.codeLookup.id Where c.name IN (:skills) "
			+ "and j.vendor.id <> :vendorId and j.statusEnum=:statusEnum and "
			+ "((:rateType IS NOT NULL and j.rateTypeEnum=:rateType and j.currencyType='INR') or (:usdRateType IS NOT NULL and j.rateTypeEnum=:usdRateType and j.currencyType='USD')) and j.active=true")
	List<Job> findByJobBySkills(List<String> skills, Long vendorId, StatusEnum statusEnum, RateTypeEnum rateType, RateTypeEnum usdRateType);
	
	@Query("SELECT j FROM Job j WHERE j.vendor.id=:vendorId and (:jobStatus IS NULL OR j.statusEnum = :jobStatus) and j.active=true and (j.deleted=false or j.deleted IS NULL) ORDER BY j.title ASC")
	List<Job> getJobListByCurrentVenodorId(Long vendorId,StatusEnum jobStatus);
	
	@Query("select distinct j from Job j Inner join SkillsCodeLookup sk ON j.id=sk.job.id Inner JOIN CodeLookup c ON c.id=sk.codeLookup.id Where c.name IN (:skills) "
			+ "and j.vendor.id <> :vendorId and j.id <> :id and j.statusEnum=:statusEnum and "
			+ "((:rateType IS NOT NULL and j.rateTypeEnum=:rateType and j.currencyType='INR') or (:usdRateType IS NOT NULL and j.rateTypeEnum=:usdRateType and j.currencyType='USD')) and j.active=true AND j.workFrom IN (:deploymentTypeEnum) AND (:location IS NULL OR j.location =:location)")
	List<Job> findByMatchingIdJobBySkills(List<String> skills,
			Long vendorId, Long id, StatusEnum statusEnum, RateTypeEnum rateType , RateTypeEnum usdRateType ,List<DeploymentTypeEnum> deploymentTypeEnum,String location );
	
	@Query("select distinct j from Job j Inner join SkillsCodeLookup sk ON j.id=sk.job.id Inner JOIN CodeLookup c ON c.id=sk.codeLookup.id Where c.name IN (:skills) "
			+ "and j.vendor.id <> :vendorId and j.statusEnum=:statusEnum and "
			+ "((:rateType IS NOT NULL and j.rateTypeEnum=:rateType and j.currencyType='INR') or (:usdRateType IS NOT NULL and j.rateTypeEnum=:usdRateType and j.currencyType='USD')) and j.active=true AND j.workFrom IN (:deploymentTypeEnum) AND (:location IS NULL OR j.location =:location)")
	List<Job> findByJobBySkills(List<String> skills, Long vendorId, StatusEnum statusEnum, RateTypeEnum rateType, RateTypeEnum usdRateType,List<DeploymentTypeEnum> deploymentTypeEnum,String location);
	
}
