package com.daynilgroup.vendormanagement.service;

import com.daynilgroup.vendormanagement.entity.VerifyEmail;

public interface VerifyEmailService extends AbstractService<VerifyEmail> {
		String verifyEmail(String randomNumer) throws Exception;
		VerifyEmail findByVendorId(Long vendorId);
		
}
