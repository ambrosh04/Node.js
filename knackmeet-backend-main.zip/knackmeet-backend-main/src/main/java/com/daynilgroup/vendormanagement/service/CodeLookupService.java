/**
 * 
 */
package com.daynilgroup.vendormanagement.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.daynilgroup.vendormanagement.entity.CodeLookup;
import com.daynilgroup.vendormanagement.model.response.DropdownResponse;
import com.daynilgroup.vendormanagement.model.response.EmailSubscriptionDropDownResponse;

/**
 * @author Prerana
 *
 */
public interface CodeLookupService extends AbstractService<CodeLookup> {

	Boolean existsByNameAndTypeIdAndIdNot(String name, Long typeId, Long id);

	Page<CodeLookup> getAllCodeLookupType(Pageable pageable);

	void deleteById(Long id);

	List<CodeLookup> getByTypeCode(String code,String name);
	
	Page<CodeLookup> getByTypeCode(String code, Pageable pageable);

	Page<CodeLookup> searchByName(String name, Long typeId, Pageable pageable);

	List<DropdownResponse> getSkills(String code1, String code2);
	
	List<DropdownResponse> getAllCodeLookUpByCodeAndParentId(String code, Long parentId);

	List<DropdownResponse> getByTypeCodeAndDeletedFalseOrDeletedIsNull(String code);
	
	List<EmailSubscriptionDropDownResponse> findByTypeCodeAndDeletedFalseOrDeletedIsNull(String code);

}
