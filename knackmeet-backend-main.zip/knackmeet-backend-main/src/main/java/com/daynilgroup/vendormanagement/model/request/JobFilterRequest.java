package com.daynilgroup.vendormanagement.model.request;

import java.math.BigDecimal;
import java.util.List;

import com.daynilgroup.vendormanagement.constants.CurrencyTypeEnum;
import com.daynilgroup.vendormanagement.constants.DeploymentTypeEnum;
import com.daynilgroup.vendormanagement.constants.RateTypeEnum;
import com.daynilgroup.vendormanagement.constants.StatusEnum;
import com.daynilgroup.vendormanagement.model.pag.PaginationRequestModel;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@Getter
@Setter
@FieldDefaults(level = AccessLevel.PRIVATE)
public class JobFilterRequest {

	Integer noOfResources;

	List<Long> skillIds;

	DeploymentTypeEnum workFrom;
	
	CurrencyTypeEnum currencyTypeEnum;

	BigDecimal minRate;

	BigDecimal maxRate;

	Integer minExperience;

	Integer maxExperience;

	String title;

	Long cityId;

	Long stateId;

	Long countryId;

	StatusEnum status;

	PaginationRequestModel paginationRequestModel;
	
	Long vendorId;
	
	RateTypeEnum rateType;

	Long categoryId;
}
