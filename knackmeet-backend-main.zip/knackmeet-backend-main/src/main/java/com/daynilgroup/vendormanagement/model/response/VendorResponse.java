package com.daynilgroup.vendormanagement.model.response;

import java.time.LocalDateTime;
import java.util.List;

import com.daynilgroup.vendormanagement.constants.StatusEnum;

import lombok.Data;

@Data
public class VendorResponse {
	Long id;

	String agencyName;

	String website;

	LocalDateTime incorparationDate;

	Long teamStrength;

	StatusEnum status;

	String base64MediaString;

	String gstNumber;

	String location;

	String directorName;

	String profilePhotoPath;

	String base64MediaProofOfIdentity;

	String base64MediaProofOfRegistration;
	
	String companyPrimaryNumber;
	
	String companyPrimaryEmail;
	
	String companyDescription;

	
}
