
package com.daynilgroup.vendormanagement.util;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CompoundSelection;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Order;
import javax.persistence.criteria.Path;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.persistence.criteria.Selection;

import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.daynilgroup.vendormanagement.constants.Constants;
import com.daynilgroup.vendormanagement.constants.ResourceStatusEnum;
import com.daynilgroup.vendormanagement.entity.BaseEntity;
import com.daynilgroup.vendormanagement.entity.BaseEntity_;
import com.daynilgroup.vendormanagement.entity.CodeLookup_;
import com.daynilgroup.vendormanagement.entity.Job_;
import com.daynilgroup.vendormanagement.entity.ResourceJobs_;
import com.daynilgroup.vendormanagement.model.inf.DateUtil;
import com.daynilgroup.vendormanagement.model.pag.PageModel;
import com.daynilgroup.vendormanagement.model.pag.PaginationRequestModel;
import com.daynilgroup.vendormanagement.util.inf.CriteriaHelper;

import lombok.val;

@Component
public class CriteriaUtil implements CriteriaHelper {

	@PersistenceContext
	private EntityManager entityManager;

	public void addDefaultPredicates(CriteriaBuilder criteriaBuilder, List<Predicate> predicates,
			Root<? extends BaseEntity> root) {
		predicates.add(criteriaBuilder.or(criteriaBuilder.isFalse(root.get(BaseEntity_.DELETED)),
				criteriaBuilder.isNull(root.get(BaseEntity_.DELETED))));
	}

	public void addDefaultPredicates(CriteriaBuilder criteriaBuilder, List<Predicate> predicates, Path<?> root) {
		predicates.add(criteriaBuilder.or(criteriaBuilder.isFalse(root.get(BaseEntity_.DELETED)),
				criteriaBuilder.isNull(root.get(BaseEntity_.DELETED))));
	}

	public List<Predicate> getDefaultPredicates(CriteriaBuilder criteriaBuilder, Path<?> root) {
		List<Predicate> predicates = new ArrayList<>();
		addDefaultPredicates(criteriaBuilder, predicates, root);
		return predicates;
	}

	public List<Predicate> getDefaultPredicates(CriteriaBuilder criteriaBuilder, List<Predicate> predicates,
			Root<? extends BaseEntity> root) {
		predicates.add(criteriaBuilder.or(criteriaBuilder.isFalse(root.get(BaseEntity_.DELETED)),
				criteriaBuilder.isNull(root.get(BaseEntity_.DELETED))));
		return predicates;
	}

	public void addPredicates(CriteriaBuilder criteriaBuilder, List<Predicate> predicates, Expression expression,
			String value) {
		if (StringUtils.hasText(value)) {
			predicates.add(criteriaBuilder.like(expression, "%" + value + "%"));
		}
	}

	public void addPredicatesNotEqual(CriteriaBuilder criteriaBuilder, List<Predicate> predicates,
			Expression expression, Object value) {
		if (value != null) {
			predicates.add(criteriaBuilder.notEqual(expression, value));
		}
	}

	public void addPredicates(CriteriaBuilder criteriaBuilder, List<Predicate> predicates, Expression expression,
			Long value) {
		if (value != null) {
			predicates.add(criteriaBuilder.equal(expression, value));
		}
	}

	public void addPredicates(CriteriaBuilder criteriaBuilder, List<Predicate> predicates, Expression expression,
			Integer value) {
		if (value != null) {
			predicates.add(criteriaBuilder.equal(expression, value));
		}
	}

	public void addPredicates(CriteriaBuilder criteriaBuilder, List<Predicate> predicates, Expression expression,
			Collection<Long> list) {
		if (!CollectionUtils.isEmpty(list)) {
			predicates.add(criteriaBuilder.in(expression).value(list));
		}
	}

	public void addPredicates(CriteriaBuilder criteriaBuilder, List<Predicate> predicates, Expression expression,
			List<Long> list, boolean isNot) {
		if (!CollectionUtils.isEmpty(list)) {
			Predicate in = criteriaBuilder.in(expression).value(list);
			if (isNot) {
				in = criteriaBuilder.not(in);
			}
			predicates.add(in);
		}
	}

	public void addPredicates(CriteriaBuilder criteriaBuilder, List<Predicate> predicates, Expression expression,
			Date fromDate, Date toDate) {
		if (toDate == null) {
			toDate = new Date();
		}
		if (fromDate != null) {
			Predicate between = criteriaBuilder.between(expression, DateUtil.getStartDate(fromDate),
					DateUtil.getEndDate(toDate));
			predicates.add(between);
		}
	}

	public void addPredicates(CriteriaBuilder criteriaBuilder, List<Predicate> predicates, Expression expression,
			Expression expression2, Integer fromValue, Integer toValue) {
		if (fromValue != null && toValue != null) {
			Predicate between = criteriaBuilder.between(expression, fromValue, toValue);
			predicates.add(between);

			predicates.add(criteriaBuilder.lessThan(expression2, 1));

		} else {
			if (fromValue != null)

				predicates.add(criteriaBuilder.greaterThanOrEqualTo(expression, fromValue));

			else if (toValue != null) {

				predicates.add(criteriaBuilder.lessThanOrEqualTo(expression, toValue));
				predicates.add(criteriaBuilder.lessThan(expression2, 1));
			}
		}
	}

	public void addPredicates(CriteriaBuilder criteriaBuilder, List<Predicate> predicates, Expression expression,
			BigDecimal fromValue, BigDecimal toValue) {
		if (fromValue != null && toValue != null) {
			Predicate between = criteriaBuilder.between(expression, fromValue, toValue);
			predicates.add(between);
		}
	}

	public void addPredicates(CriteriaBuilder criteriaBuilder, List<Predicate> predicates, Expression expression,
			Date date) {
		if (date != null) {
			Predicate between = criteriaBuilder.between(expression, DateUtil.getStartDate(date),
					DateUtil.getEndDate(date));
			predicates.add(between);
		}
	}

	public void addPredicates(CriteriaBuilder criteriaBuilder, List<Predicate> predicates, Expression expression,
			Enum value) {
		if (value != null) {
			predicates.add(criteriaBuilder.equal(expression, value));
		}
	}

	public void addPredicates(CriteriaBuilder criteriaBuilder, List<Predicate> predicates, Expression expression,
			Expression expression1, Enum value, Boolean value1) {
		if (value != null) {
			predicates.add(criteriaBuilder.and(criteriaBuilder.equal(expression, value),
					criteriaBuilder.equal(expression1, value1)));
//			predicates.add(criteriaBuilder.equal(expression, value));
		}
	}

	public void addPredicates(CriteriaBuilder criteriaBuilder, List<Predicate> predicates, Expression expression,
			Boolean value) {
		if (value != null) {
			predicates.add(criteriaBuilder.equal(expression, value));
		}
	}

	public void addPredicatesIsNull(CriteriaBuilder criteriaBuilder, List<Predicate> predicates, Expression expression,
			Boolean value) {
		if (value != null && value) {
			predicates.add(criteriaBuilder.isNull(expression));
		}
	}

	public void addPredicatesIsNotNull(CriteriaBuilder criteriaBuilder, List<Predicate> predicates,
			Expression expression, Boolean value) {
		if (value != null && value) {
			predicates.add(criteriaBuilder.isNotNull(expression));
		}
	}

	public Long getCount(CriteriaBuilder criteriaBuilder, Class<?> countFromClass, List<Predicate> predicates) {
		CriteriaQuery<Long> countQuery = criteriaBuilder.createQuery(Long.class);
		populateCriteriaQuery(countQuery, criteriaBuilder.countDistinct(countQuery.from(countFromClass)), predicates);
		return entityManager.createQuery(countQuery).getSingleResult();
	}

	public boolean isCount(CriteriaQuery<?> criteriaQuery) {
		return criteriaQuery.getResultType().equals(Long.class);
	}

	public void populateCriteriaQuery(CriteriaQuery<?> criteriaQuery, Selection selection, List<Predicate> predicates,
			Order order) {
		populateCriteriaQuery(criteriaQuery, selection, predicates, order != null ? Arrays.asList(order) : null);
	}

	public void populateCriteriaQuery(CriteriaQuery<?> criteriaQuery, Selection selection, List<Predicate> predicates,
			List<Order> orders) {
		criteriaQuery.distinct(true);
		criteriaQuery.select(selection);
		criteriaQuery.where(predicates.toArray(new Predicate[0]));
		criteriaQuery.orderBy(orders);
	}

	public void populateCriteriaQuery(CriteriaQuery<?> criteriaQuery, Selection selection, List<Predicate> predicates) {
		criteriaQuery.distinct(true);
		criteriaQuery.select(selection);
		criteriaQuery.where(predicates.toArray(new Predicate[0]));
	}

	public PageModel getPageModel(TypedQuery typedQuery, Long totalCount, List<Predicate> predicates,
			PaginationRequestModel paginationModel) {
		PaginationUtil.setPaginationToQuery(typedQuery, paginationModel);

		Long pageCount = 0L;
		List data = new ArrayList<>();

		if (totalCount > 0) {
			data = typedQuery.getResultList();
			pageCount = totalCount / typedQuery.getMaxResults();
			if (totalCount % typedQuery.getMaxResults() > 0) {
				pageCount++;
			}
		}
		return PageModel.builder().data(data).pageCount(pageCount).totalCount(totalCount).build();
	}

	public PageModel getPageModel(CriteriaBuilder criteriaBuilder, CriteriaQuery<?> criteriaQuery,
			Class<?> countFromClass, Selection selection, List<Predicate> predicates, Order order,
			PaginationRequestModel paginationModel) {

		criteriaQuery.distinct(true);
		criteriaQuery.select(selection);
		criteriaQuery.where(predicates.toArray(new Predicate[0]));
		criteriaQuery.orderBy(order);

		TypedQuery typedQuery = entityManager.createQuery(criteriaQuery);
		PaginationUtil.setPaginationToQuery(typedQuery, paginationModel);

		CriteriaQuery<Long> countQuery = criteriaBuilder.createQuery(Long.class);
		countQuery.select(criteriaBuilder.countDistinct(countQuery.from(countFromClass)));
		countQuery.where(predicates.toArray(new Predicate[0]));
		Long totalCount = entityManager.createQuery(countQuery).getSingleResult();

		Long pageCount = 0L;
		List data = new ArrayList<>();

		if (totalCount > 0) {
			data = typedQuery.getResultList();
			pageCount = totalCount / typedQuery.getMaxResults();
			if (totalCount % typedQuery.getMaxResults() > 0) {
				pageCount++;
			}
		}
		return PageModel.builder().data(data).pageCount(pageCount).totalCount(totalCount).build();
	}

	public List getList(CriteriaQuery<?> criteriaQuery, Selection<?> selection, List<Predicate> predicates,
			Order order) {
		populateCriteriaQuery(criteriaQuery, selection, predicates, order);
		TypedQuery<?> typedQuery = entityManager.createQuery(criteriaQuery);
		return typedQuery.getResultList();
	}

	public List getList(CriteriaQuery<?> criteriaQuery, Selection<?> selection, List<Predicate> predicates,
			List<Order> orders) {
		populateCriteriaQuery(criteriaQuery, selection, predicates, orders);
		TypedQuery<?> typedQuery = entityManager.createQuery(criteriaQuery);
		return typedQuery.getResultList();
	}

	public PageModel getPageModel(CriteriaQuery<?> listQuery, CriteriaQuery<Long> countQuery,
			PaginationRequestModel pagination) {
		TypedQuery<?> listTypedQuery = entityManager.createQuery(listQuery);
		TypedQuery<Long> countTypedQuery = entityManager.createQuery(countQuery);
		PaginationUtil.setPaginationToQuery(listTypedQuery, pagination);

		List<?> list = listTypedQuery.getResultList();
		Long totalCount = !CollectionUtils.isEmpty(list) ? countTypedQuery.getSingleResult() : 0L;
		return getPageModel(list, totalCount, listTypedQuery.getMaxResults());
	}

	public PageModel getPageModel(List<?> list, Long totalCount, Integer pageSize) {
		Long pageCount = 0L;
		if (totalCount > 0) {
			pageCount = totalCount / pageSize;
			if (totalCount % pageSize > 0) {
				pageCount++;
			}
		}
		return PageModel.builder().data(list).pageCount(pageCount).totalCount(totalCount).build();
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void addPredicates(CriteriaBuilder criteriaBuilder, List<Predicate> predicates, Expression expression,
			Date date, String operator) {
		if (date != null) {
			Predicate predicate = null;
			switch (operator) {
			case Constants.CRITERIA_GREATER_EQUAL:
				predicate = criteriaBuilder.greaterThanOrEqualTo(expression, DateUtil.getStartDate(date));
				break;
			case Constants.CRITERIA_lESS_EQUAL:
				predicate = criteriaBuilder.lessThanOrEqualTo(expression, DateUtil.getEndDate(date));
				break;
			default:
				break;
			}
			predicates.add(predicate);
		}
	}

	public <T> T getSingleResult(CriteriaQuery<T> criteriaQuery, Selection<T> selection, List<Predicate> predicates) {
		populateCriteriaQuery(criteriaQuery, selection, predicates);
		return entityManager.createQuery(criteriaQuery).getSingleResult();
	}

	public void addPredicatesEqual(CriteriaBuilder criteriaBuilder, List<Predicate> predicates, Expression expression,
			String value) {
		if (StringUtils.hasText(value)) {
			predicates.add(criteriaBuilder.equal(expression, value));
		}
	}

	public Order getDefaultOrder(CriteriaBuilder criteriaBuilder, String sortBy, Sort.Direction direction,
			Root<?> root) {
		Order order = null;
		if (sortBy == null) {
			sortBy = BaseEntity_.CREATED_ON;
			Expression<?> ex = criteriaBuilder.selectCase()
					.when(root.get(BaseEntity_.UPDATED_ON).isNull(), root.get(sortBy))
					.otherwise(root.get(BaseEntity_.UPDATED_ON));
			order = criteriaBuilder.desc(ex);
		} else if (Sort.Direction.ASC.equals(direction)) {
			order = criteriaBuilder.asc(root.get(sortBy));
		} else {
			order = criteriaBuilder.desc(root.get(sortBy));
		}
		return order;
	}

	public List getDropdownRespone(CriteriaQuery<?> criteriaQuery, CompoundSelection<?> selection,
			List<Predicate> predicates, Order order) {
		populateCriteriaQuery(criteriaQuery, selection, predicates, order);
		return entityManager.createQuery(criteriaQuery).setMaxResults(10).getResultList();
	}

	public void addPredicatesEqual(CriteriaBuilder criteriaBuilder, List<Predicate> predicates, Path<?> expression,
			BigDecimal value) {
		if (value != null) {
			predicates.add(criteriaBuilder.equal(expression, value));
		}
	}

	public void addPredicates(CriteriaBuilder criteriaBuilder, List<Predicate> predicates, Path<Object> expression,
			BigDecimal price) {
		if (price != null) {
			predicates.add(criteriaBuilder.equal(expression, price));
		}
	}

	public void addPredicatesIn(CriteriaBuilder criteriaBuilder, List<Predicate> predicates, Expression expression,
			List<?> list) {
		if (!CollectionUtils.isEmpty(list)) {
			predicates.add(criteriaBuilder.in(expression).value(list));
		}
	}

	public void addPredicatesBetween(CriteriaBuilder criteriaBuilder, List<Predicate> predicates,
			Expression expression1, Expression expression2, Integer minValue, Integer MaxValue) {
		if (minValue != null && MaxValue != null) {
			predicates.add(criteriaBuilder.and(criteriaBuilder.greaterThanOrEqualTo(expression1, minValue),
					criteriaBuilder.lessThanOrEqualTo(expression2, MaxValue)));
		}

	}

	public void addPredicatesBetween(CriteriaBuilder criteriaBuilder, List<Predicate> predicates,
			Expression expression1, Expression expression2, BigDecimal minValue, BigDecimal maxValue) {
		if (minValue != null && maxValue != null) {
			predicates.add(criteriaBuilder.and(criteriaBuilder.greaterThanOrEqualTo(expression1, minValue),
					criteriaBuilder.lessThanOrEqualTo(expression2, maxValue)));
		}
	}

	public void addPredicatesOr(CriteriaBuilder criteriaBuilder, List<Predicate> predicates, Expression expression,
			Expression expression1, String value) {
		if (value != null) {
			predicates.add(criteriaBuilder.or(criteriaBuilder.like(expression, "%" + value + "%"),
					criteriaBuilder.like(expression1, "%" + value + "%")));
		}
	}
	public void addPredicatesOr(CriteriaBuilder criteriaBuilder, List<Predicate> predicates, Expression expression, Object bigDecimal) {
		if (bigDecimal != null) {
			predicates.add(criteriaBuilder.or(criteriaBuilder.equal(expression, bigDecimal),
					criteriaBuilder.equal(expression, null)));
		}
	}

	public void addPredicates(CriteriaBuilder criteriaBuilder, List<Predicate> predicates, Expression expression,
			List<String> keyWords) {
		if (!keyWords.isEmpty()) {

			List<Predicate> localPredicates = new ArrayList<>();
			for (String name : keyWords) {
				localPredicates.add(criteriaBuilder.like(expression, "%" + name + "%"));
			}

			predicates.add(criteriaBuilder.or(localPredicates.toArray(new Predicate[0])));
		}

	}

	public void addPredicates(CriteriaBuilder criteriaBuilder, List<Predicate> predicates,
			Expression<Integer> expression, Integer minValue, Integer maxValue) {
		if (minValue != null && maxValue != null) {
			predicates.add(criteriaBuilder.between(expression, minValue, maxValue));
		}

	}

	public void addPredicatesGreaterThenOrEqualTo(CriteriaBuilder criteriaBuilder, List<Predicate> predicates,
			Expression<Integer> expression, Integer minValue) {
		if (minValue != null) {
			predicates.add(criteriaBuilder.greaterThanOrEqualTo(expression, minValue));
		}

	}

	public void addPredicatesLessThenOrEqualTo(CriteriaBuilder criteriaBuilder, List<Predicate> predicates,
			Expression<Integer> expression, Integer maxValue) {

		if (maxValue != null) {
			predicates.add(criteriaBuilder.lessThanOrEqualTo(expression, maxValue));
		}
	}

	public void addPredicatesGreaterThenOrEqualTo(CriteriaBuilder criteriaBuilder, List<Predicate> predicates,
			Expression expression, BigDecimal minValue) {
		if (minValue != null) {
			predicates.add(criteriaBuilder.greaterThanOrEqualTo(expression, minValue));
		}

	}

	public void addPredicatesLessThenOrEqualTo(CriteriaBuilder criteriaBuilder, List<Predicate> predicates,
			Expression expression, BigDecimal maxValue) {
		if (maxValue != null) {
			predicates.add(criteriaBuilder.lessThanOrEqualTo(expression, maxValue));
		}

	}

	public void addPredicatesOr(CriteriaBuilder criteriaBuilder, List<Predicate> predicates, Expression expression,
			Expression expression2, List<String> value) {
		if (!value.isEmpty()) {
			List<Predicate> localPredicates1 = new ArrayList<>();
			List<Predicate> localPredicates2 = new ArrayList<>();
			for (String name : value) {
				if (StringUtils.hasText(name)) {
					localPredicates1.add(criteriaBuilder.like(expression, "%" + name + "%"));
					localPredicates2.add(criteriaBuilder.like(expression2, "%" + name + "%"));

				}
			}
			predicates.add(criteriaBuilder.or(criteriaBuilder.or(localPredicates1.toArray(new Predicate[0])),
					criteriaBuilder.or(localPredicates2.toArray(new Predicate[0]))));

		}
	}

	public void addPredicatesAnd(CriteriaBuilder criteriaBuilder, List<Predicate> predicates, Expression expression,
			Expression expression2, List<String> value) {
		if (!value.isEmpty()) {
			List<Predicate> localPredicates1 = new ArrayList<>();
			List<Predicate> localPredicates2 = new ArrayList<>();
			for (String name : value) {
				if (StringUtils.hasText(name)) {
					localPredicates1.add(criteriaBuilder.like(expression, "%" + name + "%"));
					localPredicates2.add(criteriaBuilder.like(expression2, "%" + name + "%"));

				}
			}
			predicates.add(criteriaBuilder.and(criteriaBuilder.or(localPredicates1.toArray(new Predicate[0])),
					criteriaBuilder.or(localPredicates2.toArray(new Predicate[0]))));

		}
	}

	public void addPredicatesNotIn(CriteriaBuilder criteriaBuilder, List<Predicate> predicates, Expression expression,
			List<?> value) {
		if (!value.isEmpty()) {
			predicates.add(criteriaBuilder.not(expression.in(value)));
		}

	}

}
