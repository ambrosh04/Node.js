package com.daynilgroup.vendormanagement.constants;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.experimental.FieldDefaults;

/**
 *
 * @author manish
 */
@Getter
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public enum SupportStatus {
	PENDING("Pending"), RESOLVED("Resolved"), WORK_IN_PROGRESS("Work_In_Progress");

	String displayname;
}
