package com.daynilgroup.vendormanagement.rest.exception;

import java.util.List;

import com.daynilgroup.vendormanagement.exception.RestExceptionCode;
import com.daynilgroup.vendormanagement.exception.RestExecption;

import lombok.Getter;
import lombok.NoArgsConstructor;

/**
 *
 * @author Manish
 */
@Getter
@NoArgsConstructor
public class ValidationRestException extends RestExecption {

    public final String errorCode = RestExceptionCode.VALIDATION_ERROR_CODE;
    public String message = "Validation Error: ";

    public ValidationRestException(String message) {
        this.message += message;
    }

    public ValidationRestException(List<String> messageList) {
        StringBuilder messegeBuilder = new StringBuilder();
        messageList.forEach(message -> {
            messegeBuilder.append(message);
            messegeBuilder.append("\n");
        });
        this.message += messegeBuilder.toString();
    }
}
