package com.daynilgroup.vendormanagement.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;

import com.daynilgroup.vendormanagement.constants.CodeLookUpRelationTypeEnum;
import com.daynilgroup.vendormanagement.constants.RefTypeEnum;
import com.daynilgroup.vendormanagement.constants.StatusEnum;
import com.daynilgroup.vendormanagement.entity.CodeLookUpRelation;
import com.daynilgroup.vendormanagement.entity.CodeLookup;
import com.daynilgroup.vendormanagement.model.request.SubscribeEMailNotificationRequest;
import com.daynilgroup.vendormanagement.model.request.SubscribeForEMailNotificationRequest;
import com.daynilgroup.vendormanagement.repository.CodeLookUpRelationRepository;
import com.daynilgroup.vendormanagement.service.CodeLookUpRelationService;
import com.daynilgroup.vendormanagement.service.CodeLookupService;
import com.daynilgroup.vendormanagement.util.CommonUtil;
import com.daynilgroup.vendormanagement.util.EntityUtil;

@Service
public class CodeLookUpRelationServiceImpl implements CodeLookUpRelationService{

	@Autowired
	CodeLookUpRelationRepository codeLookUpRelationRepository;
	

	@Autowired
	EntityUtil entityUtil;
	
	@Autowired
	CodeLookupService codeLookupService;
	
	@Autowired
	CodeLookUpRelationService codeLookUpRelationService;
	
	@Override
	public JpaRepository<CodeLookUpRelation, Long> getJpaRepository() {
		return codeLookUpRelationRepository;
	}

	@Override
	public List<CodeLookUpRelation> findByRefIdAndRefTypeAndType(Long refId, RefTypeEnum refType,
			CodeLookUpRelationTypeEnum type) {

		List<CodeLookUpRelation> CodelookupRelationList = codeLookUpRelationRepository
				.findByRefIdAndRefTypeAndType(refId, refType, type);

		return CodelookupRelationList;
	}

	@Override
	public void setActive(List<CodeLookUpRelation> CodelookupRelationList, String name) {
		for (CodeLookUpRelation codeLookUpRelation : CodelookupRelationList) {
			if (codeLookUpRelation.getCodeLookup().getName().equals(name)) {
				codeLookUpRelation.setActive(false);
				save(codeLookUpRelation);
				return;
			}
		}

	}

	@Override
	public StatusEnum getStatusEnumRejectedByAdmin(List<CodeLookUpRelation> CodelookupRelationList) {
		for (CodeLookUpRelation codeLookUpRelation : CodelookupRelationList) {
			if (codeLookUpRelation.getActive()) {
				return StatusEnum.REJECTED;
			}
		}
		return StatusEnum.UNVERIFIED;
	}

	@Override
	public void deleteByRefIdAndRefTypeAndType(Long refId, RefTypeEnum refType, CodeLookUpRelationTypeEnum type) {
		 codeLookUpRelationRepository
			.deleteByRefIdAndRefTypeAndType(refId, refType, type);
		
	}

	@Override
	public void hardDeleteByRefIdAndRefTypeAndType(Long refId, RefTypeEnum refType, CodeLookUpRelationTypeEnum type) {
		codeLookUpRelationRepository
		.hardDeleteByRefIdAndRefTypeAndType(refId, refType, type);
		
	}

	@Override
	public CodeLookUpRelation createSubscribeForEmailNotification(
			SubscribeForEMailNotificationRequest unSubEmailNotificationRequest) throws Exception {
		for (SubscribeEMailNotificationRequest unsubscribeEMailNotificationRequest : unSubEmailNotificationRequest
				.getSubscribeEmailNotificationRequest()) {
			CodeLookUpRelation relation;
			relation = getCodeLookUpRelation(entityUtil.getCurrentVendorId(), RefTypeEnum.VENDOR,
					CodeLookUpRelationTypeEnum.SUBSCRIBE_FOR_EMAIL_NOTIFICATION,
					unsubscribeEMailNotificationRequest.getCodeLookUpId());
			if (relation == null) {
				relation = new CodeLookUpRelation();
				relation.setRefId(entityUtil.getCurrentVendorId());
				relation.setRefType(RefTypeEnum.VENDOR);
				relation.setType(CodeLookUpRelationTypeEnum.SUBSCRIBE_FOR_EMAIL_NOTIFICATION);
				relation.setCodeLookup(unsubscribeEMailNotificationRequest.getCodeLookUpId() != null
						? CommonUtil.getEntityReferenceWithId(unsubscribeEMailNotificationRequest.getCodeLookUpId(),
								codeLookupService, CodeLookup.class)
						: null);
			}

			relation.setActive(unsubscribeEMailNotificationRequest.getSubscribeStatus());

			codeLookUpRelationService.save(relation);

		}
		
		
		
		return null;
	}

	@Override
	public CodeLookUpRelation getCodeLookUpRelation(Long refId, RefTypeEnum refType, CodeLookUpRelationTypeEnum type,
			Long codeLookUpId) {

		return codeLookUpRelationRepository.findByRefIdAndRefTypeAndTypeAndCodeLookupId(refId, refType, type,
				codeLookUpId);
	}

	@Override
	public CodeLookUpRelation getActiveStatus(Long refId, RefTypeEnum refType, CodeLookUpRelationTypeEnum type) {
		return codeLookUpRelationRepository.findByRefIdAndRefTypeAndTypeAndDeletedFalseOrDeletedIsNull(refId, refType, type);
	}
}
