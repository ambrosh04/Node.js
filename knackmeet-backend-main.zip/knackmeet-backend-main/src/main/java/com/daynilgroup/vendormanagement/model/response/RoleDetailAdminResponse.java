package com.daynilgroup.vendormanagement.model.response;

import java.io.Serializable;
import java.util.List;

import com.daynilgroup.vendormanagement.constants.RoleTypeEnum;

import lombok.AccessLevel;
import lombok.Builder;
import lombok.Getter;
import lombok.experimental.FieldDefaults;

/**
 *
 * @author Dnyaneshwar
 */
@Getter
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
public class RoleDetailAdminResponse implements Serializable {

	static final long serialVersionUID = 1L;

	Long id;

	String name;

	Boolean active;

	RoleTypeEnum type;

	List<String> access;
}
