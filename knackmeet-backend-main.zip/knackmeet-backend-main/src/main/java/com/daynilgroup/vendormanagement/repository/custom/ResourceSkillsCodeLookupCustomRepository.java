package com.daynilgroup.vendormanagement.repository.custom;

import com.daynilgroup.vendormanagement.model.filter.ResourceSkillsFilterModel;
import com.daynilgroup.vendormanagement.model.pag.PageModel;

public interface ResourceSkillsCodeLookupCustomRepository {

	PageModel findAll(ResourceSkillsFilterModel resourceSkillsFilterModel);

}
