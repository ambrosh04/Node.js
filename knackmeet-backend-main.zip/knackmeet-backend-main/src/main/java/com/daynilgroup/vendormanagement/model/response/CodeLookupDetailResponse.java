package com.daynilgroup.vendormanagement.model.response;

import com.daynilgroup.vendormanagement.constants.StatusEnum;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class CodeLookupDetailResponse {

	String description;
	String name;
	Long typeId;
	Long id;
	Long parentId;
	Boolean active;
	StatusEnum status;
	String coverImage;
	Integer displayOrder;
}
