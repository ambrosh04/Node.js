package com.daynilgroup.vendormanagement.service;

import java.util.List;

import com.daynilgroup.vendormanagement.entity.Education;

public interface EducationService extends AbstractService<Education> {

	void softDeleteByInId(List<Long> deleteEducations);

	List<Education> findAllByDeleteFalse(Long resourceId);

}
