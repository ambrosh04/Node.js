package com.daynilgroup.vendormanagement.pdf.content.extractor;

import java.io.File;
import java.io.FileInputStream;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;

public class PdfReader {

	public String readPDFFile() throws Exception {
		File file = new File("C:\\Users\\dell\\OneDrive\\Desktop\\mehtaexp.cv.pdf");
		// File file = new File("C:\\Users\\dell\\OneDrive\\Desktop\\Pdfreader.pdf");
		FileInputStream filesin = new FileInputStream(file);

		PDDocument pdDocument = PDDocument.load(filesin);

		PDFTextStripper pdfTextStripper = new PDFTextStripper();
		pdfTextStripper.setStartPage(1);
		pdfTextStripper.setEndPage(3);
		String text = pdfTextStripper.getText(pdDocument);

		pdDocument.close();
		filesin.close();
		return text;

	}
}
