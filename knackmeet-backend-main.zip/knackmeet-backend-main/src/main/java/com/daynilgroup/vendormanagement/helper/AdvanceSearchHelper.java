package com.daynilgroup.vendormanagement.helper;

import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import com.daynilgroup.vendormanagement.model.pag.PageModel;
import com.daynilgroup.vendormanagement.model.request.AdvanceSearchRequest;
import com.daynilgroup.vendormanagement.repository.SearchHistoryRepository;
import com.daynilgroup.vendormanagement.service.JobService;
import com.daynilgroup.vendormanagement.service.ResourceSkillsCodeLookupService;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;

@Service
@FieldDefaults(level = AccessLevel.PRIVATE)
public class AdvanceSearchHelper {

	@Autowired
	ResourceSkillsCodeLookupService resourceSkillsCodeLookupService;

	@Autowired
	JobService jobService;
	
	@Autowired
	SearchHistoryHelper searchHistoryHelper;

	@Autowired
	SearchHistoryRepository historyRepository;

	public PageModel search(AdvanceSearchRequest advanceSearchRequest) throws Exception {
		if (!Objects.isNull(advanceSearchRequest.getJobSearchRequest())
				&& !ObjectUtils.isEmpty(advanceSearchRequest.getJobSearchRequest())) {
			historyRepository.save(searchHistoryHelper.getJobSearchRequest(advanceSearchRequest.getJobSearchRequest()));

			return jobService.getJobsFilterListByVendorId(advanceSearchRequest.getJobSearchRequest());
		}
		else if (!Objects.isNull(advanceSearchRequest.getResourceSkillsFilterModel())
				&& !ObjectUtils.isEmpty(advanceSearchRequest.getResourceSkillsFilterModel())) {
			historyRepository.save(searchHistoryHelper.getResourceSkillsFilterModel(advanceSearchRequest.getResourceSkillsFilterModel()));
			return resourceSkillsCodeLookupService.getResourceList(advanceSearchRequest.getResourceSkillsFilterModel());
		} else {
			throw new Exception("Issue in the payload");
		}
	}

}
