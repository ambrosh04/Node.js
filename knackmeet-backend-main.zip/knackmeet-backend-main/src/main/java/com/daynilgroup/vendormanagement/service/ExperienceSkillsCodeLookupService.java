package com.daynilgroup.vendormanagement.service;

import com.daynilgroup.vendormanagement.entity.ExperienceSkillsCodeLookup;

public interface ExperienceSkillsCodeLookupService extends AbstractService<ExperienceSkillsCodeLookup> {

	void deleteByExperienceId(Long experienceId);

}
