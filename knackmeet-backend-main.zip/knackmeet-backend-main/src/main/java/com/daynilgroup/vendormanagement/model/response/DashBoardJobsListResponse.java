package com.daynilgroup.vendormanagement.model.response;

import java.time.LocalDateTime;

import lombok.AccessLevel;
import lombok.Builder;
import lombok.Data;
import lombok.experimental.FieldDefaults;

@Data
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
public class DashBoardJobsListResponse {

	Long jobId;
	String myJob;
	String applicant;
	String resourceStatus;
	LocalDateTime date;
}
