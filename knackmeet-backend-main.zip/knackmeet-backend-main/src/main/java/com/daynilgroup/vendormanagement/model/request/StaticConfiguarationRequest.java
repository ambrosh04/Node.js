package com.daynilgroup.vendormanagement.model.request;

import java.io.Serializable;

import com.daynilgroup.vendormanagement.constants.StaticConfigurationEnum;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class StaticConfiguarationRequest implements Serializable {

	static final long serialVersionUID = 1L;

	Long id;

	StaticConfigurationEnum name;

	String value;

}
