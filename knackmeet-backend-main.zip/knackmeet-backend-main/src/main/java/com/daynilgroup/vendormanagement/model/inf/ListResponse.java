package com.daynilgroup.vendormanagement.model.inf;

import java.io.Serializable;

public interface ListResponse extends Serializable {

	public Long getId();

}
