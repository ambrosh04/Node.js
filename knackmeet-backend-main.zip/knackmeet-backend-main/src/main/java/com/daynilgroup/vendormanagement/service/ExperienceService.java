package com.daynilgroup.vendormanagement.service;

import java.util.List;

import com.daynilgroup.vendormanagement.entity.Experience;
import com.daynilgroup.vendormanagement.request.ExperienceRequest;

public interface ExperienceService extends AbstractService<Experience>{

	void softDeleteByInId(List<Long> deleteExperiences);

	List<Experience> findAllByDeleteFalse(Long long1);
	
	List<Integer> getToYearByDeleteFalse(Long resourceId);
	
	List<Integer> getFromYearByDeleteFalse(Long resourceId);
	
	void create(ExperienceRequest experienceRequest) throws Exception;
	

}
