package com.daynilgroup.vendormanagement.service;

import com.daynilgroup.vendormanagement.entity.RoleAccess;

public interface RoleAccessService  extends AbstractService<RoleAccess>{

	void deleteByRoleId(Long userId);

}
