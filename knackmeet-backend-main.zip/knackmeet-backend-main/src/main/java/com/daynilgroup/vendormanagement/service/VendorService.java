/**
 * 
 */
package com.daynilgroup.vendormanagement.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.daynilgroup.vendormanagement.constants.StatusEnum;
import com.daynilgroup.vendormanagement.constants.UserType;
import com.daynilgroup.vendormanagement.entity.Vendor;

/**
 * @author Prerana
 *
 */

public interface VendorService extends AbstractService<Vendor> {

	Vendor findByUserId(Long userId);

	Boolean existsByMobileNumberAndUserTypeAndIdNot(String mobileNumber, UserType userType, Long Id);

	void verifyVendor(Long vendorId, StatusEnum status);

	Page<Vendor> getList(String agencyName, String name,String location,Pageable pageable);

	List<Vendor> getvendorDetails();

	void deleteById(Long id);

	Long getAllVendorCountExceptAdmin(UserType userType);

	void rejectVendor(Long vendorId, StatusEnum status);

	Boolean existsByCompanyPrimaryNumber(String companyNumber) throws Exception;

	Boolean existsByCompanyPrimaryEmail(String companyPrimaryEmail) throws Exception;
	
    Boolean existsByCompanyPrimaryNumberAndIdNot(String companyNumber,Long id)throws Exception;
	
	Boolean existsByCompanyPrimaryEmailAndIdNot(String companyPrimaryEmail,Long id)throws Exception;
	
	void sendEmailToVerifyEmailId(Long  vendorId) throws Exception;
	
	List<Vendor> getListByUserType(UserType userType);

	Boolean existsByAgencyName(String agencyName) throws Exception;
	
	Vendor findByCompanyPrimaryEmail(String companyPrimaryEmail);
}
