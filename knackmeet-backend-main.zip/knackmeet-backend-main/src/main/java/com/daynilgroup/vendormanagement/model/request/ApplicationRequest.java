package com.daynilgroup.vendormanagement.model.request;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Date;

import com.daynilgroup.vendormanagement.constants.ResourceStatusEnum;
import com.daynilgroup.vendormanagement.model.pag.PaginationRequestModel;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@Getter
@Setter
@FieldDefaults(level = AccessLevel.PRIVATE)
public class ApplicationRequest implements Serializable {
	ResourceStatusEnum resourceStatus;
	String name;
	String startDate;
	String endDate;
	PaginationRequestModel paginationRequestModel;
}
