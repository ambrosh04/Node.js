package com.daynilgroup.vendormanagement.request.inf;

import java.util.List;

/**
 *
 * @author Manish
 */
public interface ImageListRequest {

    public List<String> getBase64ImageStrings();    
    
    public List<String> getDeletedImages();
}

