/**
 * 
 */
package com.daynilgroup.vendormanagement.repository.custom.impl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.ListJoin;
import javax.persistence.criteria.Order;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.persistence.criteria.Selection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Repository;

import com.daynilgroup.vendormanagement.constants.Constants;
import com.daynilgroup.vendormanagement.constants.DeploymentTypeEnum;
import com.daynilgroup.vendormanagement.constants.StatusEnum;
import com.daynilgroup.vendormanagement.entity.Address;
import com.daynilgroup.vendormanagement.entity.Address_;
import com.daynilgroup.vendormanagement.entity.CodeLookup;
import com.daynilgroup.vendormanagement.entity.CodeLookup_;
import com.daynilgroup.vendormanagement.entity.Job;
import com.daynilgroup.vendormanagement.entity.Job_;
import com.daynilgroup.vendormanagement.entity.Resource;
import com.daynilgroup.vendormanagement.entity.Resource_;
import com.daynilgroup.vendormanagement.entity.SkillsCodeLookup;
import com.daynilgroup.vendormanagement.entity.SkillsCodeLookup_;
import com.daynilgroup.vendormanagement.entity.Vendor;
import com.daynilgroup.vendormanagement.entity.Vendor_;
import com.daynilgroup.vendormanagement.model.pag.PageModel;
import com.daynilgroup.vendormanagement.model.pag.PaginationRequestModel;
import com.daynilgroup.vendormanagement.model.request.JobFilterRequest;
import com.daynilgroup.vendormanagement.model.request.JobSearchRequest;
import com.daynilgroup.vendormanagement.model.response.DropdownResponse;
import com.daynilgroup.vendormanagement.model.response.JobListResponse;
import com.daynilgroup.vendormanagement.repository.CodeLookupRepository;
import com.daynilgroup.vendormanagement.repository.custom.JobCustomRepository;
import com.daynilgroup.vendormanagement.service.VendorService;
import com.daynilgroup.vendormanagement.util.CommonUtil;
import com.daynilgroup.vendormanagement.util.CriteriaUtil;
import com.daynilgroup.vendormanagement.util.EntityUtil;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;

/**
 * @author Prerana
 *
 */
@Repository
@FieldDefaults(level = AccessLevel.PRIVATE)
public class JobCustomRepositoryImpl implements JobCustomRepository {

	@PersistenceContext
	EntityManager entityManager;

	@Autowired
	CriteriaUtil criteriaUtil;

	@Autowired
	EntityUtil entityUtil;
	
	@Autowired
	CodeLookupRepository codeLookupRepository;
	
	@Autowired 
	VendorService vendorService;

	@Override
	public PageModel getJobsFilterList(JobFilterRequest jobFilterRequest) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<JobListResponse> listQuery = criteriaBuilder.createQuery(JobListResponse.class);
		populateQuery(criteriaBuilder, listQuery, jobFilterRequest, false);
		CriteriaQuery<Long> countQuery = criteriaBuilder.createQuery(Long.class);
		populateQuery(criteriaBuilder, countQuery, jobFilterRequest, true);

		return criteriaUtil.getPageModel(listQuery, countQuery, jobFilterRequest.getPaginationRequestModel());
	}

	private void populateQuery(CriteriaBuilder criteriaBuilder, CriteriaQuery<?> criteriaQuery,
			JobFilterRequest jobFilterRequest, boolean isCount) {

		Root<Job> job = criteriaQuery.from(Job.class);
		Join<Job, Vendor> vendor = job.join(Job_.vendor);
		Join<Job, CodeLookup> countryCodeLookup = job.join(Job_.country,JoinType.LEFT);
		List<Predicate> predicates = criteriaUtil.getDefaultPredicates(criteriaBuilder, job);
		
		criteriaUtil.addPredicates( criteriaBuilder, predicates,vendor.get(Vendor_.ID),
			    jobFilterRequest.getVendorId() == null ? entityUtil.getCurrentVendorId() : jobFilterRequest.getVendorId());

		criteriaUtil.addPredicates(criteriaBuilder, predicates, job.get(Job_.NO_OF_RESOURCES),
				jobFilterRequest.getNoOfResources());

		criteriaUtil.addPredicates(criteriaBuilder, predicates, job.get(Job_.WORK_FROM),
				jobFilterRequest.getWorkFrom());
		criteriaUtil.addPredicates(criteriaBuilder, predicates, countryCodeLookup.get(CodeLookup_.ID),
				jobFilterRequest.getCountryId());
		criteriaUtil.addPredicates(criteriaBuilder, predicates, job.get(Job_.TITLE), jobFilterRequest.getTitle());
		criteriaUtil.addPredicates(criteriaBuilder, predicates, job.get(Job_.CURRENCY_TYPE),
				jobFilterRequest.getCurrencyTypeEnum());
		criteriaUtil.addPredicates(criteriaBuilder, predicates, job.get(Job_.RATE_TYPE_ENUM),
				jobFilterRequest.getRateType());

		if (!CommonUtil.isEmpty(jobFilterRequest.getSkillIds())) {
			for (Long id : jobFilterRequest.getSkillIds()) {
				ListJoin<Job, SkillsCodeLookup> skillsCodeLookup = job.join(Job_.skillsCodeLookup, JoinType.LEFT);
				Join<SkillsCodeLookup, CodeLookup> skills = skillsCodeLookup.join(SkillsCodeLookup_.CODE_LOOKUP,
						JoinType.LEFT);

				predicates.add(criteriaBuilder.equal(skills.get(CodeLookup_.ID), id));
			}

		}

		if (jobFilterRequest.getStatus() != null && StatusEnum.ON_HOLD.equals(jobFilterRequest.getStatus())) {
			predicates.add(criteriaBuilder.notEqual(job.get(Job_.STATUS_ENUM), StatusEnum.REJECTED));
			predicates.add(criteriaBuilder.notEqual(job.get(Job_.STATUS_ENUM), StatusEnum.CLOSED));
			criteriaUtil.addPredicates(criteriaBuilder, predicates, job.get(Job_.ACTIVE), Boolean.FALSE);
		} else if ((jobFilterRequest.getStatus() != null) && (StatusEnum.VERIFIED.equals(jobFilterRequest.getStatus())
				|| StatusEnum.UNVERIFIED.equals(jobFilterRequest.getStatus()))) {
			criteriaUtil.addPredicates(criteriaBuilder, predicates, job.get(Job_.STATUS_ENUM),
					jobFilterRequest.getStatus());

			criteriaUtil.addPredicates(criteriaBuilder, predicates, job.get(Job_.ACTIVE), Boolean.TRUE);
		} else if (jobFilterRequest.getStatus() != null && StatusEnum.REJECTED.equals(jobFilterRequest.getStatus())) {
			criteriaUtil.addPredicates(criteriaBuilder, predicates, job.get(Job_.STATUS_ENUM),
					jobFilterRequest.getStatus());
		}
		else if (jobFilterRequest.getStatus() != null && StatusEnum.CLOSED.equals(jobFilterRequest.getStatus())) {
			criteriaUtil.addPredicates(criteriaBuilder, predicates, job.get(Job_.STATUS_ENUM),
					jobFilterRequest.getStatus());
		}

		if (jobFilterRequest.getMinExperience() != null) {
			criteriaUtil.addPredicatesGreaterThenOrEqualTo(criteriaBuilder, predicates, job.get(Job_.MIN_EXPERIENCE),
					jobFilterRequest.getMinExperience());

		}
		if (jobFilterRequest.getMaxExperience() != null) {
			criteriaUtil.addPredicatesLessThenOrEqualTo(criteriaBuilder, predicates, job.get(Job_.MAX_EXPERIENCE),
					jobFilterRequest.getMaxExperience());

		}
		if (jobFilterRequest.getMinRate() != null) {
			criteriaUtil.addPredicatesGreaterThenOrEqualTo(criteriaBuilder, predicates, job.get(Job_.MIN_RATE),
					jobFilterRequest.getMinRate());
		}
		if (jobFilterRequest.getMaxRate() != null) {
			criteriaUtil.addPredicatesLessThenOrEqualTo(criteriaBuilder, predicates, job.get(Job_.MAX_RATE),
					jobFilterRequest.getMaxRate());
		}

		Selection<?> selection;
		if (isCount) {
			selection = criteriaBuilder.countDistinct(job);
		} else {
			criteriaQuery.groupBy(job.get(Job_.ID));
			selection = criteriaBuilder.construct(JobListResponse.class, job.get(Job_.ID),
					 countryCodeLookup.get(CodeLookup_.NAME), job.get(Job_.TITLE),
					job.get(Job_.WORK_FROM), job.get(Job_.RATE_TYPE_ENUM), job.get(Job_.MIN_RATE),
					job.get(Job_.MAX_RATE), job.get(Job_.NO_OF_RESOURCES), job.get(Job_.MIN_EXPERIENCE),
					job.get(Job_.MAX_EXPERIENCE), job.get(Job_.START_DATE), job.get(Job_.CREATED_ON),
					job.get(Job_.CURRENCY_TYPE), job.get(Job_.STATUS_ENUM), 
					job.get(Job_.ACTIVE),job.get(Job_.CLOSED_DATE),job.get(Job_.LOCATION),job.get(Job_.DURATION));
		}

		Order order = criteriaBuilder.desc(job.get(Job_.ID));
		criteriaUtil.populateCriteriaQuery(criteriaQuery, selection, predicates, order);
	}

	@Override
	public PageModel getJobsSearchFilter(JobSearchRequest jobRequestAdvanced) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();

		CriteriaQuery<JobListResponse> listQuery = criteriaBuilder.createQuery(JobListResponse.class);
		populateQuery(criteriaBuilder, listQuery, jobRequestAdvanced, false);

		CriteriaQuery<Long> countQuery = criteriaBuilder.createQuery(Long.class);
		populateQuery(criteriaBuilder, countQuery, jobRequestAdvanced, true);

		return criteriaUtil.getPageModel(listQuery, countQuery, jobRequestAdvanced.getPaginationRequestModel());
	}

	private void populateQuery(CriteriaBuilder criteriaBuilder, CriteriaQuery<?> criteriaQuery,
			JobSearchRequest jobRequestAdvanced, boolean isCount) {

		Root<SkillsCodeLookup> root = criteriaQuery.from(SkillsCodeLookup.class);
		Join<SkillsCodeLookup, Job> skillJob = root.join(SkillsCodeLookup_.job, JoinType.LEFT);

		Join<Job, CodeLookup> duration = skillJob.join(Job_.DURATION,JoinType.LEFT);
		//Join<Job, RateTypeEnum> rateTypeEnum = skillJob.join(Job_.RATE_TYPE_ENUM,JoinType.LEFT);
		Join<Job, CodeLookup> country = skillJob.join(Job_.COUNTRY,JoinType.LEFT);
		Join<Job, Vendor> vendor = skillJob.join(Job_.VENDOR);
	//	Join<Resource, CodeLookup> country = skillJob.join(Job_.COUNTRY,JoinType.LEFT);
		ListJoin<Job, SkillsCodeLookup> jobSkillsCodeLookup = skillJob.join(Job_.skillsCodeLookup, JoinType.LEFT);
		Join<SkillsCodeLookup, CodeLookup> skills = jobSkillsCodeLookup.join(SkillsCodeLookup_.CODE_LOOKUP,
				JoinType.LEFT);

		//	List<DropdownResponse> valueLabel = jobRequestAdvanced.getKeyWords();
//		List<String> keywords = new ArrayList<>();
//
//		for (DropdownResponse dropdownResponse : valueLabel) {
//			if (dropdownResponse.getLabel() != null) {
//				keywords.add(dropdownResponse.getLabel());
//			}
//		}

		List<Predicate> predicates = criteriaUtil.getDefaultPredicates(criteriaBuilder, root);
		Long currentVendorId = entityUtil.getCurrentVendorId();
//		if (!keywords.isEmpty()) {
//
//			switch (jobRequestAdvanced.getJobSearchInTypeEnum()) {
//
//			case TITLEANDSKILLS:
//
//				criteriaUtil.addPredicatesAnd(criteriaBuilder, predicates, skills.get(CodeLookup_.NAME),
//						skillJob.get(Job_.TITLE), keywords);
//
//				break;
//			case TITLE:
//				criteriaUtil.addPredicates(criteriaBuilder, predicates, skillJob.get(Job_.TITLE), keywords);
//
//				break;
//
//			case KEYSKILLS:
//				predicates.add(skills.get(CodeLookup_.ID).isNotNull());
//
//				criteriaUtil.addPredicates(criteriaBuilder, predicates, skills.get(CodeLookup_.NAME), keywords);
//
//				break;
//
//			default:
//
//				criteriaUtil.addPredicatesOr(criteriaBuilder, predicates, skills.get(CodeLookup_.NAME),
//						skillJob.get(Job_.TITLE), keywords);
//				break;
//			}
//		}
		criteriaUtil.addPredicatesOr(criteriaBuilder, predicates, skills.get(CodeLookup_.NAME),
		skillJob.get(Job_.TITLE), jobRequestAdvanced.getKeyword());

		criteriaUtil.addPredicates(criteriaBuilder, predicates, skillJob.get(Job_.RATE_TYPE_ENUM),
				jobRequestAdvanced.getRateTypeEnum());
		
		if(jobRequestAdvanced.getWorkFrom() !=null &&jobRequestAdvanced.getWorkFrom().equals(DeploymentTypeEnum.REMOTE)&&jobRequestAdvanced.getCountryName()!=null) {
			List<CodeLookup> countries = codeLookupRepository.getByType_codeAndNameLikeOrNameIsNullAndActiveTrueAndDeletedFalseOrDeletedIsNull("PHONE-CODE", jobRequestAdvanced.getCountryName());
			for (CodeLookup vendorCountry : countries) {
				String modifiedCountryName = vendorCountry.getName().replaceAll(Constants.REMOVE_COUNTRY_CODE, "").replaceAll(" ",
						"");
				if(jobRequestAdvanced.getCountryName().replaceAll(" ", "").equals(modifiedCountryName)) {
					Join<Vendor, CodeLookup> vendorCountryCodelookup = vendor.join(Vendor_.COUNTRY_CODE);
					criteriaUtil.addPredicates(criteriaBuilder, predicates, vendorCountryCodelookup.get(CodeLookup_.ID),
							vendorCountry.getId());
					break;
				}

			}
			if(countries.size()==0) {
				criteriaUtil.addPredicates(criteriaBuilder, predicates, skillJob.get(Job_.STATUS_ENUM), StatusEnum.UNVERIFIED);
			}
		}
		else if (jobRequestAdvanced.getWorkFrom() != null
				&& !jobRequestAdvanced.getWorkFrom().equals(DeploymentTypeEnum.REMOTE)
				&& jobRequestAdvanced.getCountryId() == null) {

			if (currentVendorId != null) {
			
			Vendor currentVendor = vendorService.findById(currentVendorId);
			String currentVendorCountry = currentVendor.getCountryCode().getName();
			String modifiedCountryName = currentVendorCountry.replaceAll(Constants.REMOVE_COUNTRY_CODE, "").replaceAll(" ", "");
			List<CodeLookup> countries = codeLookupRepository
					.getByTypeCodeAndDeletedFalseOrDeletedIsNull(Constants.COUNTRY, modifiedCountryName);

			for (CodeLookup vendorCountry : countries) {
				String removedSpaceCountryName = vendorCountry.getName().replaceAll(" ", "");
				if (modifiedCountryName.equals(removedSpaceCountryName)) {
					criteriaUtil.addPredicates(criteriaBuilder, predicates, country.get(CodeLookup_.ID),
							vendorCountry.getId());
				}
			}
			if (countries.size() == 0) {
				criteriaUtil.addPredicates(criteriaBuilder, predicates, skillJob.get(Job_.STATUS_ENUM),
						StatusEnum.UNVERIFIED);
			}
			}

		} else if (jobRequestAdvanced.getWorkFrom() != null
				&& !jobRequestAdvanced.getWorkFrom().equals(DeploymentTypeEnum.REMOTE)
				&& jobRequestAdvanced.getCountryId() != null) {
			criteriaUtil.addPredicates(criteriaBuilder, predicates, country.get(CodeLookup_.ID),
					jobRequestAdvanced.getCountryId());
		}
		criteriaUtil.addPredicates(criteriaBuilder, predicates, country.get(CodeLookup_.ID),
				jobRequestAdvanced.getCountryId());
		
		criteriaUtil.addPredicates(criteriaBuilder, predicates, skillJob.get(Job_.WORK_FROM),
				jobRequestAdvanced.getWorkFrom());
		
		
		criteriaUtil.addPredicates(criteriaBuilder, predicates, duration.get(CodeLookup_.ID),
				jobRequestAdvanced.getDurationId());
		if (jobRequestAdvanced.getMinExperience() != null) {
			criteriaUtil.addPredicatesGreaterThenOrEqualTo(criteriaBuilder, predicates,
					skillJob.get(Job_.MIN_EXPERIENCE), jobRequestAdvanced.getMinExperience());

		}
		if (jobRequestAdvanced.getMaxExperience() != null) {
			criteriaUtil.addPredicatesLessThenOrEqualTo(criteriaBuilder, predicates, skillJob.get(Job_.MAX_EXPERIENCE),
					jobRequestAdvanced.getMaxExperience());

		}
		if (jobRequestAdvanced.getMinRate() != null) {
			criteriaUtil.addPredicatesGreaterThenOrEqualTo(criteriaBuilder, predicates, skillJob.get(Job_.MIN_RATE),
					jobRequestAdvanced.getMinRate());
		}
		if (jobRequestAdvanced.getMaxRate() != null) {
			criteriaUtil.addPredicatesLessThenOrEqualTo(criteriaBuilder, predicates, skillJob.get(Job_.MAX_RATE),
					jobRequestAdvanced.getMaxRate());
		}
		criteriaUtil.addPredicates(criteriaBuilder, predicates, skillJob.get(Job_.ACTIVE), Boolean.TRUE);
		criteriaUtil.addPredicates(criteriaBuilder, predicates, skillJob.get(Job_.STATUS_ENUM), StatusEnum.VERIFIED);
		if (currentVendorId != null) {
			predicates.add(criteriaBuilder.notEqual(vendor.get(Vendor_.ID), currentVendorId));
		}
		criteriaUtil.addPredicates(criteriaBuilder, predicates, skillJob.get(Job_.CURRENCY_TYPE),
				jobRequestAdvanced.getCurrencyTypeEnum());

		Selection<?> selection;
		if (isCount) {
			selection = criteriaBuilder.countDistinct(skillJob);
		} else {

			selection = criteriaBuilder.construct(JobListResponse.class, skillJob.get(Job_.ID),
					country.get(CodeLookup_.NAME),
					skillJob.get(Job_.TITLE), skillJob.get(Job_.WORK_FROM), skillJob.get(Job_.RATE_TYPE_ENUM),
					skillJob.get(Job_.MIN_RATE), skillJob.get(Job_.MAX_RATE), skillJob.get(Job_.NO_OF_RESOURCES),
					skillJob.get(Job_.MIN_EXPERIENCE), skillJob.get(Job_.MAX_EXPERIENCE), skillJob.get(Job_.START_DATE),
					skillJob.get(Job_.CREATED_ON), skillJob.get(Job_.CURRENCY_TYPE), skillJob.get(Job_.UPDATED_ON),
					skillJob.get(Job_.STATUS_ENUM),skillJob.get(Job_.LOCATION),skillJob.get(Job_.DURATION));
		}
		Order order = null ;
		if (jobRequestAdvanced.getPaginationRequestModel().getSortBy().equals(Constants.NAME)
				&& jobRequestAdvanced.getPaginationRequestModel().getSortDirection().equals(Direction.ASC)) {
			order= criteriaBuilder.asc(skillJob.get(Job_.TITLE));
		}
		else if (jobRequestAdvanced.getPaginationRequestModel().getSortBy().equals(Constants.NAME)
				&& jobRequestAdvanced.getPaginationRequestModel().getSortDirection().equals(Direction.DESC)) {
			order= criteriaBuilder.desc(skillJob.get(Job_.TITLE));
		}
		else if (jobRequestAdvanced.getPaginationRequestModel().getSortBy().equals(Constants.RATE)
				&& jobRequestAdvanced.getPaginationRequestModel().getSortDirection().equals(Direction.ASC)) {
			order= criteriaBuilder.asc(skillJob.get(Job_.MIN_RATE));
		}else if (jobRequestAdvanced.getPaginationRequestModel().getSortBy().equals(Constants.ID)
				&& jobRequestAdvanced.getPaginationRequestModel().getSortDirection().equals(Direction.DESC)) {
			order=criteriaBuilder.desc(skillJob.get(Job_.ID));
		}
		else {
			order= criteriaBuilder.desc(skillJob.get(Job_.MIN_RATE));
		}
		criteriaUtil.populateCriteriaQuery(criteriaQuery, selection, predicates, order);
	}

}
