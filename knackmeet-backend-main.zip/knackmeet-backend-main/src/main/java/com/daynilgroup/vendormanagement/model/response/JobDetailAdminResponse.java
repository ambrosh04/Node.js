package com.daynilgroup.vendormanagement.model.response;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;

import com.daynilgroup.vendormanagement.constants.CurrencyTypeEnum;
import com.daynilgroup.vendormanagement.constants.DeploymentTypeEnum;
import com.daynilgroup.vendormanagement.constants.JobTypeEnum;
import com.daynilgroup.vendormanagement.constants.RateTypeEnum;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class JobDetailAdminResponse {
	static final long serialVersionUID = 1L;

	Long id;

	String title;

	Long countryId;

	Long stateId;

	AdvanceSearchDropdownModel city;

	List<AdvanceSearchDropdownModel> skills;

	Integer noOfResources;

	Long categoryId;

	DeploymentTypeEnum workFrom;

	Integer minExperience;

	Integer maxExperience;

	Long durationId;

	JobTypeEnum jobType;

	CurrencyTypeEnum currencyType;

	RateTypeEnum rateType;

	BigDecimal minRate;

	BigDecimal maxRate;

	String description;

	LocalDateTime startDate;

	LocalDateTime postedDate;
	
	String location;
	
	BigDecimal latitude;
	
	BigDecimal longitude;
	
	LocalTime startTime;

	LocalTime endTime;

}
