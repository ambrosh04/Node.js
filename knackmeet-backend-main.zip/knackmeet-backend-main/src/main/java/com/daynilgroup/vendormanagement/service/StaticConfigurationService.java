package com.daynilgroup.vendormanagement.service;


import org.springframework.data.domain.Pageable;

import org.springframework.data.domain.Page;

import com.daynilgroup.vendormanagement.constants.StaticConfigurationEnum;
import com.daynilgroup.vendormanagement.entity.StaticConfiguration;


public interface StaticConfigurationService  extends AbstractService<StaticConfiguration>{

	Page<StaticConfiguration> getList(Pageable pageable);
	
	StaticConfiguration findByName(StaticConfigurationEnum staticConfigurationEnum);
		
	
}
