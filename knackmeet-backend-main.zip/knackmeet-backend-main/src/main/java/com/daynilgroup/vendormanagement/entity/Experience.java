package com.daynilgroup.vendormanagement.entity;

import java.math.BigDecimal;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.daynilgroup.vendormanagement.constants.DeploymentTypeEnum;
import com.daynilgroup.vendormanagement.constants.EmploymentTypeEnum;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

@Data
@Entity
@Table(name = "experience")
@AllArgsConstructor
@NoArgsConstructor
@FieldDefaults(level=AccessLevel.PRIVATE)
public class Experience extends BaseEntity{
	
	static final long serialVersionUID = 1L;

	@JoinColumn(name = "title_id", referencedColumnName = "id", nullable = false)
	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	CodeLookup title;
	
	@Enumerated(EnumType.STRING)
	@Column(name = "employment_type", nullable = false)
	EmploymentTypeEnum employmentType; 
	
	@JoinColumn(name = "company_id", referencedColumnName = "id", nullable = false)
	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	Company company;
	
	@Column(name="company_address", nullable = false)
	String companyAddress;
	
	@Column(name="latitude", nullable = false)
	BigDecimal companyLatitude;
	
	@Column(name="longitude", nullable = false)
	BigDecimal companyLongitude;
	
	@Enumerated(EnumType.STRING)
	@Column(name="deployment_type")
	DeploymentTypeEnum deploymentType;
	
	@Column(name="from_month", nullable = false)
	Integer fromMonth;
	
	@Column(name="to_month")
	Integer toMonth;
	
	@Column(name="from_year", nullable = false)
	Integer fromYear;
	
	@Column(name="to_year")
	Integer toYear;
	
	@JoinColumn(name = "industry_id", referencedColumnName = "id", nullable = false)
	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	CodeLookup industry;
	
	@Column(name="description")   
	@Lob
	String description;
	
	@OneToMany(mappedBy = "experience", fetch = FetchType.LAZY)
	List<ExperienceSkillsCodeLookup> experienceSkillsCodeLookup;
	
	@JoinColumn(name = "resource_id", referencedColumnName = "id")
	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	Resource resource;
	
	@Column(name = "present_company")
	Boolean PresentCompany = false;
	
}
