package com.daynilgroup.vendormanagement.model.response;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import com.daynilgroup.vendormanagement.constants.DeploymentTypeEnum;
import com.daynilgroup.vendormanagement.constants.EmploymentTypeEnum;
import com.daynilgroup.vendormanagement.request.ExperienceSkillsCodeLookupRequest;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class ExperienceDetailAdminResponse implements Serializable {

	static final long serialVersionUID = 1L;

	Long id;

	AdvanceSearchDropdownModel title;

	EmploymentTypeEnum employmentType;
	
	CompanyResponse company;

	String companyAddress;

	BigDecimal companyLatitude;

	BigDecimal companyLongitude;

	DeploymentTypeEnum deploymentType;

	Integer fromMonth;

	Integer toMonth;

	Integer fromYear;

	Integer toYear;

	AdvanceSearchDropdownModel industry;

	String description;

	List<AdvanceSearchDropdownModel> skillsCodeLookups;

	Long resource;
	
	Boolean presentCompany;

}
