package com.daynilgroup.vendormanagement.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;

import com.daynilgroup.vendormanagement.constants.StatusEnum;
import com.daynilgroup.vendormanagement.entity.Vendor;
import com.daynilgroup.vendormanagement.entity.VerifyEmail;
import com.daynilgroup.vendormanagement.repository.VerifyEmailRepository;
import com.daynilgroup.vendormanagement.service.VendorService;
import com.daynilgroup.vendormanagement.service.VerifyEmailService;

@Service
public class VerifyEmailServiceImpl implements VerifyEmailService {
	
	@Autowired
	VerifyEmailRepository verifyEmailRepository;
	
	@Autowired 
	VendorService vendorService;

	@Override
	public JpaRepository<VerifyEmail, Long> getJpaRepository() {
		// TODO Auto-generated method stub
		return verifyEmailRepository;
	}

	@Override
	public String verifyEmail(String randomNumer) throws Exception {
		String message="";
		VerifyEmail verifyEmail = verifyEmailRepository.findByRandomNumber(randomNumer);
		if(verifyEmail!=null)
		{
			if(verifyEmail.getStatusEnum()==StatusEnum.EMAIL_PENDING)
			{
				Vendor vendor = verifyEmail.getVendor();
				vendor.setDeleted(Boolean.FALSE);
				vendor.setStatusEnum(StatusEnum.UNVERIFIED);
				vendorService.save(vendor);
				verifyEmail.setStatusEnum(StatusEnum.VERIFIED);
				save(verifyEmail);
				message ="Your email is confirmed.";
			}
			else {
				message="Your email is already confirmed.";
			}
			return message;	
		}
		else {
			throw new Exception("Something went wrong");
		}
	}

	@Override
	public VerifyEmail findByVendorId(Long vendorId) {

		return verifyEmailRepository.findByVendorId(vendorId);
	}
	
}
