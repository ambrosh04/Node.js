package com.daynilgroup.vendormanagement.model.response;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

import com.daynilgroup.vendormanagement.constants.ResourceStatusEnum;

import lombok.AccessLevel;
import lombok.Builder;
import lombok.Data;
import lombok.experimental.FieldDefaults;

@Builder
@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
public class JobResponse {

	Long jobId;

	String category;

	List<String> skills;

	String city;

	String state;

	String country;

	String title;

	String workFrom;

	String rateType;

	BigDecimal minRate;

	BigDecimal maxRate;

	Integer noOfResource;

	Integer minExperience;

	Integer maxExperience;

	LocalDateTime startDate;

	LocalDateTime postedDate;

	String currencyType;

	String status;

	LocalDateTime updatedOn;

	Boolean active;

	Integer percentage;
	
	ResourceStatusEnum statusEnum;
	
	String location;

}
