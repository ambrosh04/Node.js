package com.daynilgroup.vendormanagement.model.response;

import com.daynilgroup.vendormanagement.constants.StatusEnum;

import lombok.AccessLevel;
import lombok.Builder;
import lombok.Data;
import lombok.experimental.FieldDefaults;

@Data
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
public class CodeLookupDetailAdminResponse {

	static final long serialVersionUID = 1L;
	String description;
	String name;
	Long typeId;
	String typeName;
	Long id;
	Long parentId;
	Boolean active;
	StatusEnum status;
	String image;
	Integer displayOrder;

}