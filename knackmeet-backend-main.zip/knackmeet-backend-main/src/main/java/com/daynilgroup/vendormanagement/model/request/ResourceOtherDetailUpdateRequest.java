package com.daynilgroup.vendormanagement.model.request;

import java.io.Serializable;
import java.math.BigDecimal;

import com.daynilgroup.vendormanagement.constants.CurrencyTypeEnum;
import com.daynilgroup.vendormanagement.constants.DeploymentTypeEnum;
import com.daynilgroup.vendormanagement.constants.RateTypeEnum;
import com.daynilgroup.vendormanagement.model.response.AdvanceSearchDropdownModel;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

@Data
@AllArgsConstructor
@NoArgsConstructor
@FieldDefaults(level =AccessLevel.PRIVATE)
public class ResourceOtherDetailUpdateRequest implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	Long id;
	
	AdvanceSearchDropdownModel designation;

	DeploymentTypeEnum deploymenType;

	Long availabilityId;

	Long countryId;

	Long categoryId;

	BigDecimal rate;

	CurrencyTypeEnum currencyType;

	RateTypeEnum rateTypeEnum;

	BigDecimal usdRate;

	RateTypeEnum usdRateType;
	
    String location;
	
	BigDecimal latitude;
	
	BigDecimal longitude;


}
