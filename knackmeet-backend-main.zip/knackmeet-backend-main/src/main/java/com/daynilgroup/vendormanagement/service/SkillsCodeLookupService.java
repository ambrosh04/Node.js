package com.daynilgroup.vendormanagement.service;

import java.util.List;

import com.daynilgroup.vendormanagement.entity.SkillsCodeLookup;

public interface SkillsCodeLookupService extends AbstractService<SkillsCodeLookup> {

	public void deleteByJobId(Long jobId);

	List<SkillsCodeLookup> findAllByJobId(Long jobId);
}
