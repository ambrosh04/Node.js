package com.daynilgroup.vendormanagement.rest.controller.inf.embedded;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;

import com.daynilgroup.vendormanagement.entity.BaseEntity;
import com.daynilgroup.vendormanagement.exception.SaveRestException;
import com.daynilgroup.vendormanagement.helper.AbstractHelper;
import com.daynilgroup.vendormanagement.repository.event.PostSave;
import com.daynilgroup.vendormanagement.repository.event.PreSave;
import com.daynilgroup.vendormanagement.request.inf.RequestInf;
import com.daynilgroup.vendormanagement.rest.exception.ValidationRestException;
import com.daynilgroup.vendormanagement.service.AbstractService;

/**
 *
 * @author Manish
 * @param <E>
 * @param <C>
 */

public interface Create<E, C> extends AbstractInf {

	@SuppressWarnings("rawtypes")
	public AbstractService getService();

	@SuppressWarnings("rawtypes")
	public AbstractHelper getHelper();

	@Transactional
	default public ResponseEntity<Object> create(C request) throws Exception {
		try {
			List<String> errorMsgList = new ArrayList<>();
			if (getHelper() instanceof PreSave && ((RequestInf) request).getId() != null) {
				Object oldEntity = getService().findById(((RequestInf) request).getId());
				if (oldEntity != null) {
					try {
						((PreSave) getHelper()).preSaveAction(oldEntity, request);
					} catch (Exception e) {
						errorMsgList.add("PreSave activity failed." + e.getMessage());
						return new ResponseEntity<>(new ValidationRestException(errorMsgList),
								HttpStatus.INTERNAL_SERVER_ERROR);
					}
				}
			}
			Object entity = getHelper().getEntity(request);
			entity = getService().save(entity);
			getHelper().uploadImage(entity, request);
			getService().save(entity);
			if (this instanceof PostSave) {
				if (((PostSave) this).postSaveAction(entity, request)) {
					getService().save(entity);
				}
			}
			Long entityId = null;
			if (entity instanceof BaseEntity) {
				entityId = ((BaseEntity) entity).getId();
			}
			return new ResponseEntity<>(entityId, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<>(new SaveRestException(e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

}