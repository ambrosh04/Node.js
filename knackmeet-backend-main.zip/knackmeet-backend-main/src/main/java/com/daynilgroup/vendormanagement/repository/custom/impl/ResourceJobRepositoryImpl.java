
/**
 * 
 */
package com.daynilgroup.vendormanagement.repository.custom.impl;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Order;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.persistence.criteria.Selection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.daynilgroup.vendormanagement.constants.CurrencyTypeEnum;
import com.daynilgroup.vendormanagement.constants.ResourceStatusEnum;
import com.daynilgroup.vendormanagement.entity.Address;
import com.daynilgroup.vendormanagement.entity.Address_;
import com.daynilgroup.vendormanagement.entity.CodeLookup;
import com.daynilgroup.vendormanagement.entity.CodeLookup_;
import com.daynilgroup.vendormanagement.entity.Job;
import com.daynilgroup.vendormanagement.entity.Job_;
import com.daynilgroup.vendormanagement.entity.Resource;
import com.daynilgroup.vendormanagement.entity.ResourceJobs;
import com.daynilgroup.vendormanagement.entity.ResourceJobs_;
import com.daynilgroup.vendormanagement.entity.Resource_;
import com.daynilgroup.vendormanagement.entity.User;
import com.daynilgroup.vendormanagement.entity.User_;
import com.daynilgroup.vendormanagement.entity.Vendor;
import com.daynilgroup.vendormanagement.entity.Vendor_;
import com.daynilgroup.vendormanagement.model.filter.JobsFilterModel;
import com.daynilgroup.vendormanagement.model.filter.ResourceFilterModel;
import com.daynilgroup.vendormanagement.model.inf.DateUtil;
import com.daynilgroup.vendormanagement.model.pag.PageModel;
import com.daynilgroup.vendormanagement.model.request.ResourceJobFilterRequest;
import com.daynilgroup.vendormanagement.model.response.JobListResponse;
import com.daynilgroup.vendormanagement.model.response.ResourceListResponse;
import com.daynilgroup.vendormanagement.repository.ResourceJobCustomRepository;
import com.daynilgroup.vendormanagement.request.InvitationsSendRequest;
import com.daynilgroup.vendormanagement.util.CriteriaUtil;
import com.daynilgroup.vendormanagement.util.EntityUtil;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;

/**
 * @author Prerana
 *
 */
@Repository
@FieldDefaults(level = AccessLevel.PRIVATE)
public class ResourceJobRepositoryImpl implements ResourceJobCustomRepository {

	@PersistenceContext
	EntityManager entityManager;

	@Autowired
	CriteriaUtil criteriaUtil;

	@Autowired
	EntityUtil entityUtil;

	@Override
	public PageModel getResourceListByStatus(ResourceFilterModel resourceJobFilterModel) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();

		CriteriaQuery<ResourceListResponse> listQuery = criteriaBuilder.createQuery(ResourceListResponse.class);
		populateQuery(criteriaBuilder, listQuery, resourceJobFilterModel, false);

		CriteriaQuery<Long> countQuery = criteriaBuilder.createQuery(Long.class);
		populateQuery(criteriaBuilder, countQuery, resourceJobFilterModel, true);

		return criteriaUtil.getPageModel(listQuery, countQuery, resourceJobFilterModel.getPaginationRequestModel());
	}

	private void populateQuery(CriteriaBuilder criteriaBuilder, CriteriaQuery<?> criteriaQuery,
			ResourceFilterModel resourceJobFilterModel, Boolean isCount) {

		Root<ResourceJobs> resourceJobs = criteriaQuery.from(ResourceJobs.class);
		Join<ResourceJobs, Resource> resource = resourceJobs.join(ResourceJobs_.resource);

		Join<ResourceJobs, Job> job = resourceJobs.join(ResourceJobs_.job);
		Join<Resource, Vendor> vendor = resource.join(Resource_.vendor);

		Join<Resource, CodeLookup> availability = resource.join(Resource_.availability);
		Join<Resource, CodeLookup> designation = resource.join(Resource_.designation);
		Join<Resource, CodeLookup> country = resource.join(Resource_.country,JoinType.LEFT);
		Join<ResourceJobs, User> user = resourceJobs.join(ResourceJobs_.APPLIED_BY,JoinType.LEFT);
		List<Predicate> predicates = new ArrayList<>();
		criteriaUtil.addDefaultPredicates(criteriaBuilder, predicates, resourceJobs);
		criteriaUtil.addPredicates(criteriaBuilder, predicates, job.get(Job_.ID), resourceJobFilterModel.getJobId());
		criteriaUtil.addPredicates(criteriaBuilder, predicates, resourceJobs.get(ResourceJobs_.RESOURCE_STATUS),
				resourceJobFilterModel.getResourceStatusEnum());
		criteriaUtil.addPredicates(criteriaBuilder, predicates, resource.get(Resource_.NAME),
				resourceJobFilterModel.getName());
		if(resourceJobFilterModel.getCurrencyType().equals(CurrencyTypeEnum.INR)) {
			criteriaUtil.addPredicatesIsNotNull(criteriaBuilder, predicates, resourceJobs.get(ResourceJobs_.RESOURCE).get(Resource_.RATE), Boolean.TRUE);
		}else if(resourceJobFilterModel.getCurrencyType().equals(CurrencyTypeEnum.USD)){
			criteriaUtil.addPredicatesIsNotNull(criteriaBuilder, predicates,resourceJobs.get(ResourceJobs_.RESOURCE).get(Resource_.USD_RATE), Boolean.TRUE);
		}

//		criteriaUtil.addPredicatesNotIn(criteriaBuilder, predicates, resourceJobs.get(ResourceJobs_.RESOURCE_STATUS),
//				Arrays.asList(ResourceStatusEnum.INVITED));

		if (resourceJobFilterModel.getStartDate() != null && resourceJobFilterModel.getEndDate() != null) {
			String startDate = resourceJobFilterModel.getStartDate();
			String endDate = resourceJobFilterModel.getEndDate();
			predicates.add(criteriaBuilder.greaterThanOrEqualTo(resourceJobs.get(ResourceJobs_.UPDATED_ON),
					LocalDateTime.parse(startDate, DateUtil.dateTimeFormatter())));
			predicates.add(criteriaBuilder.lessThanOrEqualTo(resourceJobs.get(ResourceJobs_.UPDATED_ON),
					LocalDateTime.parse(endDate, DateUtil.dateTimeFormatter())));
		}
		Selection<?> selection;
		if (isCount) {
			selection = criteriaBuilder.countDistinct(resourceJobs);
		} else {
			selection = criteriaBuilder.construct(ResourceListResponse.class, resourceJobs.get(ResourceJobs_.ID),
					resource.get(Resource_.ID), resource.get(Resource_.FIRST_NAME), resource.get(Resource_.LAST_NAME),
					availability.get(CodeLookup_.NAME), designation.get(CodeLookup_.NAME), resourceJobs.get(ResourceJobs_.RESOURCE_INR_RATE),
					resource.get(Resource_.CURRENCY_TYPE), resource.get(Resource_.RATE_TYPE_ENUM),
					resource.get(Resource_.YEARS_EXPERIENCE), resource.get(Resource_.MONTHS_EXPERIENCE),
					country.get(CodeLookup_.NAME), resource.get(Resource_.GENDER),
					resource.get(Resource_.ACTIVE), resource.get(Resource_.HIGHER_EDUCATION),
					resource.get(Resource_.PASSING_YEAR), resource.get(Resource_.STATUS_ENUM),
					resourceJobs.get(ResourceJobs_.UPDATED_ON), resourceJobs.get(ResourceJobs_.RESOURCE_STATUS),
					resource.get(Resource_.DEPLOYMEN_TYPE), vendor.get(Vendor_.AGENCY_NAME), vendor.get(Vendor_.ID),
					resourceJobs.get(ResourceJobs_.RESOURCE_USD_RATE), resource.get(Resource_.USD_RATE_TYPE),resource.get(Resource_.LOCATION), user,vendor.get(Vendor_.USER).get(User_.ID)
					);
		}

		Order order = criteriaBuilder.desc(resourceJobs.get(ResourceJobs_.UPDATED_ON));
		criteriaUtil.populateCriteriaQuery(criteriaQuery, selection, predicates, order);

	}

	@Override
	public PageModel getJobListByResourceId(JobsFilterModel jobsFilterModel) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();

		CriteriaQuery<JobListResponse> listQuery = criteriaBuilder.createQuery(JobListResponse.class);
		populateQuery(criteriaBuilder, listQuery, jobsFilterModel, false);

		CriteriaQuery<Long> countQuery = criteriaBuilder.createQuery(Long.class);
		populateQuery(criteriaBuilder, countQuery, jobsFilterModel, true);

		return criteriaUtil.getPageModel(listQuery, countQuery, jobsFilterModel.getPaginationRequestModel());
	}

	private void populateQuery(CriteriaBuilder criteriaBuilder, CriteriaQuery<?> criteriaQuery,
			JobsFilterModel jobsFilterModel, Boolean isCount) {

		Root<ResourceJobs> resourceJobs = criteriaQuery.from(ResourceJobs.class);

		Join<ResourceJobs, Resource> resource = resourceJobs.join(ResourceJobs_.resource);
		Join<ResourceJobs, Job> job = resourceJobs.join(ResourceJobs_.job);
		Join<Job, Vendor> vendor = job.join(Job_.vendor);

	//	Join<Job, Address> address = job.join(Job_.address);
		Join<Job, CodeLookup> duration = job.join(Job_.duration);
		Join<Job, CodeLookup> country = job.join(Job_.country,JoinType.LEFT);
		Join<ResourceJobs, User> user = resourceJobs.join(ResourceJobs_.APPLIED_BY,JoinType.LEFT);
		List<Predicate> predicates = new ArrayList<>();
		criteriaUtil.addDefaultPredicates(criteriaBuilder, predicates, resourceJobs);
		criteriaUtil.addPredicates(criteriaBuilder, predicates, resource.get(Resource_.ID),
				jobsFilterModel.getResourceId());
		criteriaUtil.addPredicates(criteriaBuilder, predicates, resourceJobs.get(ResourceJobs_.RESOURCE_STATUS),
				jobsFilterModel.getResourceStatus());
		criteriaUtil.addPredicates(criteriaBuilder, predicates, job.get(Job_.TITLE), jobsFilterModel.getTitle());
//		criteriaUtil.addPredicatesIn(criteriaBuilder, predicates, resourceJobs.get(ResourceJobs_.RESOURCE_STATUS),
//				Arrays.asList(ResourceStatusEnum.INVITED, ResourceStatusEnum.INVITATION_ACCEPTED,
//						ResourceStatusEnum.INVITATION_REJECTED));

		if (jobsFilterModel.getStartDate() != null && jobsFilterModel.getEndDate() != null) {
			String startDate = jobsFilterModel.getStartDate();

			String endDate = jobsFilterModel.getEndDate();
			predicates.add(criteriaBuilder.greaterThanOrEqualTo(resourceJobs.get(ResourceJobs_.UPDATED_ON),
					LocalDateTime.parse(startDate, DateUtil.dateTimeFormatter())));
			predicates.add(criteriaBuilder.lessThanOrEqualTo(resourceJobs.get(ResourceJobs_.UPDATED_ON),
					LocalDateTime.parse(endDate, DateUtil.dateTimeFormatter())));
		}

		Selection<?> selection;
		if (isCount) {
			selection = criteriaBuilder.countDistinct(resourceJobs);
		} else {
			selection = criteriaBuilder.construct(JobListResponse.class, resourceJobs.get(ResourceJobs_.ID),
					job.get(Job_.ID),country.get(CodeLookup_.NAME), job.get(Job_.TITLE),
					job.get(Job_.WORK_FROM), job.get(Job_.RATE_TYPE_ENUM), job.get(Job_.MIN_RATE),
					job.get(Job_.MAX_RATE), job.get(Job_.NO_OF_RESOURCES), job.get(Job_.MIN_EXPERIENCE),
					job.get(Job_.MAX_EXPERIENCE), job.get(Job_.START_DATE), resourceJobs.get(ResourceJobs_.UPDATED_ON),
					job.get(Job_.CURRENCY_TYPE), job.get(Job_.STATUS_ENUM),
					resourceJobs.get(ResourceJobs_.RESOURCE_STATUS), duration.get(CodeLookup_.NAME),
					vendor.get(Vendor_.AGENCY_NAME), vendor.get(Vendor_.ID),resourceJobs.get(ResourceJobs_.RESOURCE_USD_RATE),resourceJobs.get(ResourceJobs_.RESOURCE_INR_RATE),job.get(Job_.LOCATION),user,vendor.get(Vendor_.USER).get(User_.ID));
		}

		Order order = criteriaBuilder.desc(resourceJobs.get(ResourceJobs_.UPDATED_ON));
		criteriaUtil.populateCriteriaQuery(criteriaQuery, selection, predicates, order);

	}

	@Override
	public PageModel findAllInvitationsRecived(ResourceJobFilterRequest resourceJobFilterModel) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();

		CriteriaQuery<ResourceListResponse> listQuery = criteriaBuilder.createQuery(ResourceListResponse.class);
		populateQuery(criteriaBuilder, listQuery, resourceJobFilterModel, false);

		CriteriaQuery<Long> countQuery = criteriaBuilder.createQuery(Long.class);
		populateQuery(criteriaBuilder, countQuery, resourceJobFilterModel, true);

		return criteriaUtil.getPageModel(listQuery, countQuery, resourceJobFilterModel.getPaginationRequestModel());
	}

	private void populateQuery(CriteriaBuilder criteriaBuilder, CriteriaQuery<?> criteriaQuery,
			ResourceJobFilterRequest resourceJobFilterModel, Boolean isCount) {

		Root<ResourceJobs> resourceJobs = criteriaQuery.from(ResourceJobs.class);
		Join<ResourceJobs, Resource> resource = resourceJobs.join(ResourceJobs_.resource);

		Join<Resource, Vendor> vendor = resource.join(Resource_.vendor);
		Join<Resource, CodeLookup> availability = resource.join(Resource_.availability);
		Join<Resource, CodeLookup> designation = resource.join(Resource_.designation);
		Join<Resource, Address> address = resource.join(Resource_.address);
		Join<Address, CodeLookup> state = address.join(Address_.state);
		Join<Address, CodeLookup> country = address.join(Address_.country);

		List<Predicate> predicates = new ArrayList<>();
		criteriaUtil.addDefaultPredicates(criteriaBuilder, predicates, resourceJobs);
//		if (resourceJobFilterModel.getResourceStatusEnum() != null
//				&& (resourceJobFilterModel.getResourceStatusEnum() == ResourceStatusEnum.INVITATION_ACCEPTED
//						|| resourceJobFilterModel.getResourceStatusEnum() == ResourceStatusEnum.INVITATION_REJECTED)) {
//			criteriaUtil.addPredicates(criteriaBuilder, predicates, resourceJobs.get(ResourceJobs_.RESOURCE_STATUS),
//					resourceJobFilterModel.getResourceStatusEnum());
//		} else {
//
//			criteriaUtil.addPredicatesIn(criteriaBuilder, predicates, resourceJobs.get(ResourceJobs_.RESOURCE_STATUS),
//					Arrays.asList(ResourceStatusEnum.INVITED, ResourceStatusEnum.INVITATION_ACCEPTED,
//							ResourceStatusEnum.INVITATION_REJECTED));
//		}
		criteriaUtil.addPredicates(criteriaBuilder, predicates, resourceJobs.get(ResourceJobs_.RESOURCE_STATUS),
				ResourceStatusEnum.INVITED);

		criteriaUtil.addPredicates(criteriaBuilder, predicates, resource.get(Resource_.NAME),
				resourceJobFilterModel.getName());

		criteriaUtil.addPredicates(criteriaBuilder, predicates, vendor.get(Vendor_.ID),
				entityUtil.getCurrentVendorId());

		if (resourceJobFilterModel.getStartDate() != null && resourceJobFilterModel.getEndDate() != null) {
			String startDate = resourceJobFilterModel.getStartDate();
			String endDate = resourceJobFilterModel.getEndDate();
			predicates.add(criteriaBuilder.greaterThanOrEqualTo(resourceJobs.get(ResourceJobs_.UPDATED_ON),
					LocalDateTime.parse(startDate, DateUtil.dateTimeFormatter())));
			predicates.add(criteriaBuilder.lessThanOrEqualTo(resourceJobs.get(ResourceJobs_.UPDATED_ON),
					LocalDateTime.parse(endDate, DateUtil.dateTimeFormatter())));
		}
		Selection<?> selection;
		if (isCount) {
			selection = criteriaBuilder.countDistinct(resourceJobs);
		} else {
			selection = criteriaBuilder.construct(ResourceListResponse.class, resourceJobs.get(ResourceJobs_.ID),
					resource.get(Resource_.ID), resource.get(Resource_.FIRST_NAME), resource.get(Resource_.LAST_NAME),
					availability.get(CodeLookup_.NAME), designation.get(CodeLookup_.NAME), resource.get(Resource_.RATE),
					resource.get(Resource_.CURRENCY_TYPE), resource.get(Resource_.RATE_TYPE_ENUM),
					resource.get(Resource_.YEARS_EXPERIENCE), resource.get(Resource_.MONTHS_EXPERIENCE),
					state.get(CodeLookup_.NAME), country.get(CodeLookup_.NAME), resource.get(Resource_.GENDER),
					resource.get(Resource_.ACTIVE), resource.get(Resource_.HIGHER_EDUCATION),
					resource.get(Resource_.PASSING_YEAR), resource.get(Resource_.STATUS_ENUM),
					resourceJobs.get(ResourceJobs_.UPDATED_ON), resourceJobs.get(ResourceJobs_.RESOURCE_STATUS),
					resource.get(Resource_.DEPLOYMEN_TYPE), vendor.get(Vendor_.AGENCY_NAME), vendor.get(Vendor_.ID));

		}

		Order order = criteriaBuilder.desc(resourceJobs.get(ResourceJobs_.UPDATED_ON));
		criteriaUtil.populateCriteriaQuery(criteriaQuery, selection, predicates, order);

	}

	@Override
	public PageModel findAllInvitationsSend(InvitationsSendRequest resourceJobFilterRequest) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();

		CriteriaQuery<JobListResponse> listQuery = criteriaBuilder.createQuery(JobListResponse.class);
		populateQuery(criteriaBuilder, listQuery, resourceJobFilterRequest, false);

		CriteriaQuery<Long> countQuery = criteriaBuilder.createQuery(Long.class);
		populateQuery(criteriaBuilder, countQuery, resourceJobFilterRequest, true);

		return criteriaUtil.getPageModel(listQuery, countQuery, resourceJobFilterRequest.getPaginationRequestModel());
	}

	private void populateQuery(CriteriaBuilder criteriaBuilder, CriteriaQuery<?> criteriaQuery,
			InvitationsSendRequest invitationsSendRequest, Boolean isCount) {

		Root<ResourceJobs> resourceJobs = criteriaQuery.from(ResourceJobs.class);

		Join<ResourceJobs, Job> job = resourceJobs.join(ResourceJobs_.job);
		Join<Job, Vendor> vendor = job.join(Job_.vendor);

	//	Join<Job, Address> address = job.join(Job_.address);
	//	Join<Address, CodeLookup> state = address.join(Address_.state);
		Join<Job, CodeLookup> duration = job.join(Job_.duration);
		Join<Job, CodeLookup> country = job.join(Job_.country,JoinType.LEFT);

		List<Predicate> predicates = new ArrayList<>();
		criteriaUtil.addDefaultPredicates(criteriaBuilder, predicates, resourceJobs);

//		criteriaUtil.addPredicates(criteriaBuilder, predicates, resourceJobs.get(ResourceJobs_.RESOURCE_STATUS),
//				invitationsSendRequest.getResourceStatus());
		criteriaUtil.addPredicates(criteriaBuilder, predicates, job.get(Job_.TITLE), invitationsSendRequest.getTitle());
//		if (invitationsSendRequest.getResourceStatus() != null
//				&& (invitationsSendRequest.getResourceStatus() == ResourceStatusEnum.INVITATION_ACCEPTED
//						|| invitationsSendRequest.getResourceStatus() == ResourceStatusEnum.INVITATION_REJECTED)) {
//			criteriaUtil.addPredicates(criteriaBuilder, predicates, resourceJobs.get(ResourceJobs_.RESOURCE_STATUS),
//					invitationsSendRequest.getResourceStatus());
//		} else {
//
//			criteriaUtil.addPredicatesIn(criteriaBuilder, predicates, resourceJobs.get(ResourceJobs_.RESOURCE_STATUS),
//					Arrays.asList(ResourceStatusEnum.INVITED, ResourceStatusEnum.INVITATION_ACCEPTED,
//							ResourceStatusEnum.INVITATION_REJECTED));
//		}
		criteriaUtil.addPredicates(criteriaBuilder, predicates, resourceJobs.get(ResourceJobs_.RESOURCE_STATUS),
				ResourceStatusEnum.INVITED);
		criteriaUtil.addPredicates(criteriaBuilder, predicates, vendor.get(Vendor_.ID),
				entityUtil.getCurrentVendorId());
		if (invitationsSendRequest.getStartDate() != null && invitationsSendRequest.getEndDate() != null) {
			String startDate = invitationsSendRequest.getStartDate();

			String endDate = invitationsSendRequest.getEndDate();
			predicates.add(criteriaBuilder.greaterThanOrEqualTo(resourceJobs.get(ResourceJobs_.UPDATED_ON),
					LocalDateTime.parse(startDate, DateUtil.dateTimeFormatter())));
			predicates.add(criteriaBuilder.lessThanOrEqualTo(resourceJobs.get(ResourceJobs_.UPDATED_ON),
					LocalDateTime.parse(endDate, DateUtil.dateTimeFormatter())));
		}

		Selection<?> selection;
		if (isCount) {
			selection = criteriaBuilder.countDistinct(resourceJobs);
		} else {
			selection = criteriaBuilder.construct(JobListResponse.class, resourceJobs.get(ResourceJobs_.ID),
					job.get(Job_.ID), country.get(CodeLookup_.NAME), country.get(CodeLookup_.NAME), job.get(Job_.TITLE),
					job.get(Job_.WORK_FROM), job.get(Job_.RATE_TYPE_ENUM), job.get(Job_.MIN_RATE),
					job.get(Job_.MAX_RATE), job.get(Job_.NO_OF_RESOURCES), job.get(Job_.MIN_EXPERIENCE),
					job.get(Job_.MAX_EXPERIENCE), job.get(Job_.START_DATE), resourceJobs.get(ResourceJobs_.UPDATED_ON),
					job.get(Job_.CURRENCY_TYPE), job.get(Job_.STATUS_ENUM),
					resourceJobs.get(ResourceJobs_.RESOURCE_STATUS), duration.get(CodeLookup_.NAME),
					vendor.get(Vendor_.AGENCY_NAME), vendor.get(Vendor_.ID));
		}

		Order order = criteriaBuilder.desc(resourceJobs.get(ResourceJobs_.UPDATED_ON));
		criteriaUtil.populateCriteriaQuery(criteriaQuery, selection, predicates, order);

	}

}
