package com.daynilgroup.vendormanagement.model.response;

import lombok.AccessLevel;
import lombok.Builder;
import lombok.Data;
import lombok.experimental.FieldDefaults;

@Builder
@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
public class ResourceJobCountResponse {

	Long applied;
	Long shortlisted;
	Long hired;
	Long rejected;
	Long all;
	

}
