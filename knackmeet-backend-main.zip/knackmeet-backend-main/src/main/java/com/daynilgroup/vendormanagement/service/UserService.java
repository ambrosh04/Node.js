/**
 * 
 */
package com.daynilgroup.vendormanagement.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.daynilgroup.vendormanagement.constants.UserType;
import com.daynilgroup.vendormanagement.entity.User;
import com.daynilgroup.vendormanagement.model.request.UserForgotPasswordRequest;

/**
 * @author Prerana
 *
 */
public interface UserService extends AbstractService<User> {

	User findByEmailIdOrMobile(String searchString);

	User findByEmailIdOrMobileAndUserType(String searchString, UserType userType);

	Boolean existsByMobileNumberAndIdNot(String mobileNumber, Long Id) throws Exception;

	Boolean existsByMobileNumber(String mobileNumber) throws Exception;

	Boolean existsByEmailId(String emailId) throws Exception;

	Page<User> findAll(Pageable pageable);

	Boolean existsByEmailIdNumberAndIdNot(String emailId, Long Id) throws Exception;

	User findActiveUserByUserId(Long userId);

	void changePassword(Long id, String password);

	void validateUserByEmailId(String emailId) throws Exception;

	void validateTokenAndSetPassword(UserForgotPasswordRequest userRequest);
	
	void updatePageSize(Integer pageSize);
	
	Boolean existsByMobileNumberAndCompanyPrimaryNumber(String mobileNumber) throws Exception;
	
	Boolean existsByEmailIdAndCompanyPrimaryEmail(String companyPrimaryEmail) throws Exception;

}
