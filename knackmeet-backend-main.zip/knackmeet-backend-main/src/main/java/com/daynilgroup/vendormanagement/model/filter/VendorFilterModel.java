package com.daynilgroup.vendormanagement.model.filter;

import com.daynilgroup.vendormanagement.constants.Status;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.experimental.FieldDefaults;

@Builder
@Data
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class VendorFilterModel {

	String agencyName;

	String website;

	Long teamStrength;

	Status status;

	Boolean active;

	Long user;
}
