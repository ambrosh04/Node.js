package com.daynilgroup.vendormanagement.service;

import com.daynilgroup.vendormanagement.model.response.AdminDashboardCountResponse;

public interface AdminDashboardService {
	
	
	AdminDashboardCountResponse getAdminDashboardCountResponse();
	

}
