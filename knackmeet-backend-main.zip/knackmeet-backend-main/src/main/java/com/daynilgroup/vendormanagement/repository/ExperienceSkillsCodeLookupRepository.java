package com.daynilgroup.vendormanagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.daynilgroup.vendormanagement.entity.ExperienceSkillsCodeLookup;

@Repository
public interface ExperienceSkillsCodeLookupRepository  extends JpaRepository<ExperienceSkillsCodeLookup, Long>{
	
	@Modifying
	@Transactional
	@Query("DELETE FROM ExperienceSkillsCodeLookup esc where esc.experience.id =:experienceId")
	public void deleteByExperienceId(Long experienceId);

}
