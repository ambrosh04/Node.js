package com.daynilgroup.vendormanagement.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.daynilgroup.vendormanagement.constants.CodeLookUpRelationTypeEnum;
import com.daynilgroup.vendormanagement.constants.RefTypeEnum;
import com.daynilgroup.vendormanagement.entity.CodeLookUpRelation;

@Repository
public interface CodeLookUpRelationRepository extends JpaRepository<CodeLookUpRelation, Long>{

	List<CodeLookUpRelation> findByRefIdAndRefTypeAndType(Long refId, RefTypeEnum refType,
			CodeLookUpRelationTypeEnum type);

	@Transactional
	void deleteByRefIdAndRefTypeAndType(Long refId, RefTypeEnum refType, CodeLookUpRelationTypeEnum type);

	@Modifying
	@Query("DELETE FROM CodeLookUpRelation c WHERE c.refId = :refId AND c.refType = :refType AND c.type = :type")
	void hardDeleteByRefIdAndRefTypeAndType(Long refId, RefTypeEnum refType, CodeLookUpRelationTypeEnum type);
	
	CodeLookUpRelation findByRefIdAndRefTypeAndTypeAndCodeLookupId(Long refId, RefTypeEnum refType,
			CodeLookUpRelationTypeEnum type, Long codeLookUpId);

	CodeLookUpRelation findByRefIdAndRefTypeAndTypeAndDeletedFalseOrDeletedIsNull(Long refId, RefTypeEnum refType,
			CodeLookUpRelationTypeEnum type);

	List<CodeLookUpRelation> findByRefTypeAndTypeAndActiveTrueAndDeletedFalse(RefTypeEnum refType,
			CodeLookUpRelationTypeEnum type);

	@Query("SELECT cr FROM CodeLookUpRelation cr INNER JOIN CodeLookup cl ON cl.id = cr.codeLookup.id WHERE cl.name = :name AND cr.deleted = false AND cr.active = :active AND cr.refId = :refId AND cr.refType = :refType AND cr.type = :type")
	CodeLookUpRelation getByRefIdAndRefTypeAndType(@Param("name") String name, @Param("active") boolean active,
			@Param("refId") Long refId, @Param("refType") RefTypeEnum refType,
			@Param("type") CodeLookUpRelationTypeEnum type);
	

}
