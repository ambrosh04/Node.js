package com.daynilgroup.vendormanagement.model.response;

import java.util.List;

import lombok.AccessLevel;
import lombok.Builder;
import lombok.Data;
import lombok.experimental.FieldDefaults;

@Builder
@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
public class ResourceJobsResponse {

	List<ResourceJobsListResponse> resourceJobsListResponse;

	Long applied;
	Long shortlisted;
	Long hired;
	Long rejected;

}
