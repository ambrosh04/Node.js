package com.daynilgroup.vendormanagement.model.response;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

import com.daynilgroup.vendormanagement.constants.RateTypeEnum;
import com.daynilgroup.vendormanagement.constants.StatusEnum;
import com.daynilgroup.vendormanagement.constants.UserType;
import com.daynilgroup.vendormanagement.helper.EducationDetailAdminResponse;

import lombok.AccessLevel;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@Getter
@Setter
@FieldDefaults(level = AccessLevel.PRIVATE)
@Builder
public class ResourceDetailResponse implements Serializable {

	static final long serialVersionUID = 1L;

	Long id;

	String firstname;

	String lastname;

	String category;

	String availabilityType;

	String base64MediaString;

	List<String> skills;

	String designation;

	String rate;

	String summary;

	String experience;

	String city;
	
	String state;
	
	String country;

	Long passingYear;

	String higherEducation;
	
	String resume;

	String description;
	
	LocalDateTime lastUpdated;
	
	String resourceStatus;
	
	String status;
	
	String agencyName;
	
	String deployementType;
	
	StatusEnum statusEnum;	
	
	Integer expInMonths;
	
	Integer expInYears;
	
	BigDecimal onlyRate;
	
	Boolean isActve;
	
	Object invitationAcceptRejecetEnum;
	
	Long userId;
	
	LocalDateTime createdOn;
	
	String usdRate;
	
	List<EducationDetailResponse>  educations;
	
	List<ExperienceDetailResponse>  experiences;
	
	BigDecimal usdRateOnly;
	
	String gender;
	
	String location;
	
	RateTypeEnum usdRateTypeOnly;
	
	RateTypeEnum rateTypeOnly;
	
	UserType appliedBy;
}
