package com.daynilgroup.vendormanagement.service;

import java.util.List;

import com.daynilgroup.vendormanagement.entity.VendorPortfolio;

public interface VendorPortfolioService extends AbstractService<VendorPortfolio>{

	List<VendorPortfolio> findByVendorAndDeletedFalse();

	
	void deleteByInId(List<Long> deletePortfolio);


	void deleteById(Long id);

}
