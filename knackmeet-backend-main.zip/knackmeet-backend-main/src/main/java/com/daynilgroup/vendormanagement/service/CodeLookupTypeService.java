/**
 * 
 */
package com.daynilgroup.vendormanagement.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.daynilgroup.vendormanagement.entity.CodeLookupType;
import com.daynilgroup.vendormanagement.model.response.AdvanceSearchDropdownModel;
import com.daynilgroup.vendormanagement.model.response.CodeLookTypeDropdownResponse;
import com.daynilgroup.vendormanagement.model.response.DropdownResponse;

/**
 * @author Prerana
 *
 */
public interface CodeLookupTypeService extends AbstractService<CodeLookupType> {

	boolean getByCodeAndId(String code, Long id);

	boolean getByNameAndId(String name, Long id);
	
	CodeLookupType findByCode(String code);

	Page<CodeLookupType> getAllCodeLookupType(Pageable pageable);

	List<AdvanceSearchDropdownModel> advanceSearchDropdown(String searchValue, String code);

	List<CodeLookTypeDropdownResponse> codeLookUpTypeDropdown();
		
    void deleteById(Long id);
    
    Page<CodeLookupType> searchByName(String name, Pageable pageable);
    
   
}
   


