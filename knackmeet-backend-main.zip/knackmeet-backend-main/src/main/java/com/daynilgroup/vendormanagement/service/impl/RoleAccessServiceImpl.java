package com.daynilgroup.vendormanagement.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;

import com.daynilgroup.vendormanagement.entity.RoleAccess;
import com.daynilgroup.vendormanagement.repository.RoleAccessRepository;
import com.daynilgroup.vendormanagement.service.RoleAccessService;

/**
 *
 * @author Manish
 */
@Service
public class RoleAccessServiceImpl implements RoleAccessService {

	@Autowired
	private RoleAccessRepository roleAccessRepository;

	@Override
	public JpaRepository<RoleAccess, Long> getJpaRepository() {
		return roleAccessRepository;
	}

	@Override
	public void deleteByRoleId(Long userId) {
		roleAccessRepository.deleteByRoleId(userId);

	}
}
