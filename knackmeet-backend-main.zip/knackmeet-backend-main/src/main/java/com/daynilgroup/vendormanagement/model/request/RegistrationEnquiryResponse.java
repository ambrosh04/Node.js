package com.daynilgroup.vendormanagement.model.request;

import java.io.Serializable;
import java.time.LocalDateTime;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

@Builder
@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
@AllArgsConstructor
@NoArgsConstructor
public class RegistrationEnquiryResponse  implements Serializable{

	private static final long serialVersionUID = 1L;

	Long id;
	
	String firstName;
	
	String lastName;
	
	String emailId;
	
	String mobileNumber;
	
	LocalDateTime createdOn;
	
	LocalDateTime updatedOn;
}
