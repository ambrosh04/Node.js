/**
 * 
 */
package com.daynilgroup.vendormanagement.constants;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.experimental.FieldDefaults;

/**
 * @author Prerana
 *
 */
@Getter
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public enum ResourceStatusEnum {

	AVAILABLE("Available"), SHORTLISTED("Shortlisted"), INTERVIEWED("Interviewed"), REJECTED("Rejected"),
	HIRED("Hired"), APPLIED("Applied"), INVITED("Invited");
	String displayName;

}
