package com.daynilgroup.vendormanagement.model.request;

import com.daynilgroup.vendormanagement.constants.JobCloseReason;
import com.daynilgroup.vendormanagement.constants.StatusEnum;

import lombok.AccessLevel;
import lombok.Data;
import lombok.experimental.FieldDefaults;

@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
public class VerifyRequest {

	Long id;

	StatusEnum status;

	JobCloseReason jobCloseReason;
	
	CodeLookUpRelationRequest codeLookUpRelationRequests;
}
