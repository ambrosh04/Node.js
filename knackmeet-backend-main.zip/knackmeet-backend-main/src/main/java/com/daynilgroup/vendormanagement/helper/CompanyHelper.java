package com.daynilgroup.vendormanagement.helper;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.daynilgroup.vendormanagement.constants.MediaTypeEnum;
import com.daynilgroup.vendormanagement.entity.Company;
import com.daynilgroup.vendormanagement.entity.Media;
import com.daynilgroup.vendormanagement.entity.Vendor;
import com.daynilgroup.vendormanagement.model.response.CompanyListResponse;
import com.daynilgroup.vendormanagement.model.response.CompanyResponse;
import com.daynilgroup.vendormanagement.request.CompanyRequest;
import com.daynilgroup.vendormanagement.service.CompanyService;
import com.daynilgroup.vendormanagement.service.VendorService;
import com.daynilgroup.vendormanagement.util.CommonUtil;
import com.daynilgroup.vendormanagement.util.FileUpload;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;

@Component
@FieldDefaults(level = AccessLevel.PRIVATE)
public class CompanyHelper extends AbstractHelper<Company, CompanyRequest, CompanyListResponse, Object, CompanyResponse> {

	@Autowired
	FileUpload fileUpload;
	
	@Autowired
	CompanyService companyService;

	@Autowired
	VendorService vendorService;
	
	@Autowired
	AttributeMediaUploadHelper attributeMediaUploadHelper;


	@Override
	public Company getEntity(CompanyRequest request) throws Exception {
		Company company = null;
		if (CommonUtil.isValid(request.getId())) {
			company = companyService.findById(request.getId());
		} else {
			company = new Company();
			company.setName(request.getName());
			company.setWebsite(request.getWebsite());
			if (CommonUtil.isValid(request.getVendorId())) {
				Vendor vendor = vendorService.findById(request.getVendorId());
				company.setVendor(vendor);
			}

		}
			
			if (!CommonUtil.isEmpty(request.getBase64String())) {
				Media media = attributeMediaUploadHelper.uploadMedia("Company", company.getMedia(),
						request.getBase64String(), MediaTypeEnum.IMAGE);
				company.setMedia(media);
			}

			
		
		return company;
	}

	@Override
	public List<CompanyListResponse> getListResponse(List<Company> companies) {
		List<CompanyListResponse> companyListResponses = new ArrayList<>();
		companies.forEach(company -> {
			companyListResponses
					.add(CompanyListResponse.builder().id(company.getId()).name(company.getName())
							.logoPath(company.getMedia() != null ? fileUpload
									.generatePresignedURL(company.getMedia().getPath()) : null)
							.website(company.getWebsite()).build());
		});
		return companyListResponses;
	}

	@Override
	public Object getDetailResponse(Company entity) {
		return null;
	}

	@Override
	public CompanyResponse getDetailForAdminResponse(Company company) {
		return CompanyResponse.builder().id(company.getId()).name(company.getName())
							.logoPath(company.getMedia() != null ? fileUpload
									.generatePresignedURL(company.getMedia().getPath()) : null)
							.website(company.getWebsite()).build();
	}

}
