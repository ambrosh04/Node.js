/**
 * 
 */
package com.daynilgroup.vendormanagement.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.daynilgroup.vendormanagement.constants.UserType;
import com.daynilgroup.vendormanagement.entity.Vendor;

/**
 * @author Prerana
 *
 */
@Repository
public interface VendorRepository extends JpaRepository<Vendor, Long> {

	Vendor findByUserId(Long userId);

	@Query("SELECT COUNT(u.id)>0 FROM User u  where (u.deleted=false or u.deleted IS NULL) and u.mobile=?1 and u.userType=?2 and (?3 IS NULL OR u.id<>?3)")
	Boolean existsByMobileNumberAndUserTypeAndIdNot(String mobileNumber, UserType userType, Long Id);

	//	@Query("SELECT COUNT(*)  FROM Job j INNER JOIN ResourceJobs rj ON  j.id= rj.job.id Where j.vendor.id =:vendorId")

	

	@Query("SELECT v FROM Vendor v INNER JOIN User u ON u.id=v.user.id  where (u.userType=:userType)and (:agencyName IS NULL OR v.agencyName LIKE (%:agencyName%))and (:name IS NULL OR CONCAT(u.firstName,' ',u.lastName) LIKE (%:name%))and (:location  IS NULL OR v.location LIKE (%:location%))")
	Page<Vendor> findAllVendorExceptAdmin(UserType userType, String agencyName, String name,String location, Pageable pageable);

	@Query("SELECT v FROM Vendor v INNER JOIN User u ON u.id=v.user.id  where (u.userType=:userType) and v.deleted=false ")
	Page<Vendor> findAllVendorExceptAdmin(UserType userType, Pageable pageable);

	@Query("SELECT COUNT(*) FROM Vendor v INNER JOIN User u ON u.id=v.user.id  where (u.userType=:userType)")
    Long getAllVendorCountExceptAdmin(UserType userType);
	
	Boolean existsByCompanyPrimaryNumber(String companyNumber);

	Boolean existsByCompanyPrimaryEmail(String companyPrimaryEmail);
	
	@Query("SELECT COUNT(v.id)>0 FROM Vendor v  where (v.deleted=false or v.deleted IS NULL) and v.companyPrimaryNumber=?1 and (?2 IS NULL OR v.id<>?2)")
	Boolean existsByCompanyPrimaryNumberAndIdNot(String companyNumber,Long id);
	
	@Query("SELECT COUNT(v.id)>0 FROM Vendor v  where (v.deleted=false or v.deleted IS NULL) and v.companyPrimaryEmail=?1 and (?2 IS NULL OR v.id<>?2)")
	Boolean existsByCompanyPrimaryEmailAndIdNot(String companyPrimaryEmail,Long id);
	
	@Query("SELECT v FROM Vendor v WHERE v.id !=:vendorId and (v.deleted=false or v.deleted IS NULL) and v.statusEnum='VERIFIED'")
	List<Vendor> getVerifiedVendorsAndIdNot(@Param("vendorId") Long vendorId);
	
	@Query("SELECT v FROM Vendor v INNER JOIN User u ON u.id=v.user.id  where (u.userType=:userType)")
	List<Vendor> findAllVendorExceptAdmin(UserType userType);

	Boolean existsByAgencyName(String agencyName);
	
	Vendor findByCompanyPrimaryEmail(String companyPrimaryEmail);
}
