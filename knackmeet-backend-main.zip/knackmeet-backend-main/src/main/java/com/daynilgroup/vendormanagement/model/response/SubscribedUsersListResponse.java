package com.daynilgroup.vendormanagement.model.response;

import java.io.Serializable;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
public class SubscribedUsersListResponse implements Serializable {

	static final long serialVersionUID = 1L;

	Long id;

	Long userSubscriptionId;

	String name;

	String emailId;

	String mobileNumber;

	String agencyName;

	String countryCode;

	
	
}
