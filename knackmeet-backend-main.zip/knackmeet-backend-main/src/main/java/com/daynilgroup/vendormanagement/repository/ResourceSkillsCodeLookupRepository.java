package com.daynilgroup.vendormanagement.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.daynilgroup.vendormanagement.entity.ResourceSkillsCodeLookup;
import com.daynilgroup.vendormanagement.repository.custom.ResourceSkillsCodeLookupCustomRepository;

@Repository
public interface ResourceSkillsCodeLookupRepository  extends JpaRepository<ResourceSkillsCodeLookup, Long>, ResourceSkillsCodeLookupCustomRepository{
	
	@Modifying
	@Transactional
	@Query("DELETE FROM ResourceSkillsCodeLookup rsc where rsc.resource.id =:resourceId")
	public void deleteByResourceId(Long resourceId);
	
	List<ResourceSkillsCodeLookup> findAllByResourceId(Long resourceId);
	
	ResourceSkillsCodeLookup findByResourceIdAndCodeLookupId(Long resourceId, Long codeLookupId );

}
