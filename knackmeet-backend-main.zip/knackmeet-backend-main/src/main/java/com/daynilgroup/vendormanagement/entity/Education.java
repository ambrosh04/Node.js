package com.daynilgroup.vendormanagement.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.AccessLevel;
import lombok.Data;
import lombok.experimental.FieldDefaults;

/**
 *
 * @author manish
 */
@Data
@Entity
@Table(name = "education")
@FieldDefaults(level = AccessLevel.PRIVATE)
public class Education extends BaseEntity {

	static final long serialVersionUID = 1L;

	@Column(name = "school_name", nullable = false)
	String schoolName;

	@JoinColumn(name = "degree_id", referencedColumnName = "id", nullable = false)
	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	CodeLookup degree;

	@JoinColumn(name = "specialization_id", referencedColumnName = "id", nullable = false)
	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	CodeLookup specialization;

	@Column(name = "from_year", nullable = false)
    Integer fromYear;

	@Column(name = "from_month", nullable = false)
	Integer fromMonth;

	@Column(name = "to_year")
	Integer toYear;

	@Column(name = "to_month")
	Integer toMonth;

	@Column(name = "description")
	@Lob
	String description;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "resource_id", referencedColumnName = "id", nullable = false)
	Resource resource;
	
}
