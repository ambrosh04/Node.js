package com.daynilgroup.vendormanagement.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

@FieldDefaults(level = AccessLevel.PRIVATE)
@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name="subscribed_users")
public class SubscribedUsers extends BaseEntity {

	private static final long serialVersionUID = 1L;
	
	@Column(name="name")
	String name;
	
	@Column(name="email_id",nullable = false)
	String emailId;
	
	@Column(name="mobile_number")
	String mobileNumber;
	
	@Column(name="agency_name")
	String agencyName;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "country_code_id", referencedColumnName = "id")
	CodeLookup countryCode;
}
