package com.daynilgroup.vendormanagement.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.daynilgroup.vendormanagement.entity.SkillsCodeLookup;

public interface SkillsCodeLookupRepository extends JpaRepository<SkillsCodeLookup, Long> {

	@Modifying
	@Transactional
	@Query("DELETE FROM SkillsCodeLookup sc WHERE sc.job.id =:jobId")
	public void deleteByJobId(Long jobId);
	
	List<SkillsCodeLookup> findAllByJobId(Long jobId);
}
