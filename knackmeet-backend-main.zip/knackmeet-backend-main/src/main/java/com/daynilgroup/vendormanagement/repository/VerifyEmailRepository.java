package com.daynilgroup.vendormanagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.daynilgroup.vendormanagement.entity.VerifyEmail;

public interface VerifyEmailRepository  extends JpaRepository<VerifyEmail, Long>{

	VerifyEmail findByRandomNumber(String randomNumber);
	
	VerifyEmail findByVendorId(Long vendor);
	
}
