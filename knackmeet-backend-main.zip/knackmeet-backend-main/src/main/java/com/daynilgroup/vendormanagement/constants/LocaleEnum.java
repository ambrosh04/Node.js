package com.daynilgroup.vendormanagement.constants;

import lombok.AllArgsConstructor;

import lombok.Getter;

@Getter
@AllArgsConstructor
public enum LocaleEnum {

	EN("English"), HI("हिंदी");

	String displayName;

}
