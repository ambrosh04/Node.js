package com.daynilgroup.vendormanagement.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.daynilgroup.vendormanagement.entity.Experience;

@Repository
public interface ExperienceRepository extends JpaRepository<Experience, Long>{

	@Modifying
	@Transactional
	@Query("update Experience e set e.deleted=true where e.id in :deleteExperiences")
	void softDeleteByInId(List<Long> deleteExperiences);

	@Query("SELECT e FROM Experience e WHERE e.resource.id=:resourceId AND (e.deleted=false or e.deleted IS NULL) ORDER BY e.fromYear DESC,e.fromMonth DESC")
	List<Experience> findAllByDeleteFalse(Long resourceId);
	
	@Query("SELECT e.toYear FROM Experience e WHERE e.resource.id=:resourceId AND (e.deleted=false or e.deleted IS NULL)")
	List<Integer> getToYearByDeleteFalse(Long resourceId);
	
	@Query("SELECT e.fromYear FROM Experience e WHERE e.resource.id=:resourceId AND (e.deleted=false or e.deleted IS NULL)")
	List<Integer> getFromYearByDeleteFalse(Long resourceId);

}
