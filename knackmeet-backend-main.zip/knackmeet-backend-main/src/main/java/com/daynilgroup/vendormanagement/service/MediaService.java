package com.daynilgroup.vendormanagement.service;

import com.daynilgroup.vendormanagement.entity.Media;

/**
 *
 * @author manish
 */
public interface MediaService extends AbstractService<Media> {

	void deleteMedia(String path);

	Boolean doesExists(String path);

}
