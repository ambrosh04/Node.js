package com.daynilgroup.vendormanagement.helper;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.daynilgroup.vendormanagement.constants.Constants;
import com.daynilgroup.vendormanagement.entity.CodeLookup;
import com.daynilgroup.vendormanagement.entity.RegistrationEnquiry;
import com.daynilgroup.vendormanagement.model.request.RegistrationEnquiryRequest;
import com.daynilgroup.vendormanagement.model.request.RegistrationEnquiryResponse;
import com.daynilgroup.vendormanagement.service.CodeLookupService;
import com.daynilgroup.vendormanagement.service.RegistrationEnquiryService;
import com.daynilgroup.vendormanagement.util.CommonUtil;

@Component
public class RegistrationEnquiryHelper extends AbstractHelper<RegistrationEnquiry, RegistrationEnquiryRequest, RegistrationEnquiryResponse, RegistrationEnquiryResponse, RegistrationEnquiryResponse> {

	@Autowired 
	RegistrationEnquiryService registrationEnquiryService;
	
	@Autowired
	CodeLookupService codeLookupService;
	
	
	@Override
	public RegistrationEnquiry getEntity(RegistrationEnquiryRequest request) throws Exception {

		RegistrationEnquiry registrationEnquiry=null;
		List<RegistrationEnquiry> registrationEnquiryList = registrationEnquiryService
				.findByEmailOrMobileNumberAndPhoneCode(request.getEmailId(), request.getMobileNumber(),request.getPhoneCodeId());

		if (registrationEnquiryList.size() == 1) {
			registrationEnquiry = registrationEnquiryList.get(0);
		} else {
			for (RegistrationEnquiry registrationEnquirys : registrationEnquiryList) {
				registrationEnquiryService.deleteById(registrationEnquirys.getId());
			}
			registrationEnquiry = new RegistrationEnquiry();
		}
		registrationEnquiry.setFirstName(request.getFirstName());
		registrationEnquiry.setLastName(request.getLastName());
		registrationEnquiry.setMobileNumber(request.getMobileNumber());
		registrationEnquiry.setEmailId(request.getEmailId());
		registrationEnquiry.setTimeZone(request.getTimeZone());
		CodeLookup codeLookup = CommonUtil.getEntityReferenceWithId(request.getPhoneCodeId(), codeLookupService,
				CodeLookup.class);
		registrationEnquiry.setCountryCode(codeLookup);
		return registrationEnquiry;
	}

	@Override
	public List<RegistrationEnquiryResponse> getListResponse(List<RegistrationEnquiry> entityList) {
		List<RegistrationEnquiryResponse> RegistrationEnquiryListResponse = new ArrayList<>();
		entityList.forEach(registrationEnquiry -> {
			RegistrationEnquiryListResponse.add(RegistrationEnquiryResponse.builder().id(registrationEnquiry.getId())
					.firstName(registrationEnquiry.getFirstName()).lastName(registrationEnquiry.getLastName())
					.emailId(registrationEnquiry.getEmailId()).mobileNumber(registrationEnquiry.getCountryCode()!=null?registrationEnquiry.getCountryCode().getName().replaceAll(Constants.REMOVE_COUNTRY_NAME_FROM_PHONE_CODE, "")+" "+ registrationEnquiry.getMobileNumber():registrationEnquiry.getMobileNumber())
					.createdOn(registrationEnquiry.getCreatedOn()).updatedOn(registrationEnquiry.getUpdatedOn())
					.build());
		});
		return RegistrationEnquiryListResponse;
	}

	@Override
	public RegistrationEnquiryResponse getDetailResponse(RegistrationEnquiry entity) {
		return null;
	}

	@Override
	public RegistrationEnquiryResponse getDetailForAdminResponse(RegistrationEnquiry entity) {
		return null;
	}

	


}
