package com.daynilgroup.vendormanagement.constants;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.experimental.FieldDefaults;

@Getter
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public enum JobCloseReason {

	ACCIDENTAL_JOB_POSTING_CREATION("Accidental job posting creation"), ALL_POSITIONS_FILLED("All positions filled"),
	FILLED_BY_ALTERNATE_SOURCE("Filled by alternate source"),
	NO_AGENCY_FOR_REQUESTED_SKILLS("No agency for requested skills"),
	PROJECT_WAS_CANCELLED("Project was cancelled");

	String displayName;
}
