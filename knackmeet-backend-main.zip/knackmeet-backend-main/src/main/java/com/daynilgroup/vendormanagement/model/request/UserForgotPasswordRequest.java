package com.daynilgroup.vendormanagement.model.request;

import java.io.Serializable;

import lombok.AccessLevel;
import lombok.Data;
import lombok.experimental.FieldDefaults;

@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
public class UserForgotPasswordRequest implements Serializable{
	
	
	/*
	 *  @author Rohit
	 */
	private static final long serialVersionUID = 1L;

	 String token;
	 
	 String password;
}
