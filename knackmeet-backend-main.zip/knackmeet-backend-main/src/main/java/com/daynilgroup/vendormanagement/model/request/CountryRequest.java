/**
 * 
 */
package com.daynilgroup.vendormanagement.model.request;

import com.daynilgroup.vendormanagement.annotion.FieldProperty;
import com.daynilgroup.vendormanagement.request.inf.RequestInf;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

/**
 * @author Prerana
 *
 */
@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class CountryRequest implements RequestInf {

	static final long serialVersionUID = 1L;

	Long id;

	@FieldProperty(required = true, onlyAlphabets = true)
	@JsonProperty(required = true)
	String name;

	@FieldProperty(required = true, onlyAlphabets = true, length = 2)
	String code;

}
