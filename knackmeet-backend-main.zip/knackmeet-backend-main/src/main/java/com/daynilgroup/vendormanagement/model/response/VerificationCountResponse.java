package com.daynilgroup.vendormanagement.model.response;

import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class VerificationCountResponse {
	Long all;
	Long pending;
	Long verified;
	Long rejected;
	Long closed;
}
