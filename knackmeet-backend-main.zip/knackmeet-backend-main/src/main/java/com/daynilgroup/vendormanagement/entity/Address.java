/**
 * 
 */
package com.daynilgroup.vendormanagement.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

/**
 * @author Prerana
 *
 */
@Entity
@Table(name = "address")
@NoArgsConstructor
@Getter
@Setter
@FieldDefaults(level = AccessLevel.PRIVATE)
public class Address extends BaseEntity {

	static final long serialVersionUID = 1L;

	@ManyToOne(targetEntity = CodeLookup.class, fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JoinColumn(name = "country_id", nullable = false)
	CodeLookup country;

	@ManyToOne(targetEntity = CodeLookup.class, fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JoinColumn(name = "state_id", nullable = false)
	CodeLookup state;

}
