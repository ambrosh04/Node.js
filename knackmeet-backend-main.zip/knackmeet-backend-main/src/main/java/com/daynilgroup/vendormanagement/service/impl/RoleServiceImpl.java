package com.daynilgroup.vendormanagement.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;

import com.daynilgroup.vendormanagement.constants.RoleTypeEnum;
import com.daynilgroup.vendormanagement.entity.Role;
import com.daynilgroup.vendormanagement.repository.RoleRepository;
import com.daynilgroup.vendormanagement.service.RoleService;

@Service
public class RoleServiceImpl implements RoleService {

	@Autowired
	RoleRepository roleRepository;

	@Override
	public JpaRepository<Role, Long> getJpaRepository() {

		return roleRepository;
	}

	@Override
	public Role findByType(RoleTypeEnum type) {
		return roleRepository.findByType(type);
	}

}
