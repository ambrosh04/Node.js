/**
 * 
 */
package com.daynilgroup.vendormanagement.service.impl;

import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;

import com.daynilgroup.vendormanagement.constants.Constants;
import com.daynilgroup.vendormanagement.constants.StatusEnum;
import com.daynilgroup.vendormanagement.constants.UserType;
import com.daynilgroup.vendormanagement.entity.Vendor;
import com.daynilgroup.vendormanagement.entity.VerifyEmail;
import com.daynilgroup.vendormanagement.model.response.UserVendorResponse;
import com.daynilgroup.vendormanagement.repository.VendorRepository;
import com.daynilgroup.vendormanagement.service.VendorService;
import com.daynilgroup.vendormanagement.service.VerifyEmailService;
import com.daynilgroup.vendormanagement.util.CommonUtil;
import com.daynilgroup.vendormanagement.util.EmailSenderUtil;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;

/**
 * @author Prerana
 *
 */
@Service
@FieldDefaults(level = AccessLevel.PRIVATE)
public class VendorServiceImpl implements VendorService {

	@Autowired
	VendorRepository vendorRepository;

	@Autowired
	VendorService vendorService;
	
	@Autowired
	VerifyEmailService verifyEmailService;
	
	@Autowired
	EmailSenderUtil emailSenderUtil;

	@Override
	public JpaRepository<Vendor, Long> getJpaRepository() {
		return vendorRepository;
	}

	@Override
	public Vendor findByUserId(Long userId) {
		return vendorRepository.findByUserId(userId);
	}

	@Override
	public Boolean existsByMobileNumberAndUserTypeAndIdNot(String mobileNumber, UserType userType, Long Id) {
		return vendorRepository.existsByMobileNumberAndUserTypeAndIdNot(mobileNumber, userType, Id);
	}

	@Override
	public void verifyVendor(Long vendorId, StatusEnum status) {
		Vendor vendor = vendorService.findById(vendorId);
		if (CommonUtil.isEmpty(vendor)) {
			throw new RuntimeException("Vendor Not Found with given ID# " + vendorId);
		}
		vendor.setStatusEnum(status != null ? status : StatusEnum.UNVERIFIED);
		save(vendor);
	}

	@Override

	public Page<Vendor> getList(String agencyName,String name,String location,Pageable pageable) {
		return vendorRepository.findAllVendorExceptAdmin(UserType.VENDOR,agencyName,name,location, pageable);
	}

	public void deleteById(Long id) {
		vendorRepository.deleteById(id);
	}

	@Override
	public List<Vendor> getvendorDetails() {
		return vendorRepository.findAll();
	}
	
	@Override
	public Long getAllVendorCountExceptAdmin(UserType userType) {
		
		return vendorRepository.getAllVendorCountExceptAdmin(userType);
	}

	@Override
	public void rejectVendor(Long vendorId, StatusEnum status) {
		Vendor vendor = vendorService.findById(vendorId);
		if (CommonUtil.isEmpty(vendor)) {
			throw new RuntimeException("Invalid Vendor Id");
		} else if (vendor.getStatusEnum() == StatusEnum.REJECTED) {
			throw new RuntimeException("Vendor has been alredy rejected.");
		}
		vendor.setStatusEnum(status != null ? status : StatusEnum.REJECTED);
		save(vendor);

	}

	@Override
	public Boolean existsByCompanyPrimaryNumber(String companyNumber) throws Exception {
		return vendorRepository.existsByCompanyPrimaryNumber(companyNumber);
	}

	@Override
	public Boolean existsByCompanyPrimaryEmail(String companyEmail) throws Exception {
		return vendorRepository.existsByCompanyPrimaryEmail(companyEmail);
	}

	@Override
	public Boolean existsByCompanyPrimaryNumberAndIdNot(String companyNumber, Long id) throws Exception {
		return vendorRepository.existsByCompanyPrimaryNumberAndIdNot(companyNumber, id);
	}

	@Override
	public Boolean existsByCompanyPrimaryEmailAndIdNot(String companyPrimaryEmail, Long id) throws Exception {
		return vendorRepository.existsByCompanyPrimaryEmailAndIdNot(companyPrimaryEmail, id);
	}

	@Override
	public void sendEmailToVerifyEmailId(Long vendorId) throws Exception {
		Vendor vendor = findById(vendorId);
		
		VerifyEmail verifyEmail = verifyEmailService.findByVendorId(vendorId);	
		if(verifyEmail==null) {
			 verifyEmail=new VerifyEmail();
			 verifyEmail.setVendor(vendor);
			 verifyEmail.setStatusEnum(StatusEnum.EMAIL_PENDING);
		}
		String randomString = UUID.randomUUID().toString();
		verifyEmail.setRandomNumber(randomString);
		verifyEmailService.save(verifyEmail);
		emailSenderUtil.sendMail(
				verifyEmail.getRandomNumber(), vendor.getCompanyPrimaryEmail()!=null?vendor.getCompanyPrimaryEmail():vendor.getUser().getEmailId(), Constants.VERIFY_EMAIL,
				Constants.VERIFY_EMAIL_SUBJECT);
	}

	@Override
	public List<Vendor> getListByUserType(UserType userType) {

		return vendorRepository.findAllVendorExceptAdmin(userType);
	}

	@Override
	public Boolean existsByAgencyName(String agencyName) throws Exception {
		return vendorRepository.existsByAgencyName(agencyName);
	}

	@Override
	public Vendor findByCompanyPrimaryEmail(String companyPrimaryEmail) {
		return vendorRepository.findByCompanyPrimaryEmail(companyPrimaryEmail);
	}
}
