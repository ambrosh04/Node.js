package com.daynilgroup.vendormanagement.model.request;

import java.math.BigDecimal;
import java.util.List;

import com.daynilgroup.vendormanagement.constants.CurrencyTypeEnum;
import com.daynilgroup.vendormanagement.constants.DeploymentTypeEnum;
import com.daynilgroup.vendormanagement.constants.Gender;
import com.daynilgroup.vendormanagement.constants.RateTypeEnum;
import com.daynilgroup.vendormanagement.constants.StatusEnum;
import com.daynilgroup.vendormanagement.model.pag.PaginationRequestModel;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@Getter
@Setter
@FieldDefaults(level = AccessLevel.PRIVATE)
public class ResourceFilterRequest {

	List<Long> skillsCodeLookups;
	
	Gender gender;
	
	CurrencyTypeEnum currencyTypeEnum;

	Long availabilityId;

	Long countryId;

	Long stateId;

	Long cityId;

	String nameOrCategory;

	DeploymentTypeEnum deploymenType;

	BigDecimal minRate;

	BigDecimal maxRate;

	Integer minExp;

	Integer maxExp;

	StatusEnum status;

	PaginationRequestModel paginationRequestModel;
	
	BigDecimal usdRate;
	
	RateTypeEnum usdRateType;
	
	String designation;
	
	Long vendorId;
	
	RateTypeEnum rateType;
	
	RateTypeEnum rateTypeWithoutCT;
}
