package com.daynilgroup.vendormanagement.helper;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.daynilgroup.vendormanagement.constants.MediaTypeEnum;
import com.daynilgroup.vendormanagement.entity.Media;
import com.daynilgroup.vendormanagement.service.MediaService;
import com.daynilgroup.vendormanagement.util.Base64Util;
import com.daynilgroup.vendormanagement.util.FileUpload;
import com.google.api.pathtemplate.ValidationException;

import lombok.extern.slf4j.Slf4j;

import java.io.IOException;
import java.io.Serializable;
import java.util.logging.Level;
import java.util.logging.Logger;

@Slf4j
@Component
public class AttributeMediaUploadHelper implements Serializable {

	private static final long serialVersionUID = 1L;

	@Autowired
	private Base64Util base64Util;

	@Autowired
	private FileUpload fileUpload;

	@Autowired
	private MediaService mediaService;

	public Boolean deleteOldMedia(String oldMediaUrlpath) throws RuntimeException, IOException {
		if (StringUtils.isNotBlank(oldMediaUrlpath)) {
			Boolean flag = fileUpload.deleteFileByS3(oldMediaUrlpath);
			if (flag && mediaService.doesExists(oldMediaUrlpath)) {
				mediaService.deleteMedia(oldMediaUrlpath);
				return true;
			}
		}
		return false;
	}

	public Media uploadMedia(String attributeClassName, Media media, String base64Media, MediaTypeEnum mediaTypeEnum) {
		try {
			if (media == null) {
				media = new Media();
			}
			String extension = base64Util.getExtension(base64Media);
			String urlPath = null;
			switch (mediaTypeEnum) {
			case VIDEO:
				if (extension.equalsIgnoreCase("mp4")) {
					urlPath = fileUpload.uploadBase64StringFileToPrivateBucket(attributeClassName + "/video-",
							RandomStringUtils.randomAlphanumeric(6), base64Media);
					media.setMediaType(MediaTypeEnum.VIDEO);
				} else {
					new ValidationException("please upload Mp4 formated file only.");
				}
				break;
			case DOCUMENT:
				if (extension.equals("pdf") || extension.equals("doc") || extension.equals("docx")) {
					urlPath = fileUpload.uploadBase64StringFileToPrivateBucket(attributeClassName + "/doc-",
							RandomStringUtils.randomAlphanumeric(6), base64Media);
					media.setMediaType(MediaTypeEnum.DOCUMENT);
				} else {
					new ValidationException("please upload pdf / doc / docx formated file only.");
				}
				break;
			case IMAGE:
				if (extension.equals("png") || extension.equals("jpg") || extension.equals("jpeg")
						|| extension.equals("svg")) {
					urlPath = fileUpload.uploadBase64StringFileToPrivateBucket(attributeClassName + "/image-",
							RandomStringUtils.randomAlphanumeric(6), base64Media);
					media.setMediaType(MediaTypeEnum.IMAGE);
				} else {
					new ValidationException("please upload png / svg / jpg / jpeg formated file only.");
				}
				break;
			default:
				break;
			}
			media.setPath(urlPath);
			return (Media) mediaService.save(media);
		} catch (RuntimeException | IOException ex) {
			Logger.getLogger(ResourceHelper.class.getName()).log(Level.SEVERE, null, ex);
		}
		return null;
	}

	public Media setMedia(String attributeClassName, Media media, String base64Media, MediaTypeEnum mediaTypeEnum) {
		try {
			if (media == null) {
				media = new Media();
			}
			String extension = base64Util.getExtension(base64Media);
			String urlPath = null;
			switch (mediaTypeEnum) {
			case VIDEO:
				if (extension.equalsIgnoreCase("mp4")) {
					urlPath = fileUpload.uploadBase64StringToPrivateBucket(attributeClassName,
							RandomStringUtils.randomAlphanumeric(6), base64Media);
					media.setMediaType(MediaTypeEnum.VIDEO);
				} else {
					new ValidationException("please upload Mp4 formated file only.");
				}
				break;
			case DOCUMENT:
				if (extension.equals("pdf") || extension.equals("doc") || extension.equals("docx")) {
					urlPath = fileUpload.uploadBase64StringToPrivateBucket(attributeClassName,
							RandomStringUtils.randomAlphanumeric(6), base64Media);
					media.setMediaType(MediaTypeEnum.DOCUMENT);
				} else {
					new ValidationException("please upload pdf / doc / docx formated file only.");
				}
				break;
			case IMAGE:
				if (extension.equals("png") || extension.equals("jpg") || extension.equals("jpeg")
						|| extension.equals("svg")) {
					urlPath = fileUpload.uploadBase64StringToPrivateBucket(attributeClassName,
							RandomStringUtils.randomAlphanumeric(6), base64Media);
					media.setMediaType(MediaTypeEnum.IMAGE);
				} else {
					new ValidationException("please upload png / svg / jpg / jpeg formated file only.");
				}
				break;
			default:
				break;
			}

			media.setPath(urlPath);
			return (Media) mediaService.save(media);
		} catch (RuntimeException | IOException ex) {
			Logger.getLogger(ResourceHelper.class.getName()).log(Level.SEVERE, null, ex);
		}
		return null;
	}

	public Media uploadMediaForResume(String attributeClassName, Media media, String base64Media, String resumeName,
			MediaTypeEnum mediaTypeEnum) {
		log.info("inside uploadMediaForResume");
		switch (mediaTypeEnum) {
		case DOCUMENT:
			try {
				if (media == null) {
					media = new Media();
				}
				String extension = base64Util.getExtension(base64Media);
				String urlPath = null;
				if (extension.equals("pdf") || extension.equals("doc") || extension.equals("docx")
						|| extension.equals("pptx") || extension.equals("ppt")) {
					urlPath = fileUpload.uploadBase64StringFileToPublicBucket(attributeClassName + "", "", base64Media);

					media.setMediaType(MediaTypeEnum.DOCUMENT);
				} else {
					new ValidationException("Please upload pdf / doc / docx / pptx / ppt formated file only.");
				}
				media.setPath(urlPath.substring(1));
				return (Media) mediaService.save(media);
			} catch (RuntimeException | IOException ex) {
				log.error(ExceptionUtils.getStackTrace(ex));
				Logger.getLogger(ResourceHelper.class.getName()).log(Level.SEVERE, null, ex);
			}
		}
		return null;
	}

	public Media setMediaWithFileName(String attributeClassName, Media media, String base64Media, String fileName,
			MediaTypeEnum mediaTypeEnum) {
		try {
			if (media == null) {
				media = new Media();
			}
			String extension = base64Util.getExtension(base64Media);
			String urlPath = null;
			switch (mediaTypeEnum) {
			case DOCUMENT:
				if (extension.equals("pdf") || extension.equals("doc") || extension.equals("docx")
						|| extension.equals("pptx") || extension.equals("ppt")) {
					urlPath = fileUpload.uploadBase64StringToPrivateBucket(attributeClassName, fileName, base64Media);

					media.setMediaType(MediaTypeEnum.DOCUMENT);
				} else {
					new ValidationException("Please upload pdf / doc / docx / pptx / ppt formated file only.");
				}
			case VIDEO:
				if (extension.equalsIgnoreCase("mp4")) {
					urlPath = fileUpload.uploadBase64StringToPrivateBucket(attributeClassName, fileName, base64Media);
					media.setMediaType(MediaTypeEnum.VIDEO);
				} else {
					new ValidationException("please upload Mp4 formated file only.");
				}
			case IMAGE:
				if (extension.equals("png") || extension.equals("jpg") || extension.equals("jpeg")
						|| extension.equals("svg")) {
					urlPath = fileUpload.uploadBase64StringToPrivateBucket(attributeClassName, fileName, base64Media);
					media.setMediaType(MediaTypeEnum.IMAGE);
				} else {
					new ValidationException("please upload png / svg / jpg / jpeg formated file only.");
				}

				media.setPath(urlPath);
				return (Media) mediaService.save(media);
			}
		} catch (RuntimeException | IOException ex) {
			log.error(ExceptionUtils.getStackTrace(ex));
			Logger.getLogger(ResourceHelper.class.getName()).log(Level.SEVERE, null, ex);
		}
		return null;
	}
}
