package com.daynilgroup.vendormanagement.model.response;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

import com.daynilgroup.vendormanagement.constants.DeploymentTypeEnum;

import lombok.AccessLevel;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

@Data
@NoArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class JobDetailsResponses implements Serializable{

	private static final long serialVersionUID = 1L;
	
	Long id;
	
	String title;

	String description;

	String workFrom;

	String vendorLogoPath;
	
	String experience;
	
	String duration;
	
	List<String> skills;
	
	Integer numberOfResources;
	
	LocalDateTime createdOn;
	
	BigDecimal minRate;

	BigDecimal maxRate;
	
	String rateType;
	
	String currencyType;
	
}
