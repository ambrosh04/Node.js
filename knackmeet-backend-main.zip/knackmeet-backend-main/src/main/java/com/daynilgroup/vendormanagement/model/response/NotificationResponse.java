package com.daynilgroup.vendormanagement.model.response;

import java.io.Serializable;
import java.time.LocalDateTime;

import com.daynilgroup.vendormanagement.constants.ResourceStatusEnum;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class NotificationResponse implements Serializable {

	
	String resourceName;
	LocalDateTime date;
	String jobTitle;
	ResourceStatusEnum resourceStatus;
}
