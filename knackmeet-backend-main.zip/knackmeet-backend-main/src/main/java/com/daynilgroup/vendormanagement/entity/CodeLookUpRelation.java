package com.daynilgroup.vendormanagement.entity;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import com.daynilgroup.vendormanagement.constants.CodeLookUpRelationTypeEnum;
import com.daynilgroup.vendormanagement.constants.RefTypeEnum;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "code_lookup_relation", uniqueConstraints = {
	    @UniqueConstraint(name = "UK_code_lookup_relation_code_lookup",columnNames = {"ref_id", "ref_type", "type","code_look_up_id"})
	})
@FieldDefaults(level = AccessLevel.PRIVATE)
public class CodeLookUpRelation extends BaseEntity{

	private static final long serialVersionUID = 1L;
	
	@Column(name = "ref_id",nullable = false)
	Long refId;
	
	@Column(name = "ref_type",nullable = false)
	@Enumerated(EnumType.STRING)
	RefTypeEnum refType;
	
	@JoinColumn(name = "code_look_up_id", nullable = false, referencedColumnName = "id")
	@ManyToOne(fetch = FetchType.LAZY)
	CodeLookup codeLookup;
	
	@Column(name = "type",nullable = false)
	@Enumerated(EnumType.STRING)
	CodeLookUpRelationTypeEnum type;

}
