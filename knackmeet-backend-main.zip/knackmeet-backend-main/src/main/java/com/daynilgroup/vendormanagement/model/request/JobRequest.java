package com.daynilgroup.vendormanagement.model.request;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalTime;
import java.util.Date;
import java.util.List;

import com.daynilgroup.vendormanagement.constants.CurrencyTypeEnum;
import com.daynilgroup.vendormanagement.constants.DeploymentTypeEnum;
import com.daynilgroup.vendormanagement.constants.JobTypeEnum;
import com.daynilgroup.vendormanagement.constants.RateTypeEnum;
import com.daynilgroup.vendormanagement.constants.TimeZoneEnum;
import com.daynilgroup.vendormanagement.model.response.AdvanceSearchDropdownModel;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.FieldDefaults;

@Getter
@Setter
@FieldDefaults(level = AccessLevel.PRIVATE)
@ToString
public class JobRequest implements Serializable {

	static final long serialVersionUID = 1L;

	Long id;

	String title;

	Long countryId;

	Long stateId;

	AdvanceSearchDropdownModel city;

	List<AdvanceSearchDropdownModel> skillsCodeLookup;

	Integer noOfResources;

	Long categoryId;

	DeploymentTypeEnum workFrom;

	Integer minExperience;

	Integer maxExperience;

	Long durationId;

	JobTypeEnum jobType;

	CurrencyTypeEnum currencyType;

	RateTypeEnum rateTypeEnum;

	BigDecimal minRate;

	BigDecimal maxRate;

	String description;
	
	Date startDate;

    String location;
	
	BigDecimal latitude;
	
	BigDecimal longitude;

	TimeZoneEnum timeZoneEnum;

	LocalTime startTime;

	LocalTime endTime;

	Long vendorId;
}
