package com.daynilgroup.vendormanagement.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;

import com.daynilgroup.vendormanagement.entity.RegistrationEnquiry;
import com.daynilgroup.vendormanagement.repository.RegistrationEnquiryRepository;
import com.daynilgroup.vendormanagement.service.RegistrationEnquiryService;

@Service
public class RegistrationEnquiryServiceImpl implements RegistrationEnquiryService {
	
	@Autowired
	RegistrationEnquiryRepository partialRegisterUserRepository;

	@Override
	public JpaRepository<RegistrationEnquiry, Long> getJpaRepository() {
		return partialRegisterUserRepository;
	}

	@Override
	public void deleteById(Long id) {
		partialRegisterUserRepository.deleteById(id);
		
	}

	@Override
	public List<RegistrationEnquiry> findByEmailOrMobileNumberAndPhoneCode(String email, String mobileNumber,Long phoneCodeId) {
		return partialRegisterUserRepository.findByEmailIdOrMobileNumberAndCountryCodeId(email, mobileNumber,phoneCodeId);
	}

}
