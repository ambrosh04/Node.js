package com.daynilgroup.vendormanagement.model.request;

import com.daynilgroup.vendormanagement.constants.UserType;
import com.daynilgroup.vendormanagement.request.inf.RequestInf;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AccessLevel;
import lombok.Builder;
import lombok.Getter;
import lombok.NonNull;
import lombok.experimental.FieldDefaults;

/**
*
* @author prerana
*/
@Getter
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
public class UserRequest implements RequestInf {

	static final long serialVersionUID = 1L;

	Long id;

	String emailId;

	@NonNull
	@JsonProperty(required = true)
	String mobile;

	@JsonProperty(required = true)
	String password;

	UserType userType;

}