package com.daynilgroup.vendormanagement.constants;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.experimental.FieldDefaults;

@Getter
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public enum CodeLookUpRelationTypeEnum {

	RESOURCE_REJECT_REASON("Resource Reject Reason"), 
	RESOURCE_SKILL("Resource Skill"),
	JOB_REJECT_REASON("Job Reject Reason"), 
	JOB_SKILL("Job Skill"),
	RESOURCE_JOBS_WITHDROW_REASON("Resource Jobs Withdrow Reason"),
	SUBSCRIBE_FOR_EMAIL_NOTIFICATION("Subscribe For Email Notification");

	String displayName;

}
