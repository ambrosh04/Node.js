package com.daynilgroup.vendormanagement.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import com.daynilgroup.vendormanagement.entity.EmailLog;

public interface EmailLogRepository extends JpaRepository<EmailLog, Long>{
	
	Page<EmailLog> findAll(Pageable pageable);


}
