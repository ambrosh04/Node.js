package com.daynilgroup.vendormanagement.request.inf;

import java.io.Serializable;

/**
 *
 * @author Manish
 */
public interface RequestInf extends Serializable {

    public Long getId();

}