package com.daynilgroup.vendormanagement.constants;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.experimental.FieldDefaults;

@Getter
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public enum InvitationStatusEnum {

	INVITATION_ACCEPTED("Invitation Accepted"), INVITATION_REJECTED("Invitation Rejected");

	String displayName;

}
