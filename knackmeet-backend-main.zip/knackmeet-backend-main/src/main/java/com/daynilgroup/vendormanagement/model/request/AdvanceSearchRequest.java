package com.daynilgroup.vendormanagement.model.request;

import com.daynilgroup.vendormanagement.model.filter.ResourceSkillsFilterModel;

import lombok.AccessLevel;
import lombok.Builder;
import lombok.Getter;
import lombok.experimental.FieldDefaults;

/**
 *
 * @author Shivendra Sharma
 */

@Getter
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
public class AdvanceSearchRequest {

	JobSearchRequest jobSearchRequest;

	ResourceSkillsFilterModel resourceSkillsFilterModel;
}
