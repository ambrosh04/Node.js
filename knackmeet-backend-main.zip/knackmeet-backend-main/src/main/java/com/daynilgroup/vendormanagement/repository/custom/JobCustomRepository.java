/**
 * 
 */
package com.daynilgroup.vendormanagement.repository.custom;

import com.daynilgroup.vendormanagement.model.pag.PageModel;
import com.daynilgroup.vendormanagement.model.request.JobFilterRequest;
import com.daynilgroup.vendormanagement.model.request.JobSearchRequest;

/**
 * @author Prerana
 *
 */
public interface JobCustomRepository {

	PageModel getJobsFilterList(JobFilterRequest jobFilterRequest);
	
	PageModel getJobsSearchFilter(JobSearchRequest jobRequestAdvanced);
	
}
