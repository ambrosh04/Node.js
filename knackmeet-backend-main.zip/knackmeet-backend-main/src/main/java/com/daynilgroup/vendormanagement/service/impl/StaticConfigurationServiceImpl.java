package com.daynilgroup.vendormanagement.service.impl;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;

import com.daynilgroup.vendormanagement.constants.StaticConfigurationEnum;
import com.daynilgroup.vendormanagement.entity.StaticConfiguration;
import com.daynilgroup.vendormanagement.repository.StaticConfigurationRepository;
import com.daynilgroup.vendormanagement.service.StaticConfigurationService;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;

@Service
@FieldDefaults(level = AccessLevel.PRIVATE)
public class StaticConfigurationServiceImpl implements StaticConfigurationService {

	@Autowired
	StaticConfigurationRepository staticConfigurationRepository;

	@Override
	public JpaRepository<StaticConfiguration, Long> getJpaRepository() {
		return staticConfigurationRepository;
	}

	@Override
	public Page<StaticConfiguration> getList(Pageable pageable) {
		return staticConfigurationRepository.findByDeletedFalse(pageable);
	}

	@Override
	public StaticConfiguration findByName(StaticConfigurationEnum staticConfigurationEnum) {
		return staticConfigurationRepository.findByNameAndDeletedFalse(staticConfigurationEnum);
	}

}
