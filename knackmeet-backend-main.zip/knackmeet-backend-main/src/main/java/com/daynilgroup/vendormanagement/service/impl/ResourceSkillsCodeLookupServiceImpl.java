package com.daynilgroup.vendormanagement.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.ObjectUtils;

import com.daynilgroup.vendormanagement.constants.CurrencyTypeEnum;
import com.daynilgroup.vendormanagement.constants.StaticConfigurationEnum;
import com.daynilgroup.vendormanagement.entity.Resource;
import com.daynilgroup.vendormanagement.entity.ResourceSkillsCodeLookup;
import com.daynilgroup.vendormanagement.model.filter.ResourceSkillsFilterModel;
import com.daynilgroup.vendormanagement.model.pag.PageModel;
import com.daynilgroup.vendormanagement.model.response.ResourceListResponse;
import com.daynilgroup.vendormanagement.repository.ResourceSkillsCodeLookupRepository;
import com.daynilgroup.vendormanagement.service.ResourceService;
import com.daynilgroup.vendormanagement.service.ResourceSkillsCodeLookupService;
import com.daynilgroup.vendormanagement.service.StaticConfigurationService;
import com.daynilgroup.vendormanagement.util.CommonUtil;
import com.daynilgroup.vendormanagement.util.FileUpload;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;

@Service
@FieldDefaults(level = AccessLevel.PRIVATE)
public class ResourceSkillsCodeLookupServiceImpl implements ResourceSkillsCodeLookupService {

	@Autowired
	ResourceService resourceService;
	
	@Autowired
	FileUpload fileUpload;

	
	@Autowired
	ResourceSkillsCodeLookupRepository resourceSkillscodeLookupRepository;
	
	@Autowired
	StaticConfigurationService staticConfigurationService;

	@Override
	public JpaRepository<ResourceSkillsCodeLookup, Long> getJpaRepository() {
		return resourceSkillscodeLookupRepository;
	}

	@Override
	public void deleteByResourceId(Long resourceId) {
		resourceSkillscodeLookupRepository.deleteByResourceId(resourceId);
		
	}

	@Override
	public List<ResourceSkillsCodeLookup> findAllByResourceId(Long resourceId) {
		return resourceSkillscodeLookupRepository.findAllByResourceId(resourceId);
	}

	@SuppressWarnings("unchecked")
	@Override
	public PageModel getResourceList(ResourceSkillsFilterModel resourceSkillsFilterModel) {
		PageModel models = resourceSkillscodeLookupRepository.findAll(resourceSkillsFilterModel);
		if (!ObjectUtils.isEmpty(models.getData())) {
			List<ResourceListResponse> resourceListResponse =  (List<ResourceListResponse>) models.getData();
			resourceListResponse.forEach(resourceResponse -> {
				Resource resource =resourceService. findById(resourceResponse.getId());
				List<String> skills = new ArrayList<>();
				List<ResourceSkillsCodeLookup> skillsAndDeginationsCodeLookups = resourceSkillscodeLookupRepository.findAllByResourceId(resource.getId());
				if(!CollectionUtils.isEmpty(skillsAndDeginationsCodeLookups)) {
					skillsAndDeginationsCodeLookups.forEach(skillAndDeginationCodeLookup ->{
						skills.add(skillAndDeginationCodeLookup.getCodeLookup().getName());
						
					});
					resourceResponse.setSkills(skills);
					resourceResponse.setBase64MediaString(resource != null &&  resource.getProfilePhoto() != null
							? fileUpload.generatePresignedURL(resource.getProfilePhoto().getPath())
							: null);
					resourceResponse.setUsdRate(resource.getUsdRate()!=null?CommonUtil.getRateStr(CurrencyTypeEnum.USD.getDisplayName(), CommonUtil.resourceRateWithCommission(resource.getUsdRate(), staticConfigurationService.findByName(StaticConfigurationEnum.RESOURCE_COMMISSION).getValue()), resource.getUsdRateType().getDisplayName()):null);
					resourceResponse.setRate(resource.getRate()!=null?CommonUtil.getRateStr(CurrencyTypeEnum.INR.getDisplayName(), CommonUtil.resourceRateWithCommission(resource.getRate(), staticConfigurationService.findByName(StaticConfigurationEnum.RESOURCE_COMMISSION).getValue()), resource.getRateTypeEnum().getDisplayName()):null);


				}
			});
		}
		return models;
			
	}

	@Override
	public ResourceSkillsCodeLookup findByResourceIdAndCodeLookupId(Long resourceId, Long codeLookupId) {
		return resourceSkillscodeLookupRepository.findByResourceIdAndCodeLookupId(resourceId, codeLookupId);
	}
	

}
