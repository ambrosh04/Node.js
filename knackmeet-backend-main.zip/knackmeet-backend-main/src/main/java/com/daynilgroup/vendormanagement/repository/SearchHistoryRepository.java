package com.daynilgroup.vendormanagement.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.daynilgroup.vendormanagement.constants.SearchType;
import com.daynilgroup.vendormanagement.entity.SearchHistory;

public interface SearchHistoryRepository extends JpaRepository<SearchHistory, Long> {
	
	@Query("select sh from SearchHistory sh where sh.vendor.id=:vendorId and sh.searchType='HIRE_DEVELOPER' ORDER BY date DESC")
	Page<SearchHistory> getSearchHistoryListForHireDeveloperExceptVendorId(Long vendorId,Pageable pageable);

	@Query("select sh from SearchHistory sh where sh.vendor.id=:vendorId and sh.searchType='JOBS_OR_PROJECTS' ORDER BY date DESC")
	Page<SearchHistory> getSearchHistoryListForJobOrProjectExceptVendorId(Long vendorId,Pageable pageable);
	
	@Query("select sh from SearchHistory sh where sh.vendor.id=:vendorId and sh.searchType=:searchType ORDER BY date DESC")
	Page<SearchHistory> getRecentSearchHistoryExceptVendorId(Long vendorId,SearchType searchType,Pageable pageable);

	@Query("select sh from SearchHistory sh where sh.vendor.id=:vendorId and sh.searchType=:searchType ORDER BY date DESC")
	List<SearchHistory> getRecentSearchHistoryExceptVendorId(Long vendorId,SearchType searchType);


}
