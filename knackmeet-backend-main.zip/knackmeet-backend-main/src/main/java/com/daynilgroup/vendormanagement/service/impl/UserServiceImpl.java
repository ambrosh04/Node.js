/**
 * 
 */
package com.daynilgroup.vendormanagement.service.impl;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.daynilgroup.vendormanagement.constants.Constants;
import com.daynilgroup.vendormanagement.constants.UserType;
import com.daynilgroup.vendormanagement.entity.User;
import com.daynilgroup.vendormanagement.entity.Vendor;
import com.daynilgroup.vendormanagement.model.request.UserForgotPasswordRequest;
import com.daynilgroup.vendormanagement.repository.UserRepository;
import com.daynilgroup.vendormanagement.repository.VendorRepository;
import com.daynilgroup.vendormanagement.rest.exception.CustomException;
import com.daynilgroup.vendormanagement.service.UserService;
import com.daynilgroup.vendormanagement.service.VendorService;
import com.daynilgroup.vendormanagement.util.EmailSenderUtil;
import com.daynilgroup.vendormanagement.util.EntityUtil;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;

/**
 * @author Prerana
 *
 */
@Service
@Slf4j
@FieldDefaults(level = AccessLevel.PRIVATE)
public class UserServiceImpl implements UserService {

	@Autowired
	UserRepository userRepository;

	@Autowired
	PasswordEncoder bcryptPasswordEncoder;

	@Value("${domain.url}")
	String domainUrl;

	@Autowired
	EmailSenderUtil emailSenderUtil;
	
	@Autowired
	VendorRepository vendorRepository;
	
	@Autowired
	EntityUtil entityUtil;
	
	@Autowired
	VendorService vendorService;

	@Override
	public JpaRepository<User, Long> getJpaRepository() {
		return userRepository;
	}

	@Override
	public User findByEmailIdOrMobile(String searchString) {
		return userRepository.findByEmailIdOrMobile(searchString, searchString);
	}

	@Override
	public User findByEmailIdOrMobileAndUserType(String searchString, UserType userType) {
		return userRepository.findByEmailIdOrMobileAndUserType(searchString, searchString, userType);
	}

	@Override
	public Boolean existsByMobileNumberAndIdNot(String mobileNumber, Long Id) throws Exception {
		try {
			return userRepository.existsByMobileNumberAndIdNot(mobileNumber, Id);
		} catch (Exception e) {
			throw new Exception("Account already exists with the given mobile number.");
		}
	}

	@Override
	public Page<User> findAll(Pageable pageable) {
		return userRepository.findAll(pageable);
	}

	@Override
	public Boolean existsByEmailIdNumberAndIdNot(String emailId, Long Id) throws Exception {
		try {
			return userRepository.existsByEmailIdAndIdNot(emailId, Id);
		} catch (Exception e) {
			throw new Exception("Account already exists with the given email id.");

		}
	}

	@Override
	public User findActiveUserByUserId(Long userId) {
		return userRepository.findByIdAndActiveTrue(userId);
	}

	@Override
	@Transactional
	public void changePassword(Long userId, String password) {
		if (userId != null) {
			userRepository.changePassword(bcryptPasswordEncoder.encode(password), userId);
		} else {
			throw new CustomException("User Id Not Found!");
		}
	}

	@Override
	public void validateUserByEmailId(String emailId) throws Exception {
		User existingUser = userRepository.findByEmailIdAndActiveTrue(emailId);
		if (existingUser != null) {
			Vendor vendor = vendorRepository.findByUserId(existingUser.getId());
			String forgetPasswordToken = RandomStringUtils.randomAlphabetic(15);
			existingUser.setForgotPasswordToken(forgetPasswordToken);
			userRepository.save(existingUser);
			Map<String, Object> model = new HashMap<>();
			model.put(Constants.NAME, vendor.getAgencyName());
			log.info("domainUrl : {}", domainUrl);
			model.put(Constants.REDIRECT_LINK, domainUrl + Constants.RESET_PASSWORD_TOKEN + forgetPasswordToken);
			new Thread() {
				public void run() {
					emailSenderUtil.sendEmail(emailId,  model, Constants.FORGOT_PASSWORD_TEMPLATE,
							Constants.FORGOT_PASSWORD_SUBJECT);
				}
			}.start();
		}
		 else {
			throw new Exception("Account doesn't exists with the given email id.");
		}
	}

	@Override
	public void validateTokenAndSetPassword(UserForgotPasswordRequest userRequest) {
		User existingUser = userRepository.findActiveUserByForgotPasswordToken(userRequest.getToken());
		if (existingUser != null) {
			existingUser.setPassword(bcryptPasswordEncoder.encode(userRequest.getPassword()));
			userRepository.save(existingUser);
		} else {
			throw new RuntimeException("Invalid Token");
		}
	}

	@Override
	public Boolean existsByMobileNumber(String mobileNumber) throws Exception {
		return userRepository.existsByMobile(mobileNumber);
	}

	@Override
	public Boolean existsByEmailId(String emailId) throws Exception {
		return userRepository.existsByEmailId(emailId);
	}

	@Override
	public void updatePageSize(Integer pageSize) {
		User user = entityUtil.getCurrentUser();
		user.setPageSize(pageSize);
		save(user);
	}

	@Override
	public Boolean existsByMobileNumberAndCompanyPrimaryNumber(String mobileNumber) throws Exception {
		boolean userExists = this.existsByMobileNumber(mobileNumber);
		boolean vendorExists = vendorService.existsByCompanyPrimaryNumber(mobileNumber);
		return (userExists || vendorExists);
	}

	@Override
	public Boolean existsByEmailIdAndCompanyPrimaryEmail(String companyPrimaryEmail) throws Exception {
		boolean userEmail = this.existsByEmailId(companyPrimaryEmail);
		boolean vendorEmail = vendorService.existsByCompanyPrimaryEmail(companyPrimaryEmail);
		return (userEmail || vendorEmail);
	}
}
