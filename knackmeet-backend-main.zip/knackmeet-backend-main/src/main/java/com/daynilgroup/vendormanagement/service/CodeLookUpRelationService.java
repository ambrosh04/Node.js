package com.daynilgroup.vendormanagement.service;

import java.util.List;

import com.daynilgroup.vendormanagement.constants.CodeLookUpRelationTypeEnum;
import com.daynilgroup.vendormanagement.constants.RefTypeEnum;
import com.daynilgroup.vendormanagement.constants.StatusEnum;
import com.daynilgroup.vendormanagement.entity.CodeLookUpRelation;
import com.daynilgroup.vendormanagement.model.request.SubscribeForEMailNotificationRequest;

public interface CodeLookUpRelationService extends AbstractService<CodeLookUpRelation> {
	
	List<CodeLookUpRelation> findByRefIdAndRefTypeAndType(Long refId,RefTypeEnum refType,CodeLookUpRelationTypeEnum type);
	
	void setActive(List<CodeLookUpRelation> CodelookupRelationList,String name);
	
	public StatusEnum getStatusEnumRejectedByAdmin(List<CodeLookUpRelation> CodelookupRelationList);
	
	void deleteByRefIdAndRefTypeAndType(Long refId,RefTypeEnum refType,CodeLookUpRelationTypeEnum type);

	void hardDeleteByRefIdAndRefTypeAndType(Long refId,RefTypeEnum refType,CodeLookUpRelationTypeEnum type);
	
	CodeLookUpRelation createSubscribeForEmailNotification(
			SubscribeForEMailNotificationRequest unSubEmailNotificationRequest) throws Exception;

	CodeLookUpRelation getCodeLookUpRelation(Long refId, RefTypeEnum refType, CodeLookUpRelationTypeEnum type,
			Long codeLookUpId);

	CodeLookUpRelation getActiveStatus(Long refId, RefTypeEnum refType, CodeLookUpRelationTypeEnum type);
}
