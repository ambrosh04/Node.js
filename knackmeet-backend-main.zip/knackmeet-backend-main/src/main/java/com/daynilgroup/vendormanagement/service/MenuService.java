package com.daynilgroup.vendormanagement.service;

import java.util.List;

import com.daynilgroup.vendormanagement.entity.Menu;

public interface MenuService  extends AbstractService<Menu> {
	
	 List<Long> getParentIds(List<Long> ids);

}
