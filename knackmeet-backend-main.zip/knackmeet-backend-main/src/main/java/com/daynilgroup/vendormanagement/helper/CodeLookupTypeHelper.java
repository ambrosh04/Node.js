/**
 * 
 */
package com.daynilgroup.vendormanagement.helper;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.daynilgroup.vendormanagement.entity.CodeLookupType;
import com.daynilgroup.vendormanagement.model.request.CreateCodeLookupTypeRequest;
import com.daynilgroup.vendormanagement.model.response.CodeLookupTypeAdminDetailResponse;
import com.daynilgroup.vendormanagement.model.response.CodeLookupTypeDetailResponse;
import com.daynilgroup.vendormanagement.model.response.CodeLookupTypeListResponse;
import com.daynilgroup.vendormanagement.service.CodeLookupTypeService;
import com.daynilgroup.vendormanagement.util.CommonUtil;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;

/**
 * @author Prerana
 *
 */
@Component
@FieldDefaults(level = AccessLevel.PRIVATE)
public class CodeLookupTypeHelper extends
		AbstractHelper<CodeLookupType, CreateCodeLookupTypeRequest, CodeLookupTypeListResponse, CodeLookupTypeDetailResponse, CodeLookupTypeAdminDetailResponse> {

	@Autowired
	CodeLookupTypeService codeLookupTypeService;

	@Override
	public CodeLookupType getEntity(CreateCodeLookupTypeRequest createCodeLookupTypeRequest) throws Exception {
		CodeLookupType codeLookupType;
		if (CommonUtil.isValid(createCodeLookupTypeRequest.getId())) {
			codeLookupType = codeLookupTypeService.findById(createCodeLookupTypeRequest.getId());
			if (codeLookupTypeService.getByCodeAndId(createCodeLookupTypeRequest.getCode(),
					createCodeLookupTypeRequest.getId())) {
				throw new Exception("Code already exist..!, Please provide another code. ");
			}
			if (codeLookupTypeService.getByNameAndId(createCodeLookupTypeRequest.getName(),
					createCodeLookupTypeRequest.getId())) {
				throw new Exception("Name already exist..!, Please provide another name. ");
			}
			if (!codeLookupType.getEditable()) {
				throw new Exception("Sorry..! You can't edit this record.");
			}
		} else {
			codeLookupType = new CodeLookupType();
			if (codeLookupTypeService.getByCodeAndId(createCodeLookupTypeRequest.getCode(), null)) {
				throw new Exception("Code already exist..!, Please provide another code. ");
			}
			if (codeLookupTypeService.getByNameAndId(createCodeLookupTypeRequest.getName(), null)) {
				throw new Exception("Name already exist..!, Please provide another name. ");
			}
		}
		codeLookupType.setCode(createCodeLookupTypeRequest.getCode().trim().toUpperCase());
		codeLookupType.setName(createCodeLookupTypeRequest.getName());
		codeLookupType.setActive(createCodeLookupTypeRequest.getActive());
		if (CommonUtil.isValid(createCodeLookupTypeRequest.getParentId())) {
			CodeLookupType parentCodeLookupType = codeLookupTypeService
					.findById(createCodeLookupTypeRequest.getParentId());
			if (parentCodeLookupType != null) {
				codeLookupType.setParentId(parentCodeLookupType);
			}
		} else {
			codeLookupType.setParentId(null);
		}
		codeLookupType.setCoverImgRequire(createCodeLookupTypeRequest.getCoverImgRequire() != null
				? createCodeLookupTypeRequest.getCoverImgRequire()
				: Boolean.FALSE);
		return codeLookupType;
	}

	@Override
	public List<CodeLookupTypeListResponse> getListResponse(List<CodeLookupType> codeLookupTypeList) {
		List<CodeLookupTypeListResponse> codeLookupTypeListResponseList = new ArrayList<>();
		codeLookupTypeList.forEach(codeLookupType -> {
			codeLookupTypeListResponseList.add(CodeLookupTypeListResponse.builder().id(codeLookupType.getId())
					.code(codeLookupType.getCode()).name(codeLookupType.getName()).active(codeLookupType.getActive())
					.parentId(codeLookupType.getParentId() != null ? codeLookupType.getParentId().getId() : null)
					.parentName(codeLookupType.getParentId() != null ? codeLookupType.getParentId().getName() : null)
					.editable(codeLookupType.getEditable()).deletable(codeLookupType.getDeletable()).build());
		});
		return codeLookupTypeListResponseList;
	}

	@Override
	public CodeLookupTypeDetailResponse getDetailResponse(CodeLookupType codeLookupType) {
		return CodeLookupTypeDetailResponse.builder().id(codeLookupType.getId()).code(codeLookupType.getCode())
				.active(codeLookupType.getActive())
				.parentId(codeLookupType.getParentId() != null ? codeLookupType.getParentId().getId() : null)
				.parentName(codeLookupType.getParentId() != null ? codeLookupType.getParentId().getName() : null)
				.name(codeLookupType.getName()).build();
	}

	@Override
	public CodeLookupTypeAdminDetailResponse getDetailForAdminResponse(CodeLookupType codeLookupType) {
		return CodeLookupTypeAdminDetailResponse.builder().id(codeLookupType.getId()).code(codeLookupType.getCode())
				.active(codeLookupType.getActive()).name(codeLookupType.getName())
				.parentId(codeLookupType.getParentId() != null ? codeLookupType.getParentId().getId() : null)
				.parentName(codeLookupType.getParentId() != null ? codeLookupType.getParentId().getName() : null)
				.coverImgRequire(codeLookupType.getCoverImgRequire()).build();
	}
	
	 public List<CodeLookupTypeListResponse> getListItemTypeResponse(List<CodeLookupType> codeLookupTypeList) {
	        List<CodeLookupTypeListResponse> codeLookupTypeListResponseList = new ArrayList<>();
	        codeLookupTypeList.forEach(codeLookupType -> {
	            codeLookupTypeListResponseList.add(CodeLookupTypeListResponse.builder().id(codeLookupType.getId())
	                    .code(codeLookupType.getCode()).name(codeLookupType.getName())
	                    .active(codeLookupType.getActive())
	                    .parentId(codeLookupType.getParentId() != null ? codeLookupType.getParentId().getId() : null)
	                    .parentName(codeLookupType.getParentId() != null ? codeLookupType.getParentId().getName() : null)
	                    .editable(codeLookupType.getEditable())
	                    .deletable(codeLookupType.getDeletable())
	                    .build());
	        });
	        return codeLookupTypeListResponseList;
	    }

}
