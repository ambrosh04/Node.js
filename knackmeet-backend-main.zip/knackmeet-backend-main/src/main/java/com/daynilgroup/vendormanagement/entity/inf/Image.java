package com.daynilgroup.vendormanagement.entity.inf;

import com.daynilgroup.vendormanagement.entity.Media;

/**
 *
 * @author manish
 */
public interface Image {
	Media getImageId();

	void setImageId(Media image);
}
