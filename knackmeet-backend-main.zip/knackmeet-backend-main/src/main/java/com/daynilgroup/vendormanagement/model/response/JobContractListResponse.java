package com.daynilgroup.vendormanagement.model.response;

import java.io.Serializable;

import lombok.AccessLevel;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

@Data
@NoArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class JobContractListResponse implements Serializable {

	private static final long serialVersionUID = 1L;

	int id;

	String state;

	String country;

	String skills;

	String title;

	String rateType;

	String rate;

	String experience;

	String currencyType;

	String duration;

	String actionUrl;
	
	String workFrom;

}
