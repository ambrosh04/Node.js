package com.daynilgroup.vendormanagement.exception.response;

import java.io.Serializable;

import com.daynilgroup.vendormanagement.constants.StaticConfigurationEnum;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

@Builder
@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
@AllArgsConstructor
@NoArgsConstructor
public class StaticConfiguarationResponse implements Serializable {

	private static final long serialVersionUID = 1L;

	Long id;

	String label;

	StaticConfigurationEnum code;

	String value;

}
