package com.daynilgroup.vendormanagement.service;

import java.util.List;

import com.daynilgroup.vendormanagement.entity.ResourceJobs;
import com.daynilgroup.vendormanagement.model.response.DashBoardJobsListResponse;
import com.daynilgroup.vendormanagement.model.response.DashBoardResponse;
import com.daynilgroup.vendormanagement.model.response.NotificationResponse;

public interface DashBoardService {

	DashBoardResponse getDashBoardResponse();
	//dashboard

	List<DashBoardJobsListResponse> getListResponse(List<ResourceJobs> resourceJobsList);
	
	List<NotificationResponse> getNotificationResponse(List<ResourceJobs> resourceJobsList);

}
