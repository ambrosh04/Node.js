package com.daynilgroup.vendormanagement.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;

import com.daynilgroup.vendormanagement.constants.Constants;
import com.daynilgroup.vendormanagement.entity.VendorPortfolio;
import com.daynilgroup.vendormanagement.repository.VendorPortfolioRepository;
import com.daynilgroup.vendormanagement.service.VendorPortfolioService;
import com.daynilgroup.vendormanagement.util.EntityUtil;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;

@Service
@FieldDefaults(level = AccessLevel.PRIVATE)
public class VendorPortfolioServiceImpl implements VendorPortfolioService{
	
	@Autowired
	VendorPortfolioRepository portfolioRepository;
	
	@Autowired
	EntityUtil entityUtil;

	@Override
	public JpaRepository<VendorPortfolio, Long> getJpaRepository() {
		return portfolioRepository;
	}

	/**
	 * return portfolio list for current vendor id.
	 */
	@Override
	public List<VendorPortfolio> findByVendorAndDeletedFalse() {
		Long vendorId=entityUtil.getCurrentVendorId();
		return portfolioRepository.findByVendorAndDeletedFalse(vendorId);
	}
	
	/**
	 * soft delete in list.
	 */
	@Override
	public void deleteByInId(List<Long> deletePortfolio) {
		portfolioRepository.softDeleteByInId(deletePortfolio);
	}

	@Override
	public void deleteById(Long id) {
		VendorPortfolio portfolio = portfolioRepository.findById(id).orElseThrow(() -> new RuntimeException(Constants.VENDOR_PORTFOLIO_NOT_FOUND + id));
		portfolio.setDeleted(Boolean.TRUE);
		portfolioRepository.save(portfolio);
	}

}
