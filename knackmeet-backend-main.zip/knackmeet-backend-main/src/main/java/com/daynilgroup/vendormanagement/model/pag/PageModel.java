package com.daynilgroup.vendormanagement.model.pag;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 *
 * @author Manish
 */

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PageModel implements Serializable {

	private static final long serialVersionUID = 1L;

	private Object data;

	private Long totalCount;

	private Long pageCount;

}