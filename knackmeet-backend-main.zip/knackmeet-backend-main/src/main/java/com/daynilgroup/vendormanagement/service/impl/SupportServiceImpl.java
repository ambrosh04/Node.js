package com.daynilgroup.vendormanagement.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;

import com.daynilgroup.vendormanagement.entity.Support;
import com.daynilgroup.vendormanagement.repository.SupportRepository;
import com.daynilgroup.vendormanagement.service.SupportService;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;

@Service
@FieldDefaults(level = AccessLevel.PRIVATE)
public class SupportServiceImpl implements SupportService {

	@Autowired
	SupportRepository supportRepository;

	@Override
	public JpaRepository<Support, Long> getJpaRepository() {

		return supportRepository;
	}

}
