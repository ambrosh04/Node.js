package com.daynilgroup.vendormanagement.model.request;

import java.io.Serializable;

import com.daynilgroup.vendormanagement.constants.CodeLookUpRelationTypeEnum;
import com.daynilgroup.vendormanagement.constants.RefTypeEnum;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

@Data
@FieldDefaults(level = AccessLevel.PRIVATE)	
@AllArgsConstructor
@NoArgsConstructor
public class CodelookupRelationListRequest implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	Long refId;
	
	RefTypeEnum refType;

	CodeLookUpRelationTypeEnum type;

}
