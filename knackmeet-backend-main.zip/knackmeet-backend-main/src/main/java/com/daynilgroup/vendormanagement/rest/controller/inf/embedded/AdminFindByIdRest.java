package com.daynilgroup.vendormanagement.rest.controller.inf.embedded;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.daynilgroup.vendormanagement.constants.UrlConstants;
import com.daynilgroup.vendormanagement.rest.exception.DataNotFoundRestException;

/**
 *
 * @author Manish
 */
public interface AdminFindByIdRest extends AbstractInf {


	@GetMapping(path = UrlConstants.API_FIND_BY_ID)
	default ResponseEntity<Object> findById(@PathVariable Long id) {
		try {
			@SuppressWarnings("unchecked")
			Object response = getHelper().getDetailForAdminResponse(getService().findById(id));
			return new ResponseEntity<>(response, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<>(new DataNotFoundRestException(e.getMessage()),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

}
