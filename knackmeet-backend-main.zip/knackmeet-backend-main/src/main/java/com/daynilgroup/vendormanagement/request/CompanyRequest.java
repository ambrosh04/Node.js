package com.daynilgroup.vendormanagement.request;

import com.daynilgroup.vendormanagement.request.inf.RequestInf;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

@Data
@AllArgsConstructor
@NoArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class CompanyRequest implements RequestInf {

	static final long serialVersionUID = 1L;

	Long id;
	String name;
	String logoPath;
	String website;
	String base64String;
	Long vendorId;

}
