package com.daynilgroup.vendormanagement.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.daynilgroup.vendormanagement.entity.Media;


/**
 *
 * @author Manish
 */
public interface MediaRepository extends JpaRepository<Media, Long> {

    
    @Modifying
    @Transactional
    @Query(value = "Delete from media where path =:path", nativeQuery = true)
    void deleteMedia(@Param("path") String path);
    
    @Query("Select CASE WHEN count(m.id)> 0 THEN true ELSE false END FROM Media m where m.path=:path")
    Boolean isExist(@Param("path") String path);
}
