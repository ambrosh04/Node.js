package com.daynilgroup.vendormanagement.model.response;

import java.time.LocalDateTime;

import com.daynilgroup.vendormanagement.constants.StatusEnum;
import com.daynilgroup.vendormanagement.model.inf.ListResponse;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.experimental.FieldDefaults;

@Data
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
@AllArgsConstructor
public class VendorListResponse implements ListResponse {

	static final long serialVersionUID = 1L;

	Long id;

	String agencyName;

	String website;

	LocalDateTime incorparationDate;

	Long teamStrength;

	StatusEnum status;

	Boolean active;

	Long user;

	String gstNumber;

	String location;

	String directorName;
	
	String firstName;
	
	String lastName;
	
	String emailId;
	
	String mobile;
	
	LocalDateTime createdOn;
	
	String companyPrimaryNumber;

	String companyPrimaryEmail;

	String companyDescription;
	
	String userCountryCode;

}
