package com.daynilgroup.vendormanagement.repository;

import java.util.Set;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import com.daynilgroup.vendormanagement.entity.Address;

public interface AddressRepository extends JpaRepository<Address, Long> {

	Page<Address> findAllByDeletedFalse(Pageable pageable);

	Set<Address> findAllByDeletedFalse();

	Address findByCountryIdAndStateId(Long countryId, Long stateId);
}
