package com.daynilgroup.vendormanagement.model.response;

import com.daynilgroup.vendormanagement.constants.UserType;

import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class UserListResPonse {
	Long id;

	String firstName;

	String lastName;

	String emailId;

	String mobile;

	UserType userType;
}
