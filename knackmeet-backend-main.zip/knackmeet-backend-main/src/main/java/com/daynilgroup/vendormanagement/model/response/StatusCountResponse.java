package com.daynilgroup.vendormanagement.model.response;

import lombok.AccessLevel;
import lombok.Builder;
import lombok.Data;
import lombok.experimental.FieldDefaults;

@Builder
@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
public class StatusCountResponse {
	Long all;
	Long verified;
	Long notVerified;
	Long onHold;
	Long rejected;
	Long closed;

}
