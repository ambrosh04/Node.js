package com.daynilgroup.vendormanagement.util.inf;

import org.springframework.stereotype.Component;

/**
 * @author Manish
 *
 */

@Component
public interface CriteriaHelper {


}
