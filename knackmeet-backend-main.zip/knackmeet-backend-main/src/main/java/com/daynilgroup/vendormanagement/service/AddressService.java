package com.daynilgroup.vendormanagement.service;

import java.util.Set;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.daynilgroup.vendormanagement.entity.Address;
import com.daynilgroup.vendormanagement.model.response.DropdownResponse;

public interface AddressService extends AbstractService<Address> {

	Page<Address> findAll(Pageable pageable);

	Address findByCountryIdAndStateId(Long countryId, Long stateId);

	Set<DropdownResponse> getAddressDropdown();
	
	Set<DropdownResponse> getCountryAndStateDropdown();
}
