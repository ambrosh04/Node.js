package com.daynilgroup.vendormanagement.helper;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

import com.daynilgroup.vendormanagement.entity.CodeLookup;
import com.daynilgroup.vendormanagement.entity.SubscribedUsers;
import com.daynilgroup.vendormanagement.model.request.SubscribedUsersRequest;
import com.daynilgroup.vendormanagement.model.response.SubscribedUsersListResponse;
import com.daynilgroup.vendormanagement.model.response.SubscribedUsersResponse;
import com.daynilgroup.vendormanagement.service.CodeLookupService;
import com.daynilgroup.vendormanagement.service.SubscribedUsersService;
import com.daynilgroup.vendormanagement.util.CommonUtil;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;

@Component
@Lazy
@FieldDefaults(level = AccessLevel.PRIVATE)
public class SubscribedUsersHelper extends
		AbstractHelper<SubscribedUsers, SubscribedUsersRequest, SubscribedUsersListResponse, SubscribedUsersListResponse, SubscribedUsersResponse> {

	@Autowired
	SubscribedUsersService subscribedUsersService;
	@Autowired
	CodeLookupService codeLookupService;

	@Override
	@Transactional
	public SubscribedUsers getEntity(SubscribedUsersRequest request) throws Exception {
		SubscribedUsers subscribedUsers;
		if (CommonUtil.isValid(request.getId())) {
			subscribedUsers = subscribedUsersService.findById(request.getId());

		} else {
			subscribedUsers = new SubscribedUsers();
			subscribedUsers.setName(request.getName());
			subscribedUsers.setEmailId(request.getEmailId());
			subscribedUsers.setMobileNumber(request.getMobileNumber());
			subscribedUsers.setAgencyName(request.getAgencyName());
			subscribedUsers.setCountryCode(request.getCountryCode() != null
					? CommonUtil.getEntityReferenceWithId(request.getCountryCode(), codeLookupService, CodeLookup.class)
					: null);

		}

		return subscribedUsers;
	}

	@Override
	public List<SubscribedUsersListResponse> getListResponse(List<SubscribedUsers> entityList) {
		List<SubscribedUsersListResponse> subscribedUsersListResponses = new ArrayList<>();

		entityList.forEach(subscribedUsers -> {
			SubscribedUsersListResponse subscribedUsersListResponse = SubscribedUsersListResponse.builder()
					.id(subscribedUsers.getId()).name(subscribedUsers.getName()).emailId(subscribedUsers.getEmailId())
					.mobileNumber(subscribedUsers.getMobileNumber()).agencyName(subscribedUsers.getAgencyName())
					.countryCode(subscribedUsers.getCountryCode() != null ? subscribedUsers.getCountryCode().getName()
							: null)
					.build();

			subscribedUsersListResponses.add(subscribedUsersListResponse);
		});

		return subscribedUsersListResponses;
	}

	@Override
	public SubscribedUsersListResponse getDetailResponse(SubscribedUsers entity) {
		return null;
	}

	@Override
	public SubscribedUsersResponse getDetailForAdminResponse(SubscribedUsers entity) {
		return null;
	}

}
