/**
 * 
 */
package com.daynilgroup.vendormanagement.entity;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.ColumnDefault;

import com.daynilgroup.vendormanagement.constants.CurrencyTypeEnum;
import com.daynilgroup.vendormanagement.constants.DeploymentTypeEnum;
import com.daynilgroup.vendormanagement.constants.JobCloseReason;
import com.daynilgroup.vendormanagement.constants.RateTypeEnum;
import com.daynilgroup.vendormanagement.constants.TimeZoneEnum;
import com.daynilgroup.vendormanagement.model.inf.DateUtil;
import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

/**
 * @author Prerana
 *
 */
@Getter
@Setter
@Entity
@Table(name = "job")
@FieldDefaults(level = AccessLevel.PRIVATE)
public class Job extends BaseEntity {

	static final long serialVersionUID = 1L;

	@Column(name = "title", nullable = false)
	String title;

	@Column(name = "job_no")
	String jobNo;

	@JoinColumn(name = "address_id")
	@ManyToOne(fetch = FetchType.EAGER, targetEntity = Address.class)
	Address address;

	@OneToMany(mappedBy = "job", cascade = CascadeType.ALL,fetch = FetchType.EAGER)
	List<SkillsCodeLookup> skillsCodeLookup;

	@Column(name = "no_of_resources", nullable = false)
	Integer noOfResources;

	@Column(name = "start_date")
	LocalDateTime startDate;

	@Enumerated(EnumType.STRING)
	@Column(name = "work_from", nullable = false)
	DeploymentTypeEnum workFrom;

	@Column(name = "min_experience", nullable = false)
	Integer minExperience;

	@Column(name = "max_experience", nullable = false)
	Integer maxExperience;

	@JoinColumn(name = "duration_id", referencedColumnName = "id", nullable = false)
	@ManyToOne(fetch = FetchType.LAZY)
	CodeLookup duration;

	@Enumerated(EnumType.STRING)
	@Column(name = "currency_type")
	CurrencyTypeEnum currencyType;

	@Enumerated(EnumType.STRING)
	@Column(name = "rate_type", nullable = false)
	RateTypeEnum rateTypeEnum;

	@Column(name = "min_rate", nullable = false)
	BigDecimal minRate;

	@Column(name = "max_rate", nullable = false)
	BigDecimal maxRate;

	@Column(name = "description", nullable = false)
	@Lob
	String description;

	@JoinColumn(name = "vendor_id", referencedColumnName = "id", nullable = false)
	@ManyToOne(fetch = FetchType.LAZY)
	Vendor vendor;

	@Column(name = "applicants_count", nullable = false)
	@ColumnDefault("0")
	Integer applicantsCount = 0;

	@Column(name = "reason")
	@Lob
	String reason;
	
	@Column(name = "closed_date")
	LocalDateTime closedDate;
	
	@Column(name="location")
	String location;
	
	@Column(name="latitude")
	BigDecimal latitude;
	
	@Column(name="longitude")
	BigDecimal longitude;
	
	@JoinColumn(name = "country_id", referencedColumnName = "id")
	@ManyToOne(fetch = FetchType.EAGER)
	CodeLookup country;
	
	@OneToMany(mappedBy = "refId", cascade = CascadeType.ALL,fetch = FetchType.LAZY)
	List<CodeLookUpRelation> codeLookUpRelation;

	public LocalDateTime getStartDate() {
		return DateUtil.getUTCToUserTimezone(startDate);
	}
	
	public LocalDateTime getClosedDate() {
		return DateUtil.getUTCToUserTimezone(closedDate);
	}

	@JoinColumn(name = "category_id", referencedColumnName = "id")
	@ManyToOne(fetch = FetchType.EAGER)
	CodeLookup category;

	@Enumerated(EnumType.STRING)
	@Column(name = "close_reason")
	JobCloseReason closeReason;

	@Enumerated(EnumType.STRING)
	@Column(name = "time_zone")
	TimeZoneEnum timeZoneEnum;
	
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "HH:mm")
	@Column(name="start_time")
	LocalTime startTime;
	
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "HH:mm")
	@Column(name="end_time")
	LocalTime endTime;
}
