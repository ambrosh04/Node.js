package com.daynilgroup.vendormanagement.model.response;

import java.io.Serializable;
import java.util.List;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class ResourceSkillsResponse implements Serializable{
	
	static final long serialVersionUID = 1L;

	Long resourceId;
	
	List<AdvanceSearchDropdownModel> advanceSearchDropdownModels;
}
