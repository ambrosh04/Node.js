package com.daynilgroup.vendormanagement.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.daynilgroup.vendormanagement.entity.Company;

@Repository
public interface CompanyRepository extends JpaRepository<Company, Long> {

	@Query("SELECT c FROM Company c where (:companyName IS NULL OR c.name LIKE (%:companyName%) OR c.website LIKE (%:companyName%)) and c.media.id IS NOT NULL")
	List<Company> findAllByName(String companyName);

	Company findByWebsite(String website);

	@Query("SELECT c FROM Company c WHERE c.name =:name")
	List<Company> getListByName(String name);

	Company findByVendorId(Long vendorId);
}
