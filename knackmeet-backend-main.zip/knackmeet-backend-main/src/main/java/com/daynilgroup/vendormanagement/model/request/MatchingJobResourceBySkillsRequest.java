package com.daynilgroup.vendormanagement.model.request;

import java.util.List;

import com.daynilgroup.vendormanagement.constants.JobResourceEnum;
import com.daynilgroup.vendormanagement.model.pag.PaginationRequestModel;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class MatchingJobResourceBySkillsRequest {
	Long id;

	JobResourceEnum jobResourceEnum;

	List<String> skills;

	PaginationRequestModel paginationRequestModel;
}
