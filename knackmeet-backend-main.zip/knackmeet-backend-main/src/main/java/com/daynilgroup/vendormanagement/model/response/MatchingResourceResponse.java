/**
 * 
 */
package com.daynilgroup.vendormanagement.model.response;

import java.io.Serializable;
import java.util.List;

import com.daynilgroup.vendormanagement.constants.DeploymentTypeEnum;
import com.daynilgroup.vendormanagement.constants.Gender;
import com.daynilgroup.vendormanagement.constants.ResourceStatusEnum;
import com.daynilgroup.vendormanagement.constants.StatusEnum;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

/**
 * @author Manish
 *
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class MatchingResourceResponse implements Serializable {

	static final long serialVersionUID = 1L;

	Long resourceId;

	String resourceName;

	String designation;

	ResourceStatusEnum status;

	String availabilityType;
	
	String agencyName;
	
	Long userId;

	String base64MediaString;

	List<String> skills;

	String rate;

	String experience;

	String state;

	String country;

	String gender;

	Boolean active;

	String higherEducation;

	Long passingYear;

	StatusEnum statusEnum;

	Integer appliedJobCount;

	String deploymentType;
	
	String usdRate;
	
	String location;
}
