package com.daynilgroup.vendormanagement.model.response;

import com.daynilgroup.vendormanagement.model.inf.ListResponse;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.experimental.FieldDefaults;

@Data
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
@AllArgsConstructor
public class CompanyListResponse implements ListResponse {

	static final long serialVersionUID = 1L;

	Long id;
	String name;
	String logoPath;
	String website;

}
