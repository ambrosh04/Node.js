package com.daynilgroup.vendormanagement.util;

import java.io.UnsupportedEncodingException;
import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.Charset;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.reflect.FieldUtils;
import org.apache.commons.lang3.text.WordUtils;
import org.apache.tomcat.util.json.JSONParser;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.amazonaws.util.Base64;
import com.daynilgroup.vendormanagement.constants.Constants;
import com.daynilgroup.vendormanagement.constants.ResourceStatusEnum;
import com.daynilgroup.vendormanagement.constants.RoleTypeEnum;
import com.daynilgroup.vendormanagement.constants.TimeZoneEnum;
import com.daynilgroup.vendormanagement.constants.UserType;
import com.daynilgroup.vendormanagement.entity.BaseEntity;
import com.daynilgroup.vendormanagement.entity.Role;
import com.daynilgroup.vendormanagement.model.inf.DateUtil;
import com.daynilgroup.vendormanagement.security.CustomUserDetail;
import com.daynilgroup.vendormanagement.service.AbstractService;
import com.google.gson.Gson;

import lombok.extern.slf4j.Slf4j;

/**
 *
 * @author prerana
 */
@Slf4j
@Component
public class CommonUtil {

	public static final List<String> EMPTY_LIST_STRING = new ArrayList<>();

	public static String convertStringToVariableName(String str) {
		str = str.replaceAll("[^a-zA-Z0-9]", "");
		StringBuilder builder = new StringBuilder(str);
		builder.setCharAt(0, Character.toLowerCase(builder.charAt(0)));
		return builder.toString();
	}

	public static boolean hasUppercaseLetters(String str) {
		for (int i = 0; i < str.length(); i++) {
			if (Character.isUpperCase(str.charAt(i))) {
				return true;
			}
		}
		return false;
	}

	public static boolean isEmpty(String str) {
		return !StringUtils.hasText(str);
	}

	public static boolean isEmpty(Collection<?> collection) {
		return CollectionUtils.isEmpty(collection);
	}

	public static boolean isValid(Long value) {
		return value != null && value > 0;
	}

	public static boolean isValid(Integer value) {
		return value != null && value > 0;
	}

	public static Field getField(Class target, Class<? extends Annotation> annotaion, Class fieldType) {
		Field statusField = null;
		List<Field> fields = FieldUtils.getFieldsListWithAnnotation(target, annotaion);
		if (!CollectionUtils.isEmpty(fields)) {
			for (Field field : fields) {
				if (field.getType().equals(fieldType)) {
					statusField = field;
					break;
				}
			}
		}
		return statusField;
	}

	public static boolean isValidGSTNo(String str) {
		String regex = "^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$";
		Pattern gstPattern = Pattern.compile(regex);
		Matcher matcher = gstPattern.matcher(str);
		return matcher.matches();
	}

	public static Long getUserIdFromSession() throws Exception {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		if (authentication != null && authentication.isAuthenticated()) {
			CustomUserDetail customUserDetail = (CustomUserDetail) authentication.getPrincipal();
			return customUserDetail.getId();
		} else {
			throw new Exception("Authentication Not Found!");
		}
	}

//	public static LocaleEnum getLocaleEnum() {
//		LocaleEnum locale = Constants.DEFAULT_LOCALE;
//		try {
//			Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
//			if (principal instanceof CustomUserDetail) {
//				CustomUserDetail customUserDetail = (CustomUserDetail) principal;
//				locale = customUserDetail.getLocale();
//			}
//		} catch (Exception e) {
//			log.error(e.getMessage());
//		}
//		return locale;
//	}
//
//	public static LocaleEnum getLocaleForCloud() {
//		return Constants.DEFAULT_LOCALE;
//	}

	public static String getRateStr(String currencyType, BigDecimal rate, String rateType) {
		if(!isValid(rate)) {
			return null;
		}
		currencyType = currencyType == "INR" ? "₹ " : "$ ";

		String finalRate = currencyType +(rate != null ? rate.intValue():null) + "(" + rateType + ")";
		return finalRate;

	}

	public static String getRateString(String currencyType, BigDecimal rate, String rateType) {
		if(!isValid(rate)) {
			return null;
		}
		currencyType = currencyType == "INR" ? "₹ " : "$ ";

		String finalRate = currencyType + (rate != null ? rate.intValue():null) + "(" + rateType + ")";
		return finalRate;

	}
	
	public static String getExperience(Integer year, Integer months) {
		String experience = "";
		String yearsExperience = year != null && year !=0 ? year.toString() + " years " : "";
		String monthsExperience = months != null && months !=0 ? months.toString() + " months " : "";

		if (!yearsExperience.isEmpty()) {
			experience = yearsExperience;
		}
		if (!monthsExperience.isEmpty()) {
			experience = experience + monthsExperience;
		}
		return experience;
	}

	public static String removeHtmlTags(String text) {
		return text.replaceAll("(?s)<[^>]*>(\\s*<[^>]*>)*", " ");
	}

	public static Map<String, Object> isAvailable(Boolean exists, String errorMessage) {
		Map<String, Object> map = new HashMap<>();
		map.put(Constants.AVAILABLE, !exists);
		if (exists) {
			map.put(Constants.MESSAGE, errorMessage);
		}
		return map;
	}

	public static Map<String, Object> isExist(Boolean exists, String errorMessage) {
		Map<String, Object> map = new HashMap<>();
		map.put(Constants.EXISTS, exists);
		if (!exists) {
			map.put(Constants.MESSAGE, errorMessage);
		}
		return map;
	}

	/**
	 * This method will check if the id is present in database; If present, return a
	 * Entity object with id for reference purpose, else throws Exception.
	 *
	 * @param <T>
	 * @param id
	 * @param service
	 * @param entityClass
	 * @return
	 * @throws Exception
	 */
	public static <T extends BaseEntity> T getEntityReferenceWithId(Long id, AbstractService service,
			Class<T> entityClass) throws Exception {
		if (isValid(id)) {
			boolean exists = service.existsById(id);
			if (exists) {
				T object = entityClass.newInstance();
				((BaseEntity) object).setId(id);
				return object;
			} else {
				throw new Exception(entityClass.getSimpleName() + " Entity Not Found With Id '" + id + "'");
			}
		} else {
			return null;
		}
	}

	/**
	 * This method will check if the id is present in database; If present, return a
	 * Entity object with id for reference purpose, else throws Exception. In case
	 * of invalid id also throws Exception.
	 *
	 * @param <T>
	 * @param id
	 * @param service
	 * @param entityClass
	 * @return
	 * @throws Exception
	 */
	public <T extends BaseEntity> T getEntityReferenceWithId(Long id, AbstractService service, Class<T> entityClass,
			boolean required) throws Exception {
		T entity = getEntityReferenceWithId(id, service, entityClass);
		if (entity == null) {
			throw new Exception(entityClass.getSimpleName() + " Entity Id Should Not Be Null!");
		}
		return entity;
	}

	public static boolean isStringEmpty(Object object) {
		try {
			boolean isEmpty = false;
			if (object == null || ((String) object).trim().length() == 0) {
				isEmpty = true;
			}
			return isEmpty;
		} catch (NullPointerException e) {
			// TODO: handle exception
			return true;
		}
	}

	public static boolean isTrue(Boolean value) {
		return value != null && value;
	}

	public static boolean isValid(BigDecimal value) {
		return value != null && value.intValue() > 0;
	}

	public static boolean isValid(Double value) {
		return value != null && value > 0;
	}

	public static boolean isListEmpty(List<?> list) {
		boolean isEmpty = false;
		if (list == null || list.isEmpty()) {
			isEmpty = true;
		}
		return isEmpty;
	}

	/**
	 * URL encode String
	 *
	 * @param String url
	 * @return encoded string
	 * @throws UnsupportedEncodingException
	 */
	public static String encodeUrl(String url) {
		try {
			return URLEncoder.encode(url, Charset.defaultCharset().toString());
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		return url;
	}

	/**
	 * URL decode String
	 *
	 * @param String encodedUrl
	 * @return decoded string
	 * @throws UnsupportedEncodingException
	 */
	public static String decodeUrl(String encodedUrl) {
		try {
			return URLDecoder.decode(encodedUrl, Charset.defaultCharset().toString());
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		return encodedUrl;
	}

	public static Boolean getIsDateExpired(Date validUptoDate2) {
		Date currentDate = new Date();
		long diff = DateUtil.diff(currentDate, validUptoDate2);
		if (diff > 0) {
			return Boolean.TRUE;
		}
		return Boolean.FALSE;
	}

	public static String getEnvVariableByName(String name) {
		Map<String, String> env = System.getenv();
		String envName = env.get(name);
		return envName;
	}

	public static String generateRandomPassword() {
		// ASCII range - alphanumeric (0-9, a-z, A-Z)
		final String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
		SecureRandom random = new SecureRandom();
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < 6; i++) {
			int randomIndex = random.nextInt(chars.length());
			sb.append(chars.charAt(randomIndex));
		}
		return sb.toString();
	}

	public static Long getCurrentUserId() {
		try {
			CustomUserDetail customUserDetail = (CustomUserDetail) SecurityContextHolder.getContext()
					.getAuthentication().getPrincipal();
			return customUserDetail.getId();
		} catch (Exception e) {
//			e.printStackTrace();
			return EntityUtil.getAnonymousUserID();
		}
	}
	
	public static TimeZoneEnum getCurrentUserTimeZone() {
		try {
			CustomUserDetail customUserDetail = (CustomUserDetail) SecurityContextHolder.getContext()
					.getAuthentication().getPrincipal();
			return customUserDetail.getTimeZone();
		} catch (Exception e) {
			return null;
		}
	}

	public static Object convertStringToJsonObject(Object string) {
		try {
			if (string instanceof String && !isStringEmpty(string) && !"null".equals(string)) {
				JSONParser parser = new JSONParser(string.toString());
				return parser.parse();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public static BigDecimal getAmount(Double percentage, BigDecimal amount) {
		BigDecimal percentageAmount = new BigDecimal(percentage);
		percentageAmount = percentageAmount.divide(new BigDecimal(100));
		return amount.multiply(percentageAmount);

	}

	public static String convertByteArrayToBase64(byte[] byteArray) throws UnsupportedEncodingException {
		if (byteArray == null) {
			return "";
		}
		return new String(Base64.encode(byteArray), "UTF-8");
	}

	public static String formatAmount(BigDecimal amount) {
		if (amount != null) {
			return rupeeFormat(String.valueOf(amount.doubleValue()));
		}
		return "";
	}

	public static String rupeeFormat(String value) {
		value = value.replace(",", "");
		String fractionValue = "";
		if (value.indexOf(".") > 0) {
			fractionValue = value.substring(value.indexOf(".") + 1);
//			Long fractionIntValue = Long.parseLong(fractionValue);
			BigDecimal fractionIntValue = new BigDecimal(fractionValue);
			if (BigDecimal.ZERO.equals(fractionIntValue)) {
				fractionValue = "";
			}
			value = value.substring(0, value.indexOf("."));
		}
		char lastDigit = value.charAt(value.length() - 1);
		String result = "";
		int len = value.length() - 1;
		int nDigits = 0;

		for (int i = len - 1; i >= 0; i--) {
			result = value.charAt(i) + result;
			nDigits++;
			if (((nDigits % 2) == 0) && (i > 0)) {
				result = "," + result;
			}
		}
		if (!fractionValue.isEmpty()) {
			String output = result + lastDigit + "." + fractionValue;
			return output;
		}
		return (result + lastDigit);
	}

	@SuppressWarnings("rawtypes")
	public static List<String> getCapitalizeFullyList(Enum... enums) {
		List<String> list = new ArrayList<>();
		for (Enum enumString : enums) {
			list.add(getCapitalizeFully(enumString.toString()));
		}
		return list;
	}

	public static String getCapitalizeFully(String string) {
		return WordUtils.capitalizeFully(string.replace("_", " "));
	}

	public static String generateRandomDigit(Integer digit) {
		String no = "4";
		if (null != digit) {
			no = digit.toString();
		}
		return String.format("%0" + no + "d", new Random().nextInt(10000));
	}

	private static Double deg2rad(Double deg) {
		return (deg * Math.PI / 180.0);
	}

	private static Double rad2deg(Double rad) {
		return (rad * 180.0 / Math.PI);
	}

	public static String convertObjToJsonString(Object obj) {
		return new Gson().toJson(obj);
	}

	public static Object convertJsonToObject(String json, Class<?> clazz) {
		Gson gson = new Gson();
		return gson.fromJson(json, clazz);
	}

	public static List<String> longToString(List<Long> longs) {
		if (!isListEmpty(longs)) {
			return longs.stream().map(Object::toString).collect(Collectors.toList());
		}
		return null;
	}

	public static String getStaticFieldName(String displayNameStartsWith, String name) {
		if (isEmpty(displayNameStartsWith)) {
			return name;
		}
		return displayNameStartsWith + " " + name;
	}

	public static Object cast(String classSimpleName, Object value, Boolean isDisplay) {
		if (null == value) {
			return null;
		} else if (Long.class.getSimpleName().equals(classSimpleName)) {
			return Long.parseLong(value.toString());
		} else if (String.class.getSimpleName().equals(classSimpleName)) {
			return value.toString();
		} else if (Integer.class.getSimpleName().equals(classSimpleName)) {
			return Integer.parseInt(value.toString());
		} else if (Double.class.getSimpleName().equals(classSimpleName)) {
			return Double.parseDouble(value.toString());
		} else if (Boolean.class.getSimpleName().equals(classSimpleName)) {
			return Boolean.parseBoolean(value.toString());
		} else if (Date.class.getSimpleName().equals(classSimpleName)) {
			if (isDisplay) {
				return DateUtil.getDefaultDateTime((Date) value);
			}
			return (Date) value;
		}
		return value;
	}

	public static List<String> convertStringArrayToList(String[] strings) {
		List<String> list = new ArrayList<>();
		for (String string : strings) {
			list.add(string);
		}
		return list;
	}

	public static boolean isEmpty(Object string) {
		return ObjectUtils.isEmpty(string);
	}

	public static UserType getLoggedInUserType() {
		CustomUserDetail customUserDetail = (CustomUserDetail) SecurityContextHolder.getContext().getAuthentication()
				.getPrincipal();
		return customUserDetail.getUserType();
	}

	public static Long getLoggedInUserOrgId() {
		CustomUserDetail customUserDetail = (CustomUserDetail) SecurityContextHolder.getContext().getAuthentication()
				.getPrincipal();
		return customUserDetail.getOrgId();
	}

	public static Boolean getRoleAcess(Role role) {
		Boolean roleAcess = Boolean.FALSE;
		if (RoleTypeEnum.MASTER_ADMIN.equals(role.getType()) || RoleTypeEnum.MASTER_VENDOR.equals(role.getType())) {
			roleAcess = Boolean.TRUE;
		}
		return roleAcess;
	}

	public static Long getCountOrZero(Long count) {
		if (!CommonUtil.isValid(count)) {
			return 0L;
		}
		return count;
	}
	
	public static String getAlphaNumericString() {
		int n=12;
		String alphaNumericString = "ABCDEFGHIJKLMNOPQRSTUVWXYZ" + "0123456789" + "abcdefghijklmnopqrstuvxyz";

		StringBuilder sb = new StringBuilder(n);

		for (int i = 0; i < n; i++) {

			int index = (int) (alphaNumericString.length() * Math.random());

			sb.append(alphaNumericString.charAt(index));
		}

		return sb.toString().toUpperCase();
	}
	
	public static String getFolderStructure(Long vendorId,String fileType)
	{
		return vendorId+"/"+fileType;
	}

	public static String getFolderStructureForResource(Long vendorId,String resourceType,Long resourceId,String fileType)
	{
		return vendorId+"/"+resourceType+"/"+resourceId+"/"+fileType;
	}
	
	public static String getCommonBenchUrl(Long id, ResourceStatusEnum resourceStatusEnum) {
		return Constants.BENCH_URL + "?" + "resourceId" + "=" + id + "&" + "status" + "=" + resourceStatusEnum;
	}

	public static String getCommonAppliedJobUrl(Long id) {
		return Constants.JOB_APPLIED_URL + "?" + "jobId" + id + "=" + "&" + "status" + ResourceStatusEnum.APPLIED;
	}

	public static String getCommonWithdrawJobUrl(Long id) {
		return Constants.JOB_WITHDRAW_URL + "?" + "jobId" + "=" + id;
	}

	public static BigDecimal resourceRateWithCommission(BigDecimal rate, String percentage) {
		BigDecimal percentageValue = new BigDecimal(percentage).divide(new BigDecimal(100));

		BigDecimal value = rate.add(rate.multiply(percentageValue));
		BigDecimal roundedValue = value.setScale(0, RoundingMode.HALF_UP);
		if (value.subtract(roundedValue).abs().compareTo(new BigDecimal("0.5")) == 0) {
			roundedValue = roundedValue.subtract(BigDecimal.ONE);

		}

		return roundedValue;
	}

}
