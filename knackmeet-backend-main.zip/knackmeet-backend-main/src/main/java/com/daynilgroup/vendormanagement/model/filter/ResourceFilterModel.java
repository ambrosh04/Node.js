package com.daynilgroup.vendormanagement.model.filter;

import java.util.Date;

import com.daynilgroup.vendormanagement.constants.CurrencyTypeEnum;
import com.daynilgroup.vendormanagement.constants.ResourceStatusEnum;
import com.daynilgroup.vendormanagement.model.pag.PaginationRequestModel;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class ResourceFilterModel {

	Long jobId;

	ResourceStatusEnum resourceStatusEnum;

	String name;

	String startDate;

	String endDate;
	
	PaginationRequestModel paginationRequestModel;
	
	CurrencyTypeEnum currencyType;
}
