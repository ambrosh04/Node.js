/**
 * 
 */
package com.daynilgroup.vendormanagement.helper;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.lang3.ObjectUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.daynilgroup.vendormanagement.constants.Constants;
import com.daynilgroup.vendormanagement.constants.RoleTypeEnum;
import com.daynilgroup.vendormanagement.constants.UserType;
import com.daynilgroup.vendormanagement.entity.CodeLookup;
import com.daynilgroup.vendormanagement.entity.Role;
import com.daynilgroup.vendormanagement.entity.User;
import com.daynilgroup.vendormanagement.entity.UserRole;
import com.daynilgroup.vendormanagement.entity.Vendor;
import com.daynilgroup.vendormanagement.model.request.UserRequest;
import com.daynilgroup.vendormanagement.model.request.VendorRequest;
import com.daynilgroup.vendormanagement.model.response.UserListResPonse;
import com.daynilgroup.vendormanagement.model.response.UserResponse;
import com.daynilgroup.vendormanagement.model.response.UserResponseModel;
import com.daynilgroup.vendormanagement.service.CodeLookupService;
import com.daynilgroup.vendormanagement.service.RoleService;
import com.daynilgroup.vendormanagement.service.VendorService;
import com.daynilgroup.vendormanagement.util.CommonUtil;
import com.daynilgroup.vendormanagement.util.FileUpload;
import com.daynilgroup.vendormanagement.util.PaginationUtil;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;

/**
 * @author Prerana
 *
 */
@Component
@FieldDefaults(level = AccessLevel.PRIVATE)
public class UserHelper extends AbstractHelper<User, UserRequest, UserListResPonse, Object, UserResponse> {

	@Autowired
	VendorService vendorService;

	@Autowired
	PasswordEncoder bcryptPasswordEncoder;

	@Autowired
	RoleService roleService;

	@Autowired
	FileUpload fileUpload;

	@Autowired
	CodeLookupService codeLookupService;

	@Override
	public User getEntity(UserRequest request) throws Exception {
		return null;
	}

	@Transactional
	public void populateEntity(User user, VendorRequest request, UserType userType) throws Exception {
		if (!request.isUpdate()) {
			validateAndSetPassowrd(user, request.getPassword());
			user.setEmailId(request.getEmailId());
		}
		if(request.getIsVendorAdmin())
		{
			user.setEmailId(request.getEmailId());
		}
		user.setFirstName(request.getFirstName());
		user.setLastName(request.getLastName());
		user.setMobile(request.getMobile());
		user.setTimeZone(request.getTimeZone());
		if (CommonUtil.isValid(request.getPhoneCodeId())) {
			CodeLookup phoneCode = codeLookupService.findById(request.getPhoneCodeId());
			user.setPhoneCode(phoneCode);
		}

		List<UserRole> userRoles = setUserRoles(request, user);
		if (!CollectionUtils.isEmpty(userRoles)) {
			user.setUserRoles(userRoles);
		}
		user.setUserType(userType);
	}

	private List<UserRole> setUserRoles(VendorRequest request, User user) {
		List<UserRole> userRoles = new ArrayList<>();
		if (Boolean.TRUE.equals(request.getIsVendorAdmin())) {
			Role role = roleService.findByType(RoleTypeEnum.MASTER_VENDOR);
			if (!ObjectUtils.isEmpty(role)) {
				UserRole userRole = new UserRole();
				userRole.setRole(role);
				userRole.setUser(user);
				userRoles.add(userRole);
			}
		}
		return userRoles;
	}

	private void validateAndSetPassowrd(User user, String password) {
		if (user.getId() == null && StringUtils.hasText(password)) {
			user.setPassword(bcryptPasswordEncoder.encode(password));
		}
	}

	public UserResponseModel getUserResponseModel(User user) {
		List<RoleTypeEnum> roleTypes = new ArrayList<>();
		Vendor vendor = vendorService.findByUserId(user.getId());
		Long id, userId = user.getId();

		switch (user.getUserType()) {
		case VENDOR:
			id = vendor.getId();
			break;
		case ADMIN:
			id = user.getId();
		default:
			id = user.getId();
			break;
		}

		return UserResponseModel.builder().status(vendor != null ? vendor.getStatusEnum() : user.getStatusEnum())
				.emailId(user.getEmailId()).id(id).userId(userId).message(Constants.LOGIN_SUCCESS)
				.firstName(user.getFirstName()).lastName(user.getLastName())
				.active(vendor != null ? vendor.getActive() : user.getActive()).userType(user.getUserType())
				.agencyName(vendor != null ? vendor.getAgencyName() : null)
				.agencyLogo(vendor != null && vendor.getVendorLogo() != null ? vendor.getVendorLogo().getPath() : null)
                .pageSize(user.getPageSize()!=null?user.getPageSize():PaginationUtil.DEFAULT_PAGE_SIZE)
				.base64AgencyLogo(vendor != null && vendor.getVendorLogo() != null
						? fileUpload.generatePresignedURL(vendor.getVendorLogo().getPath())
						: null)
				.vendorPhoneCode(vendor.getCountryCode().getName())
				.build();
	}

	@Override
	public List<UserListResPonse> getListResponse(List<User> users) {
		return users.stream()
				.map(det -> UserListResPonse.builder().id(det.getId()).firstName(det.getFirstName())
						.lastName(det.getLastName()).emailId(det.getEmailId()).mobile(det.getMobile())
						.userType(det.getUserType()).build())
				.collect(Collectors.toList());

	}

	@Override
	public Object getDetailResponse(User entity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public UserResponse getDetailForAdminResponse(User entity) {
		// TODO Auto-generated method stub
		return null;
	}

}
