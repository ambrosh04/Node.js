package com.daynilgroup.vendormanagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.daynilgroup.vendormanagement.entity.Support;

public interface SupportRepository extends JpaRepository<Support, Long> {

}
