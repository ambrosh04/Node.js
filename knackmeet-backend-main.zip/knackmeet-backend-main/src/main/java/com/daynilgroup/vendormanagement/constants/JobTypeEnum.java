/**
 * 
 */
package com.daynilgroup.vendormanagement.constants;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.experimental.FieldDefaults;

/**
 * @author Prerana
 *
 */
@Getter
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public enum JobTypeEnum {

	CONTRACT("Contract"), FREELANCE_OR_PART_TIME("Freelance/Part-Time"), FULL_TIME("Full-Time");
	
	String displayName;
}
