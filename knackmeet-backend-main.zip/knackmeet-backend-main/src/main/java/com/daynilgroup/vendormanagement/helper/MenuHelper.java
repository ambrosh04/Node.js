package com.daynilgroup.vendormanagement.helper;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.daynilgroup.vendormanagement.entity.Menu;
import com.daynilgroup.vendormanagement.model.request.CreateMenuRequest;
import com.daynilgroup.vendormanagement.model.response.MenuDetailAdminResponse;
import com.daynilgroup.vendormanagement.model.response.MenuDetailResponse;
import com.daynilgroup.vendormanagement.model.response.MenuListResponse;
import com.daynilgroup.vendormanagement.service.MenuService;
import com.daynilgroup.vendormanagement.util.CommonUtil;

/**
 *
 * @author Manish
 */
@Component
public class MenuHelper
		extends AbstractHelper<Menu, CreateMenuRequest, MenuListResponse, MenuDetailResponse, MenuDetailAdminResponse> {

	@Autowired
	private MenuService menuService;

	@Override
	public Menu getEntity(CreateMenuRequest createMenuRequest) throws Exception {
		try {
			Menu menu;
			if (CommonUtil.isValid(createMenuRequest.getId())) {
				menu = menuService.findById(createMenuRequest.getId());
			} else {
				menu = new Menu();
			}

			if (CommonUtil.isValid(createMenuRequest.getParentId())) {
				menu.setParentId(new Menu(createMenuRequest.getParentId()));
			}
			menu.setDisplayOrder(createMenuRequest.getDisplayOrder());
			menu.setMasterMenu(createMenuRequest.getMasterMenu());
			menu.setIcon(createMenuRequest.getIcon());
			menu.setActive(createMenuRequest.getActive());
			menu.setTitle(createMenuRequest.getTitle());
			menu.setUrlPath(createMenuRequest.getPath());
			menu.setCode(createMenuRequest.getCode());
			return menu;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public List<MenuListResponse> getListResponse(List<Menu> entityList) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public MenuDetailResponse getDetailResponse(Menu entity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public MenuDetailAdminResponse getDetailForAdminResponse(Menu entity) {
		// TODO Auto-generated method stub
		return null;
	}
}