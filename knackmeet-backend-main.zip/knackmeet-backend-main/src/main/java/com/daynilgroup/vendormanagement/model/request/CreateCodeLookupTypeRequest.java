package com.daynilgroup.vendormanagement.model.request;

import com.daynilgroup.vendormanagement.request.inf.RequestInf;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class CreateCodeLookupTypeRequest implements RequestInf {

	static final long serialVersionUID = 1L;

	Long id;
	String code;
	String name;
	Long parentId;
	Boolean active;
	Boolean coverImgRequire;

}