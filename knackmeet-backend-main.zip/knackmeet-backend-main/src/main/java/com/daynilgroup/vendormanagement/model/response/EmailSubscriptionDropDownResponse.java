package com.daynilgroup.vendormanagement.model.response;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Value;

/**
 * 
 * @author Manish
 *
 */
@Value
public class EmailSubscriptionDropDownResponse implements Serializable {

	static final long serialVersionUID = 1L;

	@JsonProperty(value = "value")
	Object value;

	@JsonProperty(value = "label")
	String label;
	
	@JsonProperty(value="status")
	Boolean status;

}
