
package com.daynilgroup.vendormanagement.util;

import java.math.RoundingMode;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.thymeleaf.context.Context;
import org.thymeleaf.spring5.SpringTemplateEngine;

import com.daynilgroup.vendormanagement.config.SchedulerConfig;
import com.daynilgroup.vendormanagement.constants.CodeLookUpRelationTypeEnum;
import com.daynilgroup.vendormanagement.constants.Constants;
import com.daynilgroup.vendormanagement.constants.CurrencyTypeEnum;
import com.daynilgroup.vendormanagement.constants.RefTypeEnum;
import com.daynilgroup.vendormanagement.constants.ResultTypeEnum;
import com.daynilgroup.vendormanagement.constants.UserType;
import com.daynilgroup.vendormanagement.entity.CodeLookUpRelation;
import com.daynilgroup.vendormanagement.entity.Job;
import com.daynilgroup.vendormanagement.entity.SkillsCodeLookup;
import com.daynilgroup.vendormanagement.entity.SubscribedUsers;
import com.daynilgroup.vendormanagement.entity.User;
import com.daynilgroup.vendormanagement.entity.Vendor;
import com.daynilgroup.vendormanagement.helper.EmailLogHelper;
import com.daynilgroup.vendormanagement.model.response.JobContractListResponse;
import com.daynilgroup.vendormanagement.repository.CodeLookUpRelationRepository;
import com.daynilgroup.vendormanagement.repository.JobRepository;
import com.daynilgroup.vendormanagement.repository.SkillsCodeLookupRepository;
import com.daynilgroup.vendormanagement.repository.SubscribedUsersRepository;
import com.daynilgroup.vendormanagement.repository.UserRepository;
import com.daynilgroup.vendormanagement.repository.VendorRepository;
import com.daynilgroup.vendormanagement.request.EmailLogRequest;
import com.daynilgroup.vendormanagement.service.JobService;
import com.daynilgroup.vendormanagement.service.VendorService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class EmailSenderUtil {

	@Value("${domain.url}")
	String domainUrl;
	
	@Value("${email.sender.address}")
	String fromEmailId;

	@Value("${email.sender.password}")
	String password;
	
	@Value("${email.sender.host}")
	String host;
	
	@Autowired
	private SpringTemplateEngine springTemplateEngine;
	
	@Autowired
	JobService jobService;

	
	@Autowired
	UserRepository userRepository;

	@Autowired
	JobRepository jobRepository;
	
	@Autowired
	SchedulerConfig schedulerConfig;
	
	@Autowired
	SkillsCodeLookupRepository codeLookupRepository;
	
	@Autowired
	VendorRepository vendorRepository;
	
	@Autowired
	CodeLookUpRelationRepository codeLookUpRelationRepository;
	
	@Autowired
	SubscribedUsersRepository subscribedUsersRepository;
	
	@Autowired
	EntityUtil entityUtil;
	
	@Autowired
	EmailLogHelper emailLogHelper;
	
	@Autowired
	VendorService vendorService;
	
	@Value("${spring.profiles.active}")
	private String activeProfile;

	public void sendEmail(String emailId, Map<String, Object> model, String forgotPasswordTemplate, String subject) {
		EmailLogRequest emailLogRequest=null;
		Vendor vendor = vendorService.findByCompanyPrimaryEmail(emailId);
		
		try {
			
			if (activeProfile!=null && activeProfile.equals("dev")) {
				emailId = "knackmeet.env.test@yopmail.com";
			}else if (activeProfile!=null && activeProfile.equals("uat")) {
				emailId = "knackmeet.env.uat@yopmail.com";
			}
			emailLogRequest=new EmailLogRequest(null,ResultTypeEnum.SUCCESS,emailId,subject," ",vendor !=null?vendor.getId():null);
			JavaMailSenderImpl mailSender = new JavaMailSenderImpl();
			JavaMailSenderImpl javaMailSender = configureMailSender(mailSender);
			MimeMessage mimeMessage = javaMailSender.createMimeMessage();
			MimeMessageHelper mimeMessageHelper = new MimeMessageHelper(mimeMessage,
					MimeMessageHelper.MULTIPART_MODE_MIXED_RELATED, StandardCharsets.UTF_8.name());
			Context context = new Context();
			context.setVariables(model);
			String html = springTemplateEngine.process(forgotPasswordTemplate, context);
			mimeMessageHelper.setTo(emailId.split(","));
			mimeMessageHelper.setFrom(fromEmailId);
			mimeMessageHelper.setFrom(fromEmailId, "Knackmeet");
			mimeMessageHelper.setText(html, true);
			mimeMessageHelper.setSubject(subject);
			javaMailSender.send(mimeMessage);
		    
			emailLogHelper.getEntity(emailLogRequest);
		} catch (Exception exception) {
			exception.printStackTrace();
			emailLogRequest=new EmailLogRequest(null,ResultTypeEnum.FAILED,emailId,subject,exception.getMessage(),vendor !=null?vendor.getId():null);
			try {
				emailLogHelper.getEntity(emailLogRequest);
			} catch (Exception e) {
				e.printStackTrace();
			}
			throw new RuntimeException("Email Not Sent");
			
		}
	}

	private JavaMailSenderImpl configureMailSender(JavaMailSenderImpl mailSender) {
		mailSender.setHost(host);
		mailSender.setPort(465);
		mailSender.setUsername(fromEmailId);
		mailSender.setPassword(password);
		Properties props = mailSender.getJavaMailProperties();
		props.put("mail.transport.protocol", "smtp");
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.debug", "false");
		props.put("mail.smtp.ssl.enable", "true");
		return mailSender;
	}

	public void sendMail(String name, String message, String url, String emailId, String template, String subject) {

		Map<String, Object> model = new HashMap<>();
		model.put(Constants.NAME, name);
		model.put(Constants.MESSAGE, message);
		log.info("domainUrl : {}", domainUrl);
		model.put(Constants.REDIRECT_LINK, domainUrl + url);
		new Thread() {
			public void run() {
				sendEmail(emailId, model, template, subject);
			}
		}.start();

	}
	

	public void sendMail(String name, String message, String emailId, String template, String subject) {

		Map<String, Object> model = new HashMap<>();
		model.put(Constants.NAME, name);
		model.put(Constants.MESSAGE, message);
		log.info("domainUrl : {}", domainUrl);
		new Thread() {
			public void run() {

				sendEmail(emailId, model, template, subject);
			}
		}.start();
			}
	
	
	
	public void sendMail(String name, String message, String Resource_Name, String Designation, String redirect_link,String emailId, String template, String subject) {

		Map<String, Object> model = new HashMap<>();
		model.put(Constants.NAME, name);
		model.put(Constants.MESSAGE, message);
		model.put(Constants.RESOURCE_NAME, Resource_Name);
		model.put(Constants.RESOURCE_DESIGNATION, Designation);
		model.put(Constants.NOTIFICATION_REDIRECT_LINK, domainUrl+redirect_link);
		
		log.info("domainUrl : {}", model.get(Constants.NOTIFICATION_REDIRECT_LINK));
		new Thread() {
			public void run() {
				sendEmail(emailId, model, template, subject);
			}
	}.start();

	}
	
	public void sendMailWithReason(String name, String message, List<String> reasons, String Resource_Name, String Designation, String redirect_link,String emailId, String template, String subject) {

		Map<String, Object> model = new HashMap<>();
		model.put(Constants.NAME, name);
		model.put(Constants.MESSAGE, message);
		model.put(Constants.REASON_LIST, reasons);
		model.put(Constants.RESOURCE_NAME, Resource_Name);
		model.put(Constants.RESOURCE_DESIGNATION, Designation);
		model.put(Constants.NOTIFICATION_REDIRECT_LINK, domainUrl+redirect_link);
		
		log.info("domainUrl : {}", model.get(Constants.NOTIFICATION_REDIRECT_LINK));
		new Thread() {
			public void run() {
				sendEmail(emailId, model, template, subject);
			}
	}.start();

	}
	
	
	public void sendMail(String name, String message, String Job_Title, String redirect_link,String emailId, String template, String subject) {

		Map<String, Object> model = new HashMap<>();
		model.put(Constants.NAME, name);
		model.put(Constants.MESSAGE, message);
		model.put(Constants.JOB_TITLE,Job_Title);
		
		model.put(Constants.NOTIFICATION_REDIRECT_LINK, domainUrl+redirect_link);
		new Thread() {
			public void run() {
				sendEmail(emailId, model, template, subject);
			}
		}.start();

	}
	
	public void sendMailWithReasons(String name, String message, List<String> reasons, String Job_Title, String redirect_link,String emailId, String template, String subject) {
		
		Map<String, Object> model = new HashMap<>();
		model.put(Constants.NAME, name);
		model.put(Constants.MESSAGE, message);
		model.put(Constants.REASON_LIST, reasons);
		model.put(Constants.JOB_TITLE,Job_Title);
		
		model.put(Constants.NOTIFICATION_REDIRECT_LINK, domainUrl+redirect_link);
		new Thread() {
			public void run() {
				sendEmail(emailId, model, template, subject);
			}
		}.start();
		
	}
	
	
	public void sendMail( String token, String emailId, String template, String subject) {

		Map<String, Object> model = new HashMap<>();	
		model.put(Constants.REDIRECT_LINK,domainUrl+Constants.VERIFY_EMAIL_LINK + token);

		log.info("domainUrl : {}", domainUrl);
		new Thread() {
			public void run() {
				sendEmail(emailId, model, template, subject);
			}

	}.start();

		


	}

	public void sendRejectMail(String name, String message, String reason, String emailId, String template,
			String subject) {

		Map<String, Object> model = new HashMap<>();
		model.put(Constants.NAME, name);
		model.put(Constants.MESSAGE, message);
		model.put(Constants.REASON, reason);
		log.info("domainUrl : {}", domainUrl);
		new Thread() {
			public void run() {

				sendEmail(emailId, model, template, subject);
			}
		}.start();
	}

	public void sendJobContractEmail(String emailId, Map<String, Object> model, String forgotPasswordTemplate,
			String subject) {
		EmailLogRequest emailLogRequest=null;
		Vendor vendor = vendorService.findByCompanyPrimaryEmail(emailId);
		try {
			
			if (activeProfile!=null && activeProfile.equals("dev")) {
				emailId = "knackmeet.env.test@yopmail.com";
			}else if (activeProfile!=null && activeProfile.equals("uat")) {
				emailId = "knackmeet.env.uat@yopmail.com";
			}
			emailLogRequest=new EmailLogRequest(null,ResultTypeEnum.SUCCESS,emailId,subject," ",vendor !=null?vendor.getId():null);
			JavaMailSenderImpl mailSender = new JavaMailSenderImpl();
			JavaMailSenderImpl javaMailSender = configureMailSender(mailSender);
			MimeMessage mimeMessage = javaMailSender.createMimeMessage();
			MimeMessageHelper mimeMessageHelper = new MimeMessageHelper(mimeMessage,
					MimeMessageHelper.MULTIPART_MODE_MIXED_RELATED, StandardCharsets.UTF_8.name());
			Context context = new Context();
			context.setVariables(model);
			String html = springTemplateEngine.process(forgotPasswordTemplate, context);
			mimeMessageHelper.setTo(emailId);
			mimeMessageHelper.setFrom("noreply@knackmeet.com");
			mimeMessageHelper.setFrom("noreply@knackmeet.com", "Knackmeet");
			mimeMessageHelper.setText(html, true);
			mimeMessageHelper.setSubject(subject);
			javaMailSender.send(mimeMessage);
			emailLogHelper.getEntity(emailLogRequest);
		} catch (Exception exception) {
			exception.printStackTrace();
			emailLogRequest=new EmailLogRequest(null,ResultTypeEnum.FAILED,emailId,subject,exception.getMessage(),vendor !=null?vendor.getId():null);
			try {
				emailLogHelper.getEntity(emailLogRequest);
			} catch (Exception e) {
				e.printStackTrace();
			}
			throw new RuntimeException("Email Not Sent");

		}
	}

	public void sendJobContractMail(String name, String actionUrl, String emailId, String template, String subject,Long vendorId) {
		Map<String, Object> model = new HashMap<>();

		List<JobContractListResponse> jobContractListResponses = new ArrayList<>();
		List<Job> jobs = jobService.getJobContracts(vendorId);
		int count = 1;
		for (Job job : jobs) {

			JobContractListResponse jobContractListResponse = new JobContractListResponse();
			jobContractListResponse.setId(count);
			jobContractListResponse.setTitle(job.getTitle());
			List<String> skillList = getSkillNameList(job.getSkillsCodeLookup());
			jobContractListResponse.setSkills(String.join(",", skillList));

			String experience = job.getMinExperience() + " - " + job.getMaxExperience();
			jobContractListResponse.setExperience(experience);
			String rate = job.getMinRate().setScale(0, RoundingMode.DOWN) + " To "
					+ job.getMaxRate().setScale(0, RoundingMode.DOWN);
			jobContractListResponse.setRate(rate);
			jobContractListResponse.setWorkFrom(job.getWorkFrom().getDisplayName());
			if (job.getVendor().getId().equals(vendorId)) {
				jobContractListResponse.setActionUrl(domainUrl + Constants.VERIFIED_JOB_ACTION_LINK + job.getId());
			} else {
				jobContractListResponse.setActionUrl(domainUrl + Constants.EXCEPT_VENODR_JOB_ACTION_LINK + job.getId());
			}
			jobContractListResponses.add(jobContractListResponse);
			count++;
		}
		model.put(Constants.NAME, name);
		model.put("jobContractListResponses", jobContractListResponses);
		new Thread() {
			public void run() {

				sendJobContractEmail(emailId, model, template, subject);
			}
		}.start();
	}

	
	public List<String> getSkillNameList(List<SkillsCodeLookup> skillsCodeLookups) {
		List<String> resourseIdList = new ArrayList<>();
		skillsCodeLookups.forEach(skill -> {
			resourseIdList.add(skill.getCodeLookup().getName());
		});
		return resourseIdList;
	}

	@Transactional(rollbackFor = Exception.class)
	@Scheduled(cron = "#{@schedulerConfig.getCronExpression()}")
	public void getJobContractResponse() {
		List<User> users = userRepository.sendJobDetailsMailToAllVerifiedUser();
		 Long vendorId =null;
		for (User user : users) {
			Vendor vendor = vendorRepository.findByUserId(user.getId());
			vendorId = vendor.getId();
			CodeLookUpRelation codLookUpRelation = codeLookUpRelationRepository.getByRefIdAndRefTypeAndType(Constants.OPEN_CONTRATC_REQUIREMENTS, false, vendor.getId(), RefTypeEnum.VENDOR, CodeLookUpRelationTypeEnum.SUBSCRIBE_FOR_EMAIL_NOTIFICATION);
			if (codLookUpRelation==null) {
			sendJobContractMail(vendor.getAgencyName(),
					Constants.HIRED_JOB_ON_CONTRACT_ACTION_LINK,  vendor.getCompanyPrimaryEmail()==null? user.getEmailId():vendor.getCompanyPrimaryEmail(), Constants.HIRED_JOB_ON_CONTRACT,
					Constants.HIRED_JOB_ON_CONTRACT_SUBJECT,vendor.getId());
		}}
		List<SubscribedUsers> subscribedUsers = subscribedUsersRepository.findAll();
		for(SubscribedUsers subscribedUser:subscribedUsers) {
			sendJobContractMail(subscribedUser.getAgencyName(),
					Constants.HIRED_JOB_ON_CONTRACT_ACTION_LINK,  subscribedUser.getEmailId(), Constants.HIRED_JOB_ON_CONTRACT,
					Constants.HIRED_JOB_ON_CONTRACT_SUBJECT,vendorId);
		}
	}

	public void sendMail(String name, String job_Title, String workFrom, String rate, Integer no_of_position,
			String contract_duration, String redirect_link, String emailId, String template, String subject) {
		Map<String, Object> model = new HashMap<>();
		model.put(Constants.EXCEPT_VERIFIED_JOB_VENDOR_AGENCY_NAME, name);
		model.put(Constants.VERIFIED_JOB_TITLE, job_Title);
		model.put(Constants.VERIFIED_JOB_WORK_FROM, workFrom);
		model.put(Constants.VERIFIED_JOB_RATE, rate);
		model.put(Constants.VERIFIED_JOB_NO_OF_POSITION, no_of_position);
		model.put(Constants.VERIFIED_JOB_CONTRACT_DURATION, contract_duration);
		model.put(Constants.NOTIFICATION_REDIRECT_LINK, domainUrl + redirect_link);
		new Thread() {
			public void run() {
				sendEmail(emailId, model, template, subject);
			}
		}.start();
	}

	public String getJobDetails(Long jobId) {
	    List<Vendor> vendors = jobService.sendMailToVerfiedVendor(jobId);
	    ExecutorService executorService = Executors.newFixedThreadPool(vendors.size());
	    Job job = jobService.findById(jobId);
	    String displayName = job.getRateTypeEnum().getDisplayName();
        String rateType = "(" + displayName + ")";
        final String currencySymbol;
        if (job.getCurrencyType() == CurrencyTypeEnum.INR) {
            currencySymbol = "₹";
        } else if (job.getCurrencyType() == CurrencyTypeEnum.USD) {
            currencySymbol = "$";
        } else {
            currencySymbol = "";
        }
	    for (Vendor vendor : vendors) {
	        User user = vendor.getUser();
	        CodeLookUpRelation codLookUpRelation = codeLookUpRelationRepository.getByRefIdAndRefTypeAndType(Constants.NEW_REQUIREMENTS, false, vendor.getId(), RefTypeEnum.VENDOR, CodeLookUpRelationTypeEnum.SUBSCRIBE_FOR_EMAIL_NOTIFICATION);
	        if (user.getUserType() != UserType.ADMIN &&  codLookUpRelation==null) {
	            executorService.execute(() -> {
	                sendMail(vendor.getAgencyName(), job.getTitle(), job.getWorkFrom().getDisplayName(),
	                        currencySymbol + " " + job.getMinRate().setScale(0, RoundingMode.DOWN) + "-"
	                                + job.getMaxRate().setScale(0, RoundingMode.DOWN) + " " + rateType,
	                        job.getNoOfResources(), job.getDuration() != null ? job.getDuration().getName() : null,
	                        Constants.EXCEPT_VENODR_JOB_ACTION_LINK + job.getId(), vendor.getCompanyPrimaryEmail(),
	                        Constants.VERIFIED_JOB_TEMPLATE, Constants.VERIFIED_JOB_SUBJECT);
	            });
	        }
	    }
		executorService.shutdown();
		List<SubscribedUsers> subscribedUsers = subscribedUsersRepository.findAll();
		ExecutorService executorServ = Executors.newFixedThreadPool(subscribedUsers.size());
		for (SubscribedUsers subscribedUser : subscribedUsers) {

			executorServ.execute(() -> {
				sendMail(subscribedUser.getAgencyName(), job.getTitle(), job.getWorkFrom().getDisplayName(),
						currencySymbol + " " + job.getMinRate().setScale(0, RoundingMode.DOWN) + "-"
								+ job.getMaxRate().setScale(0, RoundingMode.DOWN) + " " + rateType,
						job.getNoOfResources(), job.getDuration() != null ? job.getDuration().getName() : null,
						Constants.EXCEPT_VENODR_JOB_ACTION_LINK + job.getId(), subscribedUser.getEmailId(),
						Constants.VERIFIED_JOB_TEMPLATE, Constants.VERIFIED_JOB_SUBJECT);
			});
		}
		executorServ.shutdown();
	    return "Email has been sent successfully!";
	}
}