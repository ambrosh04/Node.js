package com.daynilgroup.vendormanagement.exception;

import org.springframework.http.HttpStatus;

import com.daynilgroup.vendormanagement.constants.ExceptionType;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.experimental.FieldDefaults;


@Getter
@FieldDefaults(level = AccessLevel.PRIVATE)
public class VendorManagementException extends Exception {

	static final long serialVersionUID = 1L;
	
	HttpStatus statusCode = HttpStatus.INTERNAL_SERVER_ERROR;
	ExceptionType type = ExceptionType.ERROR;
		
	public VendorManagementException(Exception e) {
		super(e.getMessage());
	}

	public VendorManagementException(String message) {
		super(message);
	}

	public VendorManagementException(int errorCodeValue, String message) {
		super(message);
		this.statusCode = HttpStatus.valueOf(errorCodeValue);
	}

	public VendorManagementException(int errorCodeValue, ExceptionType type,  String message) {
		super(message);
		this.statusCode = HttpStatus.valueOf(errorCodeValue);
		this.type = type;
	}
	
}
