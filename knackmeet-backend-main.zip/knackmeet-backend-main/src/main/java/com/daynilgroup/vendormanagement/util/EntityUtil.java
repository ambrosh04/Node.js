/**
 * 
 */
package com.daynilgroup.vendormanagement.util;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.daynilgroup.vendormanagement.constants.Constants;
import com.daynilgroup.vendormanagement.entity.BaseEntity;
import com.daynilgroup.vendormanagement.entity.Job;
import com.daynilgroup.vendormanagement.entity.Resource;
import com.daynilgroup.vendormanagement.entity.User;
import com.daynilgroup.vendormanagement.entity.Vendor;
import com.daynilgroup.vendormanagement.request.inf.RequestInf;
import com.daynilgroup.vendormanagement.service.AbstractService;
import com.daynilgroup.vendormanagement.service.UserService;
import com.daynilgroup.vendormanagement.service.VendorService;

import lombok.AccessLevel;
import lombok.SneakyThrows;
import lombok.experimental.FieldDefaults;

/**
 * @author Prerana
 *
 */
@Component
@SuppressWarnings(value = { "rawtypes", "unchecked", "deprecation" })
@FieldDefaults(level = AccessLevel.PRIVATE)
public class EntityUtil {

	@Autowired
	VendorService vendorService;

	@Autowired
	UserService userService;

	/**
	 * This methods returns the Entity based on id and if not present returns a new
	 * Object
	 *
	 * @param request
	 * @param entityClass
	 * @return Entity
	 * @throws java.lang.Exception
	 */
	public <T> T getEntityById(RequestInf request, AbstractService service, Class<T> entityClass) throws Exception {
		T entity;
		if (isValidId(request.getId())) {
			entity = (T) service.findById(request.getId());
			if (entity == null) {
				throw new Exception(
						entityClass.getSimpleName() + " Entity Not Found With Id '" + request.getId() + "'");
			}
		} else {
			entity = entityClass.newInstance();
		}
		return entity;
	}

	public boolean isValidId(Long id) {
		return CommonUtil.isValid(id);
	}

	/**
	 * This method will check if the id is present in database; If present return a
	 * Entity object with id for reference purpose, else throws Exception.
	 *
	 * @param <T>
	 * @param id
	 * @param service
	 * @param entityClass
	 * @return
	 * @throws Exception
	 */
	public <T extends BaseEntity> T getEntityReferenceWithId(Long id, AbstractService service, Class<T> entityClass)
			throws Exception {
		return CommonUtil.getEntityReferenceWithId(id, service, entityClass);
	}

	public static Long getAnonymousUserID() {
		return null;

	}

	public Long getCurrentVendorId() {
		try {
			Vendor vendor = null;
			Long userId = CommonUtil.getCurrentUserId();
			if (null != userId) {
				vendor = vendorService.findByUserId(userId);
			}
			return vendor.getId();
		} catch (Exception e) {
			e.getStackTrace();
			return null;
		}
	}

	@SneakyThrows
	public User getCurrentUser() {
		try {
			return userService.findById(CommonUtil.getCurrentUserId());
		} catch (Exception e) {
			throw new Exception("Issue in fetching user details");
		}
	}

	public Map<String, Object> setMetaDataInNotification(Long jobId, Long resourceId, Job job, Resource resource) {
		Map<String, Object> metaData = new HashMap<>();
		metaData.put(Constants.RESOURCE_ID, resourceId);
		metaData.put(Constants.JOB_ID, jobId);
		metaData.put(Constants.RESOURCE_VENDOR_ID, resource.getVendor().getId());
		metaData.put(Constants.JOB_VENDOR_ID, job.getVendor().getId());
		metaData.put(Constants.JOB_TITLE_CAMEL, job.getTitle());
		metaData.put(Constants.NAME, resource.getName());
		return metaData;
	}

}
