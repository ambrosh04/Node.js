package com.daynilgroup.vendormanagement.model.request;

import java.math.BigDecimal;
import java.util.List;

import com.daynilgroup.vendormanagement.constants.CurrencyTypeEnum;
import com.daynilgroup.vendormanagement.constants.DeploymentTypeEnum;
import com.daynilgroup.vendormanagement.constants.JobSearchInTypeEnum;
import com.daynilgroup.vendormanagement.constants.RateTypeEnum;
import com.daynilgroup.vendormanagement.model.pag.PaginationRequestModel;
import com.daynilgroup.vendormanagement.model.response.DropdownResponse;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@Getter
@Setter
@FieldDefaults(level = AccessLevel.PRIVATE)
public class JobSearchRequest {

	Integer minExperience;

	Integer maxExperience;
	

//	List<String> keyWords;
	
	List<DropdownResponse> keyWords;
	
	PaginationRequestModel paginationRequestModel;

	JobSearchInTypeEnum jobSearchInTypeEnum;

	DeploymentTypeEnum workFrom;
	
	CurrencyTypeEnum currencyTypeEnum;

	BigDecimal minRate;

	BigDecimal maxRate;

	Long cityId;

	Long stateId;

	Long countryId;
	
	String keyword;
	
	List<Long> countryIds;
	
	RateTypeEnum rateTypeEnum;
	
	Boolean isMaxRate;
	
	Long durationId;
	
	Boolean isRemote;
	
	String countryName;

}
