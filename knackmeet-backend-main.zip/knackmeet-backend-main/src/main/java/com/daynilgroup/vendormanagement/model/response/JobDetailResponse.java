package com.daynilgroup.vendormanagement.model.response;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;

import com.daynilgroup.vendormanagement.constants.JobCloseReason;
import com.daynilgroup.vendormanagement.constants.TimeZoneEnum;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class JobDetailResponse {

	Long id;

	String category;

	List<String> skills;

	String city;

	String state;

	String country;

	String title;

	String workFromHome;

	String rateType;

	BigDecimal minRate;

	BigDecimal maxRate;

	Integer minExperience;

	Integer maxExperience;

	LocalDateTime startDate;

	LocalDateTime postedDate;

	LocalDateTime updatedDate;

	String currencyType;

	String description;

	String duration;

	Integer noOfJobViewed;

	Integer noOfpostions;

	Long noOfApplication;

	String jobType;

	String agencyName;
	
	String status;
	
	Boolean isActive;
	
	Long userId;
	
	String location;
	
	String jobCloseReason;
	
	Long applicantsCount;
	
	LocalDateTime closedDate;
	
	Long categoryId;

	String timeZoneEnum;

	String startTime;

	String endTime;
}
