package com.daynilgroup.vendormanagement.helper;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.daynilgroup.vendormanagement.constants.SearchType;
import com.daynilgroup.vendormanagement.entity.SearchHistory;
import com.daynilgroup.vendormanagement.entity.Vendor;
import com.daynilgroup.vendormanagement.model.filter.ResourceSkillsFilterModel;
import com.daynilgroup.vendormanagement.model.inf.DateUtil;
import com.daynilgroup.vendormanagement.model.request.JobSearchRequest;
import com.daynilgroup.vendormanagement.model.response.DropdownResponse;
import com.daynilgroup.vendormanagement.model.response.RecentSearchHistoryResponse;
import com.daynilgroup.vendormanagement.model.response.SearchHistoryDropDownResponse;
import com.daynilgroup.vendormanagement.service.VendorService;
import com.daynilgroup.vendormanagement.util.CommonUtil;
import com.daynilgroup.vendormanagement.util.EntityUtil;
import com.google.gson.Gson;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;

@Component
@Lazy
@FieldDefaults(level = AccessLevel.PRIVATE)
public class SearchHistoryHelper {

	@Autowired
	EntityUtil entityUtil;

	@Autowired
	VendorService vendorService;

	@Transactional
	public SearchHistory getJobSearchRequest(JobSearchRequest jobRequestAdvanced) throws Exception {
		SearchHistory history = new SearchHistory();


		history.setCityId(jobRequestAdvanced.getCityId());
		history.setStateId(jobRequestAdvanced.getStateId());
		history.setCountryId(jobRequestAdvanced.getCountryId());
		history.setJobSearchInTypeEnum(jobRequestAdvanced.getJobSearchInTypeEnum());
		history.setMinExp(jobRequestAdvanced.getMinExperience());
		history.setMaxExp(jobRequestAdvanced.getMaxExperience());
		history.setDate(LocalDateTime.now());
		history.setDeleted(false);
		history.setSearchType(SearchType.JOBS_OR_PROJECTS);

		Vendor vendor = CommonUtil.getEntityReferenceWithId(entityUtil.getCurrentVendorId(), vendorService,
				Vendor.class);


//		Gson gson = new Gson();
//		String keywords = gson.toJson(jobRequestAdvanced.getKeyWords());

		history.setKeyword(jobRequestAdvanced.getKeyword());
		history.setVendor(vendor);
		return history;
	}

	@Transactional
	public SearchHistory getResourceSkillsFilterModel(ResourceSkillsFilterModel resourceSkillsFilterModel)
			throws Exception {
		SearchHistory searchhistory = new SearchHistory();

		
		searchhistory.setCityId(resourceSkillsFilterModel.getCityId());
		searchhistory.setStateId(resourceSkillsFilterModel.getStateId());
		searchhistory.setCountryId(resourceSkillsFilterModel.getCountryId());
		searchhistory.setResourceSearchInEnum(resourceSkillsFilterModel.getResourceSearchInEnum());
		searchhistory.setMinExp(resourceSkillsFilterModel.getMinExperience());
		searchhistory.setMaxExp(resourceSkillsFilterModel.getMaxExperience());
		searchhistory.setDate(LocalDateTime.now());
		searchhistory.setDeleted(false);
//		Gson gson = new Gson();
//		String keywords = gson.toJson(resourceSkillsFilterModel.getSkillOrTitle());

		searchhistory.setKeyword(resourceSkillsFilterModel.getKeyword());

		searchhistory.setSearchType(SearchType.HIRE_DEVELOPER);
		Vendor vendor = CommonUtil.getEntityReferenceWithId(entityUtil.getCurrentVendorId(), vendorService,
				Vendor.class);

		searchhistory.setVendor(vendor);
		return searchhistory;
	}

	public List<RecentSearchHistoryResponse> getRecentSearchHistoryResponse(List<SearchHistory> entityList) {
		List<RecentSearchHistoryResponse> recentSearchHistoryResponse = new ArrayList<>();
		entityList.forEach(history ->{
//
//			String keywords = history.getKeywardJson();

//			Gson gson = new Gson();
//			DropdownResponse[] array = gson.fromJson(keywords, DropdownResponse[].class);

			RecentSearchHistoryResponse.RecentSearchHistoryResponseBuilder builder = RecentSearchHistoryResponse
					.builder().id(history.getId()).date(DateUtil.localDateTimeFormatter(history.getDate()))
					//.KeywordsArray(array)
					.searchType(history.getSearchType().getDisplayName())
					.resourceSearchInEnum(
							history.getResourceSearchInEnum() != null ? history.getResourceSearchInEnum() : null)
					.jobSearchInTypeEnum(
							history.getJobSearchInTypeEnum() != null ? history.getJobSearchInTypeEnum() : null)
					.minExperience(history.getMinExp() != null ? history.getMinExp() : null)
					.maxExperience(history.getMaxExp() != null ? history.getMaxExp() : null)
					.countryId(history.getCountryId() != null ? history.getCountryId() : null)
					.stateId(history.getStateId() != null ? history.getStateId() : null)
					.cityId(history.getCityId() != null ? history.getCityId() : null)

			;
			recentSearchHistoryResponse.add(builder.build());
		});
		return recentSearchHistoryResponse;
	}
	
	public List<SearchHistoryDropDownResponse> getRecentSearchHistoryDropResponse(List<SearchHistory> entityList) {
		List<SearchHistoryDropDownResponse> dropdownResponse = new ArrayList<>();

		entityList.forEach(history -> {

			if (history.getKeyword() != null && !history.getKeyword().isEmpty()) {

				dropdownResponse.add(SearchHistoryDropDownResponse.builder().label(history.getKeyword())
						.searcHistoryId(history.getId()).build());
			}

		});

		return dropdownResponse.stream()
				.collect(Collectors.toMap(SearchHistoryDropDownResponse::getLabel, e -> e, (e1, e2) -> e1)).values()
				.stream().collect(Collectors.toList()).stream()
				.sorted(Comparator.comparing(SearchHistoryDropDownResponse::getSearcHistoryId).reversed()).limit(10)
				.collect(Collectors.toList());

	}

}
