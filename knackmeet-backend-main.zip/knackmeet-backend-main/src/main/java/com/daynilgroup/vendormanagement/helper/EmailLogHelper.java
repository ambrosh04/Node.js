package com.daynilgroup.vendormanagement.helper;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.daynilgroup.vendormanagement.entity.EmailLog;
import com.daynilgroup.vendormanagement.model.response.EmailLogResponse;
import com.daynilgroup.vendormanagement.repository.VendorRepository;
import com.daynilgroup.vendormanagement.request.EmailLogRequest;
import com.daynilgroup.vendormanagement.service.EmailLogService;
import com.daynilgroup.vendormanagement.util.CommonUtil;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;

@Component
@FieldDefaults(level = AccessLevel.PRIVATE)
public class EmailLogHelper extends AbstractHelper<EmailLog, EmailLogRequest, EmailLogResponse, EmailLogResponse, EmailLogResponse>{
	
	@Autowired
	EmailLogService emailLogService;
	
	@Autowired
	VendorRepository vendorRepository;

	@Override
	public EmailLog getEntity(EmailLogRequest request) throws Exception {
		EmailLog emailLog;
		if (CommonUtil.isValid(request.getId())) {
			emailLog = emailLogService.findById(request.getId());
		} else {
			emailLog = new EmailLog();
		}
		emailLog.setResultType(request.getResultType());
		emailLog.setLogMsg(request.getLogMsg());
		emailLog.setEmail(request.getEmail());
		emailLog.setSubject(request.getSubject());
		if (request.getVendorId() != null) {
			emailLog.setVendor(vendorRepository.getById(request.getVendorId()));
		}
		emailLogService.save(emailLog);
		return emailLog;

	}

	@Override
	public List<EmailLogResponse> getListResponse(List<EmailLog> entityList) {
		return entityList.stream().map(this::getDetailResponse).collect(Collectors.toList());
	}

	@Override
	public EmailLogResponse getDetailResponse(EmailLog emailLog) {
		return EmailLogResponse.builder().id(emailLog.getId()).resultType(emailLog.getResultType())
				.email(emailLog.getEmail()).subject(emailLog.getSubject()).logMsg(emailLog.getLogMsg())
				.agencyName(emailLog.getVendor() != null ? emailLog.getVendor().getAgencyName() : null)
				.createdOn(emailLog.getCreatedOn())
				.name(emailLog.getVendor() != null && emailLog.getVendor().getUser() != null
						? emailLog.getVendor().getUser().getFirstName() + " "
								+ emailLog.getVendor().getUser().getLastName()
						: null)
				.vendorId(emailLog.getVendor() != null ? emailLog.getVendor().getId() : null).build();
	}

	@Override
	public EmailLogResponse getDetailForAdminResponse(EmailLog entity) {
		// TODO Auto-generated method stub
		return null;
	}
	
}
