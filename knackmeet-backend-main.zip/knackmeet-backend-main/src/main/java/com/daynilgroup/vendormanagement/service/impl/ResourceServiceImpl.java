package com.daynilgroup.vendormanagement.service.impl;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.apache.commons.lang3.ObjectUtils;
import org.apache.pdfbox.cos.COSDocument;
import org.apache.pdfbox.io.RandomAccessBuffer;
import org.apache.pdfbox.pdfparser.PDFParser;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.xwpf.extractor.XWPFWordExtractor;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.daynilgroup.vendormanagement.constants.CodeLookUpConstant;
import com.daynilgroup.vendormanagement.constants.CodeLookUpRelationTypeEnum;
import com.daynilgroup.vendormanagement.constants.CurrencyTypeEnum;
import com.daynilgroup.vendormanagement.constants.DeploymentTypeEnum;
import com.daynilgroup.vendormanagement.constants.RateTypeEnum;
import com.daynilgroup.vendormanagement.constants.RefTypeEnum;
import com.daynilgroup.vendormanagement.constants.ResourceStatusEnum;
import com.daynilgroup.vendormanagement.constants.StaticConfigurationEnum;
import com.daynilgroup.vendormanagement.constants.StatusEnum;
import com.daynilgroup.vendormanagement.constants.UserType;
import com.daynilgroup.vendormanagement.entity.CodeLookup;
import com.daynilgroup.vendormanagement.entity.CodeLookupType;
import com.daynilgroup.vendormanagement.entity.Job;
import com.daynilgroup.vendormanagement.entity.Resource;
import com.daynilgroup.vendormanagement.entity.ResourceJobs;
import com.daynilgroup.vendormanagement.entity.ResourceSkillsCodeLookup;
import com.daynilgroup.vendormanagement.helper.CodeLookUpRelationHelper;
import com.daynilgroup.vendormanagement.helper.ResourceHelper;
import com.daynilgroup.vendormanagement.model.pag.PageModel;
import com.daynilgroup.vendormanagement.model.request.ApplicantRequest;
import com.daynilgroup.vendormanagement.model.request.Base64Request;
import com.daynilgroup.vendormanagement.model.request.CodeLookUpRelationRequest;
import com.daynilgroup.vendormanagement.model.request.ResourceFilterRequest;
import com.daynilgroup.vendormanagement.model.request.ResourceSkillsRequest;
import com.daynilgroup.vendormanagement.model.response.ApplicantListResponse;
import com.daynilgroup.vendormanagement.model.response.DropdownResponse;
import com.daynilgroup.vendormanagement.model.response.MatchingResourceResponse;
import com.daynilgroup.vendormanagement.model.response.ResourceListResponse;
import com.daynilgroup.vendormanagement.model.response.StatusCountResponse;
import com.daynilgroup.vendormanagement.model.response.VerificationCountResponse;
import com.daynilgroup.vendormanagement.repository.ResourceJobsRepository;
import com.daynilgroup.vendormanagement.repository.ResourceRepository;
import com.daynilgroup.vendormanagement.repository.ResourceSkillsCodeLookupRepository;
import com.daynilgroup.vendormanagement.repository.custom.ResourceCustomRepository;
import com.daynilgroup.vendormanagement.service.CodeLookUpRelationService;
import com.daynilgroup.vendormanagement.service.CodeLookupService;
import com.daynilgroup.vendormanagement.service.CodeLookupTypeService;
import com.daynilgroup.vendormanagement.service.JobService;
import com.daynilgroup.vendormanagement.service.ResourceJobsService;
import com.daynilgroup.vendormanagement.service.ResourceService;
import com.daynilgroup.vendormanagement.service.ResourceSkillsCodeLookupService;
import com.daynilgroup.vendormanagement.service.StaticConfigurationService;
import com.daynilgroup.vendormanagement.util.Base64Util;
import com.daynilgroup.vendormanagement.util.CommonUtil;
import com.daynilgroup.vendormanagement.util.EntityUtil;
import com.daynilgroup.vendormanagement.util.FileUpload;
import com.daynilgroup.vendormanagement.util.PaginationUtil;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;

@Service
@FieldDefaults(level = AccessLevel.PRIVATE)
public class ResourceServiceImpl implements ResourceService {

	@Autowired
	ResourceRepository resourceRepository;

	@Autowired
	ResourceCustomRepository resourceCustomRepository;

	@Autowired
	ResourceSkillsCodeLookupService skillsCodeLookupService;

	@Autowired
	Base64Util base64Util;

	@Autowired
	FileUpload fileUpload;

	@Autowired
	EntityUtil entityUtil;

	@Autowired
	ResourceJobsService resourceJobsService;
	
	@Autowired
	ResourceSkillsCodeLookupService resourceskillsCodeLookupService;
	
	@Autowired
	CodeLookupTypeService codeLookupTypeService;
	
	@Autowired
	CodeLookupService codeLookupService;
	
	@Autowired
	ResourceSkillsCodeLookupRepository resourceSkillsCodeLookupRepository;
	
	@Autowired
	ResourceJobsRepository resourceJobsRepository;
	
	@Autowired
	StaticConfigurationService staticConfigurationService;

	@Autowired
	CodeLookUpRelationHelper codeLookUpRelationHelper;
	
	@Autowired
	CodeLookUpRelationService codeLookUpRelationService;
	
	@Override
	public JpaRepository<Resource, Long> getJpaRepository() {
		return resourceRepository;
	}

	@Override
	public Page<Resource> getList(Pageable pageable, StatusEnum statusEnum,String name,String designation,String agencyName) {
		return resourceRepository.getResource(pageable, statusEnum, name,designation,agencyName);
	}

	public Long getCountByVendorId(Long vendorId) {
		return resourceRepository.countByVendorIdAndDeletedFalse(vendorId);
	}

	@Override
	public Long getCountBenchApplicationByvendorId(Long vendorId) {
		return resourceRepository.getCountBenchApllication(vendorId);
	}
	
	@Autowired
	JobService jobService;

	@Autowired
	ResourceService resourceService;

	@Override
	public DropdownResponse pdfDescriptiveInString(Base64Request base64Request) throws Exception {
		String fileExtension = base64Util.getExtension(base64Request.getBase64resume());
		switch (fileExtension) {
		case "docx":
			return getcontent(base64Request.getBase64resume());
		case "pdf":
			return getContentUsingPdf(base64Request.getBase64resume());
		default:
			throw new Exception("Filetype not found");
		}
	}

	private DropdownResponse getContentUsingPdf(String base64resume) throws Exception {
		PDFTextStripper pdfStripper = null;
		PDDocument pdDoc = null;
		String[] strings = base64resume.split(",");
		byte[] decodedString = Base64.getDecoder().decode(new String(strings[1]).getBytes("UTF-8"));
		PDFParser parser = new PDFParser(new RandomAccessBuffer(decodedString));
		parser.parse();
		COSDocument cosDoc = parser.getDocument();
		pdfStripper = new PDFTextStripper();
		pdDoc = new PDDocument(cosDoc);
		pdfStripper.setStartPage(1);
		pdfStripper.setEndPage(10);
		String parsedText = pdfStripper.getText(pdDoc);
		String output = parsedText.replaceAll("(\r\n)", "").replaceAll("[\n]{2,}", "\n");
		pdDoc.close();
		DropdownResponse DropdownResponse = new DropdownResponse("key", output);
		return DropdownResponse;
	}

	private DropdownResponse getcontent(String base64) throws Exception {
		String[] split = base64.split(",");
		byte[] decodedString = Base64.getDecoder().decode(new String(split[1]).getBytes("UTF-8"));
		InputStream input = new ByteArrayInputStream(decodedString);
		XWPFDocument xdoc = new XWPFDocument(OPCPackage.open(input));
		XWPFWordExtractor extractor = new XWPFWordExtractor(xdoc);
		extractor.close();
		DropdownResponse DropdownResponse = new DropdownResponse("key", extractor.getText());
		return DropdownResponse;

	}

	@Override
	public Long getResourcesCountByVendorId(Long vendorId) {
		return resourceRepository.countByVendorIdAndDeletedFalse(vendorId);
	}

	@Override
	public PageModel getFilterResources(ResourceFilterRequest resourceFilterRequest) {
		PageModel pageModel = resourceCustomRepository.getResourceFilterList(resourceFilterRequest);
		if (!ObjectUtils.isEmpty(pageModel.getData())) {
			List<ResourceListResponse> data = (List<ResourceListResponse>) pageModel.getData();
			for (ResourceListResponse resourceListResponse : data) {
				Resource resource = findById(resourceListResponse.getId());
				List<String> skills = new ArrayList<>();
				List<ResourceSkillsCodeLookup> skillsCodeLookup = skillsCodeLookupService
						.findAllByResourceId(resourceListResponse.getId());
				skillsCodeLookup.stream().filter(resourceSkills->resourceSkills.getDeleted().equals(Boolean.FALSE)).forEach(skill -> {
					skills.add(skill.getCodeLookup() != null ? skill.getCodeLookup().getName() : null);
				});
				resourceListResponse.setSkills(skills);
				resourceListResponse.setBase64MediaString(resource != null && resource.getProfilePhoto() != null
						? fileUpload.generatePresignedURL(resource.getProfilePhoto().getPath())
						: null);
				resourceListResponse.setUsdRate(resource.getUsdRate()!=null?CommonUtil.getRateStr(CurrencyTypeEnum.USD.getDisplayName(), CommonUtil.resourceRateWithCommission(resource.getUsdRate(), staticConfigurationService.findByName(StaticConfigurationEnum.RESOURCE_COMMISSION).getValue()), resource.getUsdRateType().getDisplayName()):null);
				resourceListResponse.setRate(resource.getRate()!=null?CommonUtil.getRateStr(CurrencyTypeEnum.INR.getDisplayName(), CommonUtil.resourceRateWithCommission(resource.getRate(), staticConfigurationService.findByName(StaticConfigurationEnum.RESOURCE_COMMISSION).getValue()), resource.getRateTypeEnum().getDisplayName()):null);
				resourceListResponse.setAppliedJobCount(resourceJobsRepository.findByResourceIdAndDeletedFalse(resource.getId()));
			}
		}
		return pageModel;
	}

	@Override
	public void updateStatus(Long resourceId, Boolean active) throws Exception {
		Resource resource = findById(resourceId);
		if (!ObjectUtils.isEmpty(resource)) {
			resource.setActive(active);
			save(resource);
		} else {
			throw new Exception("No Resource Found For Given Id " + resourceId);
		}
	}

	@Override
	public void verifyStatus(Long resourceId, StatusEnum statusEnum, CodeLookUpRelationRequest codeLookUpRelationRequest) throws Exception {
		Resource resource = findById(resourceId);
		if (!ObjectUtils.isEmpty(resource)) {
			resource.setStatusEnum(statusEnum);
			if(resource.getStatusEnum() == StatusEnum.REJECTED) {
				codeLookUpRelationService.deleteByRefIdAndRefTypeAndType(resource.getId(),RefTypeEnum.RESOURCE,CodeLookUpRelationTypeEnum.RESOURCE_REJECT_REASON);
				resource.setCodeLookUpRelation(codeLookUpRelationHelper.setEntity(codeLookUpRelationRequest));
			}
			save(resource);
		} else {
			throw new Exception("No Resource Found For Given Id " + resourceId);
		}
	}

	private VerificationCountResponse getAllResourceCountResponse(List<Resource> jobs) {
		Long verifiedCount = jobs.stream().filter(job -> job.getStatusEnum() == StatusEnum.VERIFIED).count();
		Long pendingCount = jobs.stream().filter(job -> job.getStatusEnum() == StatusEnum.UNVERIFIED).count();
		Long rejectedCount = jobs.stream().filter(job -> job.getStatusEnum() == StatusEnum.REJECTED).count();
		VerificationCountResponse.VerificationCountResponseBuilder builder = VerificationCountResponse.builder()
				.all(Long.valueOf(jobs.size())).pending(pendingCount).rejected(rejectedCount).verified(verifiedCount);
		return builder.build();
	}

	@Override
	public VerificationCountResponse getAllResourceCount() {

		return getAllResourceCountResponse(resourceRepository.findByDeletedFalse());
	}

	@Override
	public Long getResourceCount() {

		return resourceRepository.countByDeletedFalse();
	}

	@Override
	public List<ApplicantListResponse> getApplicantListResponse(ApplicantRequest applicantRequest) {
		Set<Resource> applicants = new HashSet<>();
		if (!CollectionUtils.isEmpty(applicantRequest.getSkills())) {
			for (String skill : applicantRequest.getSkills()) {
				List<Resource> resources = resourceRepository
						.findByVendorIdAndSkillsOrderByUpdatedOnDesc(entityUtil.getCurrentVendorId(), skill.trim());
				if (!CollectionUtils.isEmpty(resources)) {
					resources.stream().forEach(resource -> {
						applicants.add(resource);
					});
				}
			}
		}
		return applicants.stream()
				.map(applicant -> new ApplicantListResponse(applicant.getId(),
						applicant.getFirstName() + " " + applicant.getLastName(),
						applicant.getDesignation() != null ? applicant.getDesignation().getName() : null,
								getUserType(applicantRequest.getJobId(),applicant.getId()),
						resourceJobsService.existsByJobIdAndResourceIdAndDeletedFalseAndResourceStatus(
								applicantRequest.getJobId(), applicant.getId()) != null
										? resourceJobsService
												.existsByJobIdAndResourceIdAndDeletedFalseAndResourceStatus(
														applicantRequest.getJobId(), applicant.getId())
												.getResourceStatus()
										: null,
						applicant.getAvailability().getName(),
						applicant.getProfilePhoto() != null ? fileUpload
								.generatePresignedURL(applicant.getProfilePhoto().getPath())
								: null,
						getResourceSkills(applicant.getResourceSkillsCodeLookups()),
						CommonUtil.getRateStr(applicant.getCurrencyType().getDisplayName(), applicant.getRate(),
								applicant.getRateTypeEnum().getDisplayName()),
						CommonUtil.getExperience(applicant.getYearsExperience(), applicant.getMonthsExperience()),
						applicant.getCountry()!=null?applicant.getCountry().getName():null,
						applicant.getAddress().getState().getName(), applicant.getGender().getDisplayName(), applicant.getActive(),
						applicant.getHigherEducation(), applicant.getPassingYear(), applicant.getStatusEnum(),
						applicant.getAppliedJobCount(), applicant.getDeploymenType().getDisplayName(),applicant.getUsdRate()==null?null:CommonUtil.getRateString(CurrencyTypeEnum.USD.getDisplayName(), applicant.getUsdRate(),
								applicant.getUsdRateType().getDisplayName()),applicant.getLocation()!=null?applicant.getLocation():null))
				.collect(Collectors.toList());
	}

	@Override
	public PageModel getApplicantResponse(ApplicantRequest applicantRequest) {
		Pageable pageable = PaginationUtil.getPageable(applicantRequest.getPaginationRequestModel());
		Page<Resource> applicants = null;
		List<DeploymentTypeEnum> deploymentTypeEnums = new ArrayList<>();
		if (applicantRequest.getWorkFrom() != null) {
			if (applicantRequest.getWorkFrom().equals(DeploymentTypeEnum.ONSITE.getDisplayName())) {
				deploymentTypeEnums.add(DeploymentTypeEnum.ONSITE);
				deploymentTypeEnums.add(DeploymentTypeEnum.REMOTE_AND_ONSITE);
			} else if (applicantRequest.getWorkFrom().equals(DeploymentTypeEnum.REMOTE.getDisplayName())) {
				deploymentTypeEnums.add(DeploymentTypeEnum.REMOTE);
				deploymentTypeEnums.add(DeploymentTypeEnum.REMOTE_AND_ONSITE);
			} else if (applicantRequest.getWorkFrom().equals(DeploymentTypeEnum.HYBRID.getDisplayName())) {
				deploymentTypeEnums.add(DeploymentTypeEnum.HYBRID);
			}
		}
		if (deploymentTypeEnums.isEmpty()) {
			deploymentTypeEnums.add(DeploymentTypeEnum.ONSITE);
			deploymentTypeEnums.add(DeploymentTypeEnum.REMOTE);
			deploymentTypeEnums.add(DeploymentTypeEnum.HYBRID);
			deploymentTypeEnums.add(DeploymentTypeEnum.REMOTE_AND_ONSITE);
		}

		if (applicantRequest.getCurrencyType().equals(CurrencyTypeEnum.INR)) {
			applicants = resourceRepository.findByVendorIdAndSkillsAndInrCurrencyOrderByUpdatedOnDesc(
					entityUtil.getCurrentVendorId(), applicantRequest.getSkills(), applicantRequest.getRateType(),
					applicantRequest.getUsdRateType(), deploymentTypeEnums, applicantRequest.getLocation(), pageable);
		} else if (applicantRequest.getCurrencyType().equals(CurrencyTypeEnum.USD)) {
			applicants = resourceRepository.findByVendorIdAndSkillsAndUsdCurrencyOrderByUpdatedOnDesc(
					entityUtil.getCurrentVendorId(), applicantRequest.getSkills(), applicantRequest.getRateType(),
					applicantRequest.getUsdRateType(),deploymentTypeEnums, applicantRequest.getLocation(), pageable);
		}

		return getPageModel(applicantRequest, applicants);
		
	}

	private PageModel getPageModel(ApplicantRequest applicantRequest, Page<Resource> applicants) {
		PageModel.PageModelBuilder pageModel = PageModel.builder().totalCount(applicants.getTotalElements())
				.pageCount(Long.valueOf(applicants.getTotalPages()))
				.data(applicants.getContent().stream()
						.map(applicant -> new ApplicantListResponse(applicant.getId(),
								applicant.getFirstName() + " " + applicant.getLastName(),
								applicant.getDesignation() != null ? applicant.getDesignation().getName() : null,
										getUserType(applicantRequest.getJobId(),applicant.getId()),
								resourceJobsService.existsByJobIdAndResourceIdAndDeletedFalseAndResourceStatus(
										applicantRequest.getJobId(), applicant.getId()) != null
												? resourceJobsService
														.existsByJobIdAndResourceIdAndDeletedFalseAndResourceStatus(
																applicantRequest.getJobId(), applicant.getId())
														.getResourceStatus()
												: null,
								applicant.getAvailability().getName(),
								applicant.getProfilePhoto() != null ? fileUpload
										.generatePresignedURL(applicant.getProfilePhoto().getPath())
										: null,
								getResourceSkills(applicant.getResourceSkillsCodeLookups()),
								getRate(applicant,applicantRequest.getJobId(),CurrencyTypeEnum.INR),
								CommonUtil.getExperience(applicant.getYearsExperience(), applicant.getMonthsExperience()),
								applicant.getCountry() != null?applicant.getCountry().getName():null,
								applicant.getCountry() != null?applicant.getCountry().getName():null, 
								applicant.getGender().getDisplayName(), applicant.getActive(),
								applicant.getHigherEducation(), applicant.getPassingYear(), applicant.getStatusEnum(),
								applicant.getAppliedJobCount(), applicant.getDeploymenType().getDisplayName(),getRate(applicant,applicantRequest.getJobId(),CurrencyTypeEnum.USD),applicant.getLocation()!=null?applicant.getLocation():null)).sorted(Comparator.comparingLong(ApplicantListResponse::getResourceId).reversed())
						.collect(Collectors.toList())
				);
		return pageModel.build();
	}

	private List<String> getResourceSkills(List<ResourceSkillsCodeLookup> skillsCodeLookup) {
		List<String> jobSkills = new ArrayList<>();
		skillsCodeLookup.forEach(skill -> {
			jobSkills.add(skill.getCodeLookup().getName());
		});
		return jobSkills;
	}

	private StatusCountResponse getResourceStatusCountResponse(List<Resource> resources) {
		Long verifiedCount = resources.stream().filter(resource -> StatusEnum.VERIFIED.equals(resource.getStatusEnum())
				&& Boolean.TRUE.equals(resource.getActive())).count();
		Long unVerifiedCount = resources.stream()
				.filter(resource -> StatusEnum.UNVERIFIED.equals(resource.getStatusEnum())
						&& Boolean.TRUE.equals(resource.getActive()))
				.count();
		Long onHoldCount = resources.stream().filter(resource -> Boolean.FALSE.equals(resource.getActive())
				&& (!StatusEnum.REJECTED.equals(resource.getStatusEnum()))).count();
		Long rejectedCount = resources.stream().filter(resource -> StatusEnum.REJECTED.equals(resource.getStatusEnum()))
				.count();
		return StatusCountResponse.builder().verified(CommonUtil.getCountOrZero(verifiedCount))
				.notVerified(CommonUtil.getCountOrZero(unVerifiedCount)).onHold(CommonUtil.getCountOrZero(onHoldCount))
				.rejected(CommonUtil.getCountOrZero(rejectedCount)).all(Long.valueOf(resources.size())).build();
	}

	@Override
	public StatusCountResponse getResourceStatusCount() {

		return getResourceStatusCountResponse(
				resourceRepository.findByVendorIdAndDeletedFalse(entityUtil.getCurrentVendorId()));
	}

	@Override
	public Page<Resource> getAllResourceByVendorId(Long vendorId, Pageable pageable) {
		// TODO Auto-generated method stub
		return resourceRepository.findByVendorIdAndDeletedFalse(vendorId,pageable);
	}

	@Override
	@Transactional
	public void updateSkills(ResourceSkillsRequest resourceSkillsRequest) throws Exception {
		Resource resource = findById(resourceSkillsRequest.getResourceId());
		resource.setLastModifiedDate(LocalDateTime.now());
     	resourceskillsCodeLookupService.deleteByResourceId(resource.getId());
		addResourceSkillsCodeLookup(resourceSkillsRequest, resource, CodeLookUpConstant.SKILLS_CODELOOKUP_CODE);
	}

	public void addResourceSkillsCodeLookup(ResourceSkillsRequest request, Resource resource, String code) {
		if (!CollectionUtils.isEmpty(request.getSkillsCodeLookups())) {
			request.getSkillsCodeLookups().forEach(resourceSkill -> {
				CodeLookup resourceSkillsCodeLookup = null;
				if (CommonUtil.isValid(resourceSkill.getValue())) {
					resourceSkillsCodeLookup = codeLookupService.findById(resourceSkill.getValue());
				} else {
					resourceSkillsCodeLookup = new CodeLookup();
					resourceSkillsCodeLookup.setActive(true);
					resourceSkillsCodeLookup.setDescription(resourceSkill.getDescription());
					resourceSkillsCodeLookup.setName(resourceSkill.getLabel());
					CodeLookupType codeLookupType = codeLookupTypeService.findByCode(code);
					resourceSkillsCodeLookup.setType(codeLookupType);
					codeLookupService.save(resourceSkillsCodeLookup);
				}
				ResourceSkillsCodeLookup skillsCodeLookup = resourceskillsCodeLookupService
						.findByResourceIdAndCodeLookupId(resource.getId(), resourceSkillsCodeLookup.getId());
				if (skillsCodeLookup == null) {
					skillsCodeLookup = new ResourceSkillsCodeLookup();
				}
				skillsCodeLookup.setResource(resource);
				skillsCodeLookup.setDeleted(Boolean.FALSE);
				skillsCodeLookup.setCodeLookup(resourceSkillsCodeLookup);
				resourceskillsCodeLookupService.save(skillsCodeLookup);
			});
		}
	}

	@Override
	public void updateTotalExperience(Long resourceId) {
		AtomicInteger totalMonthExp = new AtomicInteger(0);
		AtomicInteger totalYearExp = new AtomicInteger(0);
		Resource resource = findById(resourceId);
     	resource.getExperiences().stream().filter(resourceExperience->resourceExperience.getDeleted().equals(Boolean.FALSE)).forEach(savedExperience -> {
			int totalMonths = ResourceHelper.getNoOfMonths(savedExperience.getFromMonth(),
					savedExperience.getFromYear(),
					savedExperience.getPresentCompany().equals(Boolean.TRUE) ? LocalDate.now().getMonthValue()
							: savedExperience.getToMonth(),
					savedExperience.getPresentCompany().equals(Boolean.TRUE) ? LocalDate.now().getYear()
							: savedExperience.getToYear());
			totalMonthExp.addAndGet(totalMonths % 12);
			totalYearExp.addAndGet(totalMonths / 12);
		});
		resource.setYearsExperience(totalYearExp.get() + (totalMonthExp.get() / 12));
		resource.setMonthsExperience(totalMonthExp.get() % 12);
		save(resource);
		
	}

	@Override
	public BigDecimal rateWithCommission(BigDecimal resourceRate) {
		return CommonUtil.resourceRateWithCommission(resourceRate,staticConfigurationService.findByName(StaticConfigurationEnum.RESOURCE_COMMISSION).getValue());

	}
	
	private String getRate(Resource resource, Long jobId, CurrencyTypeEnum currencyTypeEnum) {
		ResourceJobs resourceJobs = resourceJobsService
				.existsByJobIdAndResourceIdAndDeletedFalseAndResourceStatus(jobId, resource.getId());
		String convertedRate=null;
		if(resourceJobs!=null&&!resourceJobs.getResourceStatus().equals(ResourceStatusEnum.INVITED)) {
			if(currencyTypeEnum.equals(CurrencyTypeEnum.INR))
			{
				convertedRate=	resourceJobs.getResourceInrRate() != null
						? CommonUtil.getRateStr(CurrencyTypeEnum.INR.getDisplayName(),
								resourceJobs.getResourceInrRate(), resourceJobs.getResourceInrRateType() != null
										? resourceJobs.getResourceInrRateType().getDisplayName()
										: resourceJobs.getResource().getRateTypeEnum().getDisplayName())
						: null;
				
			}else {

				convertedRate= resourceJobs.getResourceUsdRate() != null
						? CommonUtil.getRateStr(CurrencyTypeEnum.USD.getDisplayName(),
								resourceJobs.getResourceUsdRate(), resourceJobs.getResourceUsdRateType() != null
										? resourceJobs.getResourceUsdRateType().getDisplayName()
										: resourceJobs.getResource().getUsdRateType().getDisplayName())
						: null;
			}
			
		}
		else {
			if(currencyTypeEnum.equals(CurrencyTypeEnum.INR))
			convertedRate=resource.getRate() != null
					? CommonUtil.getRateStr(CurrencyTypeEnum.INR.getDisplayName(),
							CommonUtil.resourceRateWithCommission(resource.getRate(),
									staticConfigurationService
											.findByName(StaticConfigurationEnum.RESOURCE_COMMISSION)
											.getValue()),
							resource.getRateTypeEnum().getDisplayName())
					: null;
			else {
				
			
			convertedRate= resource.getUsdRate() != null
					? CommonUtil.getRateStr(CurrencyTypeEnum.USD.getDisplayName(),
							CommonUtil.resourceRateWithCommission(resource.getUsdRate(),
									staticConfigurationService
											.findByName(StaticConfigurationEnum.RESOURCE_COMMISSION)
											.getValue()),
							resource.getUsdRateType().getDisplayName())
					: null;
			}
		}

		return convertedRate;
	}

	@Override
	public StatusEnum updateStatus(StatusEnum statusEnum, Long id) throws Exception {
		Resource resource = findById(id);
		if(resource==null) {
			throw new Exception("Invalid id");
		}
		if(resource.getStatusEnum().equals(StatusEnum.REJECTED)&&statusEnum.equals(StatusEnum.UNVERIFIED))
		{
			 StatusEnum resourceStatus = codeLookUpRelationService.getStatusEnumRejectedByAdmin(
						codeLookUpRelationService.findByRefIdAndRefTypeAndType(resource.getId(), RefTypeEnum.RESOURCE,
								CodeLookUpRelationTypeEnum.RESOURCE_REJECT_REASON));
			 resource.setStatusEnum(resourceStatus);
		}
		save(resource);
	return	resource.getStatusEnum();
		
	}

//	@Override
//	public ResourceSkillsCodeLookup findByResourceId(Long id) {
//		// TODO Auto-generated method stub
//		return resourceSkillsCodeLookupRepository.findAllByResourceId(id);
//	}

	@Override
	public List<Long> getMatchingResources(Long jobId) {
		Job job = jobService.findById(jobId);
		return resourceRepository.getVerifiedResourcesByVendorIdNotAndExceptInvited(job.getVendor().getId(), jobId);
	}

	@Override
	public PageModel getMatchingResourceList(ApplicantRequest applicantRequest) {
		Pageable pageable = PaginationUtil.getPageable(applicantRequest.getPaginationRequestModel());
		Job job = jobService.findById(applicantRequest.getJobId());
		List<Long> resourceIds;
		List<DeploymentTypeEnum> deploymentTypeEnums =new ArrayList<>();
		String location = job.getLocation();
		CodeLookup country = job.getCountry();
		if (job.getWorkFrom() != null && job.getWorkFrom().equals(DeploymentTypeEnum.ONSITE)) {
			deploymentTypeEnums.add(DeploymentTypeEnum.ONSITE);
			deploymentTypeEnums.add(DeploymentTypeEnum.REMOTE_AND_ONSITE);
			resourceIds = this.getMatchingResources(applicantRequest.getJobId(), deploymentTypeEnums, country.getId(),
					location);
		} else if (job.getWorkFrom() != null && job.getWorkFrom().equals(DeploymentTypeEnum.REMOTE)) {
			location = null;
			deploymentTypeEnums.add(DeploymentTypeEnum.REMOTE);
			deploymentTypeEnums.add(DeploymentTypeEnum.REMOTE_AND_ONSITE);
			resourceIds = this.getMatchingResources(applicantRequest.getJobId(), deploymentTypeEnums, null,
					location);
		} else if (job.getWorkFrom() != null && job.getWorkFrom().equals(DeploymentTypeEnum.HYBRID)) {
			deploymentTypeEnums.add(DeploymentTypeEnum.HYBRID);
			resourceIds = this.getMatchingResources(applicantRequest.getJobId(), deploymentTypeEnums, country.getId(),
					location);
		} else {
			resourceIds = resourceService.getMatchingResources(applicantRequest.getJobId());
		}

		Integer resourceIdsSize = resourceIds.size();
		Page<Resource> applicants = null;
		if (applicantRequest.getCurrencyType().equals(CurrencyTypeEnum.INR)) {

			if (resourceIdsSize > 0) {
				applicants = resourceRepository.findResourceBySkillsResourceIdsForAdmin(applicantRequest.getSkills(),
						job.getVendor().getId(), StatusEnum.VERIFIED, applicantRequest.getRateType(),
						applicantRequest.getUsdRateType(), resourceIds, deploymentTypeEnums,
						location, pageable);
			} else {
				applicants = resourceRepository.findResourceBySkillsForAdmin(applicantRequest.getSkills(),
						job.getVendor().getId(), StatusEnum.VERIFIED, applicantRequest.getRateType(),
						applicantRequest.getUsdRateType(),deploymentTypeEnums,location, pageable);
			}
		} else if (applicantRequest.getCurrencyType().equals(CurrencyTypeEnum.USD)) {

			if (resourceIdsSize > 0) {
				applicants = resourceRepository.findResourceBySkillsResourceIdsForAdmin(applicantRequest.getSkills(),
						job.getVendor().getId(), StatusEnum.VERIFIED, applicantRequest.getRateType(),
						applicantRequest.getUsdRateType(), resourceIds,deploymentTypeEnums,location, pageable);
			} else {
				applicants = resourceRepository.findResourceBySkillsForAdmin(applicantRequest.getSkills(),
						job.getVendor().getId(), StatusEnum.VERIFIED, applicantRequest.getRateType(),
						applicantRequest.getUsdRateType(),deploymentTypeEnums,location, pageable);
			}

		}
		PageModel.PageModelBuilder pageModel = PageModel.builder().totalCount(applicants.getTotalElements())
				.pageCount(Long.valueOf(applicants.getTotalPages()))
				.data(applicants.getContent().stream()
						.map(applicant -> new MatchingResourceResponse(applicant.getId(),
								applicant.getFirstName() + " " + applicant.getLastName(),
								applicant.getDesignation() != null ? applicant.getDesignation().getName() : null,
								resourceJobsService.existsByJobIdAndResourceIdAndDeletedFalseAndResourceStatus(
										applicantRequest.getJobId(), applicant.getId()) != null
												? resourceJobsService
														.existsByJobIdAndResourceIdAndDeletedFalseAndResourceStatus(
																applicantRequest.getJobId(), applicant.getId())
														.getResourceStatus()
												: null,
								applicant.getAvailability().getName(),
								applicant.getVendor().getAgencyName() != null ? applicant.getVendor().getAgencyName()
										: null,
								applicant.getVendor().getUser().getId(),
								applicant.getProfilePhoto() != null
										? fileUpload.generatePresignedURL(applicant.getProfilePhoto().getPath())
										: null,
								getResourceSkills(applicant.getResourceSkillsCodeLookups()),
								getRate(applicant, applicantRequest.getJobId(), CurrencyTypeEnum.INR),
								CommonUtil.getExperience(applicant.getYearsExperience(),
										applicant.getMonthsExperience()),
								applicant.getCountry() != null ? applicant.getCountry().getName() : null,
								applicant.getCountry() != null ? applicant.getCountry().getName() : null,
								applicant.getGender().getDisplayName(), applicant.getActive(),
								applicant.getHigherEducation(), applicant.getPassingYear(), applicant.getStatusEnum(),
								applicant.getAppliedJobCount(), applicant.getDeploymenType().getDisplayName(),
								getRate(applicant, applicantRequest.getJobId(), CurrencyTypeEnum.USD),
								applicant.getLocation() != null ? applicant.getLocation() : null))
						.sorted(Comparator.comparingLong(MatchingResourceResponse::getResourceId).reversed())
						.collect(Collectors.toList()));
		return pageModel.build();
	}

	private List<Long> getMatchingResources(Long jobId, List<DeploymentTypeEnum> deploymentTypeEnums, Long countryId,
			String location) {
		Job job = jobService.findById(jobId);
		return resourceRepository.getVerifiedResourcesByVendorIdNotAndExceptInvited(job.getVendor().getId(), jobId,
				deploymentTypeEnums, countryId, location);

	}

	public UserType getUserType(Long jobId, Long resourceId) {
		ResourceJobs resourceJobs = resourceJobsService
				.existsByJobIdAndResourceIdAndDeletedFalseAndResourceStatus(jobId, resourceId);
		return resourceJobs != null && resourceJobs.getAppliedBy() != null ? resourceJobs.getAppliedBy().getUserType()
				: null;
	}
}
