/**
 * 
 */
package com.daynilgroup.vendormanagement.model.request;

import java.io.Serializable;
import java.util.List;

import com.daynilgroup.vendormanagement.constants.CurrencyTypeEnum;
import com.daynilgroup.vendormanagement.constants.RateTypeEnum;
import com.daynilgroup.vendormanagement.model.pag.PaginationRequestModel;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

/**
 * @author Prerana
 *
 */
@Getter
@Setter
@FieldDefaults(level = AccessLevel.PRIVATE)
public class ApplicantRequest implements Serializable {

	static final long serialVersionUID = 1L;

	List<String> skills;

	Long JobId;
	
	String message;
	
	PaginationRequestModel paginationRequestModel;
	
	CurrencyTypeEnum currencyType;
	
	RateTypeEnum rateType;
	
	RateTypeEnum usdRateType;
	
	String workFrom;
	
	String location;

}
