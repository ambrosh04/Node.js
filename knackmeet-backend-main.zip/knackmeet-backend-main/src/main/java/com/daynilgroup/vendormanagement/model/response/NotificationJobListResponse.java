package com.daynilgroup.vendormanagement.model.response;

import java.util.List;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class NotificationJobListResponse {
	static final long serialVersionUID = 1L;

	Long id;

	List<String> skills;

	String title;

	Integer minExp;

	Integer maxExp;

}
