package com.daynilgroup.vendormanagement.constants;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.experimental.FieldDefaults;

/**
 * @author Manish
 *
 */
@Getter
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public enum SearchType {

	HIRE_DEVELOPER("Hire Developer"), JOBS_OR_PROJECTS("Jobs/Projects");

	String displayName;
}