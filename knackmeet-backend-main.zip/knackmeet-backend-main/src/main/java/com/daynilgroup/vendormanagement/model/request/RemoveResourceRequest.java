/**
 * 
 */
package com.daynilgroup.vendormanagement.model.request;

import java.io.Serializable;

import lombok.AccessLevel;
import lombok.Data;
import lombok.experimental.FieldDefaults;

/**
 * @author Prerana
 *
 */
@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
public class RemoveResourceRequest implements Serializable {

	static final long serialVersionUID = 1L;
	
	Long removedResourceId;
	
	CodeLookUpRelationRequest codeLookUpRelationRequests;

}
