package com.daynilgroup.vendormanagement.request;

import java.math.BigDecimal;
import java.util.List;

import com.daynilgroup.vendormanagement.constants.DeploymentTypeEnum;
import com.daynilgroup.vendormanagement.constants.EmploymentTypeEnum;
import com.daynilgroup.vendormanagement.model.response.AdvanceSearchDropdownModel;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class ExperienceRequest {

	Long id;

	AdvanceSearchDropdownModel title;

	EmploymentTypeEnum employmentType;

	CompanyRequest company;

	String companyAddress;

	BigDecimal companyLatitude;

	BigDecimal companyLongitude;

	DeploymentTypeEnum deploymentType;

	Integer fromMonth;

	Integer toMonth;

	Integer fromYear;

	Integer toYear;

	AdvanceSearchDropdownModel industry;

	String description;

	List<AdvanceSearchDropdownModel> skillsCodeLookups;

	Long resourceId;
	
	Boolean presentCompany;

}
