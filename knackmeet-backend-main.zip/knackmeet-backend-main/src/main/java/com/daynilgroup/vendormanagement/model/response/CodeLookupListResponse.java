package com.daynilgroup.vendormanagement.model.response;

import com.daynilgroup.vendormanagement.constants.StatusEnum;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.experimental.FieldDefaults;

@Data
@Builder
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class CodeLookupListResponse {
	Long id;

	String name;

	String description;

	Long typeId;

	String type;

	Long parentId;

	Boolean active;

	StatusEnum status;

	String coverImage;

	Integer displayOrder;

	String typeParentName;
}
