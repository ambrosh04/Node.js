/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.daynilgroup.vendormanagement.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.daynilgroup.vendormanagement.constants.Constants;
import com.daynilgroup.vendormanagement.constants.UserType;
import com.daynilgroup.vendormanagement.entity.User;
import com.daynilgroup.vendormanagement.service.UserService;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;

/**
 *
 * @author prerana
 */
@Service
@FieldDefaults(level = AccessLevel.PRIVATE)
public class CustomUserDetailService implements UserDetailsService {

	@Autowired
	UserService userService;

	@Override
	public UserDetails loadUserByUsername(String loginId) throws UsernameNotFoundException {
		if (StringUtils.hasText(loginId)) {
			User user;
			if (loginId.contains(Constants.SEPERATOR)) {
				String[] split = loginId.split(Constants.SEPERATOR);
				UserType userType = UserType.valueOf(split[1]);
				user = userService.findByEmailIdOrMobileAndUserType(split[0], userType);
			} else {
				user = userService.findByEmailIdOrMobile(loginId);
			}
			if (user == null) {
				throw new UsernameNotFoundException("Invalid username or password");
			}
			String username = StringUtils.hasText(user.getEmailId()) ? user.getEmailId() : user.getMobile();
			CustomUserDetail customUserDetail = new CustomUserDetail();
			customUserDetail.setId(user.getId());
//			customUserDetail.setLocale(Constants.DEFAULT_LOCALE);
			customUserDetail.setPassword(user.getPassword());
			customUserDetail.setUsername(username + Constants.SEPERATOR + user.getUserType());
			customUserDetail.setUserType(user.getUserType());
			customUserDetail.setTimeZone(user.getTimeZone());
			return customUserDetail;
		} else {
			throw new UsernameNotFoundException("User name is required");
		}
	}
}
