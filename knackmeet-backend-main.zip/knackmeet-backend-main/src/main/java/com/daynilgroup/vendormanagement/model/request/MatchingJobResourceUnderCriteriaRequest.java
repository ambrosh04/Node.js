package com.daynilgroup.vendormanagement.model.request;

import java.math.BigDecimal;
import java.util.List;

import com.daynilgroup.vendormanagement.constants.CurrencyTypeEnum;
import com.daynilgroup.vendormanagement.constants.JobResourceEnum;
import com.daynilgroup.vendormanagement.constants.MatchingCriteria;
import com.daynilgroup.vendormanagement.constants.RateTypeEnum;
import com.daynilgroup.vendormanagement.model.pag.PaginationRequestModel;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class MatchingJobResourceUnderCriteriaRequest {
	Long id;

	JobResourceEnum jobResourceEnum;

	List<String> skills;

	PaginationRequestModel paginationRequestModel;

	BigDecimal minRate;

	BigDecimal maxRate;

	Integer minExp;

	Integer maxExp;

	String jobTitle;

	String workFrom;
	
	MatchingCriteria matchingCriteria;
	
	BigDecimal rate;
	
	Integer expInYear;
	
	Integer expInMonths;
	
	String designation;
	
	BigDecimal usdRate;
	
	CurrencyTypeEnum currencyType;
	
	RateTypeEnum rateType;
	
	RateTypeEnum usdRateType;
	
	Long userId;
	
	String location;
	

}
