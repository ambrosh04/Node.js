package com.daynilgroup.vendormanagement.service.impl;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.daynilgroup.commons.events.enums.EventType;
import com.daynilgroup.commons.events.util.EventPublisher;
import com.daynilgroup.commons.events.wrapper.EventCreateWrapper;
import com.daynilgroup.vendormanagement.constants.Constants;
import com.daynilgroup.vendormanagement.constants.CurrencyTypeEnum;
import com.daynilgroup.vendormanagement.constants.DeploymentTypeEnum;
import com.daynilgroup.vendormanagement.constants.InvitationStatusEnum;
import com.daynilgroup.vendormanagement.constants.RateTypeEnum;
import com.daynilgroup.vendormanagement.constants.ResourceStatusEnum;
import com.daynilgroup.vendormanagement.constants.StaticConfigurationEnum;
import com.daynilgroup.vendormanagement.constants.StatusEnum;
import com.daynilgroup.vendormanagement.entity.Job;
import com.daynilgroup.vendormanagement.entity.Resource;
import com.daynilgroup.vendormanagement.entity.ResourceJobs;
import com.daynilgroup.vendormanagement.entity.ResourceSkillsCodeLookup;
import com.daynilgroup.vendormanagement.entity.SkillsCodeLookup;
import com.daynilgroup.vendormanagement.entity.Vendor;
import com.daynilgroup.vendormanagement.model.filter.JobsFilterModel;
import com.daynilgroup.vendormanagement.model.filter.ResourceFilterModel;
import com.daynilgroup.vendormanagement.model.inf.DateUtil;
import com.daynilgroup.vendormanagement.model.pag.PageModel;
import com.daynilgroup.vendormanagement.model.request.ApplicationRequest;
import com.daynilgroup.vendormanagement.model.request.InviteRequest;
import com.daynilgroup.vendormanagement.model.request.MatchingJobResourceBySkillsRequest;
import com.daynilgroup.vendormanagement.model.request.MatchingJobResourceUnderCriteriaRequest;
import com.daynilgroup.vendormanagement.model.request.ResourceJobFilterRequest;
import com.daynilgroup.vendormanagement.model.response.CountResponse;
import com.daynilgroup.vendormanagement.model.response.JobListResponse;
import com.daynilgroup.vendormanagement.model.response.ResourceDetailResponse;
import com.daynilgroup.vendormanagement.model.response.ResourceListResponse;
import com.daynilgroup.vendormanagement.repository.JobRepository;
import com.daynilgroup.vendormanagement.repository.ResourceJobCustomRepository;
import com.daynilgroup.vendormanagement.repository.ResourceJobsRepository;
import com.daynilgroup.vendormanagement.repository.ResourceRepository;
import com.daynilgroup.vendormanagement.request.InvitationsSendRequest;
import com.daynilgroup.vendormanagement.service.JobService;
import com.daynilgroup.vendormanagement.service.ResourceJobsService;
import com.daynilgroup.vendormanagement.service.ResourceService;
import com.daynilgroup.vendormanagement.service.ResourceSkillsCodeLookupService;
import com.daynilgroup.vendormanagement.service.SkillsCodeLookupService;
import com.daynilgroup.vendormanagement.service.StaticConfigurationService;
import com.daynilgroup.vendormanagement.service.VendorService;
import com.daynilgroup.vendormanagement.util.CommonUtil;
import com.daynilgroup.vendormanagement.util.EmailSenderUtil;
import com.daynilgroup.vendormanagement.util.EntityUtil;
import com.daynilgroup.vendormanagement.util.FileUpload;
import com.daynilgroup.vendormanagement.util.PaginationUtil;
import com.google.gson.Gson;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@FieldDefaults(level = AccessLevel.PRIVATE)
public class ResourceJobsServiceImpl implements ResourceJobsService {

	@Autowired
	ResourceJobsRepository resourceJobsRepository;

	@Autowired
	ResourceJobCustomRepository resourceJobCustomRepository;

	@Autowired
	ResourceService resourceService;

	@Autowired
	JobRepository jobRepository;

	@Autowired
	ResourceRepository resourceRepository;

	@Autowired
	ResourceSkillsCodeLookupService resourceSkillsCodeLookupService;

	@Autowired
	SkillsCodeLookupService skillsCodeLookupService;

	@Autowired
	FileUpload fileUpload;

	@Autowired
	EntityUtil entityUtil;

	@Autowired
	JobService jobService;

	@Value("${domain.url}")
	String domainUrl;

	@Autowired
	EmailSenderUtil emailSenderUtil;

	@Autowired
	EventPublisher eventPublisher;
	
	@Autowired
	StaticConfigurationService staticConfigurationService;
	
	@Autowired
	ResourceJobsService resourceJobsService;
	
	@Autowired
	VendorService vendorService;

	@Override
	public JpaRepository<ResourceJobs, Long> getJpaRepository() {
		return resourceJobsRepository;
	}

	@Override
	public Page<ResourceJobs> getList(Pageable pageable) {
		return resourceJobsRepository.findByVendorId(entityUtil.getCurrentVendorId(), pageable);
	}

	@Override
	public List<ResourceJobs> getListByJobId(Long id) {
		return resourceJobsRepository.findByJobId(id);
	}

	@Override
	public Long getNoOfJobApplied(Long id, ResourceStatusEnum resourceStatusEnum) {
		return resourceJobsRepository.countByJobIdAndResourceStatus(id, resourceStatusEnum);
	}

	@Override
	public List<ResourceJobs> getResourceStatusList(Long id) {
		return resourceJobsRepository.findByJobId(id);
	}

	@Override
	public void updateResourceStatus(Long jobId, Long resourceId, ResourceStatusEnum resourceStatusEnum,String rejectReason)
			throws Exception {
		ResourceJobs resourceJob = resourceJobsRepository.findByJobIdAndResourceIdAndDeletedFalse(jobId, resourceId);

		if (!ObjectUtils.isEmpty(resourceJob)) {
			Job job = jobService.findById(jobId);
			Resource resource = resourceService.findById(resourceId);
			resourceJob.setResourceStatus(resourceStatusEnum);
			save(resourceJob);
			notificationForStatusChange(jobId, resourceId, resourceStatusEnum, job, resource);

			sendUpdateStatusEmail(job, resource, resourceStatusEnum,rejectReason);

		} else {
			throw new Exception("No Job Found Against Resource Id " + resourceId);
		}
	}

	private void notificationForStatusChange(Long jobId, Long resourceId, ResourceStatusEnum resourceStatusEnum,
			Job job, Resource resource) {
		try {

			EventCreateWrapper wrapper = new EventCreateWrapper();

			Map<String, Object> jsonDataMap = new HashMap<>();
			jsonDataMap.put(Constants.RESOURCE_SMALL_CASE, resource.getFirstName());
			jsonDataMap.put(Constants.JOB_SMALL_CASE, job.getTitle());

			wrapper.setEventType(EventType.IN_APP);
			wrapper.setJsonData(jsonDataMap);
			wrapper.setMetaData(entityUtil.setMetaDataInNotification(jobId, resourceId, job, resource));
			wrapper.setVisibleToAll(false);
			wrapper.setUsersToNotify(Arrays.asList(resource.getVendor().getUser().getEmailId()));
			wrapper.setMessageTemplateType(resourceStatusEnum.getDisplayName());
			log.info("wrapper to publish : {}", new Gson().toJson(wrapper));
			eventPublisher.publishEvent(wrapper);
		} catch (Exception e) {
			e.printStackTrace();
			log.error(e.getMessage(), e);
		}
	}

	@Override
	public Long getCountApplicationByvendorId(Long vendorId) {
		return resourceJobsRepository.getResourceApplicationCount(vendorId);
	}

	@Override
	public Long getCountJobApllication(Long vendorId) {

		return resourceJobsRepository.getJobApplicationCount(vendorId);
	}

	@Override
	public Page<ResourceJobs> getApplicationList(ApplicationRequest applicationRequest) {
		LocalDateTime localDateTime1 = null;
		LocalDateTime localDateTime2 = null;
		String listOrder=Constants.DESCEDNING;
		if (applicationRequest.getStartDate() != null && applicationRequest.getEndDate() != null) {
			String startDate = applicationRequest.getStartDate();
			localDateTime1 = LocalDateTime.parse(startDate, DateUtil.dateTimeFormatter());

			String endDate = applicationRequest.getEndDate();
			localDateTime2 = LocalDateTime.parse(endDate, DateUtil.dateTimeFormatter());
			listOrder=Constants.ASCEDNING;
		}
		return resourceJobsRepository.getApplicationList(entityUtil.getCurrentVendorId(),
				applicationRequest.getResourceStatus(), applicationRequest.getName(), localDateTime1, localDateTime2,listOrder,
				PaginationUtil.getPageable(applicationRequest.getPaginationRequestModel()));

	}

	@Override
	public List<ResourceJobs> findAllJobApplicationByVendorId(Long vendorId) {
		return resourceJobsRepository.findAllJobApplicationByVendorId(vendorId);
	}

	@Override
	public void resourceJobsSoftDelete(Long jobId, Long resourceId) {
		resourceJobsRepository.resourceJobsSoftDelete(jobId, resourceId);
	}

	@Override
	public Boolean existsByJobIdAndResourceIdAndDeletedFalse(Long jobId, Long resourceId) {
		return resourceJobsRepository.existsByJobIdAndResourceIdAndDeletedFalse(jobId, resourceId);
	}

	@Override
	public PageModel getResourceListByStatus(ResourceFilterModel resourceJobFilterModel) {
		PageModel pageModel = resourceJobCustomRepository.getResourceListByStatus(resourceJobFilterModel);
		if (!ObjectUtils.isEmpty(pageModel.getData())) {
			List<ResourceListResponse> data = (List<ResourceListResponse>) pageModel.getData();
			for (ResourceListResponse resourceListResponse : data) {
				Resource resource = resourceService.findById(resourceListResponse.getResourceId());
				List<String> skills = new ArrayList<>();
				List<ResourceSkillsCodeLookup> skillsCodeLookup = resourceSkillsCodeLookupService
						.findAllByResourceId(resource.getId());
				skillsCodeLookup.forEach(skill -> {
					skills.add(skill.getCodeLookup() != null ? skill.getCodeLookup().getName() : null);
				});
				resourceListResponse.setSkills(skills);
				resourceListResponse.setBase64MediaString(resource != null
						? fileUpload.generatePresignedURL(resource.getProfilePhoto().getPath())
						: null);
				if(resourceListResponse.getResourceStatus().equals(ResourceStatusEnum.INVITED.getDisplayName()))
				{
					resourceListResponse.setUsdRate(resource.getUsdRate()!=null?CommonUtil.getRateStr(CurrencyTypeEnum.USD.getDisplayName(), CommonUtil.resourceRateWithCommission(resource.getUsdRate(), staticConfigurationService.findByName(StaticConfigurationEnum.RESOURCE_COMMISSION).getValue()), resource.getUsdRateType().getDisplayName()):null);
					resourceListResponse.setRate(resource.getRate()!=null?CommonUtil.getRateStr(CurrencyTypeEnum.INR.getDisplayName(), CommonUtil.resourceRateWithCommission(resource.getRate(), staticConfigurationService.findByName(StaticConfigurationEnum.RESOURCE_COMMISSION).getValue()), resource.getRateTypeEnum().getDisplayName()):null);
				}
				resourceListResponse.setLocation(resource.getLocation()!=null?resource.getLocation():null);
			}
		}
		;
		return pageModel;
	}

	@Override
	public PageModel getJobListByResourceId(JobsFilterModel jobsFilterModel) {
		PageModel pageModel = resourceJobCustomRepository.getJobListByResourceId(jobsFilterModel);
		if (!ObjectUtils.isEmpty(pageModel.getData())) {
			List<JobListResponse> jobListResponse = (List<JobListResponse>) pageModel.getData();
			jobListResponse.forEach(jobs -> {
				List<String> skills = new ArrayList<>();
				List<SkillsCodeLookup> skillsCodeLookups = skillsCodeLookupService.findAllByJobId(jobs.getJobId());
				if (!CollectionUtils.isEmpty(skillsCodeLookups)) {
					skillsCodeLookups.forEach(skill -> {
						skills.add(skill.getCodeLookup().getName());
					});
					jobs.setSkills(skills);
				}
				if (!jobs.getResourceStatus().equals(ResourceStatusEnum.HIRED.getDisplayName())
						&& !jobs.getResourceStatus().equals(ResourceStatusEnum.SHORTLISTED.getDisplayName())
						&& !jobs.getResourceStatus().equals(ResourceStatusEnum.REJECTED.getDisplayName())&&!jobs.getResourceStatus().equals(ResourceStatusEnum.APPLIED.getDisplayName())) {
					ResourceJobs resourceJobs = resourceJobsService.findById(jobs.getId());
					Resource resource = resourceJobs.getResource();
					jobs.setUsdRate(resource.getUsdRate()!=null?CommonUtil.getRateStr(CurrencyTypeEnum.USD.getDisplayName(), CommonUtil.resourceRateWithCommission(resource.getUsdRate(), staticConfigurationService.findByName(StaticConfigurationEnum.RESOURCE_COMMISSION).getValue()), resource.getUsdRateType().getDisplayName()):null);
					jobs.setRate(resource.getRate()!=null?CommonUtil.getRateStr(CurrencyTypeEnum.INR.getDisplayName(), CommonUtil.resourceRateWithCommission(resource.getRate(), staticConfigurationService.findByName(StaticConfigurationEnum.RESOURCE_COMMISSION).getValue()), resource.getRateTypeEnum().getDisplayName()):null);				
				}
				
			});
		}
		return pageModel;

	}

	@Override
	public List<ResourceJobs> getApplicationCountList() {

		return resourceJobsRepository.getResourceApplicationCountList(entityUtil.getCurrentVendorId());
	}

	private CountResponse getCountResponse(List<ResourceJobs> resourceApplicationList) {

		Long appliedCount = resourceApplicationList.stream()
				.filter(resourceJob -> ResourceStatusEnum.APPLIED == resourceJob.getResourceStatus()).count();
		Long shortListedCount = resourceApplicationList.stream()
				.filter(resourceJob -> ResourceStatusEnum.SHORTLISTED == resourceJob.getResourceStatus()).count();
		Long hiredCount = resourceApplicationList.stream()
				.filter(resourceJob -> ResourceStatusEnum.HIRED == resourceJob.getResourceStatus()).count();
		Long rejectedCount = resourceApplicationList.stream()
				.filter(resourceJob -> ResourceStatusEnum.REJECTED == resourceJob.getResourceStatus()).count();
		Long invitationSentOrReceivedCount = resourceApplicationList.stream()
				.filter(resourceJob -> ResourceStatusEnum.INVITED == resourceJob.getResourceStatus()).count();

		CountResponse.CountResponseBuilder builder = CountResponse.builder()
				.applied(CommonUtil.getCountOrZero(appliedCount)).hired(CommonUtil.getCountOrZero(hiredCount))
				.rejected(CommonUtil.getCountOrZero(rejectedCount))
				.invitationSentOrReceived(CommonUtil.getCountOrZero(invitationSentOrReceivedCount))
				.all(CommonUtil.getCountOrZero(appliedCount) + CommonUtil.getCountOrZero(hiredCount)
						+ CommonUtil.getCountOrZero(rejectedCount) + CommonUtil.getCountOrZero(shortListedCount)
						+ CommonUtil.getCountOrZero(invitationSentOrReceivedCount))

				.shortlisted(CommonUtil.getCountOrZero(shortListedCount));
		return builder.build();

	}

	@Override
	public CountResponse getResourceCountList(Long jobId) {
		List<ResourceJobs> resourceCountList = resourceJobsRepository.getResourceCountList(jobId);
		return getCountResponse(resourceCountList);
	}

	@Override
	public CountResponse getJobCountList(Long resourceId) {
		List<ResourceJobs> jobCountList = resourceJobsRepository.getJobCountList(resourceId);
		return getCountResponse(jobCountList);
	}

	@Override
	public void resourceJobsSoftDelete(Long vendorId) {
		// TODO Auto-generated method stub

	}

	@Override
	public Page<ResourceJobs> findAllJobApplication(ResourceJobFilterRequest resourceJobFilterRequest,
			Pageable pageable) {

		LocalDateTime localDateTime1 = null;
		LocalDateTime localDateTime2 = null;
		String listOrder=Constants.DESCEDNING;
		if (resourceJobFilterRequest.getStartDate() != null && resourceJobFilterRequest.getEndDate() != null) {
			String startDate = resourceJobFilterRequest.getStartDate();
			localDateTime1 = LocalDateTime.parse(startDate, DateUtil.dateTimeFormatter());

			String endDate = resourceJobFilterRequest.getEndDate();
			localDateTime2 = LocalDateTime.parse(endDate, DateUtil.dateTimeFormatter());
			listOrder=Constants.ASCEDNING;
		}

		return resourceJobsRepository.findAllJobApplication(entityUtil.getCurrentVendorId(),
				resourceJobFilterRequest.getTitle(), resourceJobFilterRequest.getResourceStatusEnum(), localDateTime1,
				localDateTime2,listOrder, pageable);

	}

	@Override
	public List<Job> getMatchingJob(MatchingJobResourceUnderCriteriaRequest matchingJobResourceRequest) {
		
		List<DeploymentTypeEnum> deploymentTypeEnums = new ArrayList<>();
		if (matchingJobResourceRequest.getWorkFrom() != null
				&& matchingJobResourceRequest.getWorkFrom().equals(DeploymentTypeEnum.ONSITE)) {
			deploymentTypeEnums.add(DeploymentTypeEnum.ONSITE);

		} else if (matchingJobResourceRequest.getWorkFrom() != null
				&& matchingJobResourceRequest.getWorkFrom().equals(DeploymentTypeEnum.REMOTE)) {
			deploymentTypeEnums.add(DeploymentTypeEnum.REMOTE);
		} else if (matchingJobResourceRequest.getWorkFrom() != null
				&& matchingJobResourceRequest.getWorkFrom().equals(DeploymentTypeEnum.HYBRID)) {
			deploymentTypeEnums.add(DeploymentTypeEnum.HYBRID);
		} else if (matchingJobResourceRequest.getWorkFrom() != null
				&& matchingJobResourceRequest.getWorkFrom()
						.equals(DeploymentTypeEnum.REMOTE_AND_ONSITE)) {
			deploymentTypeEnums.add(DeploymentTypeEnum.REMOTE);
			deploymentTypeEnums.add(DeploymentTypeEnum.ONSITE);
		} 
		
		else {
			deploymentTypeEnums.add(DeploymentTypeEnum.REMOTE);
			deploymentTypeEnums.add(DeploymentTypeEnum.ONSITE);
			deploymentTypeEnums.add(DeploymentTypeEnum.HYBRID);

		}
		if (matchingJobResourceRequest.getId() != null) {
			return jobRepository.findByMatchingIdJobBySkills(matchingJobResourceRequest.getSkills(),
					matchingJobResourceRequest.getUserId() != null
							&& vendorService.findByUserId(matchingJobResourceRequest.getUserId()) != null
									? vendorService.findByUserId(matchingJobResourceRequest.getUserId()).getId()
									: entityUtil.getCurrentVendorId(),
					matchingJobResourceRequest.getId(), StatusEnum.VERIFIED, matchingJobResourceRequest.getRateType(),
					matchingJobResourceRequest.getUsdRateType(),deploymentTypeEnums, matchingJobResourceRequest.getLocation());

		} else

		{
			return jobRepository.findByJobBySkills(matchingJobResourceRequest.getSkills(),
					matchingJobResourceRequest.getUserId() != null
							&& vendorService.findByUserId(matchingJobResourceRequest.getUserId()) != null
									? vendorService.findByUserId(matchingJobResourceRequest.getUserId()).getId()
									: entityUtil.getCurrentVendorId(),
					StatusEnum.VERIFIED, matchingJobResourceRequest.getRateType(),
					matchingJobResourceRequest.getUsdRateType(),deploymentTypeEnums,matchingJobResourceRequest.getLocation());
		}
	}

	@Override
	public List<Resource> getMatchingResource(MatchingJobResourceUnderCriteriaRequest matchingJobResourceRequest) {

		List<DeploymentTypeEnum> deploymentTypeEnums = new ArrayList<>();
		if (matchingJobResourceRequest.getWorkFrom() != null) {
			if (matchingJobResourceRequest.getWorkFrom().equals(DeploymentTypeEnum.ONSITE.getDisplayName())) {
				deploymentTypeEnums.add(DeploymentTypeEnum.ONSITE);
				deploymentTypeEnums.add(DeploymentTypeEnum.REMOTE_AND_ONSITE);

			} else if (matchingJobResourceRequest.getWorkFrom().equals(DeploymentTypeEnum.REMOTE.getDisplayName())) {

				deploymentTypeEnums.add(DeploymentTypeEnum.REMOTE);
				deploymentTypeEnums.add(DeploymentTypeEnum.REMOTE_AND_ONSITE);

			} else if (matchingJobResourceRequest.getWorkFrom().equals(DeploymentTypeEnum.HYBRID.getDisplayName())) {
				deploymentTypeEnums.add(DeploymentTypeEnum.HYBRID);
			}
		} else {
			deploymentTypeEnums.add(DeploymentTypeEnum.ONSITE);
			deploymentTypeEnums.add(DeploymentTypeEnum.REMOTE);
			deploymentTypeEnums.add(DeploymentTypeEnum.REMOTE_AND_ONSITE);
			deploymentTypeEnums.add(DeploymentTypeEnum.HYBRID);

		}
		if (matchingJobResourceRequest.getId() != null) {
			return resourceRepository.findResourceBySkillswithoutPagable(matchingJobResourceRequest.getSkills(),
					matchingJobResourceRequest.getUserId() != null
							&& vendorService.findByUserId(matchingJobResourceRequest.getUserId()) != null
									? vendorService.findByUserId(matchingJobResourceRequest.getUserId()).getId()
									: entityUtil.getCurrentVendorId(),
					matchingJobResourceRequest.getId(), StatusEnum.VERIFIED, matchingJobResourceRequest.getRateType(),
					matchingJobResourceRequest.getUsdRateType(),deploymentTypeEnums,matchingJobResourceRequest.getLocation());
		} else {
			return resourceRepository.findResourceBySkillswithoutPagable(matchingJobResourceRequest.getSkills(),
					matchingJobResourceRequest.getUserId() != null
							&& vendorService.findByUserId(matchingJobResourceRequest.getUserId()) != null
									? vendorService.findByUserId(matchingJobResourceRequest.getUserId()).getId()
									: entityUtil.getCurrentVendorId(),
					StatusEnum.VERIFIED, matchingJobResourceRequest.getRateType(),
					matchingJobResourceRequest.getUsdRateType(),deploymentTypeEnums,matchingJobResourceRequest.getLocation());
		}
	}

	public ResourceJobs findByJobIdAndResourceIdAndDeletedFalse(Long jobId, Long resourceId) {
		return resourceJobsRepository.findByJobIdAndResourceIdAndDeletedFalse(jobId, resourceId);
	}

	@Override
	public Page<ResourceJobs> getNotification(Pageable pageable) {
		return resourceJobsRepository.getNotifiation(entityUtil.getCurrentVendorId(), pageable);
	}

	@Override
	public ResourceJobs existsByJobIdAndResourceId(Long jobId, Long resourceId) {

		Boolean resourceJobs = resourceJobsRepository.existsByJobIdAndResourceIdAndDeletedTrue(jobId, resourceId);

		if (!resourceJobs)
			return resourceJobsRepository.findByJobIdAndResourceIdAndDeletedFalse(jobId, resourceId);
		else
			return resourceJobsRepository.findByJobIdAndResourceIdAndDeletedTrue(jobId, resourceId);
	}

	/**
	 * return the boolean of deleted resourceJobs by jobId and resourceId.
	 */
	@Override
	public Boolean existsByJobIdAndResourceIdAndDeletedTrue(Long jobId, Long resourceId) {
		return resourceJobsRepository.existsByJobIdAndResourceIdAndDeletedTrue(jobId, resourceId);
	}

	@Override
	public ResourceJobs findByJobIdAndResourceId(Long jobId, Long resourceId) {
		return resourceJobsRepository.findByJobIdAndResourceId(jobId, resourceId);
	}

	@Override
	public void invite(InviteRequest inviteRequest) {
		try {

			Job job = jobService.findById(inviteRequest.getJobId());
			Resource resource = resourceService.findById(inviteRequest.getResourceId());

			EventCreateWrapper wrapper = new EventCreateWrapper();

			Map<String, Object> jsonDataMap = new HashMap<>();
			jsonDataMap.put(Constants.RESOURCE_SMALL_CASE, resource.getFirstName());
			jsonDataMap.put(Constants.JOB_SMALL_CASE, job.getTitle());

			wrapper.setEventType(EventType.IN_APP);
			wrapper.setJsonData(jsonDataMap);
			wrapper.setMetaData(entityUtil.setMetaDataInNotification(inviteRequest.getJobId(),
					inviteRequest.getResourceId(), job, resource));
			wrapper.setVisibleToAll(false);
			wrapper.setUsersToNotify(Arrays.asList(resource.getVendor().getUser().getEmailId()));
			wrapper.setMessageTemplateType(Constants.INVITE);
			log.info("wrapper to publish : {}", new Gson().toJson(wrapper));
			eventPublisher.publishEvent(wrapper);
		} catch (Exception e) {
			e.printStackTrace();
			log.error(e.getMessage(), e);
		}
	}

	@Override
	public Page<Job> getMatchingJobOnly(MatchingJobResourceBySkillsRequest matchingJobResourceRequestOnly,
			Pageable pageble) {
		if (matchingJobResourceRequestOnly.getId() != null) {

			return jobRepository.findByJobBySkills(matchingJobResourceRequestOnly.getSkills(),
					entityUtil.getCurrentVendorId(), matchingJobResourceRequestOnly.getId(), pageble,
					StatusEnum.VERIFIED);
		} else

		{

			return jobRepository.findByJobBySkills(matchingJobResourceRequestOnly.getSkills(),
					entityUtil.getCurrentVendorId(),
					PaginationUtil.getPageable(matchingJobResourceRequestOnly.getPaginationRequestModel()),
					StatusEnum.VERIFIED);
		}
	}

	@Override
	public Page<Resource> getMatchingResourceOnly(MatchingJobResourceBySkillsRequest matchingJobResourceRequestOnly,
			Pageable pageble) {
		if (matchingJobResourceRequestOnly.getId() != null) {

			return resourceRepository.findResourceBySkills(matchingJobResourceRequestOnly.getSkills(),
					entityUtil.getCurrentVendorId(), matchingJobResourceRequestOnly.getId(), pageble,
					StatusEnum.VERIFIED);
		} else {
			return resourceRepository.findResourceBySkills(matchingJobResourceRequestOnly.getSkills(),
					entityUtil.getCurrentVendorId(), pageble, StatusEnum.VERIFIED);
		}
	}

	@Override
	public ResourceJobs existsByJobIdAndResourceIdAndDeletedFalseAndResourceStatus(Long jobId, Long resourceId) {
		return resourceJobsRepository.existsByJobIdAndResourceIdAndDeletedFalseAndResourceStatus(jobId, resourceId);

	}

	@Override
	public void sendInvitedMail(Long jobId, Long resourceId) {

		Resource resource = resourceRepository.findById(resourceId).get();
		emailSenderUtil.sendMail(StringUtils.capitalize(resource.getVendor().getAgencyName()),
				resource.getFirstName() + " " + resource.getLastName() + Constants.INIVITATION_MESSAGE,
				Constants.INIVITATION_RECIVED+jobId+"&resourceId="+resourceId, resource.getVendor().getCompanyPrimaryEmail(), Constants.MESSAGE_WITH_URL, Constants.INIVITATION_SUBJECT);
		
	
	}

	public void sendUpdateStatusEmail(Job job, Resource resource, ResourceStatusEnum resourceStatusEnum,String rejectReason) {

		switch (resourceStatusEnum) {
		case REJECTED:
			rejectReason = rejectReason.endsWith(".") ? rejectReason : rejectReason + ".";
			emailSenderUtil.sendMail(StringUtils.capitalize(resource.getVendor().getAgencyName()),
					resource.getFirstName() + " " + resource.getLastName() + Constants.REJECTED_MESSAGE+"because "+rejectReason,
					Constants.HIRED_OR_REJECTED_SHORTLISTED_URL+resource.getId()+"&status=REJECTED",
					resource.getVendor().getCompanyPrimaryEmail(), Constants.MESSAGE_WITH_URL, Constants.REJECTED_SUBJECT);
			break;
		case SHORTLISTED:
			emailSenderUtil.sendMail(StringUtils.capitalize(resource.getVendor().getAgencyName()),
					resource.getFirstName() + " " + resource.getLastName() + Constants.SHORTLISTED_MESSAGE,
					Constants.HIRED_OR_REJECTED_SHORTLISTED_URL+resource.getId()+"&status=SHORTLISTED",
					resource.getVendor().getCompanyPrimaryEmail(), Constants.MESSAGE_WITH_URL, Constants.SHORTLISTED_SUBECT);
			break;
		case HIRED:
			emailSenderUtil.sendMail(StringUtils.capitalize(resource.getVendor().getAgencyName()),
					resource.getFirstName() + " " + resource.getLastName() + Constants.HIRED_MESSAGE,
					Constants.HIRED_OR_REJECTED_SHORTLISTED_URL+resource.getId()+"&status=HIRED",
					resource.getVendor().getCompanyPrimaryEmail(), Constants.MESSAGE_WITH_URL, Constants.HIRED_SUBJECT);
			break;
		default:
			break;
		}

	}

	@Override

	public Long getCountOfInvitationReceivedAgainstCurrentVendorJob(Long vendorId) {

		return resourceJobsRepository.fetchInvitationsReceived(vendorId, ResourceStatusEnum.INVITED);
	}

	@Override
	public Long getCountOfInvitationSendAgainstAnotherVendorResource(Long vendorId) {

		return resourceJobsRepository.fetchInvitationsSent(vendorId, ResourceStatusEnum.INVITED);
	}

	public Long getInvitationReceivedCount() {

		return resourceJobsRepository.fetchInvitationsReceived(entityUtil.getCurrentVendorId(),
				ResourceStatusEnum.INVITED);
	}

	@Override
	public Long getInvitationSentCount() {

		return resourceJobsRepository.fetchInvitationsSent(entityUtil.getCurrentVendorId(), ResourceStatusEnum.INVITED);

	}

	@Override
	public PageModel findAllInvitationsRecived(ResourceJobFilterRequest resourceJobFilterRequest) {

		return resourceJobCustomRepository.findAllInvitationsRecived(resourceJobFilterRequest);

	}

	@Override
	public PageModel findAllInvitationsSend(InvitationsSendRequest resourceJobFilterRequest) {

		return resourceJobCustomRepository.findAllInvitationsSend(resourceJobFilterRequest);
	}

	@Override
	public void updateInvitationStatus(Long jobId, Long resourceId, InvitationStatusEnum invitationStatusEnum)
			throws Exception {
		ResourceJobs resourceJob = resourceJobsRepository.findByJobIdAndResourceIdAndDeletedFalse(jobId, resourceId);
		Job job = jobService.findById(jobId);
		Resource resource = resourceService.findById(resourceId);

		if (!ObjectUtils.isEmpty(resourceJob)) {
			if( resourceJob.getResourceStatus().equals(ResourceStatusEnum.APPLIED))
			{
				throw new Exception("Invitation already accepted");
			}
			
			if (invitationStatusEnum.equals(InvitationStatusEnum.INVITATION_ACCEPTED)
					&& !resourceJob.getResourceStatus().equals(ResourceStatusEnum.APPLIED)) {
				resourceJob.setResourceStatus(ResourceStatusEnum.APPLIED);
				resourceJob.setResourceInrRate(resource.getRate()!=null?CommonUtil.resourceRateWithCommission(resource.getRate(),staticConfigurationService.findByName(StaticConfigurationEnum.RESOURCE_COMMISSION).getValue()):null);
				resourceJob.setResourceUsdRate(resource.getUsdRate()!=null?CommonUtil.resourceRateWithCommission(resource.getUsdRate(),staticConfigurationService.findByName(StaticConfigurationEnum.RESOURCE_COMMISSION).getValue()):null);
				resource.setAppliedJobCount(resource.getAppliedJobCount() + 1);
				job.setApplicantsCount(job.getApplicantsCount() + 1);
				resourceJob.setAppliedBy(resource.getVendor().getUser());
				save(resourceJob);
			} else if (invitationStatusEnum.equals(InvitationStatusEnum.INVITATION_REJECTED)) {
				resourceJob.setDeleted(true);
			}
			notificationForInvitationStatusChange(jobId, resourceId, invitationStatusEnum, job, resource);
			sendInvitationUpdateStatusEmail(job, resource, invitationStatusEnum);

		} else {
			throw new Exception("No Job Found Against Resource Id " + resourceId);
		}
	}

	private void notificationForInvitationStatusChange(Long jobId, Long resourceId,
			InvitationStatusEnum invitationStatusEnum, Job job, Resource resource) {
		try {
			EventCreateWrapper wrapper = new EventCreateWrapper();
			Map<String, Object> jsonDataMap = new HashMap<>();
			jsonDataMap.put(Constants.RESOURCE_SMALL_CASE, resource.getFirstName());
			jsonDataMap.put(Constants.JOB_SMALL_CASE, job.getTitle());
			wrapper.setEventType(EventType.IN_APP);
			wrapper.setJsonData(jsonDataMap);
			wrapper.setMetaData(entityUtil.setMetaDataInNotification(jobId, resourceId, job, resource));
			wrapper.setVisibleToAll(false);
			wrapper.setUsersToNotify(Arrays.asList(job.getVendor().getUser().getEmailId()));
			wrapper.setMessageTemplateType(invitationStatusEnum.getDisplayName());
			log.info("wrapper to publish : {}", new Gson().toJson(wrapper));
			eventPublisher.publishEvent(wrapper);
		} catch (Exception e) {
			e.printStackTrace();
			log.error(e.getMessage(), e);
		}
	}

	public void sendInvitationUpdateStatusEmail(Job job, Resource resource, InvitationStatusEnum invitationStatusEnum) {
		Vendor vendor = resource.getVendor();
		switch (invitationStatusEnum) {
		case INVITATION_ACCEPTED:
			emailSenderUtil.sendMail(StringUtils.capitalize(job.getVendor().getAgencyName()),
					vendor.getAgencyName()
							+ Constants.INVITATION_ACCEPTED_MESSAGE + job.getTitle(),
							Constants.INVITATION_ACCEPTED_OR_REJECTED_URL+job.getId()+"&status=APPLIED", job.getVendor().getCompanyPrimaryEmail(), Constants.MESSAGE_WITH_URL,
					Constants.INVITATION_ACCEPTED_SUBJECT);
			
			break;
		case INVITATION_REJECTED:
			emailSenderUtil.sendMail(StringUtils.capitalize(job.getVendor().getAgencyName()),
					vendor.getAgencyName()
							+ Constants.INVITATION_REJECTED_MESSAGE + job.getTitle(),
							Constants.INVITATION_ACCEPTED_OR_REJECTED_URL+job.getId(), job.getVendor().getCompanyPrimaryEmail(), Constants.MESSAGE_WITH_URL,
					Constants.INVITATION_REJECTED_SUBJECT);
			break;
		default:
			break;
		}
	}

	@Override
	public Page<ResourceJobs> getInvitationReceviedList(ApplicationRequest applicationRequest) {
		LocalDateTime localDateTime1 = null;
		LocalDateTime localDateTime2 = null;
		String listOrder=Constants.DESCEDNING;
		
		if (applicationRequest.getStartDate() != null && applicationRequest.getEndDate() != null) {
			String startDate = applicationRequest.getStartDate();
			localDateTime1 = LocalDateTime.parse(startDate, DateUtil.dateTimeFormatter());

			String endDate = applicationRequest.getEndDate();
			localDateTime2 = LocalDateTime.parse(endDate, DateUtil.dateTimeFormatter());
			listOrder=Constants.ASCEDNING;
		}
		return resourceJobsRepository.getInvitationRecieved(entityUtil.getCurrentVendorId(),
				applicationRequest.getResourceStatus(), applicationRequest.getName(), localDateTime1, localDateTime2,listOrder,
				PaginationUtil.getPageable(applicationRequest.getPaginationRequestModel()));

	}

	@Override
	public Page<ResourceJobs> getInvitationSentList(ResourceJobFilterRequest resourceJobFilterRequest,
			Pageable pageable) {
		LocalDateTime localDateTime1 = null;
		LocalDateTime localDateTime2 = null;
		String listOrder=Constants.DESCEDNING;
		if (resourceJobFilterRequest.getStartDate() != null && resourceJobFilterRequest.getEndDate() != null) {
			String startDate = resourceJobFilterRequest.getStartDate();
			localDateTime1 = LocalDateTime.parse(startDate, DateUtil.dateTimeFormatter());

			String endDate = resourceJobFilterRequest.getEndDate();
			localDateTime2 = LocalDateTime.parse(endDate, DateUtil.dateTimeFormatter());
			listOrder=Constants.ASCEDNING;
		}

		return resourceJobsRepository.getInvitationSent(entityUtil.getCurrentVendorId(),
				resourceJobFilterRequest.getTitle(), resourceJobFilterRequest.getResourceStatusEnum(), localDateTime1,
				localDateTime2,listOrder, pageable);
	}

	@Override
	public Boolean existsByJobIdAndResourceIdAndDeleted(Long jobId,Long resourceId,Boolean deleted) {
		
		return resourceJobsRepository.existsByJobIdAndResourceIdAndDeleted(jobId,resourceId,deleted);
	}

	@Override
	public void setResourceRateAtApplied(ResourceJobs resourceJobs, ResourceDetailResponse resourceDetailResponse) {
		resourceDetailResponse
				.setRate(
						resourceJobs.getResourceInrRate() != null
								? CommonUtil.getRateStr(CurrencyTypeEnum.INR.getDisplayName(),
										resourceJobs.getResourceInrRate(), resourceJobs.getResourceInrRateType() != null
												? resourceJobs.getResourceInrRateType().getDisplayName()
												: resourceJobs.getResource().getRateTypeEnum().getDisplayName())
								: null);

		resourceDetailResponse
				.setUsdRate(
						resourceJobs.getResourceUsdRate() != null
								? CommonUtil.getRateStr(CurrencyTypeEnum.USD.getDisplayName(),
										resourceJobs.getResourceUsdRate(), resourceJobs.getResourceUsdRateType() != null
												? resourceJobs.getResourceUsdRateType().getDisplayName()
												: resourceJobs.getResource().getUsdRateType().getDisplayName())
								: null);

	}

}
