package com.daynilgroup.vendormanagement.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.daynilgroup.vendormanagement.constants.InvitationStatusEnum;
import com.daynilgroup.vendormanagement.constants.ResourceStatusEnum;
import com.daynilgroup.vendormanagement.entity.Job;
import com.daynilgroup.vendormanagement.entity.Resource;
import com.daynilgroup.vendormanagement.entity.ResourceJobs;
import com.daynilgroup.vendormanagement.model.filter.JobsFilterModel;
import com.daynilgroup.vendormanagement.model.filter.ResourceFilterModel;
import com.daynilgroup.vendormanagement.model.pag.PageModel;
import com.daynilgroup.vendormanagement.model.request.ApplicationRequest;
import com.daynilgroup.vendormanagement.model.request.InviteRequest;
import com.daynilgroup.vendormanagement.model.request.MatchingJobResourceBySkillsRequest;
import com.daynilgroup.vendormanagement.model.request.MatchingJobResourceUnderCriteriaRequest;
import com.daynilgroup.vendormanagement.model.request.ResourceJobFilterRequest;
import com.daynilgroup.vendormanagement.model.response.CountResponse;
import com.daynilgroup.vendormanagement.model.response.ResourceDetailResponse;
import com.daynilgroup.vendormanagement.request.InvitationsSendRequest;

public interface ResourceJobsService extends AbstractService<ResourceJobs> {

	Page<ResourceJobs> getList(Pageable pageable);

	List<ResourceJobs> getListByJobId(Long id);

	Long getNoOfJobApplied(Long id, ResourceStatusEnum resourceStatusEnum);

	List<ResourceJobs> getResourceStatusList(Long id);

	void updateResourceStatus(Long resourceId, Long jobId, ResourceStatusEnum resourceStatusEnum,String rejectReason) throws Exception;

	Long getCountApplicationByvendorId(Long vendorId);

	Long getCountJobApllication(Long vendorId);

	Page<ResourceJobs> getApplicationList(ApplicationRequest applicationRequest);

	void resourceJobsSoftDelete(Long vendorId);

	List<ResourceJobs> getApplicationCountList();

	CountResponse getResourceCountList(Long jobId);

	CountResponse getJobCountList(Long resourceId);

	List<ResourceJobs> findAllJobApplicationByVendorId(Long vendorId);

	void resourceJobsSoftDelete(Long jobId, Long resourceId);

	Boolean existsByJobIdAndResourceIdAndDeletedFalse(Long jobId, Long resourceId);

	ResourceJobs existsByJobIdAndResourceId(Long jobId, Long resourceId);

	PageModel getResourceListByStatus(ResourceFilterModel resourceJobFilterModel);

	PageModel getJobListByResourceId(JobsFilterModel jobsFilterModel);

	Page<ResourceJobs> findAllJobApplication(ResourceJobFilterRequest resourceJobFilterRequest, Pageable pageable);

	List<Job> getMatchingJob(MatchingJobResourceUnderCriteriaRequest matchingJobResourceRequest);

	List<Resource> getMatchingResource(MatchingJobResourceUnderCriteriaRequest matchingJobResourceRequest);

	Page<Job> getMatchingJobOnly(MatchingJobResourceBySkillsRequest matchingJobResourceRequestOnly, Pageable pageble);

	Page<Resource> getMatchingResourceOnly(MatchingJobResourceBySkillsRequest matchingJobResourceRequestOnly,
			Pageable pageble);

	ResourceJobs findByJobIdAndResourceIdAndDeletedFalse(Long jobId, Long resourceId);

	Page<ResourceJobs> getNotification(Pageable pageable);

	Boolean existsByJobIdAndResourceIdAndDeletedTrue(Long jobId, Long resourceId);

	void invite(InviteRequest inviteRequest);

	void sendInvitedMail(Long jobId, Long resourceId);

	ResourceJobs existsByJobIdAndResourceIdAndDeletedFalseAndResourceStatus(Long jobId, Long resourceId);

	Long getCountOfInvitationReceivedAgainstCurrentVendorJob(Long vendorId);

	Long getCountOfInvitationSendAgainstAnotherVendorResource(Long vendorId);

	Long getInvitationReceivedCount();

	Long getInvitationSentCount();

	PageModel findAllInvitationsRecived(ResourceJobFilterRequest resourceJobFilterRequest);

	PageModel findAllInvitationsSend(InvitationsSendRequest resourceJobFilterRequest);

	void updateInvitationStatus(Long resourceId, Long jobId, InvitationStatusEnum resourceStatusEnum) throws Exception;

	ResourceJobs findByJobIdAndResourceId(Long jobId, Long resourceId);
	
	Page<ResourceJobs> getInvitationReceviedList(ApplicationRequest applicationRequest);

	Page<ResourceJobs> getInvitationSentList(ResourceJobFilterRequest resourceJobFilterRequest,Pageable pageable);

	Boolean existsByJobIdAndResourceIdAndDeleted(Long jobId,Long resourceId,Boolean deleted);
	
	void setResourceRateAtApplied(ResourceJobs resourceJobs,ResourceDetailResponse resourceDetailResponse);
}
