package com.daynilgroup.vendormanagement.model.request;

import com.daynilgroup.vendormanagement.request.inf.RequestInf;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@Getter
@Setter
@FieldDefaults(level = AccessLevel.PRIVATE)
public class ProofIdentityRegistrationReq implements RequestInf {

	private static final long serialVersionUID = 1L;
	
	@JsonProperty(required = true)
	Long id;
	
	String base64proofOfIdentity;

	String base64proofOfIdentityName;

	String base64proofOfRegistration;

	String base64proofOfRegistrationName;

}
