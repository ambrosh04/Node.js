package com.daynilgroup.vendormanagement.helper;

import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.daynilgroup.vendormanagement.entity.Menu;
import com.daynilgroup.vendormanagement.entity.RoleAccess;
import com.daynilgroup.vendormanagement.model.request.CreateRoleAccessRequest;
import com.daynilgroup.vendormanagement.service.MenuService;
import com.daynilgroup.vendormanagement.util.CommonUtil;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;

@Component
@FieldDefaults(level = AccessLevel.PRIVATE)
public class RoleAccessHelper extends AbstractHelper<RoleAccess, CreateRoleAccessRequest, Object, Object, Object> {
	@Autowired
	MenuService menuService;

	@Transactional(rollbackFor = Exception.class)
	public List<RoleAccess> getNewRoleAccesss(List<String> accesses) {
		List<RoleAccess> roleAccesses = new LinkedList<>();
		if (!CollectionUtils.isEmpty(accesses)) {
			List<String> roleAcces = new LinkedList<>();
			accesses.forEach(roleAcces::add);

			List<Long> givenIds = new LinkedList<>();
			Map<Long, List<String>> accessMap = new HashMap<>();
			for (String access : roleAcces) {
				String[] split = access.split("-");
				Long menuId = Long.parseLong(split[0]);
				String accessString = split[1];
				givenIds.add(menuId);
				if (accessMap.containsKey(menuId)) {
					accessMap.get(menuId).add(accessString);
				} else {
					List<String> newAccess = new LinkedList<>();
					newAccess.add(accessString);
					accessMap.put(menuId, newAccess);
				}
			}
			List<Long> otherParentIds = menuService.getParentIds(givenIds);
			if (otherParentIds != null && !otherParentIds.isEmpty()) {
				Set<Long> ids = new HashSet<>();
				ids.addAll(otherParentIds);
				ids.forEach(otherParentId -> accessMap.put(otherParentId, null));
			}

			for (Map.Entry<Long, List<String>> entry : accessMap.entrySet()) {
				RoleAccess roleAccess = new RoleAccess();
				Menu menu = menuService.findById(entry.getKey());
				roleAccess.setMenu(menu);

				if (!CommonUtil.isEmpty(entry.getValue())) {
					roleAccess.setAccesss(entry.getValue().stream().collect(Collectors.joining(",")));
				}
				roleAccesses.add(roleAccess);
			}
		}
		return roleAccesses;
	}

	@Override
	public RoleAccess getEntity(CreateRoleAccessRequest request) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Object> getListResponse(List<RoleAccess> entityList) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object getDetailResponse(RoleAccess entity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object getDetailForAdminResponse(RoleAccess entity) {
		// TODO Auto-generated method stub
		return null;
	}
}
