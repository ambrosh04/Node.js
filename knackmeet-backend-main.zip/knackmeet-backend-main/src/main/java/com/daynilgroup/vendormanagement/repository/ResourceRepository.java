package com.daynilgroup.vendormanagement.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.daynilgroup.vendormanagement.constants.DeploymentTypeEnum;
import com.daynilgroup.vendormanagement.constants.RateTypeEnum;
import com.daynilgroup.vendormanagement.constants.StatusEnum;
import com.daynilgroup.vendormanagement.entity.Resource;

@Repository
public interface ResourceRepository extends JpaRepository<Resource, Long> {

	Page<Resource> findByDeletedFalseOrderByUpdatedOnDesc(Pageable pageable);

	@Query("SELECT COUNT(*)  FROM Resource r INNER JOIN ResourceJobs rj ON  r.id= rj.resource.id Where r.vendor.id =:vendorId")
	Long getCountBenchApllication(Long vendorId);

	Long countByVendorIdAndDeletedFalse(Long vendorId);

	Long countByVendorId(Long vendorId);

	List<Resource> findByVendorIdAndDeletedFalse(Long id);

	List<Resource> findByDeletedFalse();

	Long countByDeletedFalseAndActiveTrue();

	Long countByDeletedFalse();

	@Query("SELECT r FROM Resource r INNER JOIN r.designation cl where (:statusEnum IS NULL OR r.statusEnum=:statusEnum) AND (:name IS NULL OR CONCAT(r.firstName, ' ', r.lastName) LIKE %:name%) AND (:designation IS NULL OR cl.name LIKE %:designation%) AND (:agencyName IS NULL OR r.vendor.agencyName LIKE (%:agencyName%)) AND r.deleted=false order by r.lastModifiedDate desc")
	Page<Resource> getResource(Pageable pageable, StatusEnum statusEnum, String name, String designation,String agencyName);

	@Query("SELECT r FROM Resource r INNER JOIN ResourceSkillsCodeLookup rscl ON r.id=rscl.resource.id INNER JOIN CodeLookup cl ON rscl.codeLookup.id = cl.id "
			+ "WHERE r.vendor.id =:vendorId AND cl.name LIKE %:skill% AND r.active=true AND r.statusEnum='VERIFIED'  AND (r.deleted=false OR r.deleted IS NULL)")
	List<Resource> findByVendorIdAndSkillsOrderByUpdatedOnDesc(Long vendorId, String skill);

	@Query("SELECT  distinct r FROM Resource r INNER JOIN ResourceSkillsCodeLookup rscl ON r.id=rscl.resource.id INNER JOIN CodeLookup cl ON rscl.codeLookup.id = cl.id "
			+ "WHERE r.vendor.id =:vendorId AND cl.name IN (:skills) AND r.active=true AND r.statusEnum='VERIFIED'  AND (r.deleted=false OR r.deleted IS NULL)")
	Page<Resource> findByVendorIdAndSkillsOrderByUpdatedOnDesc(Long vendorId, List<String> skills,Pageable pageable);

	
	@Query("select distinct r from Resource r Inner join ResourceSkillsCodeLookup rscl ON r.id=rscl.resource.id Inner JOIN CodeLookup c ON c.id=rscl.codeLookup.id Where c.name IN (:skills) and r.vendor.id <> :vendorId and r.id <> :id and r.statusEnum=:statusEnum and r.active=true")
	Page<Resource> findResourceBySkills(List<String> skills, Long vendorId, Long id, Pageable pageable,
			StatusEnum statusEnum);

	@Query("select distinct r from Resource r Inner join ResourceSkillsCodeLookup rscl ON r.id=rscl.resource.id Inner JOIN CodeLookup c ON c.id=rscl.codeLookup.id Where c.name IN (:skills) and r.vendor.id <> :vendorId and r.id <> :id and r.statusEnum=:statusEnum and r.active=true")
	List<Resource> findResourceBySkillswithoutPagable(List<String> skills, Long vendorId, Long id,
			StatusEnum statusEnum);

	@Query("select distinct r from Resource r Inner join ResourceSkillsCodeLookup rscl ON r.id=rscl.resource.id Inner JOIN CodeLookup c ON c.id=rscl.codeLookup.id Where c.name IN (:skills) and r.vendor.id <> :vendorId and r.statusEnum=:statusEnum and r.active=true")
	List<Resource> findResourceBySkillswithoutPagable(List<String> skills, Long vendorId, StatusEnum statusEnum);

	@Query("select distinct r from Resource r Inner join ResourceSkillsCodeLookup rscl ON r.id=rscl.resource.id Inner JOIN CodeLookup c ON c.id=rscl.codeLookup.id Where c.name IN (:skills) and r.vendor.id <> :vendorId and r.statusEnum=:statusEnum and r.active=true")
	Page<Resource> findResourceBySkills(List<String> skills, Long vendorId, Pageable pageable, StatusEnum statusEnum);
	
	Page<Resource> findByVendorIdAndDeletedFalse(Long id,Pageable pageable);
	
	@Query("SELECT  distinct r FROM Resource r INNER JOIN ResourceSkillsCodeLookup rscl ON r.id=rscl.resource.id INNER JOIN CodeLookup cl ON rscl.codeLookup.id = cl.id "
			+ "WHERE r.vendor.id =:vendorId AND cl.name IN (:skills) AND ((r.rateTypeEnum IS NOT NULL and r.rateTypeEnum=:rateType) or (r.usdRateType IS NOT NULL and r.usdRateType=:usdRateType)) "
			+ "AND r.active=true AND r.statusEnum='VERIFIED' AND (r.deleted=false OR r.deleted IS NULL) AND r.rate IS NOT NULL AND (:location IS NULL OR r.location =:location) AND r.deploymenType IN (:deploymentTypeEnums) ")
	Page<Resource> findByVendorIdAndSkillsAndInrCurrencyOrderByUpdatedOnDesc(Long vendorId, List<String> skills,RateTypeEnum rateType, RateTypeEnum usdRateType, List<DeploymentTypeEnum> deploymentTypeEnums,String location, Pageable pageable);
	
	@Query("SELECT  distinct r FROM Resource r INNER JOIN ResourceSkillsCodeLookup rscl ON r.id=rscl.resource.id INNER JOIN CodeLookup cl ON rscl.codeLookup.id = cl.id "
			+ "WHERE r.vendor.id =:vendorId AND cl.name IN (:skills) AND ((r.rateTypeEnum IS NOT NULL and r.rateTypeEnum=:rateType) or (r.usdRateType IS NOT NULL and r.usdRateType=:usdRateType))"
			+ " AND r.active=true AND r.statusEnum='VERIFIED'  AND (r.deleted=false OR r.deleted IS NULL) AND r.usdRate IS NOT NULL AND r.deploymenType IN (:deploymentTypeEnums) AND (:location IS NULL OR r.location =:location) ")
	Page<Resource> findByVendorIdAndSkillsAndUsdCurrencyOrderByUpdatedOnDesc(Long vendorId, List<String> skills, RateTypeEnum rateType, RateTypeEnum usdRateType, List<DeploymentTypeEnum> deploymentTypeEnums,String location, Pageable pageable );
	
	@Query("SELECT r.id FROM Resource r INNER JOIN ResourceJobs rj ON r.id = rj.resource.id WHERE r.vendor.id != :vendorId AND (r.deleted = false OR r.deleted IS NULL) AND r.statusEnum = 'VERIFIED' AND (rj.resourceStatus IS  NULL OR rj.resourceStatus IN ('SHORTLISTED', 'HIRED', 'REJECTED','INVITED')) AND rj.job.id = :jobId")
	List<Long> getVerifiedResourcesByVendorIdNotAndExceptInvited(@Param("vendorId") Long vendorId,@Param("jobId") Long jobId);
	
	@Query("SELECT  distinct r FROM Resource r INNER JOIN ResourceSkillsCodeLookup rscl ON r.id=rscl.resource.id INNER JOIN CodeLookup cl ON rscl.codeLookup.id = cl.id "
			+ "WHERE r.vendor.id !=:vendorId AND cl.name IN (:skills) AND r.active=true AND r.statusEnum='VERIFIED'  AND (r.deleted=false OR r.deleted IS NULL) AND r.rate IS NOT NULL and (:resourceIdsSize = 0 or :resourceIds is null or r.id NOT IN (:resourceIds))")
	Page<Resource> findByVendorIdAndSkillsAndInrCurrencyOrderByUpdatedOnDes(Long vendorId, List<String> skills,List<Long> resourceIds,Integer resourceIdsSize,Pageable pageable);
	
	@Query("SELECT  distinct r FROM Resource r INNER JOIN ResourceSkillsCodeLookup rscl ON r.id=rscl.resource.id INNER JOIN CodeLookup cl ON rscl.codeLookup.id = cl.id "
			+ "WHERE r.vendor.id !=:vendorId AND cl.name IN (:skills) AND r.active=true AND r.statusEnum='VERIFIED'  AND (r.deleted=false OR r.deleted IS NULL) AND r.usdRate IS NOT NULL and ( :resourceIdsSize = 0 or :resourceIds is null or r.id NOT IN (:resourceIds))")
	Page<Resource> findByVendorIdAndSkillsAndUsdCurrencyOrderByUpdatedOnDes(Long vendorId, List<String> skills,List<Long> resourceIds,Integer resourceIdsSize, Pageable pageable);
	
	@Query("select distinct r from Resource r Inner join ResourceSkillsCodeLookup rscl ON r.id=rscl.resource.id Inner JOIN CodeLookup c ON c.id=rscl.codeLookup.id Where c.name IN (:skills) "
			+ "and r.vendor.id <> :currentVendorId and r.id <> :id and r.statusEnum=:statusEnum and "
			+ "((r.rateTypeEnum IS NOT NULL and r.rateTypeEnum=:rateType) or (r.usdRateType IS NOT NULL and r.usdRateType=:usdRateType)) and r.active=true AND r.deploymenType IN (:deploymentTypeEnums) AND (:location IS NULL OR  r.location =:location ) ")
	List<Resource> findResourceBySkillswithoutPagable(List<String> skills, Long currentVendorId, Long id,
			StatusEnum statusEnum, RateTypeEnum rateType, RateTypeEnum usdRateType,List<DeploymentTypeEnum> deploymentTypeEnums,String location);
	
	@Query("select distinct r from Resource r Inner join ResourceSkillsCodeLookup rscl ON r.id=rscl.resource.id Inner JOIN CodeLookup c ON c.id=rscl.codeLookup.id Where c.name IN (:skills)"
			+ " and r.vendor.id <> :currentVendorId and r.statusEnum=:statusEnum and "
			+ "((r.rateTypeEnum IS NOT NULL and r.rateTypeEnum=:rateType) or (r.usdRateType IS NOT NULL and r.usdRateType=:usdRateType)) and r.active=true AND r.deploymenType IN (:deploymentTypeEnums) AND (:location IS NULL OR  r.location =:location ) ")
	List<Resource> findResourceBySkillswithoutPagable(List<String> skills, Long currentVendorId,
			StatusEnum statusEnum, RateTypeEnum rateType, RateTypeEnum usdRateType,List<DeploymentTypeEnum> deploymentTypeEnums,String location);
	
	@Query("select distinct r from Resource r Inner join ResourceSkillsCodeLookup rscl ON r.id = rscl.resource.id Inner JOIN CodeLookup c ON c.id = rscl.codeLookup.id Where c.name IN (:skills) "
			+ "AND r.vendor.id !=:vendorId AND r.statusEnum = :statusEnum AND ((r.rate IS NOT NULL AND r.rateTypeEnum IS NOT NULL and r.rateTypeEnum = :rateType) or (r.usdRateType IS NOT NULL and r.usdRateType = :usdRateType AND r.usdRate IS NOT NULL)) AND r.id NOT IN (:resourceIds) "
			+ "AND r.active = true AND (r.deleted=false OR r.deleted IS NULL) AND r.deploymenType IN (:deploymentTypeEnum) AND (:location IS NULL OR r.location =:location )")
	Page<Resource> findResourceBySkillsResourceIdsForAdmin(List<String> skills, Long vendorId,
			StatusEnum statusEnum, RateTypeEnum rateType, RateTypeEnum usdRateType, List<Long> resourceIds,List<DeploymentTypeEnum> deploymentTypeEnum, String location, Pageable pageable);
	
	@Query("select distinct r from Resource r Inner join ResourceSkillsCodeLookup rscl ON r.id = rscl.resource.id Inner JOIN CodeLookup c ON c.id = rscl.codeLookup.id LEFT JOIN ResourceJobs rj ON r.id=rj.resource.id Where c.name IN (:skills) "
			+ "AND r.vendor.id !=:vendorId AND r.statusEnum = :statusEnum AND ((r.rate IS NOT NULL AND r.rateTypeEnum IS NOT NULL and r.rateTypeEnum = :rateType) or (r.usdRateType IS NOT NULL and r.usdRateType = :usdRateType AND r.usdRate IS NOT NULL)) AND (rj.deleted = false OR rj.deleted IS NULL) "
			+ "AND r.active = true AND (r.deleted=false OR r.deleted IS NULL)")
	Page<Resource> findResourceBySkillsForAdmin(List<String> skills, Long vendorId,
			StatusEnum statusEnum, RateTypeEnum rateType, RateTypeEnum usdRateType, Pageable pageable);
	
	@Query("SELECT r.id FROM Resource r INNER JOIN ResourceJobs rj ON r.id = rj.resource.id WHERE r.vendor.id != :vendorId AND (r.deleted = false OR r.deleted IS NULL) AND r.statusEnum = 'VERIFIED' AND (rj.resourceStatus IS  NULL OR rj.resourceStatus IN ('SHORTLISTED', 'HIRED', 'REJECTED','INVITED')) AND rj.job.id = :jobId AND r.deploymenType IN (:deploymentTypeEnum) AND (:countryId IS NULL OR rj.job.country.id =:countryId ) AND (:location IS NULL OR r.location =:location) ")
	List<Long> getVerifiedResourcesByVendorIdNotAndExceptInvited(@Param("vendorId") Long vendorId,@Param("jobId") Long jobId ,List<DeploymentTypeEnum> deploymentTypeEnum, Long countryId, String location);
	
	@Query("select distinct r from Resource r Inner join ResourceSkillsCodeLookup rscl ON r.id = rscl.resource.id Inner JOIN CodeLookup c ON c.id = rscl.codeLookup.id LEFT JOIN ResourceJobs rj ON r.id=rj.resource.id Where c.name IN (:skills) "
			+ "AND r.vendor.id !=:vendorId AND r.statusEnum = :statusEnum AND ((r.rate IS NOT NULL AND r.rateTypeEnum IS NOT NULL and r.rateTypeEnum = :rateType) or (r.usdRateType IS NOT NULL and r.usdRateType = :usdRateType AND r.usdRate IS NOT NULL)) AND (rj.deleted = false OR rj.deleted IS NULL) "
			+ "AND r.active = true AND (r.deleted=false OR r.deleted IS NULL) AND r.deploymenType IN (:deploymentTypeEnum)  AND (:location IS NULL OR r.location =:location ) ")
	Page<Resource> findResourceBySkillsForAdmin(List<String> skills, Long vendorId,
			StatusEnum statusEnum, RateTypeEnum rateType, RateTypeEnum usdRateType,List<DeploymentTypeEnum> deploymentTypeEnum, String location, Pageable pageable);
	
}
