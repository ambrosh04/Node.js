package com.daynilgroup.vendormanagement.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.daynilgroup.vendormanagement.entity.SearchHistory;
import com.daynilgroup.vendormanagement.request.SearchTypeRequest;

public interface SearchHistoryService extends AbstractService<SearchHistory> {

	Page<SearchHistory> getSearchHistoryListForHireDeveloperExceptVendorId(Pageable pageable) throws Exception;

	Page<SearchHistory> getSearchHistoryListForJobOrProjectExceptVendorId(Pageable pageable) throws Exception;
	
	Page<SearchHistory> getRecentSearchHistoryExceptVendorId(SearchTypeRequest searchTypeRequest,Pageable pageable) throws Exception;

	List<SearchHistory> getRecentSearchHistoryExceptVendorId(SearchTypeRequest searchTypeRequest) throws Exception;


}
