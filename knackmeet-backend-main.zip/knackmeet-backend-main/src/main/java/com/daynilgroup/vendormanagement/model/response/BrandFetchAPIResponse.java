package com.daynilgroup.vendormanagement.model.response;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class BrandFetchAPIResponse implements Serializable {

	static final long serialVersionUID = 1L;

	String claimed;
	String name;
	String domain;
	String icon;
	String brandId;

}
