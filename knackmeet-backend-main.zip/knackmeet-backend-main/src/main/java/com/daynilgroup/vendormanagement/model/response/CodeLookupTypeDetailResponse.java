package com.daynilgroup.vendormanagement.model.response;

import java.io.Serializable;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class CodeLookupTypeDetailResponse implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Long id;

	private String code;

	private String name;

	private Long parentId;

	private String parentName;

	private Boolean active;

}