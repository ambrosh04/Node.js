package com.daynilgroup.vendormanagement.constants;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.experimental.FieldDefaults;

@Getter
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public enum EmploymentTypeEnum {

	FULL_TIME("Full-time"), PART_TIME("Part-time"), SELF_EMPLOYEE("Self-employee"), FREELANCE("Freelance"),
	INTERNSHIP("Internship"), TRAINEE("Trainee");

	String displayName;

}
