package com.daynilgroup.vendormanagement.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

/**
 *
 * @author Manish
 */
@Getter
@Setter
@Entity
@Table(name = "role_access")
@FieldDefaults(level = AccessLevel.PRIVATE)
public class RoleAccess extends BaseEntity {

	static final long serialVersionUID = 1L;

	@ManyToOne(targetEntity = Role.class, fetch = FetchType.LAZY)
	@JoinColumn(name = "role_id", nullable = false)
	Role role;

	@ManyToOne(targetEntity = Menu.class, fetch = FetchType.LAZY)
	@JoinColumn(name = "menu_id", nullable = false)
	Menu menu;

	@Column(name = "accesss")
	String accesss;

}