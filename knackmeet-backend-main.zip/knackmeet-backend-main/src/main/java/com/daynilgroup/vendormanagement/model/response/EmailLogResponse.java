package com.daynilgroup.vendormanagement.model.response;

import java.time.LocalDateTime;

import com.daynilgroup.vendormanagement.constants.ResultTypeEnum;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
public class EmailLogResponse {

	Long id;

	ResultTypeEnum resultType;

	String email;

	String subject;

	String logMsg;

	Long vendorId;
	
	String agencyName;
	
	LocalDateTime createdOn;
	
	String name;
	
}
