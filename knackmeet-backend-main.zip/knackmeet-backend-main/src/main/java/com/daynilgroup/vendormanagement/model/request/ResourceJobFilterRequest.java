package com.daynilgroup.vendormanagement.model.request;

import com.daynilgroup.vendormanagement.constants.ResourceStatusEnum;
import com.daynilgroup.vendormanagement.model.pag.PaginationRequestModel;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class ResourceJobFilterRequest {

	ResourceStatusEnum resourceStatusEnum;

	String title;

	String startDate;

	String endDate;

	PaginationRequestModel paginationRequestModel;

	String name;

}
