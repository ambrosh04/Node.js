package com.daynilgroup.vendormanagement.rest.controller.inf.embedded;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.daynilgroup.vendormanagement.helper.AbstractHelper;
import com.daynilgroup.vendormanagement.service.AbstractService;
public interface AbstractInf {
	Logger BASE_LOGGER = LoggerFactory.getLogger(AbstractInf.class);

	@SuppressWarnings("rawtypes")
	public AbstractService getService();

	@SuppressWarnings("rawtypes")
	public AbstractHelper getHelper();
}
