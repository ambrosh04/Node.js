/**
 * 
 */
package com.daynilgroup.vendormanagement.model.request;

import java.time.LocalDateTime;
import java.util.List;

import com.daynilgroup.vendormanagement.constants.TimeZoneEnum;
import com.daynilgroup.vendormanagement.request.inf.RequestInf;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

/**
 * @author Prerana
 *
 */
@Getter
@Setter
@FieldDefaults(level = AccessLevel.PRIVATE)
public class VendorRequest implements RequestInf {

	static final long serialVersionUID = 1L;

	Long id;

	@JsonProperty(required = true)
	String emailId;

	boolean isUpdate = false;

	@JsonProperty(required = true)
	String mobile;

	@JsonProperty(required = true)
	String password;

	String firstName;

	String lastName;

	String agencyName;

	LocalDateTime incorparationDate;

	Long teamStrength;

	String website;

	String base64profilePhoto;

	String deletedImage;

	Boolean isVendorAdmin;

	String gstNumber;

	Long phoneCodeId;

	String directorName;

	String location;
	
	String about;
	
	List<VendorPortfolioRequest> portfolioRequests;
	
	String companyPrimaryNumber;

	String companyPrimaryEmail;

	String companyDescription;
	
	Long registrationEnquiryId;
	
	TimeZoneEnum timeZone;

	Long countryCodeId;
	
	String base64ProofOfRegistration;

	String base64ProofOfRegistrationName;
	
	String tagline;
}
