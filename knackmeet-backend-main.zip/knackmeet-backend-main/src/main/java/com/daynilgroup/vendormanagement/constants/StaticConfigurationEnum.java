package com.daynilgroup.vendormanagement.constants;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.experimental.FieldDefaults;

@Getter
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public enum StaticConfigurationEnum {
	NOTIFICATION_EMAIL("Notification Email"),RESOURCE_COMMISSION("Resource Commission");
	
	String displayName;

}
