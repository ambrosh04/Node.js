/**
 * 
 */
package com.daynilgroup.vendormanagement.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.lang3.ObjectUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;

import com.daynilgroup.vendormanagement.entity.CodeLookupType;
import com.daynilgroup.vendormanagement.model.response.AdvanceSearchDropdownModel;
import com.daynilgroup.vendormanagement.model.response.CodeLookTypeDropdownResponse;
import com.daynilgroup.vendormanagement.model.response.DropdownResponse;
import com.daynilgroup.vendormanagement.repository.AddressRepository;
import com.daynilgroup.vendormanagement.repository.CodeLookupTypeRepository;
import com.daynilgroup.vendormanagement.service.CodeLookupTypeService;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;

/**
 * @author Prerana
 *
 */
@Service
@FieldDefaults(level = AccessLevel.PRIVATE)
public class CodeLookupTypeServiceImpl implements CodeLookupTypeService {

	@Autowired
	CodeLookupTypeRepository codeLookupTypeRepository;

	@Override
	public JpaRepository<CodeLookupType, Long> getJpaRepository() {
		return codeLookupTypeRepository;
	}

	@Override
	public boolean getByCodeAndId(String code, Long id) {
		if (id != null) {
			CodeLookupType codeLookupType = codeLookupTypeRepository.findByCodeAndId(code, id);
			return codeLookupType != null && !ObjectUtils.isEmpty(codeLookupType);
		} else {
			CodeLookupType codeLookupType = codeLookupTypeRepository.findByCode(code);
			return codeLookupType != null && !ObjectUtils.isEmpty(codeLookupType);
		}
	}

	@Override
	public boolean getByNameAndId(String name, Long id) {
		if (id != null) {
			CodeLookupType codeLookupType = codeLookupTypeRepository.findByNameAndId(name, id);
			return codeLookupType != null && !ObjectUtils.isEmpty(codeLookupType);
		} else {
			CodeLookupType codeLookupType = codeLookupTypeRepository.findByName(name);
			return codeLookupType != null && !ObjectUtils.isEmpty(codeLookupType);
		}
	}

	@Override
	public CodeLookupType findByCode(String code) {
		return codeLookupTypeRepository.findByCode(code);
	}

	@Override
	public Page<CodeLookupType> getAllCodeLookupType(Pageable pageable) {
		return codeLookupTypeRepository.findByDeletedFalseOrDeletedIsNull(pageable);
	}

	@Override
	public List<AdvanceSearchDropdownModel> advanceSearchDropdown(String searchValue, String code) {
		return codeLookupTypeRepository.findByNameAndCode(searchValue, PageRequest.of(0, 10)).stream()
				.map(codeLookUpType -> new AdvanceSearchDropdownModel(codeLookUpType.getId(), codeLookUpType.getName(),
						null))
				.collect(Collectors.toList());
	}

	@Override
	public List<CodeLookTypeDropdownResponse> codeLookUpTypeDropdown() {
		List<CodeLookTypeDropdownResponse> dropdownResponses = new ArrayList<>();
		codeLookupTypeRepository.findAllByDeletedFalse().forEach(dropdown -> {
			dropdownResponses.add(new CodeLookTypeDropdownResponse(dropdown.getId(), dropdown.getName(),
					dropdown.getCoverImgRequire()));
		});
		return dropdownResponses;
	}

	@Override
	public void deleteById(Long id) {
		codeLookupTypeRepository.delete(id);
	}

	@Override
	public Page<CodeLookupType> searchByName(String name, Pageable pageable) {
		return codeLookupTypeRepository.findByNameContainsAndDeletedFalseOrDeletedIsNull(name, pageable);
	}

}
