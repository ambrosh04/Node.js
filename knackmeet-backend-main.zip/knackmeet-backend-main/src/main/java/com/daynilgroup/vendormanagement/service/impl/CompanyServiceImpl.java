package com.daynilgroup.vendormanagement.service.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.daynilgroup.vendormanagement.constants.Constants;
import com.daynilgroup.vendormanagement.entity.Company;
import com.daynilgroup.vendormanagement.entity.Vendor;
import com.daynilgroup.vendormanagement.helper.CompanyHelper;
import com.daynilgroup.vendormanagement.model.response.BrandFetchAPIResponse;
import com.daynilgroup.vendormanagement.model.response.CompanyListResponse;
import com.daynilgroup.vendormanagement.repository.CompanyRepository;
import com.daynilgroup.vendormanagement.request.CompanyRequest;
import com.daynilgroup.vendormanagement.service.CompanyService;
import com.daynilgroup.vendormanagement.util.CommonUtil;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@FieldDefaults(level = AccessLevel.PRIVATE)
public class CompanyServiceImpl implements CompanyService {

	@Autowired
	CompanyRepository companyRepository;

	@Autowired
	CompanyHelper companyHelper;
	
	@Autowired 
	RestTemplate restTemplate;

	@Override
	public JpaRepository<Company, Long> getJpaRepository() {
		return companyRepository;
	}
	
	public List<CompanyListResponse> getList(String companyName) {
		List<Company> companies = companyRepository.findAllByName(companyName);
		List<CompanyListResponse> companyListResponse = companyHelper.getListResponse(companies);
		Set<String> companyNames = companyListResponse.stream().map(company -> company.getName())
				.collect(Collectors.toSet());
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
		headers.set(Constants.REFERER, Constants.BRANDFETCH_HEADER_REFERER);
		HttpEntity<String> entity = new HttpEntity<String>(headers);
		String url = Constants.BRANDFETCH_SEARCH_URI + companyName ;
		try {
			ResponseEntity<List<BrandFetchAPIResponse>> response = restTemplate.exchange(url, HttpMethod.GET, entity,
					new ParameterizedTypeReference<List<BrandFetchAPIResponse>>() {
					});
			
			List<BrandFetchAPIResponse> brandFetchAPIResponse = response.getBody();
			brandFetchAPIResponse.stream().filter(brands -> !companyNames.contains(brands.getName())
					&& brands.getDomain() != null && brands.getName() != null).forEach(brand -> {
						companyListResponse.add(CompanyListResponse.builder().id(null).name(brand.getName())
								.logoPath(brand.getIcon()).website(brand.getDomain()).build());
					});
		} catch (Exception e) {
			log.error(e.getMessage());
		}
		return companyListResponse;
	}

	@Override
	public Company create(CompanyRequest request) {
		try {
			Company company = companyHelper.getEntity(request);
			save(company);
			return company;
		} catch (Exception e) {
			return null;
		}
	}

	@Override
	public void create(Vendor vendor) {
		List<Company> companyList = companyRepository.getListByName(vendor.getAgencyName());
		if (CommonUtil.isEmpty(companyList)) {
			Company company = new Company();
			company.setName(vendor.getAgencyName());
			company.setWebsite(vendor.getWebsite());
			company.setMedia(vendor.getVendorLogo());
			company.setVendor(vendor);
			save(company);
		}
	}


	@Override
	public List<CompanyListResponse> getListOnlyThirdApi(String companyName) {
		String url = Constants.BRANDFETCH_SEARCH_URI + companyName ;
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
		headers.set(Constants.REFERER, Constants.BRANDFETCH_HEADER_REFERER);
		HttpEntity<String> entity = new HttpEntity<String>(headers);
		List<CompanyListResponse> companyListResponse = new ArrayList<>();
		try {
			ResponseEntity<List<BrandFetchAPIResponse>> response = restTemplate.exchange(url, HttpMethod.GET, entity,
					new ParameterizedTypeReference<List<BrandFetchAPIResponse>>() {
					});
			
			List<BrandFetchAPIResponse> brandFetchAPIResponse = response.getBody();
			brandFetchAPIResponse.stream().filter(brands -> brands.getIcon()!=null).forEach(brand -> {
						companyListResponse.add(CompanyListResponse.builder().id(null).name(brand.getName())
								.logoPath(brand.getIcon()).website(brand.getDomain()).build());
					});
		} catch (Exception e) {
			log.error(e.getMessage());
		}
		return companyListResponse;
	}


	@Override
	public Page<Company> findAll(Pageable pageable) {
		return companyRepository.findAll(pageable);
	}

	@Override
	public Company findByVendorId(Long vendorId) {
		return companyRepository.findByVendorId(vendorId);
	}
}
