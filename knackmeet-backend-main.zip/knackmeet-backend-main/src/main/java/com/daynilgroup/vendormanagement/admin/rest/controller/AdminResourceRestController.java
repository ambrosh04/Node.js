package com.daynilgroup.vendormanagement.admin.rest.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.daynilgroup.vendormanagement.constants.UrlConstants;
import com.daynilgroup.vendormanagement.model.request.ApplicantRequest;
import com.daynilgroup.vendormanagement.rest.exception.DataNotFoundRestException;
import com.daynilgroup.vendormanagement.service.ResourceService;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;

@FieldDefaults(level = AccessLevel.PRIVATE)
@RestController
@RequestMapping(UrlConstants.ADMIN_RESOURCE_BASE_URL)
public class AdminResourceRestController {

	@Autowired
	ResourceService resourceService;

	@PostMapping(UrlConstants.MATCHING_RESOURCE)
	public ResponseEntity<Object> getMatchingResources(@RequestBody ApplicantRequest applicantRequest) {
		try {

			return new ResponseEntity<>(resourceService.getMatchingResourceList(applicantRequest), HttpStatus.OK);

		} catch (Exception e) {
			return new ResponseEntity<>(new DataNotFoundRestException(e.getMessage()),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}
