/**
 * 
 */
package com.daynilgroup.vendormanagement.constants;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.experimental.FieldDefaults;

/**
 * @author Rohit
 *
 */
@Getter
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public enum JobSearchInTypeEnum {

	TITLE("Job Title"),KEYSKILLS("Key Skills"),TITLEANDSKILLS("Job Tittle & Key Skills"), ANY("Any");

	String displayName;

}
