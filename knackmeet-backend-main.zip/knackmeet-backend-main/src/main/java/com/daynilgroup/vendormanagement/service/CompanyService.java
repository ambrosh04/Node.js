package com.daynilgroup.vendormanagement.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.daynilgroup.vendormanagement.entity.Company;
import com.daynilgroup.vendormanagement.entity.Vendor;
import com.daynilgroup.vendormanagement.model.response.CompanyListResponse;
import com.daynilgroup.vendormanagement.request.CompanyRequest;

public interface CompanyService extends AbstractService<Company> {

	List<CompanyListResponse> getList(String companyName);
	Company create(CompanyRequest request);
	void create(Vendor vendor);

	List<CompanyListResponse> getListOnlyThirdApi(String companyName);

	Page<Company> findAll(Pageable pageable);
	
	Company findByVendorId(Long vendorId);
}
