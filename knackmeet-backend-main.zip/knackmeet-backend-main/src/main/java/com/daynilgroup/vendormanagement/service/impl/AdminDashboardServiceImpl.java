package com.daynilgroup.vendormanagement.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.daynilgroup.vendormanagement.constants.UserType;
import com.daynilgroup.vendormanagement.model.response.AdminDashboardCountResponse;
import com.daynilgroup.vendormanagement.service.AdminDashboardService;
import com.daynilgroup.vendormanagement.service.JobService;
import com.daynilgroup.vendormanagement.service.ResourceJobsService;
import com.daynilgroup.vendormanagement.service.ResourceService;
import com.daynilgroup.vendormanagement.service.VendorService;
import com.daynilgroup.vendormanagement.util.EntityUtil;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;

@Service
@FieldDefaults(level = AccessLevel.PRIVATE)
public class AdminDashboardServiceImpl implements AdminDashboardService {

	@Autowired
	ResourceService resourceService;

	@Autowired
	JobService jobService;

	@Autowired
	ResourceJobsService resourceJobsService;

	@Autowired
	EntityUtil entityUtil;
	
	@Autowired
	VendorService vendorService;

	@Override
	public AdminDashboardCountResponse getAdminDashboardCountResponse() {
	

		Long jobCount = jobService.getJobsCountByVendorId(entityUtil.getCurrentVendorId());
		Long resourceCount = resourceService.getResourcesCountByVendorId(entityUtil.getCurrentVendorId());
		Long resourceApplicationCount = resourceJobsService.getCountApplicationByvendorId(entityUtil.getCurrentVendorId());
		Long jobApplicationCount = resourceJobsService.getCountJobApllication(entityUtil.getCurrentVendorId());
		Long jobVerificationCount = jobService.getAllJobCount();
		Long resourceVerificationCount = resourceService.getResourceCount();
		Long countOfInvitationReceivedAgainstCurrentVendorJob = resourceJobsService
				.getCountOfInvitationReceivedAgainstCurrentVendorJob(entityUtil.getCurrentVendorId());
		Long countOfInvitationSendAgainstAnotherVendorResource = resourceJobsService
				.getCountOfInvitationSendAgainstAnotherVendorResource(entityUtil.getCurrentVendorId());
		Long allVendorCount = vendorService.getAllVendorCountExceptAdmin(UserType.VENDOR);

		AdminDashboardCountResponse.AdminDashboardCountResponseBuilder builder = AdminDashboardCountResponse.builder()
				.jobCount(jobCount).resourceCount(resourceCount)
				.resourceApplicationCount(resourceApplicationCount).jobApplicationCount(jobApplicationCount)
				.jobVerificationCount(jobVerificationCount).resourceVerificationCount(resourceVerificationCount)
				.invitationReceived(countOfInvitationReceivedAgainstCurrentVendorJob)
				.allVendorCount(allVendorCount)
				.invitationSent(countOfInvitationSendAgainstAnotherVendorResource);

		return builder.build();
	}

}
