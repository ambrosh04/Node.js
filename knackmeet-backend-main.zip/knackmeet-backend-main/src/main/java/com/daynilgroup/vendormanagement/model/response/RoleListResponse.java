package com.daynilgroup.vendormanagement.model.response;

import com.daynilgroup.vendormanagement.constants.RoleTypeEnum;
import com.daynilgroup.vendormanagement.model.inf.ListResponse;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Value;
import lombok.experimental.FieldDefaults;

/**
 *
 * @author Dnyaneshwar
 */
@AllArgsConstructor
@Value
@FieldDefaults(level = AccessLevel.PRIVATE)
@Builder
public class RoleListResponse implements ListResponse {
	static final long serialVersionUID = 1L;

	Long id;
	String name;
	Boolean active;
	RoleTypeEnum type;
	boolean editable;
	boolean deletable;
}