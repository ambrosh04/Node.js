package com.daynilgroup.vendormanagement.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;

import com.daynilgroup.vendormanagement.entity.Education;
import com.daynilgroup.vendormanagement.repository.EducationRepository;
import com.daynilgroup.vendormanagement.service.EducationService;

@Service
public class EducationServiceImpl implements EducationService{
	
	@Autowired
	EducationRepository educationRepository; 

	@Override
	public JpaRepository<Education, Long> getJpaRepository() {
		return educationRepository;
	}

	@Override
	public void softDeleteByInId(List<Long> deleteEducations) {
		educationRepository.softDeleteByInId(deleteEducations);
		
	}

	@Override
	public List<Education> findAllByDeleteFalse(Long resourceId) {
		return educationRepository.getAllByDeleteFalse(resourceId);
	}

}
