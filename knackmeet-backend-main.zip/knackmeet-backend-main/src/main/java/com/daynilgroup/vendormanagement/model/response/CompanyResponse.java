package com.daynilgroup.vendormanagement.model.response;

import java.io.Serializable;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class CompanyResponse implements Serializable{
	
	static final long serialVersionUID = 1L;

	Long id;
	String name;
	String logoPath;
	String website;
    Long vendorId;
}
