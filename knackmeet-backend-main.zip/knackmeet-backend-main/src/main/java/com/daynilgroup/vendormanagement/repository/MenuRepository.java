package com.daynilgroup.vendormanagement.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.daynilgroup.vendormanagement.entity.Menu;

public interface MenuRepository extends JpaRepository<Menu, Long> {

	@Query("Select m.parentId.id From Menu m where m.id IN :ids and m.active=true and (m.deleted=false OR m.deleted IS NULL) and m.parentId IS NOT NULL ")
	List<Long> getParentIds(@Param("ids") List<Long> ids);

}
