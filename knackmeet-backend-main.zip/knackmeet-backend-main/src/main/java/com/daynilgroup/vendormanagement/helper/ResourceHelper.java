package com.daynilgroup.vendormanagement.helper;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicInteger;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.daynilgroup.vendormanagement.constants.CodeLookUpConstant;
import com.daynilgroup.vendormanagement.constants.CodeLookUpRelationTypeEnum;
import com.daynilgroup.vendormanagement.constants.Constants;
import com.daynilgroup.vendormanagement.constants.CurrencyTypeEnum;
import com.daynilgroup.vendormanagement.constants.MediaTypeEnum;
import com.daynilgroup.vendormanagement.constants.RateTypeEnum;
import com.daynilgroup.vendormanagement.constants.RefTypeEnum;
import com.daynilgroup.vendormanagement.constants.ResourceStatusEnum;
import com.daynilgroup.vendormanagement.constants.StaticConfigurationEnum;
import com.daynilgroup.vendormanagement.constants.StatusEnum;
import com.daynilgroup.vendormanagement.entity.Address;
import com.daynilgroup.vendormanagement.entity.CodeLookup;
import com.daynilgroup.vendormanagement.entity.CodeLookupType;
import com.daynilgroup.vendormanagement.entity.Education;
import com.daynilgroup.vendormanagement.entity.Experience;
import com.daynilgroup.vendormanagement.entity.Media;
import com.daynilgroup.vendormanagement.entity.Resource;
import com.daynilgroup.vendormanagement.entity.ResourceSkillsCodeLookup;
import com.daynilgroup.vendormanagement.entity.Vendor;
import com.daynilgroup.vendormanagement.model.inf.DateUtil;
import com.daynilgroup.vendormanagement.model.request.AddressRequest;
import com.daynilgroup.vendormanagement.model.request.ResourceOtherDetailUpdateRequest;
import com.daynilgroup.vendormanagement.model.request.ResourcePersonalDetailUpdateRequest;
import com.daynilgroup.vendormanagement.model.request.ResourceRequest;
import com.daynilgroup.vendormanagement.model.response.AdvanceSearchDropdownModel;
import com.daynilgroup.vendormanagement.model.response.EducationDetailResponse;
import com.daynilgroup.vendormanagement.model.response.ExperienceDetailAdminResponse;
import com.daynilgroup.vendormanagement.model.response.ExperienceDetailResponse;
import com.daynilgroup.vendormanagement.model.response.ResourceDetailAdminResponse;
import com.daynilgroup.vendormanagement.model.response.ResourceDetailResponse;
import com.daynilgroup.vendormanagement.model.response.ResourceListResponse;
import com.daynilgroup.vendormanagement.model.response.ResourceSkillsResponse;
import com.daynilgroup.vendormanagement.request.ResourceUpdateRequest;
import com.daynilgroup.vendormanagement.service.CodeLookUpRelationService;
import com.daynilgroup.vendormanagement.service.CodeLookupService;
import com.daynilgroup.vendormanagement.service.CodeLookupTypeService;
import com.daynilgroup.vendormanagement.service.EducationService;
import com.daynilgroup.vendormanagement.service.ExperienceService;
import com.daynilgroup.vendormanagement.service.MediaService;
import com.daynilgroup.vendormanagement.service.ResourceService;
import com.daynilgroup.vendormanagement.service.ResourceSkillsCodeLookupService;
import com.daynilgroup.vendormanagement.service.StaticConfigurationService;
import com.daynilgroup.vendormanagement.service.VendorService;
import com.daynilgroup.vendormanagement.util.CommonUtil;
import com.daynilgroup.vendormanagement.util.EntityUtil;
import com.daynilgroup.vendormanagement.util.FileUpload;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;

@Component
@Lazy
@Slf4j
@FieldDefaults(level = AccessLevel.PRIVATE)
public class ResourceHelper extends
		AbstractHelper<Resource, ResourceRequest, ResourceListResponse, ResourceDetailResponse, ResourceDetailAdminResponse> {

	@Autowired
	ResourceService resourceService;

	@Autowired
	CodeLookupService codeLookupService;

	@Autowired
	CodeLookupTypeService codeLookupTypeService;

	@Autowired
	AddressHelper addressHelper;

	@Autowired
	VendorService vendorService;

	@Autowired
	ResourceSkillsCodeLookupService resourceskillsCodeLookupService;

	@Autowired
	AttributeMediaUploadHelper attributeMediaUploadHelper;

	@Autowired
	ExperienceHelper experienceHelper;

	@Autowired
	EducationHelper educationHelper;

	@Autowired
	FileUpload fileUpload;

	@Autowired
	private MediaService imageService;
	@Autowired 
	EducationService educationService;
	@Autowired
	ExperienceService experienceService;

	@Autowired
	EntityUtil entityUtil;
	
	@Autowired
	StaticConfigurationService staticConfigurationService;
	
	@Autowired
	CodeLookUpRelationService codeLookUpRelationService;

	@Value("${aws.s3.url}")
	private String awsS3Url;

	@Transactional(noRollbackFor = Exception.class)
	@Override
	public Resource getEntity(ResourceRequest request) throws Exception {
		Resource resource;
		if (CommonUtil.isValid(request.getId())) {
			resource = resourceService.findById(request.getId());
			resourceskillsCodeLookupService.deleteByResourceId(resource.getId());
			if(resource.getStatusEnum()==StatusEnum.REJECTED)
			{
				resource.setStatusEnum(StatusEnum.UNVERIFIED);	
			}
		} else {
			resource = new Resource();
			resource.setStatusEnum(StatusEnum.UNVERIFIED);

		}
		resource.setFirstName(request.getFirstname());
		resource.setMiddleName(request.getMiddleName());
		resource.setLastName(request.getLastname());
		resource.setName(request.getFirstname() + " " + request.getLastname());
		resource.setGender(request.getGender());
		resource.setDeploymenType(request.getDeploymenType());
		resource.setCurrencyType(request.getCurrencyType()==null?CurrencyTypeEnum.INR:request.getCurrencyType());
		resource.setRateTypeEnum(request.getRateTypeEnum());
		resource.setRate(request.getRate());
		resource.setResourceStatus(ResourceStatusEnum.AVAILABLE);
		resource.setPassingYear(request.getPassingYear());
		resource.setHigherEducation(request.getHigherEducation());
		resource.setRId(UUID.randomUUID().toString());
		resource.setLocation(request.getLocation());
		resource.setLatitude(request.getLatitude()!=null?request.getLatitude():null);
		resource.setLongitude(request.getLongitude()!=null?request.getLongitude():null);
        resource.setCountry(request.getCountryId()!=null?CommonUtil.getEntityReferenceWithId(request.getCountryId(), codeLookupService,
				CodeLookup.class):null);
        resource.setLastModifiedDate(LocalDateTime.now());

		Vendor vendor = CommonUtil.getEntityReferenceWithId(entityUtil.getCurrentVendorId(), vendorService,
				Vendor.class);
		resource.setVendor(vendor);

		// Availability
		if (CommonUtil.isValid(request.getAvailabilityId())) {
			CodeLookup availability = CommonUtil.getEntityReferenceWithId(request.getAvailabilityId(),
					codeLookupService, CodeLookup.class);
			resource.setAvailability(availability);
		}

		// Designation
		CodeLookup designation = null;
		if (!ObjectUtils.isEmpty(request.getDesignation())) {
			designation = addCodeLookups(request.getDesignation(), resource, designation,
					CodeLookUpConstant.DESIGNATION_CODELOOKUP_CODE);
			resource.setDesignation(designation);
		}

		// String base64profilePhoto;

		if (!ObjectUtils.isEmpty(request.getBase64profilePhoto()) && !ObjectUtils.isEmpty(MediaTypeEnum.IMAGE)
				&& resource.getId() != null) {
			Media media = attributeMediaUploadHelper
					.setMedia(
							CommonUtil.getFolderStructureForResource(resource.getVendor().getId(), "Resource",
									resource.getId(), "Image"),
							resource.getProfilePhoto(), request.getBase64profilePhoto(), MediaTypeEnum.IMAGE);
			resource.setProfilePhoto(media);
		}

		// delete profile Image
		if (!ObjectUtils.isEmpty(request.getDeletedImage())) {
			String deletedImages = request.getDeletedImage();
			String oldPath = StringUtils.substringBetween(deletedImages, "com/", "?X");
			imageService.deleteMedia(oldPath);
			fileUpload.deleteFileByS3(oldPath);
		}

		// String base64resume;
		if (!ObjectUtils.isEmpty(request.getBase64resume()) && request.getResumeName() != null) {
			int indexOf = request.getResumeName().indexOf(".");
			String resumeName = request.getResumeName().substring(0, indexOf).replaceAll("[^a-zA-Z0-9.' ']", "");
			Media media = attributeMediaUploadHelper.setMediaWithFileName(
					CommonUtil.getFolderStructureForResource(resource.getVendor().getId(), "Resource", resource.getId(),
							"Resume"),
					resource.getResume(), request.getBase64resume(), resumeName, MediaTypeEnum.DOCUMENT);

			resource.setResume(media);
		}else {
			log.error("Base64resume And Resume Name Is Required");
		}

		// delete resume
		if (!ObjectUtils.isEmpty(request.getDeletedResume())) {
			String deletedResume = request.getDeletedResume();
			String oldPath = StringUtils.substringAfter(deletedResume, "com/");
			imageService.deleteMedia(oldPath);
			fileUpload.deleteFileByS3(oldPath);
		}

		resource.setUsdRateType(request.getUsdRateType());
		resource.setUsdRate(request.getUsdRate());

		resourceService.save(resource);

		// skills
		if (!CollectionUtils.isEmpty(request.getSkillsCodeLookups())) {
			addResourceSkillsCodeLookup(request, resource, CodeLookUpConstant.SKILLS_CODELOOKUP_CODE);
		}

		// Experiences
		if (resource.getExperiences() == null) {
			resource.setExperiences(new ArrayList<>());
		}
		AtomicInteger totalMonthExp = new AtomicInteger(0);
		AtomicInteger totalYearExp = new AtomicInteger(0);
		request.getExperienceRequests().forEach(exprenceRequest -> {
			try {
				exprenceRequest.setResourceId(resource.getId());
				Experience experience = experienceHelper.getEntity(exprenceRequest);
				resource.getExperiences().add(experience);
				
				int totalMonths = getNoOfMonths(experience.getFromMonth(), experience.getFromYear(),
						experience.getPresentCompany().equals(Boolean.TRUE) ? LocalDate.now().getMonthValue()
								: experience.getToMonth(),
						experience.getPresentCompany().equals(Boolean.TRUE) ? LocalDate.now().getYear()
								: experience.getToYear());
				totalMonthExp.addAndGet(totalMonths%12);
				totalYearExp.addAndGet(totalMonths/12);
			} catch (Exception e) {
				e.printStackTrace();
			}
		});
		resource.setYearsExperience(totalYearExp.get()+(totalMonthExp.get()/12));
		resource.setMonthsExperience(totalMonthExp.get()%12);

		// Educations
		if (resource.getEducations() == null) {
			resource.setEducations(new ArrayList<>());
		}
		request.getEducationRequests().forEach(educationRequest -> {
			try {
				educationRequest.setResourceId(resource.getId());
				resource.getEducations().add(educationHelper.getEntity(educationRequest));
			} catch (Exception e) {
				e.printStackTrace();
			}
		});
		return resource;
	}
	
	public static int getNoOfMonths(Integer fromMonth, Integer fromYear, Integer toMonth, Integer toYear) {
		
		Calendar fromCalendar = Calendar.getInstance();
		fromCalendar.clear();
		fromCalendar.set(Calendar.MONTH, fromMonth - 1);
		fromCalendar.set(Calendar.YEAR, fromYear);

		Calendar toCalendar = Calendar.getInstance();
		toCalendar.clear();
		toCalendar.set(Calendar.MONTH, toMonth);
		toCalendar.set(Calendar.YEAR, toYear);
		return DateUtil.getNoOfMonthsBetween(fromCalendar.getTime(), toCalendar.getTime());
	}

	private AddressRequest getAddressRequest(ResourceRequest request) {
		AddressRequest addressRequest = new AddressRequest();
		addressRequest.setCountryId(request.getCountryId());
		addressRequest.setStateId(request.getStateId());
		return addressRequest;
	}

	private CodeLookup addCodeLookups(AdvanceSearchDropdownModel designationId, Resource resource,
			CodeLookup codeLookup, String code) {
		if (CommonUtil.isValid(designationId.getValue())) {
			codeLookup = codeLookupService.findById(designationId.getValue());
		} else {
			codeLookup = new CodeLookup();
			codeLookup.setActive(true);
			codeLookup.setDescription(designationId.getDescription());
			codeLookup.setName(designationId.getLabel());

			CodeLookupType codeLookupType = codeLookupTypeService.findByCode(code);
			codeLookup.setType(codeLookupType);

			codeLookupService.save(codeLookup);
		}
		return codeLookup;
	}

	public void addResourceSkillsCodeLookup(ResourceRequest request, Resource resource, String code) {
		List<ResourceSkillsCodeLookup> resourceSkillsCodeLookups = new ArrayList<>();
		if (!CollectionUtils.isEmpty(request.getSkillsCodeLookups())) {
			request.getSkillsCodeLookups().forEach(resourceSkill -> {
				CodeLookup resourceSkillsCodeLookup = null;
				if (CommonUtil.isValid(resourceSkill.getValue())) {
					resourceSkillsCodeLookup = codeLookupService.findById(resourceSkill.getValue());
				} else {
					resourceSkillsCodeLookup = new CodeLookup();
					resourceSkillsCodeLookup.setActive(true);
					resourceSkillsCodeLookup.setDescription(resourceSkill.getDescription());
					resourceSkillsCodeLookup.setName(resourceSkill.getLabel());

					CodeLookupType codeLookupType = codeLookupTypeService.findByCode(code);
					resourceSkillsCodeLookup.setType(codeLookupType);

					codeLookupService.save(resourceSkillsCodeLookup);
				}

				ResourceSkillsCodeLookup skillsCodeLookup = new ResourceSkillsCodeLookup();
				skillsCodeLookup.setResource(resource);
				skillsCodeLookup.setCodeLookup(resourceSkillsCodeLookup);
				resourceskillsCodeLookupService.save(skillsCodeLookup);
				resourceSkillsCodeLookups.add(skillsCodeLookup);
			});
		}
		resource.setResourceSkillsCodeLookups(resourceSkillsCodeLookups);
	}

	@Override
	public List<ResourceListResponse> getListResponse(List<Resource> resources) {
		List<ResourceListResponse> resoursesList = new ArrayList<>();
		resources.forEach(resource -> {
			ResourceListResponse resourceListResponse = new ResourceListResponse();
			resourceListResponse.setId(resource.getId());
			resourceListResponse.setFirstname(resource.getFirstName());
			resourceListResponse.setLastname(resource.getLastName());
			resourceListResponse.setAvailabilityType(resource.getAvailability().getName());
			resourceListResponse.setSkills(getSkillIdList(resource.getResourceSkillsCodeLookups()));
			resourceListResponse.setState(resource.getAddress() != null && resource.getAddress().getState() != null
					? resource.getAddress().getState().getName()
					: null);
			resourceListResponse.setCountry(resource.getCountry() != null 
					? resource.getCountry().getName()
					: null);
			resourceListResponse.setRate(resource.getRate()!=null? CommonUtil.getRateStr(resource.getCurrencyType().getDisplayName(),
					CommonUtil.resourceRateWithCommission(resource.getRate(),
							staticConfigurationService
									.findByName(StaticConfigurationEnum.RESOURCE_COMMISSION).getValue()), resource.getRateTypeEnum().getDisplayName()):null);
			resourceListResponse.setDesignation(resource.getDesignation().getName());
			resourceListResponse.setExperience(
					CommonUtil.getExperience(resource.getYearsExperience(), resource.getMonthsExperience()));
			resourceListResponse.setActive(resource.getActive());
			resourceListResponse.setGender(resource.getGender().getDisplayName());
			resourceListResponse.setPassingYear(resource.getPassingYear());
			resourceListResponse.setHigherEducation(resource.getHigherEducation());
			resourceListResponse.setUserId(resource.getVendor().getUser().getId());
			resourceListResponse.setBase64MediaString(resource.getProfilePhoto() != null
					? fileUpload.generatePresignedURL(resource.getProfilePhoto().getPath())
					: null);
			resourceListResponse
					.setAgencyName(resource.getVendor() != null && resource.getVendor().getAgencyName() != null
							? resource.getVendor().getAgencyName()
							: null);
			resourceListResponse.setStatusEnum(resource.getStatusEnum());
			resourceListResponse.setCreatedOn(resource.getCreatedOn());
			resourceListResponse
					.setUsdRate(
							resource.getUsdRate() != null
									? (CommonUtil.getRateString(CurrencyTypeEnum.USD.getDisplayName(),
											CommonUtil.resourceRateWithCommission(resource.getUsdRate(),
													staticConfigurationService
															.findByName(StaticConfigurationEnum.RESOURCE_COMMISSION)
															.getValue()),
											resource.getUsdRateType().getDisplayName()))
									: null);
			
			resourceListResponse.setDeploymentType(resource.getDeploymenType().getDisplayName());
			resourceListResponse.setLocation(resource.getLocation()!=null?resource.getLocation():null);
			resoursesList.add(resourceListResponse);
		});
		return resoursesList;
	}

	@Override
	public ResourceDetailResponse getDetailResponse(Resource resource) {

		ResourceDetailResponse.ResourceDetailResponseBuilder builder = ResourceDetailResponse.builder()
				.id(resource.getId()).firstname(resource.getFirstName()).lastname(resource.getLastName())
				.availabilityType(resource.getAvailability().getName())
				.skills(getSkillIdList(resource.getResourceSkillsCodeLookups()))
				.state(resource.getAddress() != null && resource.getAddress().getState() != null
						? resource.getAddress().getState().getName()
						: null)
				.country(resource.getCountry()!= null 
						? resource.getCountry().getName()
						: null)
				.status(resource.getStatusEnum().getDisplayName())
				.designation(resource.getDesignation().getName())
				.resourceStatus(resource.getResourceStatus().getDisplayName())
				.isActve(resource.getActive()).onlyRate(resource.getRate()).expInMonths(resource.getMonthsExperience())
				.expInYears(resource.getYearsExperience()).deployementType(resource.getDeploymenType().getDisplayName())
				.experience(CommonUtil.getExperience(resource.getYearsExperience(), resource.getMonthsExperience()))
				.agencyName(resource.getVendor().getAgencyName()).higherEducation(resource.getHigherEducation())
				.passingYear(resource.getPassingYear())
				.base64MediaString(resource.getProfilePhoto() != null
						? fileUpload.generatePresignedURL(resource.getProfilePhoto().getPath())
						: null)
				.resume(resource.getResume() != null ? awsS3Url + resource.getResume().getPath() : null)
				.description(resource.getDescription() != null ? resource.getDescription() : null)
				.lastUpdated(resource.getLastModifiedDate() != null ? resource.getLastModifiedDate() : resource.getCreatedOn())
				.statusEnum(resource.getStatusEnum())
				.createdOn(resource.getCreatedOn() != null ? resource.getCreatedOn() : null)
				.userId(resource.getVendor().getUser().getId())
				.educations(getEducationDetailList(resource.getEducations(), resource))
				.usdRateOnly(resource.getUsdRate())
				.experiences(getExperienceDatailList(resource.getExperiences(), resource))
				.usdRate(resource.getUsdRate() != null ? CommonUtil.getRateStr(CurrencyTypeEnum.USD.getDisplayName(),
						CommonUtil.resourceRateWithCommission(resource.getUsdRate(),
								staticConfigurationService.findByName(StaticConfigurationEnum.RESOURCE_COMMISSION)
										.getValue()),
						resource.getUsdRateType().getDisplayName()) : null)
				.rate(resource.getRate() != null
						? CommonUtil.getRateStr(CurrencyTypeEnum.INR.getDisplayName(),
								CommonUtil.resourceRateWithCommission(resource.getRate(),
										staticConfigurationService
												.findByName(StaticConfigurationEnum.RESOURCE_COMMISSION).getValue()),
								resource.getRateTypeEnum().getDisplayName())
						: null)
				.location(resource.getLocation()!=null?resource.getLocation():null)
				.gender(resource.getGender().getDisplayName())
				.usdRateTypeOnly(resource.getUsdRate() != null ? resource.getUsdRateType() : null)
				.rateTypeOnly(resource.getRate() != null ? resource.getRateTypeEnum() : null);
		return builder.build();
	}

	private List<ExperienceDetailResponse> getExperienceDatailList(List<Experience> experiences,
			Resource resource) {
		
		List<ExperienceDetailResponse> educationResponseList = new ArrayList<>();
		experiences =experienceService.findAllByDeleteFalse(resource.getId());
		experiences.forEach(experience -> {
			educationResponseList.add(experienceHelper.getDetailResponse(experience));
		});
		return educationResponseList;
		
	}

	private List<EducationDetailResponse> getEducationDetailList(List<Education> educations, Resource resource) {
		List<EducationDetailResponse> educationResponseList = new ArrayList<>();
		educations = educationService.findAllByDeleteFalse(resource.getId());
		educations.forEach(education -> {
			
			educationResponseList.add(educationHelper.getDetailResponse(education));
		});
		return educationResponseList;
	}

	@Override
	public ResourceDetailAdminResponse getDetailForAdminResponse(Resource resource) {
		String[] resumeName = resource.getResume() != null ? resource.getResume().getPath().split("/") : null;
		Address address = resource.getAddress();
		ResourceDetailAdminResponse.ResourceDetailAdminResponseBuilder builder = ResourceDetailAdminResponse.builder()
				.id(resource.getId()).firstname(resource.getFirstName()).lastname(resource.getLastName())
				.gender(resource.getGender()).yearsExperience(resource.getYearsExperience())
				.monthsExperience(resource.getMonthsExperience()).deploymenType(resource.getDeploymenType())
				.currencyType(resource.getCurrencyType() != null ? resource.getCurrencyType() : null).rateTypeEnum(resource.getRateTypeEnum() != null ? resource.getRateTypeEnum() :null)
				.resourceStatus(resource.getResourceStatus()).availabilityId(resource.getAvailability().getId())
				.skills(getSkillIdAndNameList(resource.getResourceSkillsCodeLookups()))
				.rate(resource.getRate() != null ? resource.getRate() : null)
				.designation(getValueAndLabel(resource.getDesignation().getId(), resource.getDesignation().getName()))
				.passingYear(resource.getPassingYear()).higherEducation(resource.getHigherEducation())
				.base64MediaString(resource.getProfilePhoto() != null
						? fileUpload.generatePresignedURL(resource.getProfilePhoto().getPath())
						: null)
				.resume(resource.getResume() != null ? awsS3Url + resource.getResume().getPath() : null)
				.resumeName(
						resource.getResume() != null ?	resource.getResume().getPath().substring(resource.getResume().getPath().lastIndexOf("/") + 1):null)
				.description(resource.getDescription() != null ? resource.getDescription() : null)
				.usdRate(resource.getUsdRate() != null ? resource.getUsdRate() : null)
				.usdRateType(resource.getUsdRateType() != null ? resource.getUsdRateType() : null)
				.educations(getEducationList(resource.getEducations(), resource))
				.experiences(getExperienceList(resource.getExperiences(), resource))
				.location(resource.getLocation()!=null?resource.getLocation():null)
				.latitude(resource.getLatitude()!=null?resource.getLatitude():null)
				.countryId(resource.getCountry()!= null 
				? resource.getCountry().getId()
				: null)
				.longitude(resource.getLongitude()!=null?resource.getLongitude():null);

		return builder.build();

	}

	private List<EducationDetailAdminResponse> getEducationList(List<Education> educations, Resource resource) {
		List<EducationDetailAdminResponse> educationResponseList = new ArrayList<>();
		educations = educationService.findAllByDeleteFalse(resource.getId());
		educations.forEach(education -> {
			
			educationResponseList.add(educationHelper.getDetailForAdminResponse(education));
		});
		return educationResponseList;
	}

	private List<ExperienceDetailAdminResponse> getExperienceList(List<Experience> experiences, Resource resource) {
		List<ExperienceDetailAdminResponse> educationResponseList = new ArrayList<>();
		experiences =experienceService.findAllByDeleteFalse(resource.getId());
		experiences.forEach(experience -> {
			educationResponseList.add(experienceHelper.getDetailForAdminResponse(experience));
		});
		return educationResponseList;
	}

	private List<String> getSkillIdList(List<ResourceSkillsCodeLookup> resourceSkillsCodeLookups) {
		List<String> resourseIdList = new ArrayList<>();
		resourceSkillsCodeLookups.stream().filter(resourceSkills->resourceSkills.getDeleted().equals(Boolean.FALSE)).forEach(skill -> {
			resourseIdList.add(skill.getCodeLookup().getName());
		});
		return resourseIdList;
	}

	private List<AdvanceSearchDropdownModel> getSkillIdAndNameList(
			List<ResourceSkillsCodeLookup> resourceSkillsCodeLookups) {
		List<AdvanceSearchDropdownModel> resourseIdList = new ArrayList<>();
		resourceSkillsCodeLookups.stream().filter(resourceSkills->resourceSkills.getDeleted().equals(Boolean.FALSE)).forEach(skill -> {
			resourseIdList.add(getValueAndLabel(skill.getCodeLookup().getId(), skill.getCodeLookup().getName()));
		});
		return resourseIdList;
	}

	private AdvanceSearchDropdownModel getValueAndLabel(Long id, String label) {
		return new AdvanceSearchDropdownModel(id, label, null);
	}
	
	public Long update(ResourceUpdateRequest request) throws Exception {
		Resource resource = resourceService.findById(request.getId());
		if (resource == null) {
			throw new Exception("Invalid Id");
		}
		if(resource.getStatusEnum()==StatusEnum.REJECTED)
		{
			resource.setStatusEnum(StatusEnum.UNVERIFIED);	
		}
		resource.setFirstName(request.getFirstname());
		// resource.setMiddleName(request.getMiddleName());
		resource.setLastName(request.getLastname());
		resource.setName(request.getFirstname() + " " + request.getLastname());
		resource.setGender(request.getGender());
		resource.setDeploymenType(request.getDeploymenType());
		resource.setCurrencyType(request.getCurrencyType()==null?CurrencyTypeEnum.INR:request.getCurrencyType());
		resource.setRateTypeEnum(request.getRateTypeEnum()==null?RateTypeEnum.MONTHLY:request.getRateTypeEnum());
		resource.setRate(request.getRate());
		resource.setResourceStatus(ResourceStatusEnum.AVAILABLE);
		resource.setLocation(request.getLocation());
		resource.setLatitude(request.getLatitude());
		resource.setLongitude(request.getLongitude());
        resource.setCountry(request.getCountryId()!=null?CommonUtil.getEntityReferenceWithId(request.getCountryId(), codeLookupService,
				CodeLookup.class):null);
        resource.setLastModifiedDate(LocalDateTime.now());
		// Availability
		if (CommonUtil.isValid(request.getAvailabilityId())) {
			CodeLookup availability = CommonUtil.getEntityReferenceWithId(request.getAvailabilityId(),
					codeLookupService, CodeLookup.class);
			resource.setAvailability(availability);
		}

		// Designation
		CodeLookup designation = null;
		if (!ObjectUtils.isEmpty(request.getDesignation())) {
			designation = addCodeLookups(request.getDesignation(), resource, designation,
					CodeLookUpConstant.DESIGNATION_CODELOOKUP_CODE);
			resource.setDesignation(designation);
		}

		// String base64profilePhoto;

		if (!ObjectUtils.isEmpty(request.getBase64profilePhoto()) && !ObjectUtils.isEmpty(MediaTypeEnum.IMAGE)
				&& resource.getId() != null) {
			Media media = attributeMediaUploadHelper
					.setMedia(
							CommonUtil.getFolderStructureForResource(resource.getVendor().getId(), "Resource",
									resource.getId(), "Image"),
							resource.getProfilePhoto(), request.getBase64profilePhoto(), MediaTypeEnum.IMAGE);
			resource.setProfilePhoto(media);
		}

		// delete profile Image
		if (!ObjectUtils.isEmpty(request.getDeletedImage())) {
			String deletedImages = request.getDeletedImage();
			String oldPath = StringUtils.substringBetween(deletedImages, "com/", "?X");
			imageService.deleteMedia(oldPath);
			fileUpload.deleteFileByS3(oldPath);
		}

		// String base64resume;
		if (!ObjectUtils.isEmpty(request.getBase64resume()) && resource.getId() != null) {
			int indexOf = request.getResumeName().indexOf(".");
			String resumeName = request.getResumeName().substring(0, indexOf).replaceAll("[^a-zA-Z0-9.' ']", "");
			Media media = attributeMediaUploadHelper.setMediaWithFileName(
					CommonUtil.getFolderStructureForResource(resource.getVendor().getId(), "Resource", resource.getId(),
							"Resume"),
					resource.getResume(), request.getBase64resume(), resumeName, MediaTypeEnum.DOCUMENT);

			resource.setResume(media);
		}

		// delete resume
		if (!ObjectUtils.isEmpty(request.getDeletedResume())) {
			String deletedResume = request.getDeletedResume();
			String oldPath = StringUtils.substringAfter(deletedResume, "com/");
			imageService.deleteMedia(oldPath);
			fileUpload.deleteFileByS3(oldPath);
		}
          resource.setUsdRate(request.getUsdRate());
          resource.setUsdRateType(request.getUsdRateType()==null?RateTypeEnum.MONTHLY:request.getUsdRateType());
		return resourceService.save(resource).getId();

	}

	private AddressRequest getAddressRequest(ResourceUpdateRequest request) {
		AddressRequest addressRequest = new AddressRequest();
		addressRequest.setCountryId(request.getCountryId());
		addressRequest.setStateId(request.getStateId());
		return addressRequest;
	}

	public List<AdvanceSearchDropdownModel> getResourceSkillsByResourceId(
			List<ResourceSkillsCodeLookup> findByResourceId) {
		
		return null;
	}

	public ResourceSkillsResponse getResourceSkillsByResourceId(Resource resource) {
		
		ResourceSkillsResponse.ResourceSkillsResponseBuilder builder = ResourceSkillsResponse.builder().resourceId(resource.getId())
				.advanceSearchDropdownModels(getSkillIdAndNameList(resource.getResourceSkillsCodeLookups()));
		return builder.build();
	}

	@Transactional(rollbackFor = Exception.class)
	public Map<String, Object> updatePersonalDetail(ResourcePersonalDetailUpdateRequest request) throws Exception {
		Resource resource = resourceService.findById(request.getId());
		if (resource == null) {
			throw new Exception("Invalid Id");
		}
		Map<String, Object> responseObject = new HashMap<>();
		resource.setLastModifiedDate(LocalDateTime.now());
		if (resource.getName().equals(request.getFirstname() + " " + request.getLastname())
				&& resource.getGender().equals(request.getGender())
				&& ObjectUtils.isEmpty(request.getBase64profilePhoto())
				&& ObjectUtils.isEmpty(request.getBase64resume())) {
			responseObject.put("status", resource.getStatusEnum());
			responseObject.put("id", resource.getId());
			resourceService.save(resource);
			return responseObject;
		}
		resource.setFirstName(request.getFirstname());
		resource.setLastName(request.getLastname());
		resource.setName(request.getFirstname() + " " + request.getLastname());
		resource.setGender(request.getGender());
		
		// String base64profilePhoto;
		if (!ObjectUtils.isEmpty(request.getBase64profilePhoto()) && !ObjectUtils.isEmpty(MediaTypeEnum.IMAGE)
				&& resource.getId() != null) {
			Media media = attributeMediaUploadHelper
					.setMedia(
							CommonUtil.getFolderStructureForResource(resource.getVendor().getId(), "Resource",
									resource.getId(), "Image"),
							resource.getProfilePhoto(), request.getBase64profilePhoto(), MediaTypeEnum.IMAGE);
			resource.setProfilePhoto(media);
			if(resource.getStatusEnum().equals(StatusEnum.REJECTED)) {
				codeLookUpRelationService.setActive(codeLookUpRelationService.findByRefIdAndRefTypeAndType(resource.getId(),RefTypeEnum.RESOURCE,CodeLookUpRelationTypeEnum.RESOURCE_REJECT_REASON),Constants.ADD_CANDIDATE_PROFILE_PICTURE_REJECT_REASON);
			}
		}

		// delete profile Image
		if (!ObjectUtils.isEmpty(request.getDeletedImage())) {
			String deletedImages = request.getDeletedImage();
			String oldPath = StringUtils.substringBetween(deletedImages, "com/", "?X");
			imageService.deleteMedia(oldPath);
			fileUpload.deleteFileByS3(oldPath);
		}

		// String base64resume;
		if (!ObjectUtils.isEmpty(request.getBase64resume()) && resource.getId() != null) {
			int indexOf = request.getResumeName().indexOf(".");
			String resumeName = request.getResumeName().substring(0, indexOf).replaceAll("[^a-zA-Z0-9.' ']", "");
			Media media = attributeMediaUploadHelper.setMediaWithFileName(
					CommonUtil.getFolderStructureForResource(resource.getVendor().getId(), "Resource", resource.getId(),
							"Resume"),
					resource.getResume(), request.getBase64resume(), resumeName, MediaTypeEnum.DOCUMENT);

			resource.setResume(media);
			if(resource.getStatusEnum().equals(StatusEnum.REJECTED)) {
				codeLookUpRelationService.setActive(codeLookUpRelationService.findByRefIdAndRefTypeAndType(resource.getId(),RefTypeEnum.RESOURCE,CodeLookUpRelationTypeEnum.RESOURCE_REJECT_REASON),Constants.RESUME_IS_NOT_MATCHED_AS_PER_EXPERIENCE_REJECT_REASON);
				codeLookUpRelationService.setActive(codeLookUpRelationService.findByRefIdAndRefTypeAndType(resource.getId(),RefTypeEnum.RESOURCE,CodeLookUpRelationTypeEnum.RESOURCE_REJECT_REASON),Constants.UPLOAD_PROPER_DETAILED_RESUME_REJECT_REASON);
				codeLookUpRelationService.setActive(
						codeLookUpRelationService.findByRefIdAndRefTypeAndType(resource.getId(), RefTypeEnum.RESOURCE,
								CodeLookUpRelationTypeEnum.RESOURCE_REJECT_REASON),
						Constants.REMOVE_CONTACT_DETAILS_FROM_RESUME_REJECT_REASON);

				
			} 
		}

		// delete resume
		if (!ObjectUtils.isEmpty(request.getDeletedResume())) {
			String deletedResume = request.getDeletedResume();
			String oldPath = StringUtils.substringAfter(deletedResume, "com/");
			imageService.deleteMedia(oldPath);
			fileUpload.deleteFileByS3(oldPath);
		}
		if(!resource.getStatusEnum().equals(StatusEnum.REJECTED))
		{
		resource.setStatusEnum(StatusEnum.UNVERIFIED);
		}

		resourceService.save(resource);
		responseObject.put("status", resource.getStatusEnum());
		responseObject.put("id", resource.getId());
		return responseObject;

	}

	@Transactional(rollbackFor = Exception.class)
	public Long updateOtherDetails(ResourceOtherDetailUpdateRequest request) throws Exception {
		Resource resource = resourceService.findById(request.getId());
		if (resource == null) {
			throw new Exception("Invalid Id");
		}

		resource.setCurrencyType(request.getCurrencyType() == null ? CurrencyTypeEnum.INR : request.getCurrencyType());
		resource.setRateTypeEnum(request.getRateTypeEnum());
		resource.setRate(request.getRate());
		resource.setUsdRate(request.getUsdRate());
		resource.setUsdRateType(request.getUsdRateType());
		resource.setDeploymenType(request.getDeploymenType());
		resource.setLocation(request.getLocation());
		resource.setLatitude(request.getLatitude());
		resource.setLongitude(request.getLongitude());
		resource.setCountry(request.getCountryId() != null
				? CommonUtil.getEntityReferenceWithId(request.getCountryId(), codeLookupService, CodeLookup.class)
				: null);
		resource.setLastModifiedDate(LocalDateTime.now());
		// Availability
		if (CommonUtil.isValid(request.getAvailabilityId())) {
			CodeLookup availability = CommonUtil.getEntityReferenceWithId(request.getAvailabilityId(),
					codeLookupService, CodeLookup.class);
			resource.setAvailability(availability);
		}

		// Designation
		CodeLookup designation = null;
		if (!ObjectUtils.isEmpty(request.getDesignation())) {
			designation = addCodeLookups(request.getDesignation(), resource, designation,
					CodeLookUpConstant.DESIGNATION_CODELOOKUP_CODE);
			resource.setDesignation(designation);
		}
		return resourceService.save(resource).getId();
	}

}
