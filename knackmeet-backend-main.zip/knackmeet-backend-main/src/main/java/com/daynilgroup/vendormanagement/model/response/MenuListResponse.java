package com.daynilgroup.vendormanagement.model.response;

import java.io.Serializable;
import java.util.List;

import com.daynilgroup.vendormanagement.constants.MenuEnum;
import com.daynilgroup.vendormanagement.model.inf.ListResponse;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 *
 * @author Manish
 */
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class MenuListResponse implements Serializable, ListResponse {
	static final long serialVersionUID = 1L;
	private Long id;
	private String title;
	private String path;
	private String icon;
	private Integer displayOrder;
	private Long parentId;
	private Boolean active;
	private Boolean masterMenu;
	private List<MenuListResponse> subMenuListResponse;
	private MenuEnum code;
}