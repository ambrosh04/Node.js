package com.daynilgroup.vendormanagement.admin.rest.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.daynilgroup.vendormanagement.constants.UrlConstants;
import com.daynilgroup.vendormanagement.util.EmailSenderUtil;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;

@FieldDefaults(level = AccessLevel.PRIVATE)
@RestController
@RequestMapping(UrlConstants.ADMIN_JOB_BASE_URL)
public class AdminJobRestController {

	@Autowired
	EmailSenderUtil emailSenderUtil;

	@GetMapping(path = UrlConstants.ADMIN_SEND_MAIL_VERIFIED_JOB_DETAILS)
	public ResponseEntity<Object> senMail(@RequestParam Long jobId) {
		try {
			return new ResponseEntity<>(emailSenderUtil.getJobDetails(jobId), HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<Object>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

}
