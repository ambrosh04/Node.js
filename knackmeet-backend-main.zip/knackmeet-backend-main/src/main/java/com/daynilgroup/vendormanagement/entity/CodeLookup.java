package com.daynilgroup.vendormanagement.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.daynilgroup.vendormanagement.entity.inf.Image;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

/**
 *
 * @author manish
 */
@Entity
@Table(name = "code_lookup")
@NoArgsConstructor
@Getter
@Setter
@FieldDefaults(level = AccessLevel.PRIVATE)
public class CodeLookup extends BaseEntity implements Image {

	static final long serialVersionUID = 1L;

	@Column(name = "description")
	String description;

	@Column(name = "name")
	String name;

	@JoinColumn(name = "type_id", referencedColumnName = "id")
	@ManyToOne(optional = false,fetch = FetchType.EAGER)
	CodeLookupType type;

	@JoinColumn(name = "image_id", referencedColumnName = "id")
	@ManyToOne(fetch = FetchType.EAGER)
	Media imageId;

	@Column(name = "display_order")
	Integer displayOrder;

	@JoinColumn(name = "parent_id", referencedColumnName = "id")
	@ManyToOne(fetch = FetchType.EAGER)
	CodeLookup parentId;
}