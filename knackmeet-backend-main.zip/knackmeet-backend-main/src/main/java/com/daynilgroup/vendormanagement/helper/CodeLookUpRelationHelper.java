package com.daynilgroup.vendormanagement.helper;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.daynilgroup.vendormanagement.entity.CodeLookUpRelation;
import com.daynilgroup.vendormanagement.model.request.CodeLookUpRelationRequest;
import com.daynilgroup.vendormanagement.model.response.AdvanceSearchDropdownModel;
import com.daynilgroup.vendormanagement.model.response.CodelookupRelationListResponse;
import com.daynilgroup.vendormanagement.service.CodeLookUpRelationService;
import com.daynilgroup.vendormanagement.service.CodeLookupService;
import com.daynilgroup.vendormanagement.service.CodeLookupTypeService;


@Component
public class CodeLookUpRelationHelper extends AbstractHelper<CodeLookUpRelation, CodeLookUpRelationRequest, CodelookupRelationListResponse, Object, Object>{

	@Autowired
	CodeLookUpRelationService codeLookUpRelationService;
	@Autowired
	CodeLookupService codeLookupService;
	@Autowired
	CodeLookupTypeService codeLookupTypeService;

	public List<CodeLookUpRelation> setEntity(CodeLookUpRelationRequest request) {
		List<CodeLookUpRelation> codeLookUpRelations = new ArrayList<CodeLookUpRelation>();

		CodeLookUpRelation codeLookUpRelation = null;
		for (AdvanceSearchDropdownModel advanceSearchDropdownModel : request.getReasons()) {
			codeLookUpRelation = new CodeLookUpRelation();
			codeLookUpRelation.setRefId(request.getRefId());
			codeLookUpRelation.setRefType(request.getRefType());
			codeLookUpRelation.setType(request.getType());
			codeLookUpRelation.setCodeLookup(codeLookupService.findById(advanceSearchDropdownModel.getValue()));
			codeLookUpRelations.add(codeLookUpRelation);
		}
		return codeLookUpRelations;
	}

	@Override
	public CodeLookUpRelation getEntity(CodeLookUpRelationRequest request) throws Exception {
		return null;
	}

	@Override
	public List<CodelookupRelationListResponse> getListResponse(List<CodeLookUpRelation> CodelookupRelationList) {
		List<CodelookupRelationListResponse> CodelookupRelationListResponseList = new ArrayList<>();
		CodelookupRelationList.forEach(codeLookUpRelation -> {
			CodelookupRelationListResponseList.add(CodelookupRelationListResponse.builder()
					.id(codeLookUpRelation.getId()).name(codeLookUpRelation.getCodeLookup().getName())
					.active(codeLookUpRelation.getActive()).build());
		});
		return CodelookupRelationListResponseList;
	}

	@Override
	public Object getDetailResponse(CodeLookUpRelation entity) {
		return null;
	}

	@Override
	public Object getDetailForAdminResponse(CodeLookUpRelation entity) {
		return null;
	}

}
