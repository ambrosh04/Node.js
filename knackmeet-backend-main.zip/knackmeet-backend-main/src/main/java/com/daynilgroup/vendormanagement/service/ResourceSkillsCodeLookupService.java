package com.daynilgroup.vendormanagement.service;

import java.util.List;

import com.daynilgroup.vendormanagement.entity.ResourceSkillsCodeLookup;
import com.daynilgroup.vendormanagement.model.filter.ResourceSkillsFilterModel;
import com.daynilgroup.vendormanagement.model.pag.PageModel;

public interface ResourceSkillsCodeLookupService extends AbstractService<ResourceSkillsCodeLookup>{
	
	public void deleteByResourceId(Long resourceId);

	List<ResourceSkillsCodeLookup> findAllByResourceId(Long resourceId);

	PageModel getResourceList(ResourceSkillsFilterModel resourceSkillsFilterModel);
	
	ResourceSkillsCodeLookup findByResourceIdAndCodeLookupId(Long resourceId, Long codeLookupId );
}
