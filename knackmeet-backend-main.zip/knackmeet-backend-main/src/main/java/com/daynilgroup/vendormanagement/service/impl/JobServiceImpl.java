package com.daynilgroup.vendormanagement.service.impl;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.EnumUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.daynilgroup.vendormanagement.constants.CurrencyTypeEnum;
import com.daynilgroup.vendormanagement.constants.DeploymentTypeEnum;
import com.daynilgroup.vendormanagement.constants.StatusEnum;
import com.daynilgroup.vendormanagement.entity.Job;
import com.daynilgroup.vendormanagement.entity.Resource;
import com.daynilgroup.vendormanagement.entity.SkillsCodeLookup;
import com.daynilgroup.vendormanagement.entity.Vendor;
import com.daynilgroup.vendormanagement.helper.CodeLookUpRelationHelper;
import com.daynilgroup.vendormanagement.model.inf.DropdownEnumModel;
import com.daynilgroup.vendormanagement.model.pag.PageModel;
import com.daynilgroup.vendormanagement.model.request.CodeLookUpRelationRequest;
import com.daynilgroup.vendormanagement.model.request.JobFilterRequest;
import com.daynilgroup.vendormanagement.model.request.JobSearchRequest;
import com.daynilgroup.vendormanagement.model.response.DropdownResponse;
import com.daynilgroup.vendormanagement.model.response.JobListResponse;
import com.daynilgroup.vendormanagement.model.response.StatusCountResponse;
import com.daynilgroup.vendormanagement.model.response.VerificationCountResponse;
import com.daynilgroup.vendormanagement.repository.JobRepository;
import com.daynilgroup.vendormanagement.repository.ResourceJobsRepository;
import com.daynilgroup.vendormanagement.repository.VendorRepository;
import com.daynilgroup.vendormanagement.service.JobService;
import com.daynilgroup.vendormanagement.service.ResourceService;
import com.daynilgroup.vendormanagement.service.SkillsCodeLookupService;
import com.daynilgroup.vendormanagement.util.CommonUtil;
import com.daynilgroup.vendormanagement.util.EntityUtil;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;

@Service
@FieldDefaults(level = AccessLevel.PRIVATE)
public class JobServiceImpl implements JobService {

	@Autowired
	JobRepository jobRepository;

	@Autowired
	SkillsCodeLookupService skillsCodeLookupService;

	@Autowired
	EntityUtil entityUtil;
	
	@Autowired
	ResourceService resourceService;

	@Autowired	
	VendorRepository vendorRepository;

	@Autowired
	ResourceJobsRepository resourceJobsRepository;
	
	@Autowired
	CodeLookUpRelationHelper codeLookUpRelationHelper;

	@Override
	public JpaRepository<Job, Long> getJpaRepository() {
		return jobRepository;
	}

	@Override
	public Page<Job> getJobsList(Pageable pageable, StatusEnum jobStatus,String title,String agencyName) {
		return jobRepository.getJobList(pageable,jobStatus,title,agencyName);
	}

	@Override
	public PageModel getJobsFilterList(JobFilterRequest jobsFilterRequest) {
		PageModel pageModel = jobRepository.getJobsFilterList(jobsFilterRequest);
		if (!ObjectUtils.isEmpty(pageModel.getData())) {
			List<JobListResponse> jobListResponse = (List<JobListResponse>) pageModel.getData();
			jobListResponse.forEach(jobs -> {
				Job job = findById(jobs.getId());
				List<String> skills = new ArrayList<>();
				List<SkillsCodeLookup> skillsCodeLookups = skillsCodeLookupService.findAllByJobId(jobs.getId());
				if (!CollectionUtils.isEmpty(skillsCodeLookups)) {
					skillsCodeLookups.forEach(skill -> {
						skills.add(skill.getCodeLookup().getName());
					});
					jobs.setSkills(skills);
					jobs.setApplicantsCount(resourceJobsRepository.findByJobIdAndDeletedFalse(job.getId()));
				}
			});
		}
		return pageModel;

	}

	@Override
	public Page<Job> getListJobsByVendorId(Pageable pageable) {
		return jobRepository.findByVendorId(entityUtil.getCurrentVendorId(), pageable);
	}

	@Override
	public Long getCountJobApllication(Long vendorId) {
		return jobRepository.getCountJobApllication(vendorId);
	}

	@Override
	public Long getJobsCountByVendorId(Long id) {
		return jobRepository.countByVendorIdAndDeletedFalse(id);
	}

	@Override
	public void verifyStatus(Long jobId, StatusEnum statusEnum, CodeLookUpRelationRequest codeLookUpRelationRequest) throws Exception {
		Job job = findById(jobId);
		if (!ObjectUtils.isEmpty(job)) {
			job.setStatusEnum(statusEnum);
			if(job.getStatusEnum() == StatusEnum.REJECTED)
				job.setCodeLookUpRelation(codeLookUpRelationHelper.setEntity(codeLookUpRelationRequest));
			save(job);
		} else {
			throw new Exception("No Job Found For Given Id " + jobId);
		}
	}

	private StatusCountResponse getJobStatusCountResponse(List<Job> jobs) {
		Long verifiedCount = jobs.stream()
				.filter(job -> StatusEnum.VERIFIED.equals(job.getStatusEnum()) && Boolean.TRUE.equals(job.getActive()))
				.count();
		Long unVerifiedCount = jobs.stream().filter(
				job -> StatusEnum.UNVERIFIED.equals(job.getStatusEnum()) && Boolean.TRUE.equals(job.getActive()))
				.count();
		Long onHoldCount = jobs.stream().filter(
				job -> Boolean.FALSE.equals(job.getActive()) && !StatusEnum.REJECTED.equals(job.getStatusEnum()) && !StatusEnum.CLOSED.equals(job.getStatusEnum()))
				.count();
		Long rejectedCount = jobs.stream().filter(resource -> StatusEnum.REJECTED.equals(resource.getStatusEnum()))
				.count();
		Long closedCount = jobs.stream().filter(resource -> StatusEnum.CLOSED.equals(resource.getStatusEnum())).count();
		return StatusCountResponse.builder().verified(CommonUtil.getCountOrZero(verifiedCount))
				.notVerified(CommonUtil.getCountOrZero(unVerifiedCount)).onHold(CommonUtil.getCountOrZero(onHoldCount))
				.closed(closedCount).rejected(CommonUtil.getCountOrZero(rejectedCount)).all(Long.valueOf(jobs.size()))
				.build();
	}

	@Override
	public StatusCountResponse getJobStatusCount() {

		return getJobStatusCountResponse(jobRepository.findByVendorId(entityUtil.getCurrentVendorId()));
	}

	@Override
	public PageModel getJobsFilterListByVendorId(JobSearchRequest jobRequestAdvanced) {
		PageModel pageModel = jobRepository.getJobsSearchFilter(jobRequestAdvanced);
		if (!ObjectUtils.isEmpty(pageModel.getData())) {
			List<JobListResponse> jobListResponse = (List<JobListResponse>) pageModel.getData();
			jobListResponse.forEach(jobs -> {
				List<String> skills = new ArrayList<>();
				List<SkillsCodeLookup> skillsCodeLookups = skillsCodeLookupService.findAllByJobId(jobs.getId());
				if (!CollectionUtils.isEmpty(skillsCodeLookups)) {
					skillsCodeLookups.forEach(skill -> {
						skills.add(skill.getCodeLookup().getName());
					});
					jobs.setSkills(skills);
				}
			});
		}
		return pageModel;
	}

	@Override
	public Page<Job> getJobListExceptVendorId(Pageable pageable) {
		return jobRepository.getJobListExceptVendorId(entityUtil.getCurrentVendorId(), pageable);

	}

	private VerificationCountResponse getVerificationCountResponse(List<Job> jobs) {
		Long verifiedCount = jobs.stream().filter(job -> job.getStatusEnum() == StatusEnum.VERIFIED).count();
		Long pendingCount = jobs.stream().filter(job -> job.getStatusEnum() == StatusEnum.UNVERIFIED).count();
		Long rejectedCount = jobs.stream().filter(job -> job.getStatusEnum() == StatusEnum.REJECTED).count();
		Long closedCount = jobs.stream().filter(job -> StatusEnum.CLOSED.equals(job.getStatusEnum())).count();
		VerificationCountResponse.VerificationCountResponseBuilder builder = VerificationCountResponse.builder()
				.all(Long.valueOf(jobs.size())).pending(pendingCount).rejected(rejectedCount).verified(verifiedCount).closed(closedCount);
		return builder.build();
	}

	@Override
	public VerificationCountResponse getJobVerificationCount() {

		return getVerificationCountResponse(jobRepository.findByDeletedFalse());
	}

	@Override
	public Long getAllJobCount() {

		return jobRepository.countByDeletedFalse();
	}

	@Override
	public void updateStatus(Long jobId, Boolean onHold) throws Exception {
		Job job = findById(jobId);
		if (!ObjectUtils.isEmpty(job)) {
			if (!CommonUtil.isTrue(onHold)) {
				job.setActive(false);
			} else
				job.setActive(onHold);
			save(job);
		} else {
			throw new Exception("No Job Found For Given Id " + jobId);
		}
	}

	@Override
	public List<DropdownResponse> getJobTitleDropDown(StatusEnum jobStatus) {
		List<DropdownResponse> dropdownResponses = new ArrayList<>();
		jobRepository.getJobListByCurrentVenodorId(entityUtil.getCurrentVendorId(),jobStatus).forEach(dropdown -> {
			dropdownResponses.add(new DropdownResponse(dropdown.getId(), dropdown.getTitle()));
		});
		return dropdownResponses;
	}

	@Override
	public Page<Job> getJobListByVendorId(Long vendorId, Pageable pageable) {
		return jobRepository.findByVendorIdAndDeletedFalse(vendorId, pageable);
	}

	@Override
	public void updateStatus(Long jobId, StatusEnum statusEnum) throws Exception {
		Job job = findById(jobId);
		if (ObjectUtils.isEmpty(job)) {
			throw new Exception("No Job Found For Given Id " + jobId);
		}
		job.setStatusEnum(statusEnum);
		job.setClosedDate(LocalDateTime.now());
		save(job);
	}

	@Override
	public List<DropdownResponse> jobsByResourceCurrency(Long resourceId) {
		List<DropdownResponse> dropdownResponses = new ArrayList<>();
		Resource resource = resourceService.findById(resourceId);
		if (resource.getRate() != null && resource.getUsdRate() == null) {
			jobRepository.getCurrentVenodorId(entityUtil.getCurrentVendorId()).stream()
					.filter(job -> job.getCurrencyType().equals(CurrencyTypeEnum.INR)).forEach(dropdown -> {
						dropdownResponses.add(new DropdownResponse(dropdown.getId(), dropdown.getTitle()));
					});
		} else if (resource.getRate() == null && resource.getUsdRate() != null) {
			jobRepository.getCurrentVenodorId(entityUtil.getCurrentVendorId()).stream()
					.filter(job -> job.getCurrencyType().equals(CurrencyTypeEnum.USD)).forEach(dropdown -> {
						dropdownResponses.add(new DropdownResponse(dropdown.getId(), dropdown.getTitle()));
					});
		} else {
			jobRepository.getCurrentVenodorId(entityUtil.getCurrentVendorId()).forEach(dropdown -> {
				dropdownResponses.add(new DropdownResponse(dropdown.getId(), dropdown.getTitle()));
			});
		}
		return dropdownResponses;
	}
	
	@Override
    public List<DropdownEnumModel> getDeploymentTypeDropdown() {
		List<DropdownEnumModel> deploymentTypeDropdown = new ArrayList<>();
		List<DeploymentTypeEnum> deploymentTypeList = EnumUtils.getEnumList(DeploymentTypeEnum.class);
		deploymentTypeList.forEach(deploymentType -> {
			if (!deploymentType.equals(DeploymentTypeEnum.REMOTE_AND_ONSITE))
				deploymentTypeDropdown.add(new DropdownEnumModel(deploymentType.getDisplayName(), deploymentType.toString()));
		});
		return deploymentTypeDropdown;
	}

	@Override
	public List<Job> getJobContracts(Long vendorId) {
		return jobRepository.getJobContracts(vendorId);
	}

	@Override
	public List<Vendor> sendMailToVerfiedVendor(Long jobId) {
		Job job = findById(jobId);
		return vendorRepository.getVerifiedVendorsAndIdNot(job.getVendor().getId());
	}

}
