package com.daynilgroup.vendormanagement.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.daynilgroup.vendormanagement.constants.StatusEnum;
import com.daynilgroup.vendormanagement.entity.Job;
import com.daynilgroup.vendormanagement.entity.Vendor;
import com.daynilgroup.vendormanagement.model.inf.DropdownEnumModel;
import com.daynilgroup.vendormanagement.model.pag.PageModel;
import com.daynilgroup.vendormanagement.model.request.CodeLookUpRelationRequest;
import com.daynilgroup.vendormanagement.model.request.JobFilterRequest;
import com.daynilgroup.vendormanagement.model.request.JobSearchRequest;
import com.daynilgroup.vendormanagement.model.response.DropdownResponse;
import com.daynilgroup.vendormanagement.model.response.StatusCountResponse;
import com.daynilgroup.vendormanagement.model.response.VerificationCountResponse;

public interface JobService extends AbstractService<Job> {

	Page<Job> getJobsList(Pageable pageable, StatusEnum jobStatus,String title,String agencyName);

	PageModel getJobsFilterList(JobFilterRequest jobsFilterRequest);

	Page<Job> getListJobsByVendorId(Pageable pageable);

	Long getCountJobApllication(Long vendorId);

	Long getJobsCountByVendorId(Long id);

	StatusCountResponse getJobStatusCount();

	void verifyStatus(Long jobId, StatusEnum statusEnum, CodeLookUpRelationRequest codeLookUpRelationRequest) throws Exception;

	PageModel getJobsFilterListByVendorId(JobSearchRequest jobRequestAdvanced);

	Page<Job> getJobListExceptVendorId(Pageable pageable);

	VerificationCountResponse getJobVerificationCount();

	Long getAllJobCount();

	void updateStatus(Long jobId, Boolean onHold) throws Exception;

	List<DropdownResponse> getJobTitleDropDown(StatusEnum jobStatus);
	
	Page<Job> getJobListByVendorId(Long vendorId,Pageable pageable);
	
	void updateStatus(Long jobId, StatusEnum statusEnum) throws Exception;
	
	List<DropdownResponse> jobsByResourceCurrency(Long resourceId);
	
    List<DropdownEnumModel> getDeploymentTypeDropdown();
    
	List<Job> getJobContracts(Long vendorId);

	List<Vendor> sendMailToVerfiedVendor(Long jobId);
}
