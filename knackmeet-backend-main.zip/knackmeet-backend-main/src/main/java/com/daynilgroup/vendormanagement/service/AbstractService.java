package com.daynilgroup.vendormanagement.service;

import java.util.List;
import java.util.Optional;

import org.apache.commons.lang3.reflect.FieldUtils;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import com.daynilgroup.vendormanagement.entity.BaseEntity;

public interface AbstractService<Entity> {

	JpaRepository<Entity, Long> getJpaRepository();

	default Entity save(Entity entity) {
		return (Entity) getJpaRepository().save(entity);
	}

	default List<Entity> saveAll(List<Entity> entityList) {
		return getJpaRepository().saveAll(entityList);
	}

	default Entity softDeleteById(Long id) throws Exception {
		Optional<Entity> optional = getJpaRepository().findById(id);
		if (optional.isPresent()) {
			Entity entity = optional.get();
			return softDelete(entity);
		} else {
			throw new Exception("Couldn't delete. Entity with id " + id + " not found");
		}
	}

	default Entity softDelete(Entity entity) throws IllegalAccessException {
		if (entity instanceof BaseEntity) {
			((BaseEntity) entity).setDeleted(Boolean.TRUE);
		} else {
			FieldUtils.writeField(entity, "deleted", true, true);
		}
		return getJpaRepository().save(entity);
	}

	default void delete(Entity entity) {
		getJpaRepository().delete(entity);
	}

	default Entity findById(Long id) {
		Optional<Entity> optional = getJpaRepository().findById(id);
		if (optional.isPresent()) {
			return optional.get();
		}
		return null;
	}

	default List<Entity> findAll() {
		return getJpaRepository().findAll();
	}

	default Page<Entity> findAll(Pageable pageable) {
		return getJpaRepository().findAll(pageable);
	}

	default public boolean existsById(Long id) {
		return getJpaRepository().existsById(id);
	}

	@SuppressWarnings({ "unchecked" })
	default public boolean exists(Example example) {
		return getJpaRepository().exists(example);
	}

	default public Entity find(Example<Entity> example) {
		Optional<Entity> findOne = getJpaRepository().findOne(example);
		if (findOne.isPresent()) {
			return findOne.get();
		}
		return null;
	}

}
