package com.daynilgroup.vendormanagement.service;

import com.daynilgroup.vendormanagement.constants.RoleTypeEnum;
import com.daynilgroup.vendormanagement.entity.Role;

public interface  RoleService extends AbstractService<Role>{

	Role findByType(RoleTypeEnum type);

}
