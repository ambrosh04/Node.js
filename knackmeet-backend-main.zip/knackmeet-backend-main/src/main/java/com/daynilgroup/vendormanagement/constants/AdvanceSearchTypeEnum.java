package com.daynilgroup.vendormanagement.constants;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.experimental.FieldDefaults;

@Getter
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public enum AdvanceSearchTypeEnum {

	JOB("Job"), RESOURCE("Resource");

	String displayName;

}
