package com.daynilgroup.vendormanagement.rest.controller.inf.embedded;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.daynilgroup.vendormanagement.helper.AbstractHelper;
import com.daynilgroup.vendormanagement.service.AbstractService;
/**
 * @author Prerana
 *
 */
public interface BaseRestInf {

    Logger BASE_LOGGER = LoggerFactory.getLogger(BaseRestInf.class);

    AbstractService getService();

    AbstractHelper getHelper();

}