package com.daynilgroup.vendormanagement.model.request;

import com.daynilgroup.vendormanagement.constants.StatusEnum;

import lombok.AccessLevel;
import lombok.Data;
import lombok.experimental.FieldDefaults;

@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
public class RejectRequest {

	Long vendorId;

	StatusEnum status;

	String reason;
}
