package com.daynilgroup.vendormanagement.rest.exception;

public class CustomException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5860598227195078183L;

	public CustomException(String message) {
		super(message);
	}

}
