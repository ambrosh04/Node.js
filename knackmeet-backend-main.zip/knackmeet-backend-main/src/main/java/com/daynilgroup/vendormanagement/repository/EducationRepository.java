package com.daynilgroup.vendormanagement.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.daynilgroup.vendormanagement.entity.Address;
import com.daynilgroup.vendormanagement.entity.Education;

@Repository
public interface EducationRepository extends JpaRepository<Education, Long>  {

	@Modifying
	@Transactional
	@Query("update Education e set e.deleted=true where e.id in :deleteEducations")
	void softDeleteByInId(List<Long> deleteEducations);

	@Query("SELECT e FROM Education e WHERE e.resource.id=:resourceId AND (e.deleted=false or e.deleted IS NULL) ORDER BY e.fromYear DESC,e.fromMonth DESC")
	List<Education> getAllByDeleteFalse(Long resourceId);

}
