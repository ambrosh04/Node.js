package com.daynilgroup.vendormanagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;

import com.daynilgroup.vendormanagement.entity.RoleAccess;

public interface RoleAccessRepository extends JpaRepository<RoleAccess, Long> {

	@Transactional
	void deleteByRoleId(Long userId);
}
