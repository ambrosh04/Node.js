package com.daynilgroup.vendormanagement.model.response;

import java.io.Serializable;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class CodelookupRelationListResponse  implements Serializable {
	
	private static final long serialVersionUID = 1L;

	Long id;
	
	String name;
	
	Boolean active;
	
}
