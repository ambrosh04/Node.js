package com.daynilgroup.vendormanagement.helper;

import java.time.ZoneId;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.daynilgroup.vendormanagement.constants.CodeLookUpConstant;
import com.daynilgroup.vendormanagement.constants.ResourceStatusEnum;
import com.daynilgroup.vendormanagement.constants.StatusEnum;
import com.daynilgroup.vendormanagement.entity.CodeLookup;
import com.daynilgroup.vendormanagement.model.inf.DateUtil;
import com.daynilgroup.vendormanagement.entity.CodeLookupType;
import com.daynilgroup.vendormanagement.entity.Job;
import com.daynilgroup.vendormanagement.entity.SkillsCodeLookup;
import com.daynilgroup.vendormanagement.entity.Vendor;
import com.daynilgroup.vendormanagement.model.request.AddressRequest;
import com.daynilgroup.vendormanagement.model.request.JobRequest;
import com.daynilgroup.vendormanagement.model.response.AdvanceSearchDropdownModel;
import com.daynilgroup.vendormanagement.model.response.JobDetailAdminResponse;
import com.daynilgroup.vendormanagement.model.response.JobDetailResponse;
import com.daynilgroup.vendormanagement.model.response.JobDetailsResponses;
import com.daynilgroup.vendormanagement.model.response.JobListResponse;
import com.daynilgroup.vendormanagement.model.response.NotificationJobListResponse;
import com.daynilgroup.vendormanagement.repository.ResourceJobsRepository;
import com.daynilgroup.vendormanagement.repository.UserRepository;
import com.daynilgroup.vendormanagement.request.JobDescriptionUpdateRequest;
import com.daynilgroup.vendormanagement.service.CodeLookupService;
import com.daynilgroup.vendormanagement.service.CodeLookupTypeService;
import com.daynilgroup.vendormanagement.service.JobService;
import com.daynilgroup.vendormanagement.service.ResourceJobsService;
import com.daynilgroup.vendormanagement.service.SkillsCodeLookupService;
import com.daynilgroup.vendormanagement.service.VendorService;
import com.daynilgroup.vendormanagement.util.CommonUtil;
import com.daynilgroup.vendormanagement.util.EmailSenderUtil;
import com.daynilgroup.vendormanagement.util.EntityUtil;
import com.daynilgroup.vendormanagement.util.FileUpload;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;

@Service
@FieldDefaults(level = AccessLevel.PRIVATE)
public class JobHelper
		extends AbstractHelper<Job, JobRequest, JobListResponse, JobDetailResponse, JobDetailAdminResponse> {

	@Autowired
	JobService jobService;

	@Autowired
	CodeLookupService codeLookupService;

	@Autowired
	CodeLookupTypeService codeLookupTypeService;

	@Autowired
	SkillsCodeLookupService skillsCodeLookupService;

	@Autowired
	VendorService vendorService;

	@Autowired
	ResourceJobsService resourceJobsService;
	
	@Autowired
	AddressHelper addressHelper;

	@Autowired
	EntityUtil entityUtil;
	
	@Autowired
	EmailSenderUtil emailSenderUtil;

	@Autowired
	UserRepository userRepository;
	@Autowired
	ResourceJobsRepository resourceJobsRepository;
	
	@Autowired
	FileUpload fileUpload;

	@Transactional
	@Override
	public Job getEntity(JobRequest request) throws Exception {
		Job job;
		if (CommonUtil.isValid(request.getId())) {
			job = jobService.findById(request.getId());
			skillsCodeLookupService.deleteByJobId(job.getId());
			if(job.getStatusEnum()==StatusEnum.REJECTED)
			{
				job.setStatusEnum(StatusEnum.UNVERIFIED);	
			}
		} else {
			job = new Job();
			job.setStatusEnum(StatusEnum.UNVERIFIED);

		}

		if (request.getDescription().length()<50 || request.getDescription().length()>5000) 
			throw new RuntimeException("Description must in between 50 to 5000 character.");
		
		job.setTitle(request.getTitle());
		job.setMinExperience(request.getMinExperience());
		job.setMaxExperience(request.getMaxExperience());
		job.setCurrencyType(request.getCurrencyType());
		job.setDescription(request.getDescription());
		job.setMinRate(request.getMinRate());
		job.setMaxRate(request.getMaxRate());
		job.setNoOfResources(request.getNoOfResources());
		job.setRateTypeEnum(request.getRateTypeEnum());
		job.setWorkFrom(request.getWorkFrom());
	//	job.setStartDate(request.getStartDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime());
		
		job.setJobNo(UUID.randomUUID().toString());
		job.setLocation(request.getLocation());
		job.setLatitude(request.getLatitude());
		job.setLongitude(request.getLongitude());
		job.setCountry(request.getCountryId()!=null?CommonUtil.getEntityReferenceWithId(request.getCountryId(), codeLookupService,
				CodeLookup.class):null);
		
		job.setCategory(request.getCategoryId()!=null?CommonUtil.getEntityReferenceWithId(request.getCategoryId(), codeLookupService,
				CodeLookup.class):null);
		
		job.setTimeZoneEnum(request.getTimeZoneEnum());
		job.setStartTime(request.getStartTime());
		job.setEndTime(request.getEndTime());
		Vendor vendor = CommonUtil.getEntityReferenceWithId(
				request.getVendorId() != null ? request.getVendorId() : entityUtil.getCurrentVendorId(), vendorService,
				Vendor.class);
		job.setVendor(vendor);


		if (CommonUtil.isValid(request.getDurationId())) {
			CodeLookup duration = CommonUtil.getEntityReferenceWithId(request.getDurationId(), codeLookupService,
					CodeLookup.class);
			job.setDuration(duration);
		}

		jobService.save(job);
		
		if (!CollectionUtils.isEmpty(request.getSkillsCodeLookup())) {
			addSkillsCodeLookup(request.getSkillsCodeLookup(), job, CodeLookUpConstant.SKILLS_CODELOOKUP_CODE);
		}
		return job;
	}

	private AddressRequest getAddressRequest(JobRequest request) {
		AddressRequest addressRequest = new AddressRequest();
		addressRequest.setCountryId(request.getCountryId());
		addressRequest.setStateId(request.getStateId());
		return addressRequest;
	}

	private void addSkillsCodeLookup(List<AdvanceSearchDropdownModel> advanceSearchDropdownModels, Job job,
			String code) {
		List<SkillsCodeLookup> skillsCodeLookupList = new ArrayList<>();
		advanceSearchDropdownModels.forEach(skill -> {
			CodeLookup jobsSkillCodeLookup = null;
			if (CommonUtil.isValid(skill.getValue())) {
				jobsSkillCodeLookup = codeLookupService.findById(skill.getValue());

			} else {
				jobsSkillCodeLookup = new CodeLookup();
				jobsSkillCodeLookup.setActive(true);
				jobsSkillCodeLookup.setDescription(skill.getDescription());
				jobsSkillCodeLookup.setName(skill.getLabel());
				CodeLookupType codeLookupType = codeLookupTypeService.findByCode(code);
				jobsSkillCodeLookup.setType(codeLookupType);
				codeLookupService.save(jobsSkillCodeLookup);

			}
			SkillsCodeLookup skillsCodeLookup = new SkillsCodeLookup();
			skillsCodeLookup.setCodeLookup(jobsSkillCodeLookup);
			skillsCodeLookup.setJob(job);
			skillsCodeLookupService.save(skillsCodeLookup);
			skillsCodeLookupList.add(skillsCodeLookup);

		});

		job.setSkillsCodeLookup(skillsCodeLookupList);

	}

	@Override
	public List<JobListResponse> getListResponse(List<Job> entityList) {
		List<JobListResponse> jobResponseList = new ArrayList<>();
		entityList.forEach(job -> {
			JobListResponse jobListResponse = new JobListResponse();
			jobListResponse.setId(job.getId());
			jobListResponse.setTitle(job.getTitle());
			jobListResponse.setState(job.getAddress()!=null&&job.getAddress().getState()!=null?job.getAddress().getState().getName():null);
			jobListResponse.setCountry(job.getCountry()!=null?job.getCountry().getName():null);	
			jobListResponse.setWorkFrom(job.getWorkFrom().getDisplayName());
			jobListResponse.setRateType(job.getRateTypeEnum().getDisplayName());
			jobListResponse.setMinRate(job.getMinRate());
			jobListResponse.setMaxRate(job.getMaxRate());
			jobListResponse.setMinExperience(job.getMinExperience());
			jobListResponse.setMaxExperience(job.getMaxExperience());
			jobListResponse.setNoOfResource(job.getNoOfResources());
			jobListResponse.setStartDate(job.getStartDate());
			jobListResponse.setCurrencyType(job.getCurrencyType().getDisplayName());
			jobListResponse.setPostedDate(job.getCreatedOn());
			jobListResponse.setSkills(getSkillNameList(job.getSkillsCodeLookup()));
			jobListResponse.setUserId(job.getVendor().getUser().getId());
			jobListResponse.setLocation(job.getLocation()!=null?job.getLocation():null);
			jobListResponse.setStatus(job.getStatusEnum() != null ? job.getStatusEnum().getDisplayName() : null);
			jobListResponse.setAgencyName(
					job.getVendor() != null && job.getVendor().getAgencyName() != null ? job.getVendor().getAgencyName()
							: null);
			jobListResponse.setClosedOn(job.getClosedDate());
			jobListResponse.setTimeZoneEnum(job.getTimeZoneEnum()!=null?job.getTimeZoneEnum().name():null);
			jobListResponse.setStartTime(DateUtil.getFormattedCreatedOn(job.getStartTime()));
			jobListResponse.setEndTime(DateUtil.getFormattedCreatedOn(job.getEndTime()));
			jobListResponse.setDuration(job.getDuration()!=null?job.getDuration().getName():null);
			
			jobResponseList.add(jobListResponse);
		});
		return jobResponseList;
	}

	public JobDetailResponse getDetailResponse(Job job) {
		JobDetailResponse.JobDetailResponseBuilder builder = JobDetailResponse.builder().id(job.getId())
				.title(job.getTitle()).workFromHome(job.getWorkFrom().getDisplayName())
				.rateType(job.getRateTypeEnum().getDisplayName())
				.minRate(job.getMinRate()).maxRate(job.getMaxRate()).noOfpostions(job.getNoOfResources()).minRate(job.getMinRate()).maxRate(job.getMaxRate())
				.startDate(job.getStartDate()).minExperience(job.getMinExperience())
				.isActive(job.getActive())
				.agencyName(job.getVendor().getAgencyName())
				.status(job.getStatusEnum().getDisplayName())
				.updatedDate(job.getUpdatedOn())
				.maxExperience(job.getMaxExperience()).currencyType(job.getCurrencyType().getDisplayName())
				.postedDate(job.getCreatedOn()).description(job.getDescription())
				.duration(job.getDuration().getName()).noOfJobViewed(null)
				.noOfApplication(resourceJobsService.getNoOfJobApplied(job.getId(), ResourceStatusEnum.APPLIED))
				.skills(getSkillNameList(job.getSkillsCodeLookup()))
				.userId(job.getVendor().getUser().getId())
				.timeZoneEnum(job.getTimeZoneEnum()!=null?job.getTimeZoneEnum().name():null)
				.startTime(DateUtil.getFormattedCreatedOn(job.getStartTime()))
				.endTime(DateUtil.getFormattedCreatedOn(job.getEndTime()))
				.location(job.getLocation()!=null?job.getLocation():null)
				.closedDate(job.getClosedDate())
				.jobCloseReason(job.getCloseReason()!=null?job.getCloseReason().getDisplayName():null)
				.applicantsCount(resourceJobsRepository.findByJobIdAndDeletedFalse(job.getId()))
				.categoryId(job.getCategory()!=null?job.getCategory().getId():null);;
		return builder.build();
	}

	@Override
	public JobDetailAdminResponse getDetailForAdminResponse(Job job) {
		JobDetailAdminResponse.JobDetailAdminResponseBuilder builder = JobDetailAdminResponse.builder().id(job.getId())
				.title(job.getTitle()).workFrom(job.getWorkFrom())
				.countryId(job.getCountry() != null ? job.getCountry().getId() : null)
				.rateType(job.getRateTypeEnum()).minRate(job.getMinRate()).maxRate(job.getMaxRate())
				.noOfResources(job.getNoOfResources()).minRate(job.getMinRate())
				.maxRate(job.getMaxRate()).startDate(job.getStartDate()).minExperience(job.getMinExperience())
				.maxExperience(job.getMaxExperience()).currencyType(job.getCurrencyType()).startDate(job.getStartDate())
				.postedDate(job.getCreatedOn()).description(job.getDescription()).durationId(job.getDuration().getId())
				.skills(getSkillIdAndNameList(job.getSkillsCodeLookup()))
				.location(job.getLocation()!=null?job.getLocation():null)
				.latitude(job.getLatitude()!=null?job.getLatitude():null)
				.longitude(job.getLongitude()!=null?job.getLongitude():null)
				.categoryId(job.getCategory()!=null?job.getCategory().getId():null)
				.startTime(job.getStartTime())
				.endTime(job.getEndTime());	
		return builder.build();
	}

	private AdvanceSearchDropdownModel getValueAndLabel(Long id, String label) {
		return new AdvanceSearchDropdownModel(id, label, null);
	}

	private List<AdvanceSearchDropdownModel> getSkillIdAndNameList(List<SkillsCodeLookup> resourceSkillsCodeLookups) {
		List<AdvanceSearchDropdownModel> resourseIdList = new ArrayList<>();
		resourceSkillsCodeLookups.forEach(skill -> {
			resourseIdList.add(getValueAndLabel(skill.getCodeLookup() != null ? skill.getCodeLookup().getId() : null,
					skill.getCodeLookup() != null ? skill.getCodeLookup().getName() : null));
		});
		return resourseIdList;
	}

	private List<String> getSkillNameList(List<SkillsCodeLookup> resourceSkillsCodeLookups) {
		List<String> resourseIdList = new ArrayList<>();
		resourceSkillsCodeLookups.forEach(skill -> {
			resourseIdList.add(skill.getCodeLookup().getName());
		});
		return resourseIdList;
	}

	public List<NotificationJobListResponse> getNotificationJobListResponse(List<Job> entityList) {
		List<NotificationJobListResponse> notificationjobResponseList = new ArrayList<>();
		entityList.forEach(job -> {
			NotificationJobListResponse.NotificationJobListResponseBuilder builder = NotificationJobListResponse
					.builder().id(job.getId()).title(job.getTitle()).skills(getSkillNameList(job.getSkillsCodeLookup()))
					.minExp(job.getMinExperience()).maxExp(job.getMaxExperience());

			notificationjobResponseList.add(builder.build());
		});
		return notificationjobResponseList;
	}
	
	public List<JobDetailsResponses> getJobDetails(List<Job> jobs) {
		List<JobDetailsResponses> jobResponseList = new ArrayList<>();
		jobs.forEach(job -> {
			JobDetailsResponses jobDetailsResponses = new JobDetailsResponses();
			jobDetailsResponses.setTitle(job.getTitle());
			jobDetailsResponses.setDescription(job.getDescription());
			jobDetailsResponses.setDuration(job.getDuration()!=null?job.getDuration().getName():null);
			jobDetailsResponses.setNumberOfResources(job.getNoOfResources());
			jobDetailsResponses.setSkills(job.getSkillsCodeLookup().stream().map(skill->skill.getCodeLookup().getName()).collect(Collectors.toList()));
			jobDetailsResponses.setExperience(job.getMinExperience() + "-" + job.getMaxExperience() + " Yrs");
			jobDetailsResponses.setWorkFrom(job.getWorkFrom().getDisplayName());
			jobDetailsResponses.setVendorLogoPath(job.getVendor().getVendorLogo() != null
					? fileUpload.generatePresignedURL(job.getVendor().getVendorLogo().getPath())
					: null);
			jobDetailsResponses.setMinRate(job.getMinRate());
			jobDetailsResponses.setMaxRate(job.getMaxRate());
			jobDetailsResponses.setCreatedOn(job.getCreatedOn());
			jobDetailsResponses.setRateType(job.getRateTypeEnum().getDisplayName());
			jobDetailsResponses.setCurrencyType(job.getCurrencyType().getDisplayName());
			jobDetailsResponses.setId(job.getId());
			jobResponseList.add(jobDetailsResponses);
		});
		return jobResponseList;
	}
	
	public Long updateDescription(JobDescriptionUpdateRequest request) throws Exception {
		Job job = jobService.findById(request.getId());
		if (job == null) {
			throw new Exception("Job not found for id " + request.getId());
		}
		if (request.getDescription().length() < 50 || request.getDescription().length() > 5000)
			throw new RuntimeException("Description must in between 50 to 5000 character.");
		job.setDescription(request.getDescription());
		return jobService.save(job).getId();
	}
}
