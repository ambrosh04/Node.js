package com.daynilgroup.vendormanagement.helper;

import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.daynilgroup.vendormanagement.constants.RoleTypeEnum;
import com.daynilgroup.vendormanagement.entity.Role;
import com.daynilgroup.vendormanagement.entity.RoleAccess;
import com.daynilgroup.vendormanagement.exception.VendorManagementException;
import com.daynilgroup.vendormanagement.model.request.CreateRoleRequest;
import com.daynilgroup.vendormanagement.model.response.RoleDetailAdminResponse;
import com.daynilgroup.vendormanagement.model.response.RoleListResponse;
import com.daynilgroup.vendormanagement.service.RoleAccessService;
import com.daynilgroup.vendormanagement.service.RoleService;
import com.daynilgroup.vendormanagement.service.VendorService;
import com.daynilgroup.vendormanagement.util.CommonUtil;
import com.daynilgroup.vendormanagement.util.EntityUtil;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;

/**
 *
 * @author Manish
 */
@Component
@FieldDefaults(level = AccessLevel.PRIVATE)
@Slf4j
public class RoleHelper
		extends AbstractHelper<Role, CreateRoleRequest, RoleListResponse, Object, RoleDetailAdminResponse> {

	@Autowired
	RoleService roleService;
	@Autowired
	VendorService vendorService;
	@Autowired
	RoleAccessHelper roleAccessHelper;
	@Autowired
	RoleAccessService roleAccessService;

	@Autowired
	EntityUtil entityUtil;
	
	@Override
	@Transactional(rollbackFor = Exception.class)
	public Role getEntity(CreateRoleRequest roleRequest) throws Exception {
	      Role role;
	        if (CommonUtil.isValid(roleRequest.getId())) {
	            role = roleService.findById(roleRequest.getId());
	            if(RoleTypeEnum.MASTER_VENDOR.equals(CommonUtil.getLoggedInUserType())) {
	            	role.setType(RoleTypeEnum.VENDOR);
	            }else {
	            	role.setType(roleRequest.getType());
				}
	        } else {
	            role = new Role();
	            if (RoleTypeEnum.MASTER_ADMIN.equals(roleRequest.getType())) {
	                log.error("Invalid Role...!, You can not create MASTER_ADMIN type of roles.");
	                throw new VendorManagementException(409, "Invalid Role...!, You can not create MASTER_ADMIN type of roles.");
	            }
	            
	            if(RoleTypeEnum.MASTER_VENDOR.equals(CommonUtil.getLoggedInUserType())) {
	            	role.setType(RoleTypeEnum.VENDOR);
	            }else {
	            	role.setType(roleRequest.getType());
				}
	        }
	        role.setName(roleRequest.getName());
	        role.setActive(roleRequest.getActive());
	        if (!CollectionUtils.isEmpty(roleRequest.getAccess())) {
	            if (CommonUtil.isValid(role.getId())) {
	                roleAccessService.deleteByRoleId(role.getId());
	            }
	            List<RoleAccess> newRoleAccesss = roleAccessHelper.getNewRoleAccesss(roleRequest.getAccess());
	            newRoleAccesss.forEach(roleAccess -> roleAccess.setRole(role));
	            role.setRoleAccessList(newRoleAccesss);
	        }
	     return role;
	    }
	
	@Override
	public List<RoleListResponse> getListResponse(List<Role> roleList) {
	       return roleList.stream().map(role -> RoleListResponse.builder()
                   .active(role.getActive())
                   .id(role.getId())
                   .name(role.getName())
                   .type(role.getType())
                   .editable(CommonUtil.getRoleAcess(role))
                   .deletable(CommonUtil.getRoleAcess(role))
                   .build()).collect(Collectors.toList());
	}

	@Override
	public Object getDetailResponse(Role entity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public RoleDetailAdminResponse getDetailForAdminResponse(Role entity) {
		 List<String> access = new LinkedList<>();
	        for (RoleAccess roleAccess : entity.getRoleAccessList()) {
	            Long menuId = roleAccess.getMenu().getId();
	            
	        	if(!CommonUtil.isEmpty(roleAccess.getAccesss())) {
	        		for(String userAccess : roleAccess.getAccesss().split(","))
	        			access.add(menuId + "-" + userAccess);
	        	}
	        }

			return RoleDetailAdminResponse.builder().access(access)
					.active(entity.getActive()).type(entity.getType())
					.id(entity.getId()).name(entity.getName()).build();
	}

}
