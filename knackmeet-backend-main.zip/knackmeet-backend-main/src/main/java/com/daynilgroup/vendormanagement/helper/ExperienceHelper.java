package com.daynilgroup.vendormanagement.helper;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang3.ObjectUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.daynilgroup.vendormanagement.constants.CodeLookUpConstant;
import com.daynilgroup.vendormanagement.constants.CodeLookUpRelationTypeEnum;
import com.daynilgroup.vendormanagement.constants.Constants;
import com.daynilgroup.vendormanagement.constants.RefTypeEnum;
import com.daynilgroup.vendormanagement.constants.StatusEnum;
import com.daynilgroup.vendormanagement.entity.CodeLookUpRelation;
import com.daynilgroup.vendormanagement.entity.CodeLookup;
import com.daynilgroup.vendormanagement.entity.CodeLookupType;
import com.daynilgroup.vendormanagement.entity.Company;
import com.daynilgroup.vendormanagement.entity.Experience;
import com.daynilgroup.vendormanagement.entity.ExperienceSkillsCodeLookup;
import com.daynilgroup.vendormanagement.entity.Resource;
import com.daynilgroup.vendormanagement.model.inf.DateUtil;
import com.daynilgroup.vendormanagement.model.response.AdvanceSearchDropdownModel;
import com.daynilgroup.vendormanagement.model.response.ExperienceDetailAdminResponse;
import com.daynilgroup.vendormanagement.model.response.ExperienceDetailResponse;
import com.daynilgroup.vendormanagement.model.response.ExperienceListResponse;
import com.daynilgroup.vendormanagement.request.CompanyRequest;
import com.daynilgroup.vendormanagement.request.ExperienceRequest;
import com.daynilgroup.vendormanagement.service.CodeLookUpRelationService;
import com.daynilgroup.vendormanagement.service.CodeLookupService;
import com.daynilgroup.vendormanagement.service.CodeLookupTypeService;
import com.daynilgroup.vendormanagement.service.CompanyService;
import com.daynilgroup.vendormanagement.service.ExperienceService;
import com.daynilgroup.vendormanagement.service.ExperienceSkillsCodeLookupService;
import com.daynilgroup.vendormanagement.service.ResourceService;
import com.daynilgroup.vendormanagement.util.CommonUtil;
import com.daynilgroup.vendormanagement.util.FileUpload;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;

@Component
@Lazy
@FieldDefaults(level = AccessLevel.PRIVATE)
public class ExperienceHelper extends
		AbstractHelper<Experience, ExperienceRequest, ExperienceListResponse, ExperienceDetailResponse, ExperienceDetailAdminResponse> {

	@Autowired
	ExperienceService experienceService;
	@Autowired
	CodeLookupService codeLookupService;
	@Autowired
	CodeLookupTypeService codeLookupTypeService;
	@Autowired
	ExperienceSkillsCodeLookupService experienceSkillsCodeLookupService;
	@Autowired
	ResourceService resourceService;
	
	@Autowired
	CodeLookUpRelationService codeLookUpRelationService;

	@Autowired
	CompanyService companyService;

	@Autowired
	FileUpload fileUpload;
	
	@Autowired
	CompanyHelper companyHelper;
	
	@Override
	@Transactional(noRollbackFor = Exception.class)
	public Experience getEntity(ExperienceRequest request) throws Exception {

		Experience experience;
		Resource resource = resourceService.findById(request.getResourceId());
		Boolean isActiveSet=true;
		if (CommonUtil.isValid(request.getId())) {
			experience = experienceService.findById(request.getId());
			if (resource.getStatusEnum().equals(StatusEnum.REJECTED)) {
				Set<String> set = new HashSet<>(getExperienceSkills(experience.getExperienceSkillsCodeLookup()));

				set.retainAll(getAdvanceSearchDropdownModelSkills(request.getSkillsCodeLookups()));
				if ((set.size() != request.getSkillsCodeLookups().size())
						|| (set.size() != experience.getExperienceSkillsCodeLookup().size())) {
					codeLookUpRelationService.setActive(
							codeLookUpRelationService.findByRefIdAndRefTypeAndType(resource.getId(),
									RefTypeEnum.RESOURCE, CodeLookUpRelationTypeEnum.RESOURCE_REJECT_REASON),
							Constants.EXPERIENCE_IS_NOT_MATCHED_AS_PER_RESUME_REJECT_REASON);
					isActiveSet = false;
				}
			}
			
			if ((isActiveSet&&resource.getStatusEnum().equals(StatusEnum.REJECTED))
					&&( !experience.getDeploymentType().equals(request.getDeploymentType())
					|| !experience.getTitle().getName().equals(request.getTitle().getLabel())
					|| !experience.getEmploymentType().equals(request.getEmploymentType())
					||! experience.getCompany().getName().equals(request.getCompany().getName())
					|| !experience.getCompanyAddress().equals(request.getCompanyAddress())
					|| !experience.getIndustry().getName().equals(request.getIndustry().getLabel())
					|| (experience.getDescription()!=null && request.getDescription()!=null
							&& !experience.getDescription().equals(request.getDescription())))) {
				codeLookUpRelationService.setActive(
						codeLookUpRelationService.findByRefIdAndRefTypeAndType(resource.getId(), RefTypeEnum.RESOURCE,
								CodeLookUpRelationTypeEnum.RESOURCE_REJECT_REASON),
						Constants.EXPERIENCE_IS_NOT_MATCHED_AS_PER_RESUME_REJECT_REASON);
				isActiveSet=false;

			}
			experienceSkillsCodeLookupService.deleteByExperienceId(experience.getId());
		} else {
			experience = new Experience();
			if (resource.getStatusEnum().equals(StatusEnum.REJECTED)) {
				codeLookUpRelationService.setActive(
						codeLookUpRelationService.findByRefIdAndRefTypeAndType(resource.getId(), RefTypeEnum.RESOURCE,
								CodeLookUpRelationTypeEnum.RESOURCE_REJECT_REASON),
						Constants.EXPERIENCE_IS_NOT_MATCHED_AS_PER_RESUME_REJECT_REASON);
				isActiveSet=false;
			}
		}
		
		experience.setDeploymentType(request.getDeploymentType() != null ? request.getDeploymentType() : null);
		experience.setDescription(request.getDescription() != null ? request.getDescription() : null);	
		if (request.getEmploymentType() != null) {
			experience.setEmploymentType(request.getEmploymentType());
		} else {
			throw new Exception("Employment type could not be null");
		}
		if(isActiveSet&&resource.getStatusEnum().equals(StatusEnum.REJECTED)&&!request.getPresentCompany().equals(experience.getPresentCompany())) {
			codeLookUpRelationService.setActive(codeLookUpRelationService.findByRefIdAndRefTypeAndType(resource.getId(),RefTypeEnum.RESOURCE,CodeLookUpRelationTypeEnum.RESOURCE_REJECT_REASON), Constants.EXPERIENCE_IS_NOT_MATCHED_AS_PER_RESUME_REJECT_REASON);
			isActiveSet=false;
		}
		if (request.getPresentCompany() != true) {
			if (request.getFromMonth() != null) {
				if(isActiveSet&&experience.getFromMonth()!=null&&resource.getStatusEnum().equals(StatusEnum.REJECTED)&&!experience.getFromMonth().equals(request.getFromMonth())) {
					codeLookUpRelationService.setActive(codeLookUpRelationService.findByRefIdAndRefTypeAndType(resource.getId(),RefTypeEnum.RESOURCE,CodeLookUpRelationTypeEnum.RESOURCE_REJECT_REASON), Constants.EXPERIENCE_IS_NOT_MATCHED_AS_PER_RESUME_REJECT_REASON);
					isActiveSet=false;
				}	
				experience.setFromMonth(request.getFromMonth());
			} else {
				throw new Exception("From month could not be null");
			}
			if (request.getFromYear() != null) {
				if(isActiveSet&&experience.getFromYear()!=null&&resource.getStatusEnum().equals(StatusEnum.REJECTED)&&!experience.getFromYear().equals(request.getFromYear())) {
					codeLookUpRelationService.setActive(codeLookUpRelationService.findByRefIdAndRefTypeAndType(resource.getId(),RefTypeEnum.RESOURCE,CodeLookUpRelationTypeEnum.RESOURCE_REJECT_REASON), Constants.EXPERIENCE_IS_NOT_MATCHED_AS_PER_RESUME_REJECT_REASON);
					isActiveSet=false;
				}	
				experience.setFromYear(request.getFromYear());
			} else {
				throw new Exception("From year could not be null");
			}
			if (request.getToMonth() != null) {
				if(isActiveSet&&experience.getToMonth()!=null&&resource.getStatusEnum().equals(StatusEnum.REJECTED)&&!experience.getToMonth().equals(request.getToMonth())) {
					codeLookUpRelationService.setActive(codeLookUpRelationService.findByRefIdAndRefTypeAndType(resource.getId(),RefTypeEnum.RESOURCE,CodeLookUpRelationTypeEnum.RESOURCE_REJECT_REASON), Constants.EXPERIENCE_IS_NOT_MATCHED_AS_PER_RESUME_REJECT_REASON);
					isActiveSet=false;
				}	
				experience.setToMonth(request.getToMonth());
			} else {
				throw new Exception("To month could not be null");
			}
			if (request.getToYear() != null) {
				if(isActiveSet&&experience.getToYear()!=null&&resource.getStatusEnum().equals(StatusEnum.REJECTED)&&!experience.getToYear().equals(request.getToYear())) {
					codeLookUpRelationService.setActive(codeLookUpRelationService.findByRefIdAndRefTypeAndType(resource.getId(),RefTypeEnum.RESOURCE,CodeLookUpRelationTypeEnum.RESOURCE_REJECT_REASON), Constants.EXPERIENCE_IS_NOT_MATCHED_AS_PER_RESUME_REJECT_REASON);
					isActiveSet=false;
				}	
				experience.setToYear(request.getToYear());
			} else {
				throw new Exception("To year could not be null");
			}
		} else {
			if (request.getFromMonth() != null) {
				if(isActiveSet&&experience.getFromMonth()!=null&&resource.getStatusEnum().equals(StatusEnum.REJECTED)&&!experience.getFromMonth().equals(request.getFromMonth())) {
					codeLookUpRelationService.setActive(codeLookUpRelationService.findByRefIdAndRefTypeAndType(resource.getId(),RefTypeEnum.RESOURCE,CodeLookUpRelationTypeEnum.RESOURCE_REJECT_REASON), Constants.EXPERIENCE_IS_NOT_MATCHED_AS_PER_RESUME_REJECT_REASON);
					isActiveSet=false;
				}	
				experience.setFromMonth(request.getFromMonth());
			} else {
				throw new Exception("From month could not be null");
			}
			if (request.getFromYear() != null) {
				if(isActiveSet&&experience.getFromYear()!=null&&resource.getStatusEnum().equals(StatusEnum.REJECTED) &&!experience.getFromYear().equals(request.getFromYear())) {
					codeLookUpRelationService.setActive(codeLookUpRelationService.findByRefIdAndRefTypeAndType(resource.getId(),RefTypeEnum.RESOURCE,CodeLookUpRelationTypeEnum.RESOURCE_REJECT_REASON), Constants.EXPERIENCE_IS_NOT_MATCHED_AS_PER_RESUME_REJECT_REASON);
					isActiveSet=false;
				}	
				experience.setFromYear(request.getFromYear());
			}else {
				throw new Exception("From Year could not be null");
			}
			
		}

		if (request.getCompanyAddress() != null) {
			experience.setCompanyAddress(request.getCompanyAddress());
		} else {
			throw new Exception("Location could not be null");
		}
		if (request.getCompanyLatitude() != null) {
			experience.setCompanyLatitude(request.getCompanyLatitude());
		} else {
			throw new Exception("Latitude could not be null");
		}
		if (request.getCompanyLongitude() != null) {
			experience.setCompanyLongitude(request.getCompanyLongitude());
		} else {
			throw new Exception("Longitude could not be null");
		}
		experience.setPresentCompany(request.getPresentCompany());

		// industry
		CodeLookup industry = null;
		if (!ObjectUtils.isEmpty(request.getIndustry())) {
			industry = addCodeLookups(request.getIndustry(), experience, industry,
					CodeLookUpConstant.INDUSTRY_CODELOOKUP_CODE);
			experience.setIndustry(industry);
		} else {
			throw new Exception("Industry could not be null");
		}

		// company
		Company company = null;
		if (!ObjectUtils.isEmpty(request.getCompany())) {
			company = companyService.create(request.getCompany());
			experience.setCompany(company);
		} else {
			throw new Exception("Company could not be null");
		}

		// title
		CodeLookup title = null;
		if (!ObjectUtils.isEmpty(request.getTitle())) {
			title = addCodeLookups(request.getTitle(), experience, title,
					CodeLookUpConstant.DESIGNATION_CODELOOKUP_CODE);
			experience.setTitle(title);
		} else {
			throw new Exception("Title could not be null");
		}

		addExperienceSkillsCodeLookup(request, experience, CodeLookUpConstant.SKILLS_CODELOOKUP_CODE);
		resource.setLastModifiedDate(LocalDateTime.now());
		experience.setResource(resource);
		return experience;
	}

	private CodeLookup addCodeLookups(AdvanceSearchDropdownModel designationId, Experience experience,
			CodeLookup codeLookup, String code) {
		if (CommonUtil.isValid(designationId.getValue())) {
			codeLookup = codeLookupService.findById(designationId.getValue());
		} else {
			codeLookup = new CodeLookup();
			codeLookup.setActive(true);
			codeLookup.setDescription(designationId.getDescription());
			codeLookup.setName(designationId.getLabel());

			CodeLookupType codeLookupType = codeLookupTypeService.findByCode(code);
			codeLookup.setType(codeLookupType);

			codeLookupService.save(codeLookup);
		}
		return codeLookup;
	}

	private void addExperienceSkillsCodeLookup(ExperienceRequest request, Experience experience, String code)
			throws Exception {

		List<ExperienceSkillsCodeLookup> experienceSkillsCodeLookups = new ArrayList<>();
		if (!CollectionUtils.isEmpty(request.getSkillsCodeLookups())) {
			request.getSkillsCodeLookups().forEach(resourceSkill -> {
				CodeLookup experienceSkillsCodeLookup = null;
				if (CommonUtil.isValid(resourceSkill.getValue())) {
					experienceSkillsCodeLookup = codeLookupService.findById(resourceSkill.getValue());
				} else {
					experienceSkillsCodeLookup = new CodeLookup();
					experienceSkillsCodeLookup.setActive(true);
					experienceSkillsCodeLookup.setDescription(resourceSkill.getDescription());
					experienceSkillsCodeLookup.setName(resourceSkill.getLabel());

					CodeLookupType codeLookupType = codeLookupTypeService.findByCode(code);
					experienceSkillsCodeLookup.setType(codeLookupType);

					codeLookupService.save(experienceSkillsCodeLookup);
				}

				ExperienceSkillsCodeLookup skillsCodeLookup = new ExperienceSkillsCodeLookup();
				skillsCodeLookup.setExperience(experience);
				skillsCodeLookup.setCodeLookup(experienceSkillsCodeLookup);
				experienceSkillsCodeLookupService.save(skillsCodeLookup);
				experienceSkillsCodeLookups.add(skillsCodeLookup);
			});
		} else {
			throw new Exception("Skills could not be null");
		}
		experience.setExperienceSkillsCodeLookup(experienceSkillsCodeLookups);
	}

	@Override
	public List<ExperienceListResponse> getListResponse(List<Experience> entityList) {
		return null;
	}

	@Override
	public ExperienceDetailResponse getDetailResponse(Experience experience) {
		ExperienceDetailResponse experienceResponse = new ExperienceDetailResponse();
		experienceResponse.setId(experience.getId());
		experienceResponse.setCompany(experience.getCompany() != null ? experience.getCompany().getName() : null);
		experienceResponse.setCompanyLogo(experience.getCompany() != null && experience.getCompany().getMedia()!= null
				?fileUpload.generatePresignedURL(experience.getCompany().getMedia().getPath()):null);
		experienceResponse.setCompanyAddress(experience.getCompanyAddress());
		experienceResponse.setCompanyLatitude(experience.getCompanyLatitude());
		experienceResponse.setCompanyLongitude(experience.getCompanyLongitude());
		experienceResponse
				.setDeploymentType(experience.getDeploymentType() != null ? experience.getDeploymentType() : null);
		experienceResponse.setDescription(experience.getDescription());
		experienceResponse
				.setEmploymentType(experience.getEmploymentType() != null ? experience.getEmploymentType() : null);
		experienceResponse.setExperienceSkillsCodeLookup(getSkillIdList(experience.getExperienceSkillsCodeLookup()));
		experienceResponse.setFromYear(experience.getFromYear());
		experienceResponse.setFromMonth(experience.getFromMonth());
		experienceResponse.setToYear(experience.getToYear());
		experienceResponse.setToMonth(experience.getToMonth());
		experienceResponse.setIndustry(experience.getIndustry() != null ? experience.getIndustry().getName() : null);
		experienceResponse.setTitle(experience.getTitle() != null ? experience.getTitle().getName() : null);
		experienceResponse.setPresentCompany(experience.getPresentCompany());
		return experienceResponse;
	}
	
	private List<String> getSkillIdList(List<ExperienceSkillsCodeLookup> experienceSkillsCodeLookups) {
		List<String> experienceIdList = new ArrayList<>();
		experienceSkillsCodeLookups.forEach(skill -> {
			experienceIdList.add(skill.getCodeLookup().getName());
		});
		return experienceIdList;
	}

	@Override
	public ExperienceDetailAdminResponse getDetailForAdminResponse(Experience experience) {

		ExperienceDetailAdminResponse experienceResponse = new ExperienceDetailAdminResponse();
		experienceResponse.setId(experience.getId());
		experienceResponse.setCompany(companyHelper.getDetailForAdminResponse(experience.getCompany()));
		experienceResponse.setCompanyAddress(experience.getCompanyAddress());
		experienceResponse.setCompanyLatitude(experience.getCompanyLatitude());
		experienceResponse.setCompanyLongitude(experience.getCompanyLongitude());
		experienceResponse
				.setDeploymentType(experience.getDeploymentType() != null ? experience.getDeploymentType() : null);
		experienceResponse.setDescription(experience.getDescription());
		experienceResponse
				.setEmploymentType(experience.getEmploymentType() != null ? experience.getEmploymentType() : null);
		experienceResponse.setSkillsCodeLookups(getSkillIdAndNameList(experience.getExperienceSkillsCodeLookup()));
		experienceResponse.setFromYear(experience.getFromYear());
		experienceResponse.setFromMonth(experience.getFromMonth());
		experienceResponse.setToYear(experience.getToYear());
		experienceResponse.setToMonth(experience.getToMonth());
		experienceResponse.setIndustry(getValueAndLabel(experience.getIndustry().getId(), experience.getIndustry().getName()));
		experienceResponse.setTitle(getValueAndLabel(experience.getTitle().getId(), experience.getTitle().getName()));
		experienceResponse.setPresentCompany(experience.getPresentCompany());
		return experienceResponse;
	}

	private List<AdvanceSearchDropdownModel> getSkillIdAndNameList(
			List<ExperienceSkillsCodeLookup> experienceSkillsCodeLookups) {
		List<AdvanceSearchDropdownModel> experienceIdList = new ArrayList<>();
		experienceSkillsCodeLookups.forEach(skill -> {
			experienceIdList.add(getValueAndLabel(skill.getCodeLookup().getId(), skill.getCodeLookup().getName()));
		});
		return experienceIdList;
	}
	
	private AdvanceSearchDropdownModel getValueAndLabel(Long id, String label) {
		return new AdvanceSearchDropdownModel(id, label, null);
	}
	
	public static int getNoOfMonths(Integer fromMonth, Integer fromYear, Integer toMonth, Integer toYear) {
		Calendar fromCalendar = Calendar.getInstance();
		fromCalendar.clear();
		fromCalendar.set(Calendar.MONTH, fromMonth - 1);
		fromCalendar.set(Calendar.YEAR, fromYear);

		Calendar toCalendar = Calendar.getInstance();
		toCalendar.clear();
		toCalendar.set(Calendar.MONTH, toMonth);
		toCalendar.set(Calendar.YEAR, toYear);
		return DateUtil.getNoOfMonthsBetween(fromCalendar.getTime(), toCalendar.getTime());
	}
	private List<String> getExperienceSkills(List<ExperienceSkillsCodeLookup> skillsCodeLookup) {
		List<String> savedExperienceSkills = new ArrayList<>();
		skillsCodeLookup.forEach(skill -> {
			savedExperienceSkills.add(skill.getCodeLookup().getName());
		});
		return savedExperienceSkills;
	}
	
	private List<String> getAdvanceSearchDropdownModelSkills(List<AdvanceSearchDropdownModel> skillsCodeLookup) {
		List<String> requestExperienceSkills = new ArrayList<>();
		skillsCodeLookup.forEach(skill -> {
			requestExperienceSkills.add(skill.getLabel());
		});
		return requestExperienceSkills;
	}

}
