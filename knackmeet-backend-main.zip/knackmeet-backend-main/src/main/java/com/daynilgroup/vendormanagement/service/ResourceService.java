package com.daynilgroup.vendormanagement.service;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.daynilgroup.vendormanagement.constants.StatusEnum;
import com.daynilgroup.vendormanagement.entity.Resource;
import com.daynilgroup.vendormanagement.model.pag.PageModel;
import com.daynilgroup.vendormanagement.model.request.ApplicantRequest;
import com.daynilgroup.vendormanagement.model.request.Base64Request;
import com.daynilgroup.vendormanagement.model.request.CodeLookUpRelationRequest;
import com.daynilgroup.vendormanagement.model.request.ResourceFilterRequest;
import com.daynilgroup.vendormanagement.model.request.ResourceSkillsRequest;
import com.daynilgroup.vendormanagement.model.response.ApplicantListResponse;
import com.daynilgroup.vendormanagement.model.response.DropdownResponse;
import com.daynilgroup.vendormanagement.model.response.StatusCountResponse;
import com.daynilgroup.vendormanagement.model.response.VerificationCountResponse;

public interface ResourceService extends AbstractService<Resource> {

	Page<Resource> getList(Pageable pageable, StatusEnum statusEnum,String name,String designation,String agencyName);

	Long getCountByVendorId(Long vendorId);

	Long getCountBenchApplicationByvendorId(Long vendorId);

	DropdownResponse pdfDescriptiveInString(Base64Request base64Request) throws Exception;

	Long getResourcesCountByVendorId(Long vendorId);

	PageModel getFilterResources(ResourceFilterRequest resourceFilterRequest);

	void updateStatus(Long resourceId, Boolean active) throws Exception;

	void verifyStatus(Long resourceId, StatusEnum statusEnum, CodeLookUpRelationRequest codeLookUpRelationRequest) throws Exception;

	VerificationCountResponse getAllResourceCount();

	StatusCountResponse getResourceStatusCount();

	Long getResourceCount();

	List<ApplicantListResponse> getApplicantListResponse(ApplicantRequest applicantRequest);

	PageModel getApplicantResponse(ApplicantRequest applicantRequest);
	
	Page<Resource> getAllResourceByVendorId(Long vendorId,Pageable pageable);
	
	void updateSkills(ResourceSkillsRequest resourceSkillsRequest) throws Exception;

    void updateTotalExperience(Long resourceId);
    
    BigDecimal rateWithCommission(BigDecimal resourceRate);
    
    List<Long> getMatchingResources(Long jobId);

	PageModel getMatchingResourceList(ApplicantRequest applicantRequest);
	
    StatusEnum updateStatus(StatusEnum statusEnum,Long id) throws Exception ;

}
