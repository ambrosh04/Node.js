/**
 * 
 */
package com.daynilgroup.vendormanagement.constants;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.experimental.FieldDefaults;

/**
 * @author Prerana
 *
 */
@Getter
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public enum UserType {

	VENDOR("Vendor"),
	ADMIN("Admin");
	
	String displayName;
}
