package com.daynilgroup.vendormanagement.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.daynilgroup.vendormanagement.entity.SubscribedUsers;

public interface SubscribedUsersService extends AbstractService<SubscribedUsers> {

	Page<SubscribedUsers> findAll(Pageable pageable);
}
