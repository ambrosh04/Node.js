package com.daynilgroup.vendormanagement.model.response;

import java.time.LocalDateTime;
import java.util.List;

import com.daynilgroup.vendormanagement.constants.DeploymentTypeEnum;
import com.daynilgroup.vendormanagement.constants.Gender;
import com.daynilgroup.vendormanagement.constants.ResourceStatusEnum;
import com.daynilgroup.vendormanagement.constants.StatusEnum;

import lombok.AccessLevel;
import lombok.Builder;
import lombok.Data;
import lombok.experimental.FieldDefaults;

@Builder
@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
public class ResourceResponse {

	Long id;
	
	String name;

	Integer percentage;

	ResourceStatusEnum status;
	
	Long resourceId;

	String category;

	String availabilityType;

	String base64MediaString;

	List<String> skills;

	String designation;

	String rate;

	String experience;

	String city;

	String state;

	String country;

	String gender;

	Boolean active;

	String higherEducation;

	Long passingYear;

	StatusEnum statusEnum;

	String agencyName;

	Integer appliedJobCount;

	Long userId;

	LocalDateTime date;

	LocalDateTime updatedOn;

	LocalDateTime createdOn;
	

	String deploymentType;
	
	String resume;
	
	String usdRate;
	
	String location;
}
