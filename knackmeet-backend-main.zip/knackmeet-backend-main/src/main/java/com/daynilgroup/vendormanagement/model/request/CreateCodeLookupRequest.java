package com.daynilgroup.vendormanagement.model.request;

import com.daynilgroup.vendormanagement.constants.StatusEnum;
import com.daynilgroup.vendormanagement.request.inf.RequestInf;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@Getter
@Setter
@FieldDefaults(level = AccessLevel.PRIVATE)
public class CreateCodeLookupRequest implements RequestInf {

	static final long serialVersionUID = 1L;
	
	String description;
	String name;
	Long typeId;
	Long id;
	Long parentId;
	Boolean active;
	StatusEnum status;
	String coverImage;
	Integer displayOrder;

}