package com.daynilgroup.vendormanagement.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;

import com.daynilgroup.vendormanagement.entity.SearchHistory;
import com.daynilgroup.vendormanagement.repository.SearchHistoryRepository;
import com.daynilgroup.vendormanagement.request.SearchTypeRequest;
import com.daynilgroup.vendormanagement.service.SearchHistoryService;
import com.daynilgroup.vendormanagement.util.EntityUtil;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;

@Service
@FieldDefaults(level = AccessLevel.PRIVATE)
public class SearchHistoryServiceImpl implements SearchHistoryService {

	@Autowired
	SearchHistoryRepository searchHistoryRepository;
	@Autowired
	EntityUtil entityUtil;

	@Override
	public JpaRepository<SearchHistory, Long> getJpaRepository() {

		return searchHistoryRepository;
	}

	@Override
	public Page<SearchHistory> getSearchHistoryListForHireDeveloperExceptVendorId(Pageable pageable) {
		return searchHistoryRepository
				.getSearchHistoryListForHireDeveloperExceptVendorId(entityUtil.getCurrentVendorId(), pageable);

	}

	@Override
	public Page<SearchHistory> getSearchHistoryListForJobOrProjectExceptVendorId(Pageable pageable) throws Exception {
		return searchHistoryRepository
				.getSearchHistoryListForJobOrProjectExceptVendorId(entityUtil.getCurrentVendorId(), pageable);
	}

	@Override
	public Page<SearchHistory> getRecentSearchHistoryExceptVendorId(SearchTypeRequest searchTypeRequest,Pageable pageable) throws Exception {
		return searchHistoryRepository.getRecentSearchHistoryExceptVendorId(entityUtil.getCurrentVendorId(),searchTypeRequest.getSearchType(), pageable);
	}
	@Override
	public List<SearchHistory> getRecentSearchHistoryExceptVendorId(SearchTypeRequest searchTypeRequest) throws Exception {
		return searchHistoryRepository.getRecentSearchHistoryExceptVendorId(entityUtil.getCurrentVendorId(),searchTypeRequest.getSearchType());
		
				 
	}

}
