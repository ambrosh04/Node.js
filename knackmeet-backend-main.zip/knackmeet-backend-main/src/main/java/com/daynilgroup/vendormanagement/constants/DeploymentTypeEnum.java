package com.daynilgroup.vendormanagement.constants;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.experimental.FieldDefaults;

/**
 *
 * @author manish
 */
@Getter
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public enum DeploymentTypeEnum {

	REMOTE("Remote"), ONSITE("Onsite"), HYBRID("Hybrid"),REMOTE_AND_ONSITE("Both(Remote and Onsite)");

	String displayName;
}
