package com.daynilgroup.vendormanagement.admin.rest.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.daynilgroup.vendormanagement.constants.UrlConstants;
import com.daynilgroup.vendormanagement.entity.Job;
import com.daynilgroup.vendormanagement.helper.JobHelper;
import com.daynilgroup.vendormanagement.model.pag.PageModel;
import com.daynilgroup.vendormanagement.model.pag.PaginationRequestModel;
import com.daynilgroup.vendormanagement.rest.exception.DataNotFoundRestException;
import com.daynilgroup.vendormanagement.service.AdminDashboardService;
import com.daynilgroup.vendormanagement.service.JobService;
import com.daynilgroup.vendormanagement.util.PaginationUtil;
import com.daynilgroup.vendormanagement.vendor.rest.controller.VendorDashboardRestController;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@FieldDefaults(level = AccessLevel.PRIVATE)
@RestController
@RequestMapping(UrlConstants.ADMIN_DASHBOARD_BASE_URL)
public class AdminDashboardRestController {

	@Autowired
	AdminDashboardService adminDashboardService;

	@Autowired
	VendorDashboardRestController vendorDashboardRestController;
	
	@Autowired
	JobService jobService;

	@Autowired
	JobHelper jobHelper;

	@GetMapping(UrlConstants.ADMIN_DASHBOARD_COUNT)
	public ResponseEntity<Object> getAdminDashBoardCount() {
		try {
			return new ResponseEntity<Object>(adminDashboardService.getAdminDashboardCountResponse(), HttpStatus.OK);
		} catch (Exception e) {
			log.error(e.getMessage());
			return new ResponseEntity<Object>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@GetMapping(path = UrlConstants.JOBS_LIST)
	public ResponseEntity<Object> list(PaginationRequestModel paginationRequestModel) {
		return vendorDashboardRestController.list(paginationRequestModel);
	}
	
	@GetMapping(path = UrlConstants.JOB_LIST_NOTIFICATION)
	public ResponseEntity<Object> getJobListNotification(PaginationRequestModel paginationRequestModel) {
		try {

			Pageable pageable = PaginationUtil.getPageable(paginationRequestModel);
			Page<Job> job = jobService.getJobListExceptVendorId(pageable);

			PageModel.PageModelBuilder builder = PageModel.builder().pageCount(Long.valueOf(job.getTotalPages()))
					.totalCount(job.getTotalElements())
					.data(jobHelper.getNotificationJobListResponse(job.getContent()));
			return new ResponseEntity<Object>(builder.build(), HttpStatus.OK);

		} catch (Exception e) {
			log.error(e.getMessage());
			return new ResponseEntity<Object>(new DataNotFoundRestException(e.getMessage()),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

}
