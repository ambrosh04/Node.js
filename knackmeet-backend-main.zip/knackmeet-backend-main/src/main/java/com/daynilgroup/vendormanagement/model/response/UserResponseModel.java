package com.daynilgroup.vendormanagement.model.response;

import java.io.Serializable;

import com.daynilgroup.vendormanagement.constants.StatusEnum;
import com.daynilgroup.vendormanagement.constants.UserType;
import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class UserResponseModel implements Serializable {

	static final long serialVersionUID = 1L;

	Long id;

	Long userId;

	String emailId;

	StatusEnum status;

	String message;

	String firstName;

	String lastName;

	@JsonIgnore
	Boolean active;

	UserType userType;
	
	String agencyName;
	
	String agencyLogo;

	String base64AgencyLogo;
	
	Integer pageSize;
	
	String  vendorPhoneCode;
	
}