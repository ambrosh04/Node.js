/**
 * 
 */
package com.daynilgroup.vendormanagement.model.filter;

import java.io.Serializable;
import java.util.Date;

import com.daynilgroup.vendormanagement.constants.ResourceStatusEnum;
import com.daynilgroup.vendormanagement.model.pag.PaginationRequestModel;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

/**
 * @author Prerana
 *
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class JobsFilterModel implements Serializable {

	static final long serialVersionUID = 1L;

	Long resourceId;

	ResourceStatusEnum resourceStatus;

	String title;

	String startDate;

	String endDate;
	
	PaginationRequestModel paginationRequestModel;
}
