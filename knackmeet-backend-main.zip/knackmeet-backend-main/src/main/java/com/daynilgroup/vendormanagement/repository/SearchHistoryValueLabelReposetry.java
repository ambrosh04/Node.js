package com.daynilgroup.vendormanagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.daynilgroup.vendormanagement.entity.SearchHistoryValueLabel;

@Repository
public interface SearchHistoryValueLabelReposetry extends JpaRepository<SearchHistoryValueLabel, Long> {



}
