package com.daynilgroup.vendormanagement.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.daynilgroup.vendormanagement.entity.RegistrationEnquiry;

@Repository
public interface RegistrationEnquiryRepository extends JpaRepository<RegistrationEnquiry, Long> {

	List<RegistrationEnquiry>	findByEmailIdOrMobileNumberAndCountryCodeId(String emailId,String mobileNumber,Long phoneCodeId);
}
