package com.daynilgroup.vendormanagement.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;

import com.daynilgroup.vendormanagement.entity.SubscribedUsers;
import com.daynilgroup.vendormanagement.repository.SubscribedUsersRepository;
import com.daynilgroup.vendormanagement.service.SubscribedUsersService;

@Service
public class SubscribedUsersServiceImpl implements SubscribedUsersService {

	@Autowired
	SubscribedUsersRepository userSubscriptionRepository;

	@Override
	public JpaRepository<SubscribedUsers, Long> getJpaRepository() {

		return userSubscriptionRepository;
	}

	@Override
	public Page<SubscribedUsers> findAll(Pageable pageable) {

		return userSubscriptionRepository.findAll(pageable);
	}

}
