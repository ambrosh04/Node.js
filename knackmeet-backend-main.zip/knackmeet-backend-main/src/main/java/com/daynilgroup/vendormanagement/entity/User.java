package com.daynilgroup.vendormanagement.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.daynilgroup.vendormanagement.constants.TimeZoneEnum;
import com.daynilgroup.vendormanagement.constants.UserType;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.FieldDefaults;

/**
 *
 * @author prerana
 */
@Getter
@Setter
@ToString
@Entity
@Table(name = "user")
@FieldDefaults(level = AccessLevel.PRIVATE)
public class User extends BaseEntity {

	static final long serialVersionUID = 1L;

	@Column(name = "email_id", unique = true)
	String emailId;

	@Column(name = "mobile", unique = true, nullable = false)
	String mobile;

	@Column(name = "password", nullable = false)
	String password;

	@Column(name = "first_name")
	String firstName;

	@Column(name = "last_name")
	String lastName;

	@Enumerated(EnumType.STRING)
	@Column(name = "user_type", nullable = false)
	UserType userType;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "user")
	List<UserRole> userRoles;

	@Column(name = "forgot_password_token")
	String forgotPasswordToken;

	@ManyToOne(targetEntity = CodeLookup.class, fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "phone_code_id", referencedColumnName = "id", nullable = false)
	CodeLookup phoneCode;
	
	@Enumerated(EnumType.STRING)
	@Column(name = "time_zone")
	TimeZoneEnum timeZone;
	
	@Column(name = "page_size")
	Integer pageSize;

}