package com.daynilgroup.vendormanagement.model.response;

import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class StateAdminReponse {
private long id;
private String name;
private String code;
private long countryId;
private String countryName;
}
