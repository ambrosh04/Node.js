package com.daynilgroup.vendormanagement.model.request;

import com.daynilgroup.vendormanagement.model.response.AdvanceSearchDropdownModel;

import lombok.AccessLevel;
import lombok.Data;
import lombok.experimental.FieldDefaults;

@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
public class AddressRequest {

	Long id;

	Long countryId;

	Long stateId;

	AdvanceSearchDropdownModel city;

	String address;

	String pinCode;
}
