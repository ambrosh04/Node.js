package com.daynilgroup.vendormanagement.service;

import com.daynilgroup.vendormanagement.entity.Support;

public interface SupportService extends AbstractService<Support> {

}
