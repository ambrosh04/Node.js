package com.daynilgroup.vendormanagement.constants;

/**
 *
 * @author prerana
 */
public class Constants {

	public static final String MOBILE_NUMBER_ALREADY_EXISTS = "Mobile number already exists.";
	public static final String MOBILE_NUMBER_NOT_REGISTERED = "Mobile number is not registered. Please sign up first.";
	public static final String CODE_ALREADY_EXISTS = "Code already exists.";
	public static final String NAME_ALREADY_EXISTS = "Name already exists.";
	public static final String EMAIL_ALREADY_EXISTS = "Email already exists.";

	public static final String LOGIN_SUCCESS = "Login success.";

	public static final String MESSAGE = "message";
	public static final String AVAILABLE = "available";
	public static final String EXISTS = "exists";
	public static final String NAME = "name";
	public static final String DATE = "date";
	public static final String GENDER = "Gender";
	public static final String OTHER = "other";

	public static final String LOCALE_HEADER = "Locale";
	public static final String LATITUDE_HEADER = "Latitude";
	public static final String LONGITUDE_HEADER = "Longitude";

	public static final String RULE_NAME_ALREADY_EXISTS = "Rule name already exists.";

//	public static final LocaleEnum DEFAULT_LOCALE = LocaleEnum.EN;
	public static final String SEPERATOR = "~SEP~";
	public static final String ORDER_NUMBER_PREFIX = "Jal-";
	public static final String DISPLAY_NAME = "displayName";

	public static final String DISTANCE_IN_KM_SQL_FUNCTION = "DISTANCE_IN_KM";

	public static final String BASE_PACKAGE = "com.daynilgroup.vendormanagement";

	public static final String CRITERIA_GREATER_EQUAL = ">=";

	public static final String CRITERIA_lESS_EQUAL = "<=";

	public static final String REDIRECT_LINK = "redirect_link";

	public static final String RESET_PASSWORD_TOKEN = "/reset-password?token=";

	public static final String INVITED_URL = "/vendor/findjob/job-view";

	public static final String FORGOT_PASSWORD_TEMPLATE = "forgot-password";

	public static final String INVITED_TEMPLATE = "Invited";

	public static final String FORGOT_PASSWORD_SUBJECT = "Forgot Password";

	public static final String INIVITATION_SUBJECT = "Invitation";

	public static final String INIVITATION_MESSAGE = ", your resource has been Invited by Client. Please click on the below mentioned link or login to your respective account to avail the opportunity.";

	public static final String PENDING = "Pending";
	public static final String VERIFIED = "Verified";
	public static final String REJECTED = "Rejected";

	public static final String BASE64 = "data:image/png;base64,";

	public static final String RESOURCE_SMALL_CASE = "resource";
	public static final String JOB_SMALL_CASE = "job";

	public static final String RESOURCE_ID = "resourceId";
	public static final String JOB_ID = "jobId";

	public static final String UNIQUE_IDENTIFIER = "uniqueIdentifier";

	public static final String APPLIED_CAPS = "APPLIED";
	public static final String RESOURCE_VENDOR_ID = "resourceVendorId";
	public static final String JOB_VENDOR_ID = "jobVendorId";

	public static final String INVITE = "INVITE";

	public static final String JOB_TITLE_CAMEL = "jobTitle";

	public static final String VENDOR_PORTFOLIO_NOT_FOUND = "Vendor Portfolio Not Found with id# ";

	public static final String WITHDRAW_CAPS = "WITHDRAW";

	public static final String PROOF_OF_IMAGE_IDENTITY = "Image-Identity";
	public static final String PROOF_OF_DOCUMENT_IDENTITY = "Document-Identity";

	public static final String PROOF_OF_IMAGE_REGISTRATION = "Image-Registration";
	public static final String PROOF_OF_DOCUMENT_REGISTRATION = "Document-Registration";

	public static final String PORTFOLIO = "portfolio";

	public static final String APPLIED_MESSAGE = "has applied on your Job. Please evaluate his resume.";

	public static final String SHORTLISTED_MESSAGE = ", your resource has been shortlisted by Client.";

	public static final String REJECTED_MESSAGE = ", your resource has been Rejected by Client ";

	public static final String HIRED_MESSAGE = ", your resource has been Hired by Client. ";

	public static final String INTERVIEWED_MESSAGE = "We are good to with your resource profile for interview ";

	public static final String APPLIED_URL = "/vendor/jobapplication";

	public static final String SHORTLISTED_URL = "/vendor/benchApplication";

	public static final String REJECTED_URL = "/vendor/benchApplication";

	public static final String HIRED_URL = "/vendor/benchApplication";

	public static final String INTERVIEWED_URL = "/vendor/benchApplication";

	public static final String APPLIED_SUBJECT = "APPLIED";

	public static final String SHORTLISTED_SUBECT = "SHORTLISTED";

	public static final String REJECTED_SUBJECT = "REJECTED";

	public static final String HIRED_SUBJECT = "HIRED";

	public static final String JOB_URL = "/vendor/findjob/job-view";

	public static final String JOB_WITHDRAW_MESSAGE = " has withdrawn his application on your Job because: ";

	public static final String INVITATION_ACCEPTED_MESSAGE = "has accepted your invitation.";

	public static final String INVITATION_ACCEPTED_SUBJECT = "Invitaiton Acepted";

	public static final String INVITATION_REJECTED_MESSAGE = " has rejected your invitation for job ";

	public static final String INVITATION_REJECTED_SUBJECT = "Invitaiton Rejected";

	public static final String BENCH_URL = "/vendor/benchApplication";

	public static final String JOB_APPLIED_URL = "/vendor/jobapplication";

	public static final String JOB_WITHDRAW_URL = "/vendor/post/details";

	public static final String WITHOUT_URL = "without-url";

	public static final String REGISTRATION_SUBJECT = "Vendor registration Done";

	public static final String REGISTRATION_MESSAGE = "Thank you for registering at Knackmeet. Your application has been received and is currently being processed after verifying you can start posting your Project /Job requirements and add Bench Resource.";

	public static final String REGISTRATION_VERIFIED = "Your vendor Registration has been verified you can start posting your Project /Job requirements and Add Bench Resource Now.";

	public static final String REGISTRATION_UNVERIFIED = "Your vendor Registration has been rejected you can not start posting your Project /Job requirements and Add Bench Resource.";

	public static final String REGISTRATION_VERIFIED_SUBJECT = "Vendor registration approved";
	public static final String REGISTRATION_UNVERIFIED_SUBJECT = "Vendor registration rejected";

	public static final String RESOURCE_VERIFIED = "Your bench profile is verified. Now, you can apply for relevant jobs.";
	public static final String RESOURCE_UNVERIFIED = "Your bench resources is rejected, please fix below issue:";

	public static final String RESOURCE_VERIFIED_SUBJECT = "Bench resources verified";
	public static final String RESOURCE_UNVERIFIED_SUBJECT = "Bench resources rejected";

	public static final String RESOURCE_NAME = "Resource_Name";

	public static final String RESOURCE_DESIGNATION = "Designation";

	public static final String JOB_UNDER_REVIEW = "Your posted job is under review and will be active after verification.";
	public static final String JOB_VERIFIED = "Your posted job is verified.Now,You can search the bench candidates and invite.";
	public static final String JOB_UNVERIFIED = "Your posted job has been rejected, please fix below issue: ";

	public static final String JOB_UNDER_REVIEW_SUBJECT = "Job post under review";
	public static final String JOB_VERIFIED_SUBJECT = "Job post verified";
	public static final String JOB_UNVERIFIED_SUBJECT = "Job post reject";
	public static final String JOB_TITLE = "Job_Title";

	public static final String STATUS = "status";
	
	public static final String RESOURCE_UNDER_REVIEW = "Your Bench Resource is under review and will be active after verification.";
	
	public static final String RESOURCE_UNDER_REVIEW_SUBJECT = "Resource under review";
	
	public static final String UNVERIFIED_JOB_TITLE = ". Job Title:" + " ";
	
	public static final String REJECTED_RESOURCE_DESIGNATION = ". Designation:" + " ";
	
	public static final String JOB_FAILURE_RESPONSE = "Job Not Created";
	
	public static final String VERIFY_EMAIL = "verify-email";

	public static final String NOTIFICATION_REDIRECT_LINK = "redirect_link";
	
	public static final String RESOURCE_DESIGNATION_NAME_WITH_URL = "resource-designation-name-with-url";
	
	public static final String JOB_TITLE_WITH_URL = "job-title-with-url";

	public static final String VERIFY_EMAIL_SUBJECT = "Verify Your Email";
	
	public static final String VERIFY_EMAIL_LINK = "/accountverify?token=";
	

	public static final String JOB_UNDER_REVIEW_LINK = "/vendor/post/details?jobId=";
	
	public static final String RESOURCE_UNDER_REVIEW_LINK = "/vendor/resource/detail?resourceId=";
	
	public static final String INIVITATION_RECIVED = "/vendor/invitation/view?jobId=";
	
	public static final String MESSAGE_WITH_URL = "message-with-url";

	
	public static final String INVITATION_ACCEPTED_OR_REJECTED_URL="/vendor/post/details?jobId=";
	
	public static final String HIRED_OR_REJECTED_SHORTLISTED_URL="/vendor/resource/detail?resourceId=";

	public static final String APPLIED_OR_WITHDRAW_URL="/vendor/post/details?jobId=";
	
	public static final String VENDOR_REGISTRATION_REJECTED = "Your vendor Registration has been rejected you can not start posting your Project /Job requirements and Add Bench Resource.";
	
	public static final String REASON = "reason";

	public static final String REJECT_TEMPLATE_WITH_REASON = "reject-template-with-reason";
	
	public static final String ADMIN_MESSAGE_VENDOR_CREATE =" has been registered please verify or reject.";
	  
	public static final String ADMIN_MAIL_TEMPLATE ="admin-mail";

	public static final String ADMIN_NAME ="Deepak Thapa";
	
	public static final String ADMIN_VENDOR_VERIFY_SUBJECT = "Vendor Resgistered";
	
	public static final String ADMIN_JOB_VERIFY_SUBJECT = "Job Create";
	
	public static final String ADMIN_RESOURCE_VERIFY_SUBJECT = "Resource Added";
	
	public static final String ADMIN_MESSAGE_JOB_CREATE =" has created Job please verify or reject.";
	  
	public static final String ADMIN_MESSAGE_RESOURCE_CREATE =" has added a resource please verify or reject.";
	
	public static final String HIRED_JOB_ON_CONTRACT = "job-contract";

	public static final String HIRED_JOB_ON_CONTRACT_SUBJECT = "Open contract requirements";

	public static final String HIRED_JOB_ON_CONTRACT_ACTION_URL = "action_url";

	public static final String HIRED_JOB_ON_CONTRACT_ACTION_LINK = "/vendor/post/details?jobId=";
	
	public static final String VERIFIED_JOB_TITLE = "job_Title";

	public static final String EXCEPT_VERIFIED_JOB_VENDOR_AGENCY_NAME = "name";

	public static final String VERIFIED_JOB_WORK_FROM = "workFrom";

	public static final String VERIFIED_JOB_RATE = "rate";

	public static final String VERIFIED_JOB_NO_OF_POSITION = "no_of_position";
	public static final String VERIFIED_JOB_CONTRACT_DURATION = "contract_duration";

	public static final String VERIFIED_JOB_TEMPLATE = "verified-job";

	public static final String VERIFIED_JOB_SUBJECT = "New requirement- Knackmeet";

	public static final String VERIFIED_JOB_ACTION_LINK = "/vendor/post/details?jobId=";

	public static final String DESCEDNING = "DESC";
	
	public static final String ASCEDNING = "ASC";
	
	public static final String EXCEPT_VENODR_JOB_ACTION_LINK = "/vendor/findjob/job-view?jobId=";
	
	public static final String REASON_LIST = "reasons";
	
	public static final String REMOVE_COUNTRY_NAME_FROM_PHONE_CODE= "[^0-9+]";
	
	public static final String ADD_CANDIDATE_PROFILE_PICTURE_REJECT_REASON = "Add Candidate Profile Picture";

	public static final String EXPERIENCE_IS_NOT_MATCHED_AS_PER_RESUME_REJECT_REASON = "Experience is not matched as per resume";
                                                                                                          
	public static final String RESUME_IS_NOT_MATCHED_AS_PER_EXPERIENCE_REJECT_REASON = "Resume is not matched as per experience";

	public static final String UPLOAD_PROPER_DETAILED_RESUME_REJECT_REASON = "Upload proper Detailed resume";

	public static final String DUPLICCATE_RECORD_POSTED_BY_ANOTHER_VENDOR_REJECT_REASON = "Duplicate record posted by another Vendor";

	public static final String PROFILE_ALREADY_EXISTS_REJECT_REASON = "profile already exists";
	
	public static final String OPEN_CONTRATC_REQUIREMENTS ="Open contract requirements";
	
	public static final String NEW_REQUIREMENTS ="New requirements";
	
	public static final String BRANDFETCH_SEARCH_URI="https://api.brandfetch.io/v2/search/";
	
	public static final String ACCEPT="accept";
	
	public static final String BRANDFETCH_HEADER_ACCEPT="application/json";
	
	public static final String REFERER="Referer";
	
	public static final String BRANDFETCH_HEADER_REFERER="https://example.com/searchIntegrationPage";
	
	public static final String GET="GET";
	
	public static final String RATE="rate";
	
	public static final String ID="id";
	
	public static final String COUNTRY="COUNTRY";
	
	public static final String PHONE_CODE="PHONE-CODE";
	
	public static final String REMOVE_COUNTRY_CODE ="\\s*\\(\\+\\d+\\)";
	
    public static final String REMOVE_CONTACT_DETAILS_FROM_RESUME_REJECT_REASON = "Remove Contact Details From Resume";

}
