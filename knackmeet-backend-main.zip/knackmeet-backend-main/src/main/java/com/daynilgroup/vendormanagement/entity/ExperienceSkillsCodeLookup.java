package com.daynilgroup.vendormanagement.entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "experience_skills_code_lookup")
@NoArgsConstructor
@AllArgsConstructor
public class ExperienceSkillsCodeLookup extends BaseEntity{
	static final long serialVersionUID = 1L;

	@JoinColumn(name = "experience_id", referencedColumnName = "id")
	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	Experience experience;
	
	@JoinColumn(name = "codeLookup_id", referencedColumnName = "id")
	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	CodeLookup codeLookup;
}
