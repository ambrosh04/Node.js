package com.daynilgroup.vendormanagement.constants;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.experimental.FieldDefaults;

@Getter
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public enum StatusEnum {

	VERIFIED("Verified"), UNVERIFIED("Unverified"), REJECTED("Reject"), ON_HOLD("On Hold"),
	CLOSED("Closed"), IN_ACTIVE("In Active"), RESCHEDULED("Rescheduled"),EMAIL_PENDING("Email Pending");

	String displayName;
}
