package com.daynilgroup.vendormanagement.repository;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.daynilgroup.vendormanagement.constants.ResourceStatusEnum;
import com.daynilgroup.vendormanagement.entity.ResourceJobs;

public interface ResourceJobsRepository extends JpaRepository<ResourceJobs, Long> {

	ResourceJobs findByJobIdAndResourceIdAndDeletedFalse(Long jobId, Long resourceId);
	
	List<ResourceJobs> findByJobId(Long id);

	@Query("SELECT rj FROM ResourceJobs rj Where (:resourceId IS NULL OR rj.resource.id =:resourceId) AND (:resourceStatus IS NULL OR  rj.resourceStatus=:resourceStatus)")
	Page<ResourceJobs> findByResourceIdAndResourceStatus(Long resourceId, ResourceStatusEnum resourceStatus,
			Pageable pageable);

	Long countByJobIdAndResourceStatus(Long id, ResourceStatusEnum resourceStatusEnum);

	@Query("SELECT rj FROM ResourceJobs rj INNER JOIN Job j ON rj.job.id=j.id WHERE j.vendor.id=:vendorId AND rj.deleted=false AND rj.resourceStatus <> 'INVITED'")
	Page<ResourceJobs> findByVendorId(Long vendorId, Pageable pageable);


	@Query("SELECT COUNT(*)  FROM ResourceJobs rj  INNER JOIN   Resource r ON  r.id= rj.resource.id Where r.vendor.id =:vendorId AND rj.deleted=false AND rj.resourceStatus <> 'INVITED'")
	Long getResourceApplicationCount(Long vendorId);

	@Query("SELECT COUNT(*)  FROM  ResourceJobs rj  INNER JOIN  Job j  ON  j.id= rj.job.id Where j.vendor.id =:vendorId AND rj.deleted=false AND rj.resourceStatus <> 'INVITED'")
	Long getJobApplicationCount(Long vendorId );

	@Query("SELECT rj FROM  ResourceJobs rj  INNER JOIN  Job j  ON  j.id= rj.job.id  Where j.vendor.id =:vendorId AND (:resourceStatus IS NULL OR  rj.resourceStatus=:resourceStatus) AND (:title IS NULL OR  rj.job.title LIKE %:title%) AND ((:startDate IS NULL AND :endDate IS NULL) OR  ( rj.updatedOn>=:startDate AND rj.updatedOn<=:endDate)) AND rj.deleted = false AND rj.resourceStatus <> 'INVITED' ORDER BY CASE WHEN :listOrder = 'ASC' THEN rj.updatedOn END ASC,CASE WHEN :listOrder = 'DESC' THEN rj.updatedOn END DESC")
	Page<ResourceJobs> findAllJobApplication(Long vendorId, String title, ResourceStatusEnum resourceStatus,
			LocalDateTime startDate, LocalDateTime endDate, String listOrder,Pageable pageable);

	@Query("SELECT rj FROM  ResourceJobs rj  INNER JOIN  Job j  ON  j.id= rj.job.id Where j.vendor.id =:vendorId AND rj.deleted = false")
	List<ResourceJobs> findAllJobApplicationByVendorId(Long vendorId);

	@Modifying
	@Transactional
	@Query(value = "UPDATE resource_jobs rj join job j on rj.job_id=j.id join resource r on rj.resource_id=r.id SET rj.deleted=true,j.applicants_count=applicants_count - 1 ,r.applied_job_count=applied_job_count - 1  WHERE rj.job_id =:jobId AND rj.resource_id=:resourceId", nativeQuery = true)
	void resourceJobsSoftDelete(@Param("jobId") Long jobId, @Param("resourceId") Long resourceId);

	@Query("SELECT rj FROM ResourceJobs rj INNER JOIN Resource r ON r.id = rj.resource.id  WHERE r.vendor.id = :vendorId  AND (:resourceStatus IS NULL OR rj.resourceStatus = :resourceStatus) AND (:name IS NULL OR r.name LIKE %:name% ) AND (  (:startDate IS NULL AND :endDate IS NULL) OR  (rj.updatedOn >= :startDate AND rj.updatedOn <= :endDate)	) 	AND rj.deleted = false  AND rj.resourceStatus <> 'INVITED' ORDER BY CASE WHEN :listOrder = 'ASC' THEN rj.updatedOn END ASC,CASE WHEN :listOrder = 'DESC' THEN rj.updatedOn END DESC")
	Page<ResourceJobs> getApplicationList(Long vendorId, ResourceStatusEnum resourceStatus, String name,
			LocalDateTime startDate, LocalDateTime endDate,String listOrder, Pageable pageable);

	@Query("SELECT rj FROM ResourceJobs rj INNER JOIN Resource r ON r.id=rj.resource.id where r.vendor.id=:vendorId AND rj.deleted=false")
	List<ResourceJobs> getResourceApplicationCountList(Long vendorId);

	@Query("SELECT rj FROM ResourceJobs rj WHERE  rj.job.id=:jobId AND  rj.deleted = false")
	List<ResourceJobs> getResourceCountList(Long jobId);

	@Query("SELECT rj FROM ResourceJobs rj WHERE rj.resource.id=:resourceId AND  rj.deleted = false")
	List<ResourceJobs> getJobCountList(Long resourceId);

	@Query("SELECT COUNT(rj.id)>0 FROM ResourceJobs rj WHERE rj.job.id =:jobId AND rj.resource.id=:resourceId AND rj.deleted=false AND rj.resourceStatus <> 'INVITED'")
	Boolean existsByJobIdAndResourceIdAndDeletedFalse(Long jobId, Long resourceId);

	@Query("SELECT rj FROM ResourceJobs rj INNER JOIN Resource r ON rj.resource.id = r.id WHERE r.vendor.id=:vendorId AND rj.deleted=false ORDER BY rj.updatedOn DESC")
	Page<ResourceJobs> getNotifiation(Long vendorId, Pageable pageable);

	Boolean existsByJobIdAndResourceIdAndDeletedTrue(Long jobId, Long resourceId);

	Boolean existsByJobIdAndResourceIdAndDeleted(Long jobId, Long resourceId, Boolean isDeleted);

	ResourceJobs findByJobIdAndResourceIdAndDeletedTrue(Long jobId, Long resourceId);

	@Query("SELECT rj FROM ResourceJobs rj WHERE rj.job.id =:jobId AND rj.resource.id=:resourceId AND rj.deleted=false")
	ResourceJobs existsByJobIdAndResourceIdAndDeletedFalseAndResourceStatus(Long jobId, Long resourceId);
	
	@Query("SELECT COUNT(rj.id) FROM  ResourceJobs rj  INNER JOIN  Resource r  ON  r.id= rj.resource.id  Where r.vendor.id =:vendorId AND rj.resourceStatus=:resourceStatus AND rj.deleted=false")
    Long fetchInvitationsReceived(Long vendorId,ResourceStatusEnum resourceStatus);

	@Query("SELECT COUNT(rj.id) FROM  ResourceJobs rj  INNER JOIN  Job j  ON  j.id= rj.job.id  Where j.vendor.id =:vendorId AND   rj.resourceStatus=:resourceStatus AND rj.deleted=false")
	Long fetchInvitationsSent(Long vendorId,ResourceStatusEnum resourceStatus);


	// Invitation sent
	@Query("SELECT COUNT(rj.id)  FROM  ResourceJobs rj  INNER JOIN  Job j  ON  j.id= rj.job.id Where j.vendor.id =:vendorId AND   rj.resourceStatus IN ('INVITED','INVITATION_ACCEPTED','INVITATION_REJECTED') AND rj.deleted=false")
	Long getCountOfInvitationSent(Long vendorId);

	// Invitation received
	@Query("SELECT COUNT(rj.id)  FROM ResourceJobs rj  INNER JOIN   Resource r ON  r.id= rj.resource.id Where r.vendor.id =:vendorId AND   rj.resourceStatus IN ('INVITED','INVITATION_ACCEPTED','INVITATION_REJECTED') AND rj.deleted=false")
	Long getCountOfInvitationReceived(Long vendorId);
	
	ResourceJobs findByJobIdAndResourceId(Long jobId, Long resourceId);
	
	@Query("SELECT rj FROM ResourceJobs rj INNER JOIN Resource r ON r.id = rj.resource.id  WHERE r.vendor.id = :vendorId  AND (:resourceStatus IS NULL OR rj.resourceStatus = :resourceStatus) AND (:name IS NULL OR r.name LIKE %:name% ) AND (  (:startDate IS NULL AND :endDate IS NULL) OR  (rj.updatedOn >= :startDate AND rj.updatedOn <= :endDate)	) 	AND rj.deleted = false ORDER BY CASE WHEN :listOrder = 'ASC' THEN rj.updatedOn END ASC,CASE WHEN :listOrder = 'DESC' THEN rj.updatedOn END DESC")
	Page<ResourceJobs> getInvitationRecieved(Long vendorId, ResourceStatusEnum resourceStatus, String name,
			LocalDateTime startDate, LocalDateTime endDate,String listOrder, Pageable pageable);
	
	@Query("SELECT rj FROM  ResourceJobs rj  INNER JOIN  Job j  ON  j.id= rj.job.id  Where j.vendor.id =:vendorId AND (:resourceStatus IS NULL OR  rj.resourceStatus=:resourceStatus) AND (:title IS NULL OR  rj.job.title LIKE %:title%) AND ((:startDate IS NULL AND :endDate IS NULL) OR  ( rj.updatedOn>=:startDate AND rj.updatedOn<=:endDate)) AND rj.deleted = false ORDER BY CASE WHEN :listOrder = 'ASC' THEN rj.updatedOn END ASC,CASE WHEN :listOrder = 'DESC' THEN rj.updatedOn END DESC ")
	Page<ResourceJobs> getInvitationSent(Long vendorId, String title, ResourceStatusEnum resourceStatus,
			LocalDateTime startDate, LocalDateTime endDate,String listOrder, Pageable pageable);

	@Query("SELECT COUNT(rj.id) FROM ResourceJobs rj WHERE rj.resource.id=:resourceId AND rj.deleted=false AND rj.resourceStatus <> 'INVITED'")
	Long findByResourceIdAndDeletedFalse(Long resourceId);
	
	@Query("SELECT COUNT(rj.id) FROM ResourceJobs rj WHERE rj.job.id=:jobId AND rj.deleted=false AND rj.resourceStatus <> 'INVITED'")
	Long findByJobIdAndDeletedFalse(Long jobId);
}
