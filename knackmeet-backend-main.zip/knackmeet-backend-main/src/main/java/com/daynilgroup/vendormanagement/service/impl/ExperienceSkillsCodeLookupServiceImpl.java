package com.daynilgroup.vendormanagement.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;

import com.daynilgroup.vendormanagement.entity.ExperienceSkillsCodeLookup;
import com.daynilgroup.vendormanagement.repository.ExperienceSkillsCodeLookupRepository;
import com.daynilgroup.vendormanagement.service.ExperienceSkillsCodeLookupService;

@Service
public class ExperienceSkillsCodeLookupServiceImpl implements ExperienceSkillsCodeLookupService{

	
	@Autowired
	ExperienceSkillsCodeLookupRepository experienceSkillsCodeLookupRepository;
	
	@Override
	public JpaRepository<ExperienceSkillsCodeLookup, Long> getJpaRepository() {
		return experienceSkillsCodeLookupRepository;
	}

	@Override
	public void deleteByExperienceId(Long experienceId) {
		experienceSkillsCodeLookupRepository.deleteByExperienceId(experienceId);
		
	}

}
