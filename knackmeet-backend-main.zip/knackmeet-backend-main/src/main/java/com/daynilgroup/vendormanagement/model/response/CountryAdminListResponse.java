package com.daynilgroup.vendormanagement.model.response;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class CountryAdminListResponse {
	
	Long id;
	String name;
	String code;

}
