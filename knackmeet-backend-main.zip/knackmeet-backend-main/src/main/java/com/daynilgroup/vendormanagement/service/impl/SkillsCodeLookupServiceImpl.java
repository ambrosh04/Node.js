package com.daynilgroup.vendormanagement.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;

import com.daynilgroup.vendormanagement.entity.SkillsCodeLookup;
import com.daynilgroup.vendormanagement.repository.SkillsCodeLookupRepository;
import com.daynilgroup.vendormanagement.service.SkillsCodeLookupService;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;


@Service
@FieldDefaults(level = AccessLevel.PRIVATE)
public class SkillsCodeLookupServiceImpl implements SkillsCodeLookupService {

	@Autowired
	SkillsCodeLookupRepository skillsCodeLookupRepositry;

	@Override
	public JpaRepository<SkillsCodeLookup, Long> getJpaRepository() {

		return skillsCodeLookupRepositry;
	}

	@Override
	public void deleteByJobId(Long jobId) {
		skillsCodeLookupRepositry.deleteByJobId(jobId);
	}

	@Override
	public List<SkillsCodeLookup> findAllByJobId(Long jobId) {
		return skillsCodeLookupRepositry.findAllByJobId(jobId);
	}

}
