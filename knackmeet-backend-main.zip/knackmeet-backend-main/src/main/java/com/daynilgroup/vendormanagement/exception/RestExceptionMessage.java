package com.daynilgroup.vendormanagement.exception;

import lombok.Getter;
import lombok.NoArgsConstructor;
/**
*
* @author prerana
*/
@Getter
@NoArgsConstructor
public class RestExceptionMessage extends RestExecption {

    public final String errorCode = RestExceptionCode.VALIDATION_ERROR_CODE;
    public String message = "";

    public RestExceptionMessage(String message) {
        this.message += message;
    }
}