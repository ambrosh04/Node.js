package com.daynilgroup.vendormanagement.repository.event;

/**
*
* @author Manish
*/
public interface PreSave<E, C> {

    public void preSaveAction(E oldEntity, C createRequest) throws Exception;
}
