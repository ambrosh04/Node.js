package com.daynilgroup.vendormanagement.model.response;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import com.daynilgroup.vendormanagement.constants.CurrencyTypeEnum;
import com.daynilgroup.vendormanagement.constants.DeploymentTypeEnum;
import com.daynilgroup.vendormanagement.constants.Gender;
import com.daynilgroup.vendormanagement.constants.RateTypeEnum;
import com.daynilgroup.vendormanagement.constants.ResourceStatusEnum;
import com.daynilgroup.vendormanagement.helper.EducationDetailAdminResponse;

import lombok.AccessLevel;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@Getter
@Setter
@FieldDefaults(level = AccessLevel.PRIVATE)
@Builder
public class ResourceDetailAdminResponse implements Serializable {
	static final long serialVersionUID = 1L;

	Long id;

	String firstname;

	String middleName;

	String lastname;

	Gender gender;

	AdvanceSearchDropdownModel designation;

	String base64MediaString;

	Integer monthsExperience;

	Integer yearsExperience;

	DeploymentTypeEnum deploymenType;

	Long availabilityId;

	Long countryId;
	
	Long stateId;
	
	AdvanceSearchDropdownModel city;

	Long categoryId;

	String address;
	
	String resume;

	String resumeName;
	
	List<AdvanceSearchDropdownModel> skills;

	String base64profilePhoto;

	CurrencyTypeEnum currencyType;

	RateTypeEnum rateTypeEnum;

	BigDecimal rate;

	String base64resume;

	ResourceStatusEnum resourceStatus;
	
	Long passingYear;

	String higherEducation;
	
	String description;
	
	RateTypeEnum usdRateType;
	
	BigDecimal usdRate;
	
	List<EducationDetailAdminResponse>  educations;
	
	List<ExperienceDetailAdminResponse>  experiences;
	
	String location;
	
	BigDecimal latitude;
	
	BigDecimal longitude;
}
