package com.daynilgroup.vendormanagement.model.response;

import java.time.LocalDateTime;

import com.daynilgroup.vendormanagement.constants.StatusEnum;

import lombok.Data;

@Data
public class UserVendorResponse {

	String firstName;

	String lastName;

	String emailId;

	String mobile;

	String agencyName;

	String website;

	LocalDateTime incorparationDate;

	Long teamStrength;

	String gstNumber;

	Long phoneCodeId;

	String phoneCodeName;

	String location;

	String directorName;

	StatusEnum status;

	String profilePhotoPath;

	String base64MediaString;
	
	Long vendorId;
	
	String about;
	
	LocalDateTime createdOn;

	String reason;
	
	TimeZomeDropdown timeZone;

	String companyPrimaryNumber;

	String companyPrimaryEmail;
	
	String companyDescription;
	
	Long countryCodeId;

	String countryCodeName;
	
	String tagline;
	
	String countryName;
}
