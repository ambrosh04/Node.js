package com.daynilgroup.vendormanagement.model.response;

import java.io.Serializable;

import com.daynilgroup.vendormanagement.constants.MenuEnum;

import lombok.Builder;
import lombok.Data;

/**
*
* @author Manish
*/
@Data
@Builder
public class MenuDetailResponse implements Serializable {

   private static final long serialVersionUID = 1L;

   private Long id;
   private String title;
   private String path;
   private String icon;
   private Long parentId;
   private Boolean active;
   private Boolean masterMenu;
   private Integer displayOrder;
   private MenuEnum code;
}
