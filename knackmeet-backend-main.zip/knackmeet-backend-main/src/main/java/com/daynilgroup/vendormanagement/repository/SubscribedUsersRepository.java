package com.daynilgroup.vendormanagement.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.daynilgroup.vendormanagement.entity.SubscribedUsers;

@Repository
public interface SubscribedUsersRepository extends JpaRepository<SubscribedUsers, Long> {

	Page<SubscribedUsers> findAll(Pageable pageable);
}
