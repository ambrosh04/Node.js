package com.daynilgroup.vendormanagement.model.filter;


import java.math.BigDecimal;
import java.util.List;

import com.daynilgroup.vendormanagement.constants.CurrencyTypeEnum;
import com.daynilgroup.vendormanagement.constants.DeploymentTypeEnum;
import com.daynilgroup.vendormanagement.constants.Gender;
import com.daynilgroup.vendormanagement.constants.RateTypeEnum;
import com.daynilgroup.vendormanagement.constants.ResourceSearchInEnum;
import com.daynilgroup.vendormanagement.model.pag.PaginationRequestModel;
import com.daynilgroup.vendormanagement.model.response.DropdownResponse;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class ResourceSkillsFilterModel {

	
	List<DropdownResponse> skillOrTitle;

	ResourceSearchInEnum resourceSearchInEnum;

	Integer minExperience;

	Integer maxExperience;

	BigDecimal minRate;

	BigDecimal maxRate;

	Gender gender;
	
	CurrencyTypeEnum currencyTypeEnum;

	PaginationRequestModel paginationRequestModel;

	Long cityId;

	Long stateId;

	Long countryId;
	
	Long availabilityId;
	
	String keyword;
	
	RateTypeEnum rateTypeEnum;
	
	RateTypeEnum usdRateTypeEnum;
	
	Boolean isMaxRate;
	
	DeploymentTypeEnum deploymenType;
	
	String countryName;

}
