package com.daynilgroup.vendormanagement.model.request;

import java.io.Serializable;
import java.util.List;

import com.daynilgroup.vendormanagement.constants.CodeLookUpRelationTypeEnum;
import com.daynilgroup.vendormanagement.constants.RefTypeEnum;
import com.daynilgroup.vendormanagement.model.response.AdvanceSearchDropdownModel;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;


@Data
@AllArgsConstructor
@NoArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class CodeLookUpRelationRequest implements Serializable {

	private static final long serialVersionUID = 1L;

	Long refId;

	RefTypeEnum refType;

	List<AdvanceSearchDropdownModel> reasons;

	CodeLookUpRelationTypeEnum type;
}
