package com.daynilgroup.vendormanagement.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.daynilgroup.vendormanagement.constants.ResourceStatusEnum;
import com.daynilgroup.vendormanagement.entity.ResourceJobs;
import com.daynilgroup.vendormanagement.model.response.DashBoardJobsListResponse;
import com.daynilgroup.vendormanagement.model.response.DashBoardResponse;
import com.daynilgroup.vendormanagement.model.response.NotificationResponse;
import com.daynilgroup.vendormanagement.service.DashBoardService;
import com.daynilgroup.vendormanagement.service.JobService;
import com.daynilgroup.vendormanagement.service.ResourceJobsService;
import com.daynilgroup.vendormanagement.service.ResourceService;
import com.daynilgroup.vendormanagement.util.CommonUtil;
import com.daynilgroup.vendormanagement.util.EntityUtil;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;

@Service
@FieldDefaults(level = AccessLevel.PRIVATE)
public class DashBoardServiceImpl implements DashBoardService {

	@Autowired
	JobService jobService;

	@Autowired
	ResourceService resourceService;

	@Autowired
	ResourceJobsService resourceJobsService;

	@Autowired
	EntityUtil entityUtil;

	@Override
	public DashBoardResponse getDashBoardResponse() {
		Long myJobProjectCount = jobService.getJobsCountByVendorId(entityUtil.getCurrentVendorId());
		Long myBenchResourceCount = resourceService.getResourcesCountByVendorId(entityUtil.getCurrentVendorId());
		Long benchApplicationCount = resourceJobsService.getCountApplicationByvendorId(entityUtil.getCurrentVendorId());
		Long jobApplicationCount = resourceJobsService.getCountJobApllication(entityUtil.getCurrentVendorId());
		Long countOfInvitationReceivedAgainstCurrentVendorJob = resourceJobsService
				.getCountOfInvitationReceivedAgainstCurrentVendorJob(entityUtil.getCurrentVendorId());
		Long countOfInvitationSendAgainstAnotherVendorResource = resourceJobsService
				.getCountOfInvitationSendAgainstAnotherVendorResource(entityUtil.getCurrentVendorId());

		DashBoardResponse.DashBoardResponseBuilder builder = DashBoardResponse.builder()
				.benchApplication(benchApplicationCount).jobApplication(jobApplicationCount)
				.myBenchOrResource(myBenchResourceCount).myJobOrProjects(myJobProjectCount)
				.invitationReceived(countOfInvitationReceivedAgainstCurrentVendorJob)
				.invitationSent(countOfInvitationSendAgainstAnotherVendorResource);
		return builder.build();
	}

	@Override
	public List<DashBoardJobsListResponse> getListResponse(List<ResourceJobs> resourceJobsList) {
		List<DashBoardJobsListResponse> resourceJobsListResponses = new ArrayList<>();
		resourceJobsList.forEach(resourceJob -> {
			String experience = CommonUtil.getExperience(resourceJob.getResource().getYearsExperience(),
					resourceJob.getResource().getMonthsExperience());
			String applicant = resourceJob.getResource().getFirstName() + "(" + experience + "Exp )";
			resourceJobsListResponses.add(DashBoardJobsListResponse.builder()
					.jobId(resourceJob.getJob() != null ? resourceJob.getJob().getId() : null)
					.myJob(resourceJob.getJob() != null ? resourceJob.getJob().getTitle() : null).applicant(applicant)
					.resourceStatus(resourceJob.getResourceStatus().getDisplayName()).date(resourceJob.getUpdatedOn())
					.build());

		});
		return resourceJobsListResponses;
	}

	@Override
	public List<NotificationResponse> getNotificationResponse(List<ResourceJobs> resourceJobs) {

		List<NotificationResponse> notificationList = new ArrayList<>();

		resourceJobs.forEach(resourceJob -> {
			notificationList.add(NotificationResponse.builder().resourceName(resourceJob.getResource().getFirstName())
					.date(resourceJob.getResourceStatus() == ResourceStatusEnum.APPLIED ? resourceJob.getCreatedOn()
							: resourceJob.getUpdatedOn())
					.jobTitle(resourceJob.getJob().getTitle()).resourceStatus(resourceJob.getResourceStatus()).build());

		});

		return notificationList;

	}
}
