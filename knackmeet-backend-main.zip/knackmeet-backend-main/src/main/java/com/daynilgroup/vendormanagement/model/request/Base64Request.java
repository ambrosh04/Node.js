/**
 * 
 */
package com.daynilgroup.vendormanagement.model.request;

import java.io.Serializable;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

/**
 * @author Rohit
 *
 */
@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class Base64Request implements Serializable {

	static final long serialVersionUID = 1L;

	String base64resume;
	
}
