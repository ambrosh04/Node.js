package com.daynilgroup.vendormanagement.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.daynilgroup.vendormanagement.entity.EmailLog;

public interface EmailLogService extends AbstractService<EmailLog> {

	Page<EmailLog> getList(Pageable pageable);
}
