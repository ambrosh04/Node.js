package com.daynilgroup.vendormanagement.repository.custom.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Order;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.persistence.criteria.Selection;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort.Direction;

import com.daynilgroup.vendormanagement.constants.Constants;
import com.daynilgroup.vendormanagement.constants.CurrencyTypeEnum;
import com.daynilgroup.vendormanagement.constants.DeploymentTypeEnum;
import com.daynilgroup.vendormanagement.constants.StaticConfigurationEnum;
import com.daynilgroup.vendormanagement.constants.StatusEnum;
import com.daynilgroup.vendormanagement.entity.Address;
import com.daynilgroup.vendormanagement.entity.Address_;
import com.daynilgroup.vendormanagement.entity.CodeLookup;
import com.daynilgroup.vendormanagement.entity.CodeLookupType;
import com.daynilgroup.vendormanagement.entity.CodeLookupType_;
import com.daynilgroup.vendormanagement.entity.CodeLookup_;
import com.daynilgroup.vendormanagement.entity.Job_;
import com.daynilgroup.vendormanagement.entity.Resource;
import com.daynilgroup.vendormanagement.entity.ResourceSkillsCodeLookup;
import com.daynilgroup.vendormanagement.entity.ResourceSkillsCodeLookup_;
import com.daynilgroup.vendormanagement.entity.Resource_;
import com.daynilgroup.vendormanagement.entity.Vendor;
import com.daynilgroup.vendormanagement.entity.Vendor_;
import com.daynilgroup.vendormanagement.model.filter.ResourceSkillsFilterModel;
import com.daynilgroup.vendormanagement.model.pag.PageModel;
import com.daynilgroup.vendormanagement.model.response.DropdownResponse;
import com.daynilgroup.vendormanagement.model.response.ResourceListResponse;
import com.daynilgroup.vendormanagement.repository.CodeLookupRepository;
import com.daynilgroup.vendormanagement.repository.custom.ResourceSkillsCodeLookupCustomRepository;
import com.daynilgroup.vendormanagement.security.JwtRequestFilter;
import com.daynilgroup.vendormanagement.service.CodeLookupService;
import com.daynilgroup.vendormanagement.service.StaticConfigurationService;
import com.daynilgroup.vendormanagement.service.VendorService;
import com.daynilgroup.vendormanagement.util.CommonUtil;
import com.daynilgroup.vendormanagement.util.CriteriaUtil;
import com.daynilgroup.vendormanagement.util.EntityUtil;

public class ResourceSkillsCodeLookupCustomRepositoryImpl implements ResourceSkillsCodeLookupCustomRepository {

	static final Logger LOGGER = LogManager.getLogger(JwtRequestFilter.class);

	@PersistenceContext
	private EntityManager entityManager;

	@Autowired
	private CriteriaUtil criteriaUtil;

	@Autowired
	private EntityUtil entityUtil;
	
	@Autowired
	private StaticConfigurationService staticConfigurationService;
	
	@Autowired
	CodeLookupRepository codeLookupRepository;
	
	@Autowired
	VendorService vendorService;

	@Override
	public PageModel findAll(ResourceSkillsFilterModel resourceSkillsFilterModel) {

		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();

		CriteriaQuery<ResourceListResponse> listQuery = criteriaBuilder.createQuery(ResourceListResponse.class);
		populateQuery(criteriaBuilder, listQuery, resourceSkillsFilterModel, false);

		CriteriaQuery<Long> countQuery = criteriaBuilder.createQuery(Long.class);
		populateQuery(criteriaBuilder, countQuery, resourceSkillsFilterModel, true);

		return criteriaUtil.getPageModel(listQuery, countQuery, resourceSkillsFilterModel.getPaginationRequestModel());
	}

	private void populateQuery(CriteriaBuilder criteriaBuilder, CriteriaQuery<?> criteriaQuery,
			ResourceSkillsFilterModel resourceSkillsFilterModel, boolean isCount) {
		Root<ResourceSkillsCodeLookup> root = criteriaQuery.from(ResourceSkillsCodeLookup.class);
		Join<ResourceSkillsCodeLookup, CodeLookup> skills = root.join(ResourceSkillsCodeLookup_.CODE_LOOKUP,
				JoinType.LEFT);
		Join<ResourceSkillsCodeLookup, Resource> resource = root.join(ResourceSkillsCodeLookup_.RESOURCE,
				JoinType.LEFT);
		Join<Resource, CodeLookup> availability = resource.join(Resource_.availability);
		Join<Resource, CodeLookup> deginations = resource.join(Resource_.DESIGNATION, JoinType.LEFT);
		Join<Resource, Vendor> vendor = resource.join(Resource_.VENDOR);
		Join<Resource, CodeLookup> country = resource.join(Resource_.COUNTRY,JoinType.LEFT);

		List<Predicate> predicates = getPredicates(criteriaBuilder, resourceSkillsFilterModel, root, resource, skills,
				deginations, country, vendor, availability);

		Selection<?> selection;
		if (isCount) {
			selection = criteriaBuilder.countDistinct(resource);
		} else {
			selection = criteriaBuilder.construct(ResourceListResponse.class, resource.get(Resource_.ID),
					resource.get(Resource_.FIRST_NAME), resource.get(Resource_.LAST_NAME),
					resource.get(Resource_.AVAILABILITY).get(CodeLookup_.NAME), deginations.get(CodeLookup_.NAME),
					resource.get(Resource_.RATE), resource.get(Resource_.CURRENCY_TYPE),
					resource.get(Resource_.RATE_TYPE_ENUM), resource.get(Resource_.YEARS_EXPERIENCE),
					resource.get(Resource_.MONTHS_EXPERIENCE),
					country.get(CodeLookup_.NAME), resource.get(Resource_.GENDER), resource.get(Resource_.ACTIVE),
					resource.get(Resource_.HIGHER_EDUCATION), resource.get(Resource_.PASSING_YEAR),
					resource.get(Resource_.STATUS_ENUM), resource.get(Resource_.CREATED_ON),
					resource.get(Resource_.UPDATED_ON), vendor.get(Vendor_.AGENCY_NAME),resource.get(Resource_.USD_RATE),resource.get(Resource_.USD_RATE_TYPE),resource.get(Resource_.DEPLOYMEN_TYPE),resource.get(Resource_.LOCATION));
		}

		List<Order> orders = new ArrayList<>();
		if (resourceSkillsFilterModel.getPaginationRequestModel().getSortBy().equals(Constants.NAME)
				&& resourceSkillsFilterModel.getPaginationRequestModel().getSortDirection().equals(Direction.ASC)) {
			orders.add(criteriaBuilder.asc(resource.get(Resource_.FIRST_NAME)));
		}
		else if (resourceSkillsFilterModel.getPaginationRequestModel().getSortBy().equals(Constants.NAME)
				&& resourceSkillsFilterModel.getPaginationRequestModel().getSortDirection().equals(Direction.DESC)) {
			orders.add(criteriaBuilder.desc(resource.get(Resource_.FIRST_NAME)));
		}
		else if (resourceSkillsFilterModel.getCurrencyTypeEnum()!=null&& resourceSkillsFilterModel.getCurrencyTypeEnum().equals(CurrencyTypeEnum.INR) && resourceSkillsFilterModel.getPaginationRequestModel().getSortBy().equals(Constants.RATE)
				&& resourceSkillsFilterModel.getPaginationRequestModel().getSortDirection().equals(Direction.ASC)) {
			orders.add(criteriaBuilder.asc(resource.get(Resource_.RATE)));
		}
		else if (resourceSkillsFilterModel.getCurrencyTypeEnum()!=null&& resourceSkillsFilterModel.getCurrencyTypeEnum().equals(CurrencyTypeEnum.USD) && resourceSkillsFilterModel.getPaginationRequestModel().getSortBy().equals(Constants.RATE)
				&& resourceSkillsFilterModel.getPaginationRequestModel().getSortDirection().equals(Direction.ASC)) {
			orders.add(criteriaBuilder.asc(resource.get(Resource_.USD_RATE)));
		}
		else if (resourceSkillsFilterModel.getCurrencyTypeEnum()!=null&& resourceSkillsFilterModel.getCurrencyTypeEnum().equals(CurrencyTypeEnum.INR) && resourceSkillsFilterModel.getPaginationRequestModel().getSortBy().equals(Constants.RATE)
				&& resourceSkillsFilterModel.getPaginationRequestModel().getSortDirection().equals(Direction.DESC)) {
			orders.add(criteriaBuilder.desc(resource.get(Resource_.RATE)));
		}
		else if (resourceSkillsFilterModel.getCurrencyTypeEnum()!=null&& resourceSkillsFilterModel.getCurrencyTypeEnum().equals(CurrencyTypeEnum.USD) && resourceSkillsFilterModel.getPaginationRequestModel().getSortBy().equals(Constants.RATE)
				&& resourceSkillsFilterModel.getPaginationRequestModel().getSortDirection().equals(Direction.DESC)) {
			orders.add(criteriaBuilder.desc(resource.get(Resource_.USD_RATE)));
		}else if (resourceSkillsFilterModel.getPaginationRequestModel().getSortBy().equals(Constants.ID)
				&& resourceSkillsFilterModel.getPaginationRequestModel().getSortDirection().equals(Direction.DESC)) {
			orders.add(criteriaBuilder.desc(resource.get(Resource_.ID)));
		}
		criteriaUtil.populateCriteriaQuery(criteriaQuery, selection, predicates, orders);
	}

	private List<Predicate> getPredicates(CriteriaBuilder criteriaBuilder,
			ResourceSkillsFilterModel resourceSkillsFilterModel, Root<ResourceSkillsCodeLookup> root,
			Join<ResourceSkillsCodeLookup, Resource> resource, Join<ResourceSkillsCodeLookup, CodeLookup> skills,
			Join<Resource, CodeLookup> deginations, 
			Join<Resource, CodeLookup> country, Join<Resource, Vendor> vendor, Join<Resource, CodeLookup> availability) {
		List<Predicate> predicates = criteriaUtil.getDefaultPredicates(criteriaBuilder, root);
		 Long currentVendorId = entityUtil.getCurrentVendorId();
		if(resourceSkillsFilterModel.getDeploymenType() !=null &&resourceSkillsFilterModel.getDeploymenType().equals(DeploymentTypeEnum.REMOTE)&&resourceSkillsFilterModel.getCountryName()!=null) {
			List<CodeLookup> countries = codeLookupRepository.getByType_codeAndNameLikeOrNameIsNullAndActiveTrueAndDeletedFalseOrDeletedIsNull(Constants.PHONE_CODE, resourceSkillsFilterModel.getCountryName());
			Predicate vendorCountryPredicate =null;
			for (CodeLookup vendorCountry : countries) {
				
				String modifiedCountryName = vendorCountry.getName().replaceAll(Constants.REMOVE_COUNTRY_CODE, "").replaceAll(" ",
						"");
						if(resourceSkillsFilterModel.getCountryName().replaceAll(" ", "").equals(modifiedCountryName)) {
					Join<Vendor, CodeLookup> vendorCountryCodelookup = vendor.join(Vendor_.COUNTRY_CODE);
					 vendorCountryPredicate = criteriaBuilder.and(criteriaBuilder.equal(vendorCountryCodelookup.get(CodeLookup_.ID), vendorCountry.getId()),criteriaBuilder.equal(resource.get(Resource_.DEPLOYMEN_TYPE), DeploymentTypeEnum.REMOTE));
					break;
				}
			}
			if(vendorCountryPredicate!=null) {
			predicates.add(criteriaBuilder.or(criteriaBuilder.and(
					criteriaBuilder.equal(resource.get(Resource_.DEPLOYMEN_TYPE), DeploymentTypeEnum.REMOTE_AND_ONSITE),
					criteriaBuilder.equal(country.get(CodeLookup_.ID), resourceSkillsFilterModel.getCountryId())),
					vendorCountryPredicate));
			}else {
				predicates.add(criteriaBuilder.and(
						criteriaBuilder.equal(resource.get(Resource_.DEPLOYMEN_TYPE),
								DeploymentTypeEnum.REMOTE_AND_ONSITE),
						criteriaBuilder.equal(country.get(CodeLookup_.ID), resourceSkillsFilterModel.getCountryId())));
			}

		} else if (resourceSkillsFilterModel.getDeploymenType() != null
				&& !resourceSkillsFilterModel.getDeploymenType().equals(DeploymentTypeEnum.REMOTE)
				&& resourceSkillsFilterModel.getCountryId() == null) {

			Vendor currentVendor = vendorService.findById(currentVendorId);
			String currentVendorCountry = currentVendor.getCountryCode().getName();
			String modifiedCountryName = currentVendorCountry.replaceAll(Constants.REMOVE_COUNTRY_CODE, "").replaceAll(" ", "");
			List<CodeLookup> countries = codeLookupRepository
					.getByTypeCodeAndDeletedFalseOrDeletedIsNull(Constants.COUNTRY, modifiedCountryName);

			for (CodeLookup vendorCountry : countries) {
				String removedSpaceCountryName = vendorCountry.getName().replaceAll(" ", "");
				if (modifiedCountryName.equals(removedSpaceCountryName)) {
					criteriaUtil.addPredicates(criteriaBuilder, predicates, country.get(CodeLookup_.ID),
							vendorCountry.getId());					
				}
			}
			if (countries.size() == 0) {
				criteriaUtil.addPredicates(criteriaBuilder, predicates, resource.get(Resource_.ACTIVE), Boolean.FALSE);

			}

		} else if (resourceSkillsFilterModel.getDeploymenType() != null
				&& !resourceSkillsFilterModel.getDeploymenType().equals(DeploymentTypeEnum.REMOTE)
				&& resourceSkillsFilterModel.getCountryId() != null) {
			criteriaUtil.addPredicates(criteriaBuilder, predicates, country.get(CodeLookup_.ID),
					resourceSkillsFilterModel.getCountryId());
		}
		
			if (resourceSkillsFilterModel.getDeploymenType() != null
				&& !resourceSkillsFilterModel.getDeploymenType().equals(DeploymentTypeEnum.HYBRID)) {
			
			Predicate bothRemoteAndOnsitePredicate = criteriaBuilder.equal(resource.get(Resource_.DEPLOYMEN_TYPE), DeploymentTypeEnum.REMOTE_AND_ONSITE);
			Predicate remoteAndOnsitePredicate = criteriaBuilder.equal(resource.get(Resource_.DEPLOYMEN_TYPE), resourceSkillsFilterModel.getDeploymenType());
			Predicate finalPredicate = criteriaBuilder.or(bothRemoteAndOnsitePredicate, remoteAndOnsitePredicate);
			predicates.add(finalPredicate);		
		} else {
			criteriaUtil.addPredicates(criteriaBuilder, predicates, resource.get(Resource_.DEPLOYMEN_TYPE),
					resourceSkillsFilterModel.getDeploymenType());
		}

		criteriaUtil.addPredicates(criteriaBuilder, predicates, resource.get(Resource_.STATUS_ENUM),
				StatusEnum.VERIFIED);
		criteriaUtil.addPredicates(criteriaBuilder, predicates, resource.get(Resource_.ACTIVE),
				Boolean.TRUE);
		predicates.add(criteriaBuilder.notEqual(vendor.get(Vendor_.ID), entityUtil.getCurrentVendorId()));
		criteriaUtil.addPredicates(criteriaBuilder, predicates, availability.get(CodeLookup_.ID),
				resourceSkillsFilterModel.getAvailabilityId());

//		List<DropdownResponse> valueLabel = resourceSkillsFilterModel.getSkillOrTitle();
//		List<String> keywords = new ArrayList<>();
//
//		for (DropdownResponse dropdownResponse : valueLabel) {
//
//			if (dropdownResponse.getLabel() != null) {
//
//				keywords.add(dropdownResponse.getLabel());
//			}
//		}
		LOGGER.warn("currentVendorId=" + entityUtil.getCurrentVendorId());
//		if (resourceSkillsFilterModel.getResourceSearchInEnum() != null) {
//			switch (resourceSkillsFilterModel.getResourceSearchInEnum()) {
//			case ANY:
//
//				criteriaUtil.addPredicatesOr(criteriaBuilder, predicates, skills.get(CodeLookup_.NAME),
//						deginations.get(CodeLookup_.NAME), keywords);
//
//				break;
//
//			case DESIGNATION_AND_SKILLS:
//
//				criteriaUtil.addPredicatesAnd(criteriaBuilder, predicates, skills.get(CodeLookup_.NAME),
//						deginations.get(CodeLookup_.NAME), keywords);
//
//				break;
//
//			case KEY_SKILLS:
//
//				criteriaUtil.addPredicates(criteriaBuilder, predicates, skills.get(CodeLookup_.NAME), keywords);
//
//				break;
//
//			case DESIGNATION:
//
//				criteriaUtil.addPredicates(criteriaBuilder, predicates, deginations.get(CodeLookup_.NAME), keywords);
//				break;
//
//			}
//
//		}
		criteriaUtil.addPredicatesOr(criteriaBuilder, predicates, skills.get(CodeLookup_.NAME),
		deginations.get(CodeLookup_.NAME), resourceSkillsFilterModel.getKeyword());
		Expression<Integer> sum = criteriaBuilder.sum(resource.get(Resource_.MONTHS_EXPERIENCE),
				criteriaBuilder.prod(resource.get(Resource_.YEARS_EXPERIENCE), criteriaBuilder.literal(12)));
		if (CommonUtil.isValid(resourceSkillsFilterModel.getMinExperience())
				&& CommonUtil.isValid(resourceSkillsFilterModel.getMaxExperience())) {
			criteriaUtil.addPredicates(criteriaBuilder, predicates, sum,
					resourceSkillsFilterModel.getMinExperience() * 12,
					resourceSkillsFilterModel.getMaxExperience() * 12);
		} else if (CommonUtil.isValid(resourceSkillsFilterModel.getMinExperience())
				&& !CommonUtil.isValid(resourceSkillsFilterModel.getMaxExperience())) {
			criteriaUtil.addPredicatesGreaterThenOrEqualTo(criteriaBuilder, predicates, sum,
					resourceSkillsFilterModel.getMinExperience() * 12);
		} else if (!CommonUtil.isValid(resourceSkillsFilterModel.getMinExperience())
				&& CommonUtil.isValid(resourceSkillsFilterModel.getMaxExperience())) {
			criteriaUtil.addPredicatesLessThenOrEqualTo(criteriaBuilder, predicates, sum,
					resourceSkillsFilterModel.getMaxExperience() * 12);
		}
		BigDecimal percentageValue = new BigDecimal(staticConfigurationService.findByName(StaticConfigurationEnum.RESOURCE_COMMISSION).getValue()).divide(new BigDecimal(100));

		if (resourceSkillsFilterModel.getCurrencyTypeEnum()!=null&& resourceSkillsFilterModel.getCurrencyTypeEnum().equals(CurrencyTypeEnum.INR)) {
			if(resourceSkillsFilterModel.getMinRate() != null&&resourceSkillsFilterModel.getMaxRate() != null)
			{
				Expression<BigDecimal> rateAfterCommission = criteriaBuilder.sum(resource.get(Resource_.RATE),
						criteriaBuilder.prod(resource.get(Resource_.RATE), criteriaBuilder.literal(percentageValue))).as(BigDecimal.class);
			criteriaUtil.addPredicatesGreaterThenOrEqualTo(criteriaBuilder, predicates,rateAfterCommission,
					resourceSkillsFilterModel.getMinRate());
			if(!resourceSkillsFilterModel.getIsMaxRate()) {
			criteriaUtil.addPredicatesLessThenOrEqualTo(criteriaBuilder, predicates, rateAfterCommission,
					resourceSkillsFilterModel.getMaxRate());
			}
		
			}
			criteriaUtil.addPredicates(criteriaBuilder, predicates, resource.get(Resource_.RATE_TYPE_ENUM),
					resourceSkillsFilterModel.getRateTypeEnum());
			predicates.add(criteriaBuilder.isNotNull(resource.get(Resource_.RATE)));
			
		}
		else if (resourceSkillsFilterModel.getCurrencyTypeEnum()!=null && resourceSkillsFilterModel.getCurrencyTypeEnum().equals(CurrencyTypeEnum.USD)) {
			if(resourceSkillsFilterModel.getMinRate() != null&&resourceSkillsFilterModel.getMaxRate() != null)
			{
				Expression<BigDecimal> rateAfterCommission = criteriaBuilder.sum(resource.get(Resource_.USD_RATE),
						criteriaBuilder.prod(resource.get(Resource_.USD_RATE), criteriaBuilder.literal(percentageValue))).as(BigDecimal.class);
			criteriaUtil.addPredicatesGreaterThenOrEqualTo(criteriaBuilder, predicates, rateAfterCommission,
					resourceSkillsFilterModel.getMinRate());
			if(!resourceSkillsFilterModel.getIsMaxRate()) {
			criteriaUtil.addPredicatesLessThenOrEqualTo(criteriaBuilder, predicates, rateAfterCommission,
					resourceSkillsFilterModel.getMaxRate());
			}
			
			//predicates.add(criteriaBuilder.isNotNull(resource.get(Resource_.RATE)),rateTypePredicate),
			}
			criteriaUtil.addPredicates(criteriaBuilder, predicates, resource.get(Resource_.USD_RATE_TYPE),
					resourceSkillsFilterModel.getUsdRateTypeEnum());
			predicates.add(criteriaBuilder.isNotNull(resource.get(Resource_.USD_RATE)));
		}
		criteriaUtil.addPredicates(criteriaBuilder, predicates, resource.get(Resource_.GENDER),
				resourceSkillsFilterModel.getGender());
		return predicates;
	}

}
