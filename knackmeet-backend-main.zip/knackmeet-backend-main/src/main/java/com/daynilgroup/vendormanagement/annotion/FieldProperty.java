package com.daynilgroup.vendormanagement.annotion;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 *
 * @author bhavesh
 */
@Target(ElementType.FIELD)
@Retention(RetentionPolicy.RUNTIME)
public @interface FieldProperty {

    int length() default 255;

    /**
     * If true then converts the first character of text to uppercase.
     *
     * @return
     */
    boolean capitalize() default false;

    /**
     * If true then converts the text to uppercase.
     *
     * @return
     */
    boolean uppercase() default false;

    /**
     * If true then converts the text to lowercase.
     *
     * @return
     */
    boolean lowercase() default false;

    /**
     * Specify whether given field should be required
     *
     * @return boolean
     */
    boolean required() default false;
   
    boolean onlyAlphabets() default false;
    
    boolean allowZero() default true;
}