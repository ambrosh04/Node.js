/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.daynilgroup.vendormanagement.security;

import java.util.Date;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.daynilgroup.vendormanagement.constants.Constants;
import com.daynilgroup.vendormanagement.constants.StatusEnum;
import com.daynilgroup.vendormanagement.constants.UserType;
import com.daynilgroup.vendormanagement.entity.User;
import com.daynilgroup.vendormanagement.exception.LoginRestException;
import com.daynilgroup.vendormanagement.helper.UserHelper;
import com.daynilgroup.vendormanagement.model.response.UserResponseModel;
import com.daynilgroup.vendormanagement.request.ReferenceTokenRequest;
import com.daynilgroup.vendormanagement.service.UserService;
import com.daynilgroup.vendormanagement.util.CommonUtil;
import com.daynilgroup.vendormanagement.util.EncryptionDecryptionUtil;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;

/**
 *
 * @author prerana
 */
@Slf4j
@RestController
@RequestMapping("/auth/token")
@FieldDefaults(level = AccessLevel.PRIVATE)
public class JwtAuthenticationController {

	@Autowired
	JwtTokenUtil jwtTokenUtil;

	@Autowired
	UserService userService;

	@Autowired
	UserHelper userHelper;

	@Autowired
	AuthenticationManager authenticationManager;

	@Autowired
	CustomUserDetailService customUserDetailService;

	@Value("${jwt.secret}")
	String secret;

	@PostMapping
	public ResponseEntity<?> createAuthenticationToken(@RequestBody JwtRequest jwtRequest) throws Exception {
		try {
			String username = null;
			User user = userService.findByEmailIdOrMobile(jwtRequest.getUsername());
			if (user != null && (!user.getEmailId().equals(jwtRequest.getUsername())
					|| !user.getEmailId().equals(jwtRequest.getUsername()))) {
				return new ResponseEntity<>(new LoginRestException("Invalid username password"),
						HttpStatus.INTERNAL_SERVER_ERROR);
			}
			if (UserType.ADMIN.equals(user.getUserType())) {
				username = jwtRequest.getUsername() + Constants.SEPERATOR + UserType.ADMIN;
			} else {
				username = jwtRequest.getUsername() + Constants.SEPERATOR + UserType.VENDOR;
			}
			authenticate(username, jwtRequest.getPassword(), true);
			final UserDetails userDetails = customUserDetailService.loadUserByUsername(username);

			UserResponseModel userResponseModel = userHelper.getUserResponseModel(user);
			if (StatusEnum.UNVERIFIED.equals(userResponseModel.getStatus())) {
				userResponseModel.setMessage("Your vendor registration is under review");
				return new ResponseEntity<>(new LoginRestException("Your vendor registration is under review"),
						HttpStatus.INTERNAL_SERVER_ERROR);

			} 
			else if (StatusEnum.EMAIL_PENDING.equals(userResponseModel.getStatus())) {
				userResponseModel.setMessage("Your email is not verified. Please verify your email.");
				return new ResponseEntity<>(new LoginRestException("Your email is not verified. Please verify your email."),
						HttpStatus.INTERNAL_SERVER_ERROR);

			} 
			else if (StatusEnum.REJECTED.equals(userResponseModel.getStatus())) {
				userResponseModel.setMessage("Your vendor registration has been rejected.please check reason on your email.");
				return new ResponseEntity<>(new LoginRestException("Your vendor registration has been rejected.please check reason on your email."),
						HttpStatus.INTERNAL_SERVER_ERROR);

			} 
			else if (StatusEnum.VERIFIED.equals(userResponseModel.getStatus())
					&& Boolean.FALSE.equals(userResponseModel.getActive())) {
				userResponseModel.setMessage("User inactive");
				return new ResponseEntity<>(new JwtResponse("Unauthorized", "Unauthorized", userResponseModel),
						HttpStatus.INTERNAL_SERVER_ERROR);
			}
			final String token = jwtTokenUtil.generateToken(userDetails, 24);
			return ResponseEntity
					.ok(new JwtResponse(token, genrateReferenceToken(user.getEmailId()), userResponseModel));
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			return new ResponseEntity<>(new LoginRestException("Invalid username password"),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	private void authenticate(String username, String password, boolean authenticatePassword) throws Exception {
		Objects.requireNonNull(username);
		Objects.requireNonNull(password);
		try {
			if (authenticatePassword) {
				authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(username, password));
			}
		} catch (DisabledException e) {
			throw new Exception("User Disabled", e);
		} catch (BadCredentialsException e) {
			throw new Exception("Username or Password is Incorrect", e);
		}
	}

	private String genrateReferenceToken(String email) {
		// 3600000 - 1 hourse
		// 86940000 - 24.15 hourse
		return CommonUtil.encodeUrl(EncryptionDecryptionUtil.encrypt(email + "-" + System.currentTimeMillis() + "-"
				+ (System.currentTimeMillis() + 86940000) + "-" + secret));
	}

	@PostMapping(value = "/refreshToken")
	public ResponseEntity<?> getRefreshTokenByUsingReferenceToken(@RequestBody ReferenceTokenRequest request) {
		try {
			String email = validateReferenceToken(request.getReferenceToken(), null);
			User user = userService.findByEmailIdOrMobile(email);
			final UserDetails userDetails = customUserDetailService.loadUserByUsername(email);

			UserResponseModel userResponseModel = userHelper.getUserResponseModel(user);
			if (StatusEnum.UNVERIFIED.equals(userResponseModel.getStatus())) {
				userResponseModel.setMessage("Your vendor registration is under review");
				return new ResponseEntity<>(new LoginRestException("Your vendor registration is under review"),
						HttpStatus.INTERNAL_SERVER_ERROR);

			} else if (StatusEnum.VERIFIED.equals(userResponseModel.getStatus())
					&& Boolean.FALSE.equals(userResponseModel.getActive())) {
				userResponseModel.setMessage("User inactive");
				return new ResponseEntity<>(new JwtResponse("Unauthorized", "Unauthorized", userResponseModel),
						HttpStatus.INTERNAL_SERVER_ERROR);
			}
			final String token = jwtTokenUtil.generateToken(userDetails, 30);
			return ResponseEntity
					.ok(new JwtResponse(token, genrateReferenceToken(user.getEmailId()), userResponseModel));

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e.getMessage());
			return new ResponseEntity<>(new LoginRestException(
					"Sorry We Can't Generate New Token At This Reference Token Because " + e.getLocalizedMessage()),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	private String validateReferenceToken(String referenceToken, Date tokenGenratedData) throws Exception {
		String decrpty = EncryptionDecryptionUtil.decrypt(CommonUtil.decodeUrl(referenceToken));
		String[] data = decrpty.split("-");

		if (data.length != 4 || !data[3].equals(secret))
			throw new Exception("Reference Token Is Not Valid");

//	    	Calendar tokenData = Calendar.getInstance();
//	    	tokenData.setTime(tokenGenratedData);
		//
//	    	Calendar referenceDate = Calendar.getInstance();
//	    	referenceDate.setTime(new Date(Long.valueOf(data[1])));
//	    	
//	    	if(tokenData.get(Calendar.YEAR)   != referenceDate.get(Calendar.YEAR) 
//	    	|| tokenData.get(Calendar.MONTH)  != referenceDate.get(Calendar.MONTH)	
//	    	|| tokenData.get(Calendar.DATE)   != referenceDate.get(Calendar.DATE)	
//	    	|| tokenData.get(Calendar.HOUR)   != referenceDate.get(Calendar.HOUR)	
//	    	|| tokenData.get(Calendar.MINUTE) != referenceDate.get(Calendar.MINUTE)	)
//	    		throw new Exception("Reference Token Is Not Valid");
//	    	
		if (System.currentTimeMillis() > Long.valueOf(data[2]))
			throw new Exception("Reference Token Is Expired");

		return data[0];
	}

}
