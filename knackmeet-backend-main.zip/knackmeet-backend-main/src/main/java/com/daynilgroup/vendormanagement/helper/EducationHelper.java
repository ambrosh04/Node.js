package com.daynilgroup.vendormanagement.helper;

import java.time.LocalDateTime;
import java.util.List;

import org.apache.commons.lang3.ObjectUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.daynilgroup.vendormanagement.constants.CodeLookUpConstant;
import com.daynilgroup.vendormanagement.constants.StatusEnum;
import com.daynilgroup.vendormanagement.entity.CodeLookup;
import com.daynilgroup.vendormanagement.entity.CodeLookupType;
import com.daynilgroup.vendormanagement.entity.Education;
import com.daynilgroup.vendormanagement.entity.Resource;
import com.daynilgroup.vendormanagement.model.response.AdvanceSearchDropdownModel;
import com.daynilgroup.vendormanagement.model.response.EducationDetailResponse;
import com.daynilgroup.vendormanagement.model.response.EducationListResponse;
import com.daynilgroup.vendormanagement.request.EducationRequest;
import com.daynilgroup.vendormanagement.service.CodeLookupService;
import com.daynilgroup.vendormanagement.service.CodeLookupTypeService;
import com.daynilgroup.vendormanagement.service.EducationService;
import com.daynilgroup.vendormanagement.service.ResourceService;
import com.daynilgroup.vendormanagement.util.CommonUtil;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;

@Component
@Lazy
@FieldDefaults(level = AccessLevel.PRIVATE)
public class EducationHelper extends
		AbstractHelper<Education, EducationRequest, EducationListResponse, EducationDetailResponse, EducationDetailAdminResponse> {

	@Autowired
	EducationService educationService;
	@Autowired
	CodeLookupService codeLookupService;
	@Autowired
	CodeLookupTypeService codeLookupTypeService;
	@Autowired
	ResourceService resourceService;

	@Override
	@Transactional(noRollbackFor = Exception.class)
	public Education getEntity(EducationRequest request) throws Exception {

		Education education;
		if (CommonUtil.isValid(request.getId())) {
			education = educationService.findById(request.getId());

		} else {
			education = new Education();
		}

		if (request.getFromMonth()!= null) {
			education.setFromMonth(request.getFromMonth());
		} else {
			throw new Exception("From month could not be null");
		}
		if (request.getFromYear() != null) {
			education.setFromYear(request.getFromYear());
		} else {
			throw new Exception("From year could not be null");
		}
		if (request.getToMonth() != null) {
			education.setToMonth(request.getToMonth());
		} else {
			throw new Exception("To month could not be null");
		}
		if (request.getToYear() != null) {
			education.setToYear(request.getToYear());
		} else {
			throw new Exception("To year could not be null");
		}
		if (request.getSchoolName() != null) {
			education.setSchoolName(request.getSchoolName());
		}else {
			throw new Exception("SCchool name could not be null");
		}

		// specialization
		CodeLookup specialization = null;
		if (!ObjectUtils.isEmpty(request.getSpecialization())) {
			specialization = addCodeLookups(request.getSpecialization(), education, specialization,
					CodeLookUpConstant.SPECIALIZATION_CODELOOKUP_CODE);
			education.setSpecialization(specialization);
		}else {
			throw new Exception("Field of study could not be null");
		}

		// degree
		CodeLookup degree = null;
		if (!ObjectUtils.isEmpty(request.getDegree())) {
			degree = addCodeLookups(request.getDegree(), education, degree, CodeLookUpConstant.DEGREE_CODELOOKUP_CODE);
			education.setDegree(degree);
		}else {
			throw new Exception("Degree could not be null");
		}

		education.setDescription(request.getDescription());
		Resource resource = resourceService.findById(request.getResourceId());
		if(resource.getStatusEnum()==StatusEnum.REJECTED)
		{
			resource.setStatusEnum(StatusEnum.UNVERIFIED);	
		}
		resource.setLastModifiedDate(LocalDateTime.now());
		resourceService.save(resource);
		education.setResource(resource);
		return education;

	}

	private CodeLookup addCodeLookups(AdvanceSearchDropdownModel degreeId, Education education, CodeLookup codeLookup,
			String code) {
		if (CommonUtil.isValid(degreeId.getValue())) {
			codeLookup = codeLookupService.findById(degreeId.getValue());
		} else {
			codeLookup = new CodeLookup();
			codeLookup.setActive(true);
			codeLookup.setDescription(degreeId.getDescription());
			codeLookup.setName(degreeId.getLabel());

			CodeLookupType codeLookupType = codeLookupTypeService.findByCode(code);
			codeLookup.setType(codeLookupType);

			codeLookupService.save(codeLookup);
		}
		return codeLookup;
	}

	@Override
	public List<EducationListResponse> getListResponse(List<Education> educations) {
		
		return null;
	}

	@Override
	public EducationDetailResponse getDetailResponse(Education education) {
		EducationDetailResponse response = new EducationDetailResponse();
		response.setId(education.getId());
		response.setDegree(education.getDegree() != null ? education.getDegree().getName() : null);
		response.setDescription(education.getDescription());
		response.setFromMonth(education.getFromMonth());
		response.setFromYear(education.getFromYear());
		response.setToMonth(education.getToMonth());
		response.setToYear(education.getToYear());
		response.setSchoolName(education.getSchoolName());
		response.setSpecialization(education.getSpecialization() != null ? education.getSpecialization().getName() : null);
		return response;
	}

	@Override
	public EducationDetailAdminResponse getDetailForAdminResponse(Education education) {
		EducationDetailAdminResponse response = new EducationDetailAdminResponse();
		response.setId(education.getId());
		response.setDegree(getValueAndLabel(education.getDegree().getId(), education.getDegree().getName()));
		response.setDescription(education.getDescription());
		response.setFromMonth(education.getFromMonth());
		response.setFromYear(education.getFromYear());
		response.setToMonth(education.getToMonth());
		response.setToYear(education.getToYear());
		response.setSchoolName(education.getSchoolName());
		response.setSpecialization(getValueAndLabel(education.getSpecialization().getId(), education.getSpecialization().getName()));
		return response;
	}
	private AdvanceSearchDropdownModel getValueAndLabel(Long id, String label) {
		return new AdvanceSearchDropdownModel(id, label, null);
	}
}
