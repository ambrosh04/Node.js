package com.daynilgroup.vendormanagement.request.inf;

public interface ImageRequest {
    String getImage();
}
