/**
 * 
 */
package com.daynilgroup.vendormanagement.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;

import com.daynilgroup.vendormanagement.constants.CodeLookUpRelationTypeEnum;
import com.daynilgroup.vendormanagement.constants.RefTypeEnum;
import com.daynilgroup.vendormanagement.entity.CodeLookUpRelation;
import com.daynilgroup.vendormanagement.entity.CodeLookup;
import com.daynilgroup.vendormanagement.model.response.DropdownResponse;
import com.daynilgroup.vendormanagement.model.response.EmailSubscriptionDropDownResponse;
import com.daynilgroup.vendormanagement.repository.CodeLookUpRelationRepository;
import com.daynilgroup.vendormanagement.repository.CodeLookupRepository;
import com.daynilgroup.vendormanagement.service.CodeLookUpRelationService;
import com.daynilgroup.vendormanagement.service.CodeLookupService;
import com.daynilgroup.vendormanagement.service.VendorService;
import com.daynilgroup.vendormanagement.util.CommonUtil;
import com.daynilgroup.vendormanagement.util.EntityUtil;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;

/**
 * @author Prerana
 *
 */
@Service
@FieldDefaults(level = AccessLevel.PRIVATE)
public class CodeLookupServiceImpl implements CodeLookupService {

	@Autowired
	CodeLookupRepository codeLookupRepository;
	
	@Autowired
	CodeLookUpRelationService CodeLookUpRelationService;
	
	@Autowired
	VendorService vendorService;
	
	@Autowired
	EntityUtil entityUtil;
	
	@Autowired
	CodeLookUpRelationRepository codeLookUpRelationRepository;

	@Override
	public JpaRepository<CodeLookup, Long> getJpaRepository() {
		return codeLookupRepository;
	}

	@Override
	public Boolean existsByNameAndTypeIdAndIdNot(String name, Long typeId, Long id) {
		return codeLookupRepository.existsByNameAndTypeIdAndIdNot(name, typeId, id);
	}

	@Override
	public Page<CodeLookup> getAllCodeLookupType(Pageable pageable) {
		return codeLookupRepository.findByDeletedFalseOrDeletedIsNull(pageable);
	}

	@Override
	public void deleteById(Long id) {
		codeLookupRepository.delete(id);
	}

	@Override
	public List<CodeLookup> getByTypeCode(String code,String name) {
		return codeLookupRepository.getByType_codeAndNameLikeOrNameIsNullAndActiveTrueAndDeletedFalseOrDeletedIsNull(code,name);
	}

	@Override
	public Page<CodeLookup> getByTypeCode(String code, Pageable pageable) {
		return codeLookupRepository.getByType_codeAndActiveTrueAndDeletedFalseOrDeletedIsNull(code, pageable);
	}

	@Override
	public Page<CodeLookup> searchByName(String name, Long typeId, Pageable pageable) {
		if (typeId != null) {
			return codeLookupRepository.findByNameContainsAndTypeIdAndDeletedFalseOrDeletedIsNull(name, typeId,
					pageable);
		}
		return codeLookupRepository.findByNameContainsAndDeletedFalseOrDeletedIsNull(name, pageable);
	}

	@Override
	public List<DropdownResponse> getSkills(String code1, String code2) {
		List<DropdownResponse> dropdownResponses = new ArrayList<>();

		codeLookupRepository.getByType_codeAndType_codeAndActiveTrueAndDeletedFalseOrDeletedIsNull(code1, code2)
				.forEach(skill -> {
					dropdownResponses.add(new DropdownResponse(skill.getId(), skill.getName()));
				});
		return dropdownResponses;
	}

	@Override
	public List<DropdownResponse> getAllCodeLookUpByCodeAndParentId(String code, Long parentId) {
		List<DropdownResponse> dropdownResponses = new ArrayList<>();
		List<CodeLookup> codeLookups;
		if (CommonUtil.isValid(parentId)) {
			codeLookups = codeLookupRepository.findAllByCodeAndParentId(code, parentId);
		} else {
			codeLookups = codeLookupRepository.getByType_codeAndActiveTrueAndDeletedFalseOrDeletedIsNull(code);
		}

		codeLookups.stream().forEach(
				codeLookup -> dropdownResponses.add(new DropdownResponse(codeLookup.getId(), codeLookup.getName())));

		return dropdownResponses;
	}

	@Override
	public List<DropdownResponse> getByTypeCodeAndDeletedFalseOrDeletedIsNull(String code) {
		List<DropdownResponse> dropdownResponses = new ArrayList<>();
		
		 codeLookupRepository.getByTypeCodeAndDeletedFalseOrDeletedIsNull(code).forEach(type -> {
			dropdownResponses.add(new DropdownResponse(type.getId(), type.getName()));
		});
		 return dropdownResponses;
	}

	@Override
	public List<EmailSubscriptionDropDownResponse> findByTypeCodeAndDeletedFalseOrDeletedIsNull(String code) {
		List<EmailSubscriptionDropDownResponse> dropdownResponses = new ArrayList<>();
		List<CodeLookUpRelation> relation = codeLookUpRelationRepository.findByRefIdAndRefTypeAndType(entityUtil.getCurrentVendorId(), RefTypeEnum.VENDOR, CodeLookUpRelationTypeEnum.SUBSCRIBE_FOR_EMAIL_NOTIFICATION);	
		if(relation.size()==0) {
			 codeLookupRepository.getByTypeCodeAndDeletedFalseOrDeletedIsNull(code).forEach(type -> {
				dropdownResponses.add(new EmailSubscriptionDropDownResponse(type.getId(), type.getName(),true));
				
			});
			 return dropdownResponses;
		}
		for(CodeLookUpRelation Coderelation:relation) {
			dropdownResponses.add(new EmailSubscriptionDropDownResponse(Coderelation.getCodeLookup().getId(), Coderelation.getCodeLookup().getName(),Coderelation.getActive()));
			
		}
		 return dropdownResponses;
	}
}
