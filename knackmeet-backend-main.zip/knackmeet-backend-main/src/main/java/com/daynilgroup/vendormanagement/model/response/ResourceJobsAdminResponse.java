package com.daynilgroup.vendormanagement.model.response;

public class ResourceJobsAdminResponse {

}
