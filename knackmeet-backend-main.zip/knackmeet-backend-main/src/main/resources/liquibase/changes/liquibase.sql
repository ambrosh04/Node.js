--liquibase formatted sql
 
--changeset 15/03/2021 Prerana-Table Creation:prerana-1

--
-- Table structure for table `address`
--

create table address (
  id bigint not null auto_increment, 
  active bit, 
  created_on datetime, 
  deleted bit default 0, 
  status varchar(255), 
  updated_on datetime, 
  created_by bigint, 
  updated_by bigint, 
  city_id bigint not null, 
  country_id bigint not null, 
  state_id bigint not null, 
  primary key (id)
) engine = InnoDB; 

----------------------------------------------------------

--
-- Table structure for table `code_lookup`
-- 

create table code_lookup (
  id bigint not null auto_increment, 
  active bit, 
  created_on datetime, 
  deleted bit default 0, 
  status varchar(255), 
  updated_on datetime, 
  description varchar(255), 
  display_order integer, 
  name varchar(255), 
  created_by bigint, 
  updated_by bigint, 
  image_id bigint, 
  parent_id bigint, 
  type_id bigint not null, 
  primary key (id)
) engine = InnoDB;
 
 -- --------------------------------------------------------

--
-- Table structure for table `code_lookup_type`
--

create table code_lookup_type (
  id bigint not null auto_increment, 
  active bit, 
  created_on datetime, 
  deleted bit default 0, 
  status varchar(255), 
  updated_on datetime, 
  code varchar(255), 
  cover_img_require bit default 0 not null, 
  deletable bit default 1 not null, 
  editable bit default 1 not null, 
  name varchar(255), 
  created_by bigint, 
  updated_by bigint, 
  parent_id bigint, 
  primary key (id)
) engine = InnoDB;

-- --------------------------------------------------------

--
-- Table structure for table `job`
--

create table job (
  id bigint not null auto_increment, 
  active bit, 
  created_on datetime, 
  deleted bit default 0, 
  status varchar(255), 
  updated_on datetime, 
  currency_type varchar(255), 
  description longtext not null, 
  job_no varchar(255), 
  job_type varchar(255) not null, 
  max_experience integer not null, 
  max_rate decimal(19, 2) not null, 
  min_experience integer not null, 
  min_rate decimal(19, 2) not null, 
  no_of_resources integer not null, 
  rate_type varchar(255) not null, 
  start_date datetime, 
  title varchar(255) not null, 
  work_from varchar(255) not null, 
  created_by bigint, 
  updated_by bigint, 
  category_id bigint not null, 
  city_id bigint not null, 
  duration_id bigint not null, 
  vendor_id bigint not null, 
  primary key (id)
) engine = InnoDB;
 
-- --------------------------------------------------------

--
-- Table structure for table `media`
--
 
create table media (
  id bigint not null auto_increment, 
  media_type varchar(255), 
  path varchar(255) not null, 
  primary key (id)
) engine = InnoDB;
 
-- --------------------------------------------------------

--
-- Table structure for table `menu`
--
 
create table menu (
  id bigint not null auto_increment, 
  active bit, 
  created_on datetime, 
  deleted bit default 0, 
  status varchar(255), 
  updated_on datetime, 
  actions varchar(255), 
  code varchar(255), 
  display_order integer not null, 
  icon varchar(255), 
  master_menu bit, 
  title varchar(255), 
  url_path varchar(255), 
  created_by bigint, 
  updated_by bigint, 
  parent_id bigint, 
  primary key (id)
) engine = InnoDB;

-- --------------------------------------------------------

--
-- Table structure for table `resource`
--

create table resource (
  id bigint not null auto_increment, 
  active bit, 
  created_on datetime, 
  deleted bit default 0, 
  status varchar(255), 
  updated_on datetime, 
  currency_type varchar(255), 
  deploymen_type varchar(255) not null, 
  description longtext, 
  first_name varchar(255), 
  gender varchar(255) not null, 
  higher_education varchar(255), 
  last_name varchar(255), 
  middle_name varchar(255), 
  months_experience integer, 
  passing_year bigint, 
  r_id varchar(255), 
  rate decimal(19, 2) not null, 
  rate_type varchar(255) not null, 
  resource_status varchar(255), 
  years_experience integer, 
  created_by bigint, 
  updated_by bigint, 
  address_id bigint not null, 
  availability_id bigint not null, 
  category_id bigint not null, 
  designation_id bigint not null, 
  profile_photo_id bigint, 
  resume_id bigint, 
  vendor_id bigint not null, 
  primary key (id)
) engine = InnoDB;

-- --------------------------------------------------------

--
-- Table structure for table `resource_jobs`
--

create table resource_jobs (
  id bigint not null auto_increment, 
  active bit, 
  created_on datetime, 
  deleted bit default 0, 
  status varchar(255), 
  updated_on datetime, 
  reason_message varchar(255), 
  resource_status varchar(255) not null, 
  created_by bigint, 
  updated_by bigint, 
  job_id bigint not null, 
  resource_id bigint not null, 
  primary key (id)
) engine = InnoDB;
 
-- --------------------------------------------------------

--
-- Table structure for table `resource_skills_code_lookup`
--
 
create table resource_skills_code_lookup (
  id bigint not null auto_increment, 
  active bit, 
  created_on datetime, 
  deleted bit default 0, 
  status varchar(255), 
  updated_on datetime, 
  created_by bigint, 
  updated_by bigint, 
  code_lookup_id bigint not null, 
  resource_id bigint not null, 
  primary key (id)
) engine = InnoDB;
 
-- --------------------------------------------------------

--
-- Table structure for table `role`
--
 
create table role (
  id bigint not null auto_increment, 
  active bit, 
  created_on datetime, 
  deleted bit default 0, 
  status varchar(255), 
  updated_on datetime, 
  name varchar(255) not null, 
  type varchar(255) not null, 
  created_by bigint, 
  updated_by bigint, 
  primary key (id)
) engine = InnoDB;
 
-- --------------------------------------------------------

--
-- Table structure for table `role_access`
--
 
create table role_access (
  id bigint not null auto_increment, 
  active bit, 
  created_on datetime, 
  deleted bit default 0, 
  status varchar(255), 
  updated_on datetime, 
  accesss varchar(255), 
  created_by bigint, 
  updated_by bigint, 
  menu_id bigint not null, 
  role_id bigint not null, 
  primary key (id)
) engine = InnoDB;
 
-- --------------------------------------------------------

--
-- Table structure for table `skills_code_lookup`
--
 
create table skills_code_lookup (
  id bigint not null auto_increment, 
  active bit, 
  created_on datetime, 
  deleted bit default 0, 
  status varchar(255), 
  updated_on datetime, 
  created_by bigint, 
  updated_by bigint, 
  code_lookup_id bigint not null, 
  job_id bigint not null, 
  primary key (id)
) engine = InnoDB;
 
-- --------------------------------------------------------

--
-- Table structure for table `user`
--
 
create table user (
  id bigint not null auto_increment, 
  active bit, 
  created_on datetime, 
  deleted bit default 0, 
  status varchar(255), 
  updated_on datetime, 
  email_id varchar(255), 
  first_name varchar(255), 
  forgot_password_token varchar(255), 
  last_name varchar(255), 
  mobile varchar(255) not null, 
  password varchar(255) not null, 
  user_type varchar(255) not null, 
  created_by bigint, 
  updated_by bigint, 
  primary key (id)
) engine = InnoDB;

-- --------------------------------------------------------

--
-- Table structure for table `user_role`
--

create table user_role (
  id bigint not null auto_increment, 
  active bit, 
  created_on datetime, 
  deleted bit default 0, 
  status varchar(255), 
  updated_on datetime, 
  created_by bigint, 
  updated_by bigint, 
  role_id bigint not null, 
  user_id bigint not null, 
  primary key (id)
) engine = InnoDB;

-- --------------------------------------------------------

--
-- Table structure for table `vendor`
--

create table vendor (
  id bigint not null auto_increment, 
  active bit, 
  created_on datetime, 
  deleted bit default 0, 
  status varchar(255), 
  updated_on datetime, 
  agency_name varchar(255) not null, 
  incorparation_date date not null, 
  team_strength bigint, 
  website varchar(255) not null, 
  created_by bigint, 
  updated_by bigint, 
  user_id bigint not null, 
  vendor_logo bigint, 
  primary key (id)
) engine = InnoDB;
 
 
--
-- Indexes for dumped tables
--

 alter table code_lookup_type add constraint UK_7da0h5u4516mgc3ebb6w405g4 unique (code);
 alter table code_lookup_type add constraint UK_nw3hidi89vy20jb02rnt9v2qi unique (name);
 
 alter table user add constraint UK_r9kvst217faqa7vgeyy51oos0 unique (email_id);
 alter table user add constraint UK_cnjwxx5favk5ycqajjt17fwy1 unique (mobile);
 
 alter table address add constraint FKrlw2kp5269kf4u4umjvm0jw5d foreign key (created_by) references user (id);
 alter table address add constraint FKsg1mbednky51jt5tlitqqqrnf foreign key (updated_by) references user (id);
 alter table address add constraint FKt66kfah3i39m4d3gtetl3srh6 foreign key (city_id) references code_lookup (id);
 alter table address add constraint FKxuol017egf2ty7ncti1vpbs foreign key (country_id) references code_lookup (id);
 alter table address add constraint FKkx4osgd66121m3fddp485k6o7 foreign key (state_id) references code_lookup (id);
 
 alter table code_lookup add constraint FKdivkdwjgsfd6w072swqtr19e5 foreign key (created_by) references user (id);
 alter table code_lookup add constraint FKdd48fklvwc1u8twkkabmivxa5 foreign key (updated_by) references user (id);
 alter table code_lookup add constraint FKgxy760okn8i94euspfjep16gj foreign key (image_id) references media (id);
 alter table code_lookup add constraint FK3cienibairvadjxuslr1lire9 foreign key (parent_id) references code_lookup (id);
 alter table code_lookup add constraint FK74xoghkroqvrigtqb0p6ocvar foreign key (type_id) references code_lookup_type (id);
 
 alter table code_lookup_type add constraint FKtd6kantsft3yfiqt7v6rnmmlo foreign key (created_by) references user (id);
 alter table code_lookup_type add constraint FK4mwtx8yra9a3iqi677opafx05 foreign key (updated_by) references user (id);
 alter table code_lookup_type add constraint FKoqvhib6g126t8johb6g7vsg3 foreign key (parent_id) references code_lookup_type (id);
 
 alter table job add constraint FK3h3hl6lg6pr15j0milryj4chl foreign key (created_by) references user (id);
 alter table job add constraint FK2wk11ynt30uuug5vpqjwntpcf foreign key (updated_by) references user (id);
 alter table job add constraint FKexgx3mxhoafpvrhrfiq249isn foreign key (category_id) references code_lookup (id);
 alter table job add constraint FKekhvqnsefoml4tjury6p0vjky foreign key (city_id) references code_lookup (id);
 alter table job add constraint FK4vqa32es5paqoqe6b0twmq200 foreign key (duration_id) references code_lookup (id);
 alter table job add constraint FKjgcorf6qcf1kf87nn7psl86so foreign key (vendor_id) references vendor (id);
 
 alter table menu add constraint FK6nhy5jbkm9tslw5oa0atir0ee foreign key (created_by) references user (id);
 alter table menu add constraint FKihw9v6m15nsf7w6w4gn9jhepd foreign key (updated_by) references user (id);
 alter table menu add constraint FKgeupubdqncc1lpgf2cn4fqwbc foreign key (parent_id) references menu (id);
 
 alter table resource add constraint FKh9ky7udr66y3r3tfnyqssxf7a foreign key (created_by) references user (id);
 alter table resource add constraint FKc6scquntnscvk3ex7fedtn6ob foreign key (updated_by) references user (id);
 alter table resource add constraint FKfrpw90xv8cksarwym1oga4hqg foreign key (address_id) references address (id);
 alter table resource add constraint FKk684a6kws3ngpujtko59dvgrx foreign key (availability_id) references code_lookup (id);
 alter table resource add constraint FKjgupskuc82gm4tiqejidy9tg5 foreign key (category_id) references code_lookup (id);
 alter table resource add constraint FKgfy4glhndopwmc91pesbm1cti foreign key (designation_id) references code_lookup (id);
 alter table resource add constraint FK6mwyhxav4hoef4esev8u1uwx3 foreign key (profile_photo_id) references media (id);
 alter table resource add constraint FKo5lxx4kxul797u08lpojqc6k9 foreign key (resume_id) references media (id);
 alter table resource add constraint FKsjk8emeu24l1ofy4uod24durn foreign key (vendor_id) references vendor (id);
 
 alter table resource_jobs add constraint FKnvrio0rl667kbnuthphmqiui6 foreign key (created_by) references user (id);
 alter table resource_jobs add constraint FK7qkr2hq1giqadedyqyfe6urtv foreign key (updated_by) references user (id);
 alter table resource_jobs add constraint FKd8h8cl91hgfncl6p2fhx9m4fl foreign key (job_id) references job (id);
 alter table resource_jobs add constraint FK6o2aj50r99cjuf72xv02651ha foreign key (resource_id) references resource (id);
 
 alter table resource_skills_code_lookup add constraint FK815s9wm8uqgibiolpc2ty2f98 foreign key (created_by) references user (id);
 alter table resource_skills_code_lookup add constraint FKbukal18nljd84b2ncxhavxf5d foreign key (updated_by) references user (id);
 alter table resource_skills_code_lookup add constraint FK385lvsi6vvn5pklijejkch0bj foreign key (code_lookup_id) references code_lookup (id);
 alter table resource_skills_code_lookup add constraint FKb4bsw94va6s02jvsmts4h9hlv foreign key (resource_id) references resource (id);
 
 alter table role add constraint FKmjdbaf04ao0egch74ttawr9fo foreign key (created_by) references user (id);
 alter table role add constraint FKa5cffmyctb0862coj304faenx foreign key (updated_by) references user (id);
 
 alter table role_access add constraint FK1kc4wfktcpe45y38r3lw5p559 foreign key (created_by) references user (id);
 alter table role_access add constraint FKk6ucgb8ywe7u4aj06ctotm7ma foreign key (updated_by) references user (id);
 alter table role_access add constraint FKa7qdwsvueclwptgphamymfmf foreign key (menu_id) references menu (id);
 alter table role_access add constraint FKtieafqolqa48hq93xuaj7wp7q foreign key (role_id) references role (id);
 
 alter table skills_code_lookup add constraint FKt3oq1cub665vcqhorxebqr8ys foreign key (created_by) references user (id);
 alter table skills_code_lookup add constraint FKeivwdslj7e1hvrox7m0ypqw51 foreign key (updated_by) references user (id);
 alter table skills_code_lookup add constraint FKihg1ga5evx53k8ws64od60a6v foreign key (code_lookup_id) references code_lookup (id);
 alter table skills_code_lookup add constraint FKmv8pyyuiybdcxxjlr652ypdmg foreign key (job_id) references job (id);
 
 alter table user add constraint FKdltbr5t0nljpuuo4isxgslt82 foreign key (created_by) references user (id);
 alter table user add constraint FK2a54xhceitopkkw1hlo3tkv3i foreign key (updated_by) references user (id);
 
 alter table user_role add constraint FK31tbjydiq4ue62gty4lvugqoo foreign key (created_by) references user (id);
 alter table user_role add constraint FKrfc70mtebex36dvorkfyxqpua foreign key (updated_by) references user (id);
 alter table user_role add constraint FKa68196081fvovjhkek5m97n3y foreign key (role_id) references role (id);
 alter table user_role add constraint FK859n2jvi8ivhui0rl0esws6o foreign key (user_id) references user (id);
 
 alter table vendor add constraint FKh1peaqq14vrygar0817m63khj foreign key (created_by) references user (id);
 alter table vendor add constraint FKk40u3x7mgxdgoawx61hie6ufh foreign key (updated_by) references user (id);
 alter table vendor add constraint FKdd7gkhbeyh4y81hu5hp21ww5o foreign key (user_id) references user (id);
 alter table vendor add constraint FKpw2fps82x72t9e0aljs8swpbq foreign key (vendor_logo) references media (id);
 
 --changeset 15/03/2021 Prerana-Default Data:prerana-2
INSERT INTO `code_lookup_type` (`id`, `active`, `created_on`, `deleted`, `status`, `code`, `cover_img_require`, `deletable`, `editable`, `name`, `parent_id`)
 VALUES (1, true,'2023-03-15 14:00:04', false, 'VERIFIED', 'SKILLS', false, false, false, 'Skills',  null),
 (2, true, '2023-03-15 14:00:04', false, 'VERIFIED', 'DESIGNATION', false, false, false, 'Designation', null),
 (3, true, '2023-03-15 14:00:04', false, 'VERIFIED', 'AVABILITY', false, false, false, 'Availability',  null),
 (4, true, '2023-03-15 14:00:04', false, 'VERIFIED', 'CATAGEORY', false, false, false, 'Category',  null),
 (5, true, '2023-03-15 14:00:04', false, 'VERIFIED', 'DURATION', false, false, false, 'Duration', null),
 (6, true, '2023-03-15 14:00:04', false, 'VERIFIED', 'COUNTRY', false, false, false, 'Country', null),
 (7, true, '2023-03-15 14:00:04', false, 'VERIFIED', 'STATE', false, false, false, 'State',  6),
 (8, true, '2023-03-15 14:00:04', false, 'VERIFIED', 'CITY', false, false, false, 'City', 7);
 
 
INSERT INTO `code_lookup` (`id`, `active`, `created_on`, `deleted`, `status`, `description`, `display_order`, `name`, `image_id`, `parent_id`, `type_id`)
VALUES(1, TRUE,'2023-03-15 14:00:04', FALSE, 'VERIFIED', 'India', null, 'India', null, null, 6),
(2,TRUE,'2023-03-15 14:00:04',FALSE,'VERIFIED','Andhra Pradesh',null,'Andhra Pradesh',null,1,7),
(3,TRUE,'2023-03-15 14:00:04',FALSE,'VERIFIED','Arunachal Pradesh',null,'Arunachal Pradesh',null,1,7),
(4,TRUE,'2023-03-15 14:00:04',FALSE,'VERIFIED','Assam',null,'Assam',null,1,7),
(5,TRUE,'2023-03-15 14:00:04',FALSE,'VERIFIED','Bihar',null,'Bihar',null,1,7),
(6,TRUE,'2023-03-15 14:00:04',FALSE,'VERIFIED','Chhattisgarh',null,'Chhattisgarh',null,1,7),
(7,TRUE,'2023-03-15 14:00:04',FALSE,'VERIFIED','Goa',null,'Goa',null,1,7),
(8,TRUE,'2023-03-15 14:00:04',FALSE,'VERIFIED','Gujarat',null,'Gujarat',null,1,7),
(9,TRUE,'2023-03-15 14:00:04',FALSE,'VERIFIED','Haryana',null,'Haryana',null,1,7),
(10,TRUE,'2023-03-15 14:00:04',FALSE,'VERIFIED','Himachal Pradesh',null,'Himachal Pradesh',null,1,7),
(11,TRUE,'2023-03-15 14:00:04',FALSE,'VERIFIED','Jharkhand',null,'Jharkhand',null,1,7),
(12,TRUE,'2023-03-15 14:00:04',FALSE,'VERIFIED','Karnataka',null,'Karnataka',null,1,7),
(13,TRUE,'2023-03-15 14:00:04',FALSE,'VERIFIED','Kerala',null,'Kerala',null,1,7),
(14,TRUE,'2023-03-15 14:00:04',FALSE,'VERIFIED','Madhya Pradesh',null,'Madhya Pradesh',null,1,7),
(15,TRUE,'2023-03-15 14:00:04',FALSE,'VERIFIED','Maharashtra',null,'Maharashtra',null,1,7),
(16,TRUE,'2023-03-15 14:00:04',FALSE,'VERIFIED','Manipur',null,'Manipur',null,1,7),
(17,TRUE,'2023-03-15 14:00:04',FALSE,'VERIFIED','Meghalaya',null,'Meghalaya',null,1,7),
(18,TRUE,'2023-03-15 14:00:04',FALSE,'VERIFIED','Mizoram',null,'Mizoram',null,1,7),
(19,TRUE,'2023-03-15 14:00:04',FALSE,'VERIFIED','Nagaland',null,'Nagaland',null,1,7),
(20,TRUE,'2023-03-15 14:00:04',FALSE,'VERIFIED','Odisha',null,'Odisha',null,1,7),
(21,TRUE,'2023-03-15 14:00:04',FALSE,'VERIFIED','Punjab',null,'Punjab',null,1,7),
(22,TRUE,'2023-03-15 14:00:04',FALSE,'VERIFIED','Rajasthan',null,'Rajasthan',null,1,7),
(23,TRUE,'2023-03-15 14:00:04',FALSE,'VERIFIED','Sikkim',null,'Sikkim',null,1,7),
(24,TRUE,'2023-03-15 14:00:04',FALSE,'VERIFIED','Tamil Nadu',null,'Tamil Nadu',null,1,7),
(25,TRUE,'2023-03-15 14:00:04',FALSE,'VERIFIED','Telangana',null,'Telangana',null,1,7),
(26,TRUE,'2023-03-15 14:00:04',FALSE,'VERIFIED','Tripura',null,'Tripura',null,1,7),
(27,TRUE,'2023-03-15 14:00:04',FALSE,'VERIFIED','Uttar Pradesh',null,'Uttar Pradesh',null,1,7),
(28,TRUE,'2023-03-15 14:00:04',FALSE,'VERIFIED','Uttarakhand',null,'Uttarakhand',null,1,7),
(29,TRUE,'2023-03-15 14:00:04',FALSE,'VERIFIED','West Bengal',null,'West Bengal',null,1,7),
(30,TRUE,'2023-03-15 14:00:04',FALSE,'VERIFIED','Andaman and Nicobar Islands',null,'Andaman and Nicobar Islands',null,1,7),
(31,TRUE,'2023-03-15 14:00:04',FALSE,'VERIFIED','Chandigarh',null,'Chandigarh',null,1,7),
(32,TRUE,'2023-03-15 14:00:04',FALSE,'VERIFIED','Dadra & Nagar Haveli and Daman & Diu',null,'Dadra & Nagar Haveli and Daman & Diu',null,1,7),
(33,TRUE,'2023-03-15 14:00:04',FALSE,'VERIFIED','Delhi',null,'Delhi',null,1,7),
(34,TRUE,'2023-03-15 14:00:04',FALSE,'VERIFIED','Jammu and Kashmir',null,'Jammu and Kashmir',null,1,7),
(35,TRUE,'2023-03-15 14:00:04',FALSE,'VERIFIED','Lakshadweep',null,'Lakshadweep',null,1,7),
(36,TRUE,'2023-03-15 14:00:04',FALSE,'VERIFIED','Puducherry',null,'Puducherry',null,1,7),
(37,TRUE,'2023-03-15 14:00:04',FALSE,'VERIFIED','Ladakh',null,'Ladakh',null,1,7);

--changeset 17/03/2021 Prerana:prerana-3
 alter table job add column applicants_count int NOT NULL DEFAULT '0';
 alter table resource add column applied_job_count int NOT NULL DEFAULT '0';

 --changeset 17/03/2021 Prerana:prerana-4
UPDATE `code_lookup_type` SET `code` = 'AVAILABILITY' WHERE (`id` = '3');
UPDATE `code_lookup_type` SET `code` = 'CATEGORY' WHERE (`id` = '4');

--changeset 17/03/2023 Mansingh:mansingh-5
 ALTER TABLE job ADD COLUMN address_id BIGINT;
 ALTER table job add constraint  foreign key (address_id) references address (id);
 ALTER TABLE job DROP FOREIGN KEY `FKekhvqnsefoml4tjury6p0vjky`;
 ALTER TABLE job DROP COLUMN city_id;
 
  --changeset 21/03/2023 Prerana:prerana-5
ALTER TABLE vendor ADD COLUMN gst_number varchar(255);
 
ALTER TABLE user ADD COLUMN phone_code_id BIGINT;
ALTER TABLE user ADD CONSTRAINT FK_user_phone_code FOREIGN KEY (phone_code_id) REFERENCES code_lookup (id);

--changeset 21/03/2023 Prerana:prerana-6
INSERT INTO `code_lookup_type` (`id`, `active`, `created_on`, `deleted`, `status`, `code`, `cover_img_require`, `deletable`, `editable`, `name`, `parent_id`)
VALUES (9, true,'2023-03-21 14:00:04', false, 'VERIFIED', 'PHONE-CODE', false, false, false, 'Phone Code',  null);
 
INSERT INTO `code_lookup` (`id`, `active`, `created_on`, `deleted`, `status`, `description`, `display_order`, `name`, `image_id`, `parent_id`, `type_id`)
VALUES(38, TRUE,'2023-03-21 14:00:04', FALSE, 'VERIFIED', '+91', null, '+91', null, 1, 9);

--changeset 22/03/2023 Shivendra:shivendra-7
ALTER TABLE vendor ADD COLUMN director_name varchar(50);
ALTER TABLE vendor ADD COLUMN address_id BIGINT;
ALTER TABLE vendor ADD CONSTRAINT FK_vendor_address FOREIGN KEY (address_id) REFERENCES address (id);

--changeset 23/03/2023 Prerana:prerana-7
INSERT INTO `user` (`id`, `active`, `created_on`, `deleted`, `email_id`, `first_name`, `last_name`, `mobile`, `password`, `user_type`, `phone_code_id`) 
VALUES ('1', TRUE, '2023-03-23 14:41:43', FALSE, 'admin@gmail.com', 'Deepak', 'Thapa', '7666274732', '$2a$10$mkxoV4W.AbV2klDlYuGuuueeGA0FmWFi.r1HjLL3Hjpc.WSg0TFay', 'ADMIN', '38');

INSERT INTO `vendor` (`id`, `active`, `created_on`, `deleted`, `status`, `agency_name`, `incorparation_date`, `team_strength`, `website`, `user_id`, `vendor_logo`, `gst_number`) 
VALUES ('1', TRUE, '2023-03-23 14:41:43', FALSE, 'VERIFIED', 'Daynil Group Solutions Pvt Ltd', '2023-03-23', null, " ", '1', null, null);

--changeset 23/03/2023 Prerana:prerana-8
 ALTER TABLE vendor DROP FOREIGN KEY `FK_vendor_address`;
 ALTER TABLE vendor DROP COLUMN address_id;
 
 ALTER TABLE vendor ADD COLUMN location varchar(50);
 
--changeset 29/03/2023 Manish:Manish-9
create table search_history (id bigint not null auto_increment, 
city_id bigint, country_id bigint, date datetime, 
deleted bit default 0, 
job_search_in_type_enum varchar(255),
max_exp integer, min_exp integer, 
resource_search_in_enum varchar(255), 
search_in varchar(255), 
search_type varchar(255), 
state_id bigint, 
vendor_id bigint not null, 
primary key (id)) engine=InnoDB;

--changeset 29/03/2023 Manish:Manish-10
create table search_history_keyword (search_history_id bigint not null, 
keywords varchar(255)) engine=InnoDB;
  
--changeset 04/04/2023 Prachi:Prachi-11
alter table vendor add column proof_of_identity bigint

--changeset 04/04/2023 Prachi:Prachi-12
alter table vendor add column proof_of_registration bigint

--changeset 04/04/2023 Prachi:Prachi-13
alter table vendor add constraint FKba1abjr5lh59pmrl0n263wnhw foreign key (proof_of_identity) references media (id)

--changeset 04/04/2023 Prachi:Prachi-14
alter table vendor add constraint FK700e24hqq0rbku4u5btxive5e foreign key (proof_of_registration) references media (id)
  
--changeset 04/04/2023 Mansingh:Mansingh-15
  ALTER TABLE search_history ADD keyward_json Json;

--changeset 04/04/2023 Mansingh:Mansingh-16
 DROP TABLE `search_history_keyword`;
 
--changeset 18/04/2023 Mansingh:Mansingh-17
alter table resource add column name varchar(100);

--changeset 19/04/2023 Manish:Manish-18
CREATE TABLE `support` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `active` bit(1) DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `deleted` bit(1) DEFAULT b'0',
  `status` varchar(255) DEFAULT NULL,
  `updated_on` datetime DEFAULT NULL,
  `description` longtext NOT NULL,
  `heading` longtext NOT NULL,
  `support_status` varchar(255) NOT NULL,
  `ticket_id` varchar(255) DEFAULT NULL,
  `vendor_id` bigint DEFAULT NULL,
  `created_by` bigint DEFAULT NULL,
  `updated_by` bigint DEFAULT NULL,
  `attachment_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKt75ed42x2ltakmrt3cn64rox1` (`created_by`),
  KEY `FKl1yomsvlxsjsomo7fmi7qvrf4` (`updated_by`),
  KEY `FKiiagfrfdd26dqy0mwp2xkex2n` (`attachment_id`),
  CONSTRAINT `FKiiagfrfdd26dqy0mwp2xkex2n` FOREIGN KEY (`attachment_id`) REFERENCES `media` (`id`),
  CONSTRAINT `FKl1yomsvlxsjsomo7fmi7qvrf4` FOREIGN KEY (`updated_by`) REFERENCES `user` (`id`),
  CONSTRAINT `FKt75ed42x2ltakmrt3cn64rox1` FOREIGN KEY (`created_by`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--changeset 25/04/2023 Shivendra:Shivendra-19
 CREATE TABLE `revinfo` (
  `rev` int NOT NULL AUTO_INCREMENT,
  `revtstmp` bigint DEFAULT NULL,
  PRIMARY KEY (`rev`)
) ENGINE=InnoDB;

 CREATE TABLE `message_template` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `message` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB;

 CREATE TABLE `message_template_aud` (
  `id` bigint NOT NULL,
  `rev` int NOT NULL,
  `revtype` tinyint DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`,`rev`),
  KEY `FKxfkyqvfwij048i81ci8mgl3s` (`rev`),
  CONSTRAINT `FKxfkyqvfwij048i81ci8mgl3s` FOREIGN KEY (`rev`) REFERENCES `revinfo` (`rev`)
) ENGINE=InnoDB;

 CREATE TABLE `event` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `created_on` datetime DEFAULT NULL,
  `deleted` bit(1) DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  `event_type` varchar(255) NOT NULL,
  `hyperlinks` varchar(255) DEFAULT NULL,
  `json_data` varchar(255) DEFAULT NULL,
  `meta_data` varchar(255) DEFAULT NULL,
  `scheduled` bit(1) DEFAULT NULL,
  `start_date` datetime DEFAULT NULL,
  `users_to_notify` varchar(255) DEFAULT NULL,
  `visible_to_all` bit(1) DEFAULT NULL,
  `template_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKq8kxxx5rs1smxdtx1ql1mstai` (`template_id`),
  CONSTRAINT `FKq8kxxx5rs1smxdtx1ql1mstai` FOREIGN KEY (`template_id`) REFERENCES `message_template` (`id`)
);

 CREATE TABLE `event_aud` (
  `id` bigint NOT NULL,
  `rev` int NOT NULL,
  `revtype` tinyint DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `deleted` bit(1) DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  `event_type` varchar(255) DEFAULT NULL,
  `hyperlinks` varchar(255) DEFAULT NULL,
  `json_data` varchar(255) DEFAULT NULL,
  `meta_data` varchar(255) DEFAULT NULL,
  `scheduled` bit(1) DEFAULT NULL,
  `start_date` datetime DEFAULT NULL,
  `users_to_notify` varchar(255) DEFAULT NULL,
  `visible_to_all` bit(1) DEFAULT NULL,
  `template_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`,`rev`),
  KEY `FK76r0s14ewob41mu1pe3qdbdke` (`rev`),
  CONSTRAINT `FK76r0s14ewob41mu1pe3qdbdke` FOREIGN KEY (`rev`) REFERENCES `revinfo` (`rev`)
) ENGINE=InnoDB;

--changeset 24/04/2023 Akash:Akash-20
alter table vendor add column about varchar(1000);

--changeset 28/04/2023 Akash:Akash-21
create table vendor_portfolio (id bigint not null auto_increment, active bit, created_on datetime, deleted bit default 0, status varchar(255), updated_on datetime, vendor_id bigint, created_by bigint, updated_by bigint, portfolio_id bigint not null, primary key (id)) engine=InnoDB;
alter table vendor_portfolio add constraint FKdbnkwbg2bkuoafuoryb1rb2vk foreign key (created_by) references user (id);
alter table vendor_portfolio add constraint FK9vl52n112dyi2xvttva3kci96 foreign key (updated_by) references user (id);
alter table vendor_portfolio add constraint FKd0cqq5moyx1vwxrbgy0fsvnbs foreign key (portfolio_id) references media (id);

--changeset 04/05/2023 Shivendra:Shivendra-22
alter table resource add column reason longtext;
alter table job add column reason longtext;

--changeset 05/05/2023 Shivendra:Shivendra-23
alter table message_template modify type varchar(50) UNIQUE;
insert into message_template(message,type) values('%resource% /applied/ for %job%','APPLIED');
insert into message_template(message,type) values('%resource% /shorlisted/ for %job%','SHORTLISTED');
insert into message_template(message,type) values('%resource% /interviewed/ for %job%','INTERVIEWED');
insert into message_template(message,type) values('%resource% /rejected/ for %job%','REJECTED');
insert into message_template(message,type) values('%resource% /hired/ for %job%','HIRED');
insert into message_template(message,type) values('%resource% /invited/ for %job%','INVITE');
insert into message_template(message,type) values('%resource% /withdrawn/ from %job%','WITHDRAW');

--changeset 30/05/2023 Shivendra:Shivendra-24
insert into message_template(message,type) values('%resource% /accepted invitation/ for %job%','INVITATION ACCEPTED');
insert into message_template(message,type) values('%resource% /rejected invitation/ for %job%','INVITATION REJECTED');

--changeset 14/07/2023 Akash:Akash-25
UPDATE `user` SET `email_id` = 'admin@knackmeet.com' WHERE (`id` = '1');

--changeset 18/07/2023 Sushma:Sushma-26
ALTER TABLE job DROP COLUMN job_type;

--changeset 19/07/2-23 Mansingh:Mansingh-27
create table verify_email (
  id bigint not null auto_increment, 
  random_Number varchar(255),
  vendor_id bigint not null,
  status varchar(255), 
  primary key (id)
) engine = InnoDB;

--changeset 21/07/2-23 Mansingh:Mansingh-28
ALTER TABLE vendor MODIFY location VARCHAR(500);

--changeset 14/06/2023 mansingh:mansingh-26
alter table search_history change column keyward_json keyword varchar(500) NULL; 

--changeset 30/06/2023 mansingh:mansingh-27
truncate search_history;

--changeset 03/07/2023 Akash:Akash-28
ALTER TABLE resource drop foreign key FKjgupskuc82gm4tiqejidy9tg5;
ALTER TABLE resource DROP COLUMN category_id;

ALTER TABLE job drop foreign key FKexgx3mxhoafpvrhrfiq249isn;
ALTER TABLE job DROP COLUMN category_id;

ALTER TABLE address drop foreign key FKt66kfah3i39m4d3gtetl3srh6;
alter table address drop column city_id;

SET FOREIGN_KEY_CHECKS = 0;
truncate table address;
SET FOREIGN_KEY_CHECKS = 1;

INSERT INTO `address` (`active`, `created_on`, `deleted`, `updated_on`, `country_id`, `state_id`) 
VALUES (b'1', '2023-07-03 16:03:36', b'0', '2023-07-03 16:03:36', '1', '2'),
(b'1', '2023-07-03 16:03:36', b'0', '2023-07-03 16:03:36', '1', '3'),
(b'1', '2023-07-03 16:03:36', b'0', '2023-07-03 16:03:36', '1', '4'),
(b'1', '2023-07-03 16:03:36', b'0', '2023-07-03 16:03:36', '1', '5'),
(b'1', '2023-07-03 16:03:36', b'0', '2023-07-03 16:03:36', '1', '6'),
(b'1', '2023-07-03 16:03:36', b'0', '2023-07-03 16:03:36', '1', '7'),
(b'1', '2023-07-03 16:03:36', b'0', '2023-07-03 16:03:36', '1', '8'),
(b'1', '2023-07-03 16:03:36', b'0', '2023-07-03 16:03:36', '1', '9'),
(b'1', '2023-07-03 16:03:36', b'0', '2023-07-03 16:03:36', '1', '10'),
(b'1', '2023-07-03 16:03:36', b'0', '2023-07-03 16:03:36', '1', '11'),
(b'1', '2023-07-03 16:03:36', b'0', '2023-07-03 16:03:36', '1', '12'),
(b'1', '2023-07-03 16:03:36', b'0', '2023-07-03 16:03:36', '1', '13'),
(b'1', '2023-07-03 16:03:36', b'0', '2023-07-03 16:03:36', '1', '14'),
(b'1', '2023-07-03 16:03:36', b'0', '2023-07-03 16:03:36', '1', '15'),
(b'1', '2023-07-03 16:03:36', b'0', '2023-07-03 16:03:36', '1', '16'),
(b'1', '2023-07-03 16:03:36', b'0', '2023-07-03 16:03:36', '1', '17'),
(b'1', '2023-07-03 16:03:36', b'0', '2023-07-03 16:03:36', '1', '18'),
(b'1', '2023-07-03 16:03:36', b'0', '2023-07-03 16:03:36', '1', '19'),
(b'1', '2023-07-03 16:03:36', b'0', '2023-07-03 16:03:36', '1', '20'),
(b'1', '2023-07-03 16:03:36', b'0', '2023-07-03 16:03:36', '1', '21'),
(b'1', '2023-07-03 16:03:36', b'0', '2023-07-03 16:03:36', '1', '22'),
(b'1', '2023-07-03 16:03:36', b'0', '2023-07-03 16:03:36', '1', '23'),
(b'1', '2023-07-03 16:03:36', b'0', '2023-07-03 16:03:36', '1', '24'),
(b'1', '2023-07-03 16:03:36', b'0', '2023-07-03 16:03:36', '1', '25'),
(b'1', '2023-07-03 16:03:36', b'0', '2023-07-03 16:03:36', '1', '26'),
(b'1', '2023-07-03 16:03:36', b'0', '2023-07-03 16:03:36', '1', '27'),
(b'1', '2023-07-03 16:03:36', b'0', '2023-07-03 16:03:36', '1', '28'),
(b'1', '2023-07-03 16:03:36', b'0', '2023-07-03 16:03:36', '1', '29'),
(b'1', '2023-07-03 16:03:36', b'0', '2023-07-03 16:03:36', '1', '30'),
(b'1', '2023-07-03 16:03:36', b'0', '2023-07-03 16:03:36', '1', '31'),
(b'1', '2023-07-03 16:03:36', b'0', '2023-07-03 16:03:36', '1', '32'),
(b'1', '2023-07-03 16:03:36', b'0', '2023-07-03 16:03:36', '1', '33'),
(b'1', '2023-07-03 16:03:36', b'0', '2023-07-03 16:03:36', '1', '34'),
(b'1', '2023-07-03 16:03:36', b'0', '2023-07-03 16:03:36', '1', '35'),
(b'1', '2023-07-03 16:03:36', b'0', '2023-07-03 16:03:36', '1', '36'),
(b'1', '2023-07-03 16:03:36', b'0', '2023-07-03 16:03:36', '1', '37');

--changeset 24/07/2023 Sushma:Sushma-29
ALTER TABLE vendor MODIFY incorparation_date datetime DEFAULT NULL;

--changeset 01/08/2023 Manish:Manish-30
ALTER TABLE vendor ADD COLUMN reason LONGTEXT;

--changeset 02/08/2023 Sarjerao:Sarjerao-31
ALTER TABLE job ADD COLUMN closed_date DATETIME DEFAULT NULL; 

--changeset 09/08/2023 Mansingh:Mansingh-32
CREATE TABLE  IF NOT EXISTS static_configuration (
  id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  active BIT,
  created_on DATETIME,
  deleted BIT DEFAULT 0,
  status VARCHAR(255),
  updated_on DATETIME,
  created_by BIGINT,
  updated_by BIGINT,
  name VARCHAR(255) not null,
  value VARCHAR(255)  not null
) ENGINE = InnoDB;

--changeset 09/08/2023 Mansingh:Mansingh-33
INSERT INTO `static_configuration` (`active`, `created_on`, `deleted`, `updated_on`, `name`, `value`) 
VALUES (b'1', '2023-08-09 16:03:36', b'0', '2023-08-09 16:03:36', 'NOTIFICATION_EMAIL', 'deepak.thapa@daynilgroup.com');

--changeset 09/08/2023 Mansingh:Mansingh-34
INSERT INTO `static_configuration` (`active`, `created_on`, `deleted`, `updated_on`, `name`, `value`) 
VALUES (b'1', '2023-08-09 16:03:36', b'0', '2023-08-09 16:03:36', 'RESOURCE_COMMISSION', '0');

--changeset 02/08/2023 Akash:Akash-32

--
-- Table structure for table `education`
--

create table education (
id bigint not null auto_increment, 
active bit, 
created_on datetime, 
deleted bit default 0, 
status varchar(255), 
updated_on datetime, 
description longtext, 
from_month integer not null, 
from_year integer not null, 
school_name varchar(255) not null, 
to_month integer, 
to_year integer, 
created_by bigint, 
updated_by bigint, 
degree_id bigint not null, 
resource_id bigint not null, 
specialization_id bigint not null, 
primary key (id)) engine=InnoDB;


--
-- Table structure for table `experience`
--

create table experience (
id bigint not null auto_increment, 
active bit, 
created_on datetime, 
deleted bit default 0, 
status varchar(255), 
updated_on datetime, 
present_company bit, 
company_address varchar(255) not null, 
latitude decimal(19,2) not null, 
longitude decimal(19,2) not null, 
deployment_type varchar(255), 
description varchar(255), 
employment_type varchar(255) not null, 
from_year integer not null, 
from_month integer not null, 
to_month integer, 
to_year integer, 
created_by bigint, 
updated_by bigint, 
company_id bigint not null, 
industry_id bigint not null, 
resource_id bigint, 
title_id bigint not null, 
primary key (id)) engine=InnoDB;


--
-- Table structure for table `experience_skills_code_lookup`
--

create table experience_skills_code_lookup (
id bigint not null auto_increment, 
active bit, 
created_on datetime, 
deleted bit default 0, 
status varchar(255), 
updated_on datetime, 
created_by bigint, 
updated_by bigint, 
code_lookup_id bigint, 
experience_id bigint, 
primary key (id)) engine=InnoDB;

alter table education add constraint FKr09ad7ufqv3kitsrehiqrbgkb foreign key (created_by) references user (id);
alter table education add constraint FKb129orvpg8xy5bhsuuuxeni0e foreign key (updated_by) references user (id);
alter table education add constraint FKayjav4nv81lxurxb90etta98u foreign key (degree_id) references code_lookup (id);
alter table education add constraint FK8w63dsslwc6ffqjfu6npu3ull foreign key (resource_id) references resource (id);
alter table education add constraint FKqs6xy116hgpoxv7faaagtjben foreign key (specialization_id) references code_lookup (id);
alter table experience add constraint FK32qr814e9imoy8ojocikeec5a foreign key (created_by) references user (id);
alter table experience add constraint FKsrd7ibq0rgcy54w13868x884t foreign key (updated_by) references user (id);
alter table experience add constraint FKn5rfhlucu8qsulxe1vx4ohtpg foreign key (company_id) references code_lookup (id);
alter table experience add constraint FK23bxmaamsymp3nbm4efm9fuqy foreign key (industry_id) references code_lookup (id);
alter table experience add constraint FKt4pu2vn3xg7nhemi74qkuod67 foreign key (resource_id) references resource (id);
alter table experience add constraint FKs93nw87evb8sby7hnh8vj3khs foreign key (title_id) references code_lookup (id);
alter table experience_skills_code_lookup add constraint FKc99glrhyci4xdni18vcxipgog foreign key (created_by) references user (id);
alter table experience_skills_code_lookup add constraint FKt7w61i0299eu74wgtnmyx0e7q foreign key (updated_by) references user (id);
alter table experience_skills_code_lookup add constraint FKjqqnw8bwbc17dqcf6lytxdyik foreign key (code_lookup_id) references code_lookup (id);
alter table experience_skills_code_lookup add constraint FKsbqu17cx02rjy1r3s11w6phqd foreign key (experience_id) references experience (id);

alter table resource add column usd_rate decimal(19,2) null;
alter table resource add column usd_rate_type varchar(255) null;

--changeset 02/08/2023 Akash:Akash-33
INSERT INTO `code_lookup_type` (`id`, `active`, `created_on`, `deleted`, `status`, `code`, `cover_img_require`, `deletable`, `editable`, `name`, `parent_id`)
VALUES (10, true,'2023-08-01 11:50:04', false, 'VERIFIED', 'DEGREE', false, false, false, 'Degree',  null),
(11, true,'2023-08-02 11:50:04', false, 'VERIFIED', 'SPECIALIZATION', false, false, false, 'Specialization',  null),
(12, true,'2023-08-02 11:50:04', false, 'VERIFIED', 'INDUSTRY', false, false, false, 'Industry',  null),
(13, true,'2023-08-02 11:50:04', false, 'VERIFIED', 'COMPANY', false, false, false, 'Company',  null);
 
INSERT INTO `code_lookup` (`active`, `created_on`, `deleted`, `status`, `description`, `display_order`, `name`, `image_id`, `parent_id`, `type_id`)
VALUES(TRUE,'2023-08-02 11:50:04', FALSE, 'VERIFIED', 'Information Technology & Services', null, 'Information Technology & Services', null, 1, 12);

--changeset 03/08/2023 Akash:Akash-34
ALTER TABLE resource 
MODIFY rate decimal(19, 2) null, 
MODIFY rate_type varchar(255) null;

--changeset 11/08/2023 Sushma:Sushma-32
ALTER TABLE vendor ADD COLUMN company_primary_number VARCHAR(255);
ALTER TABLE vendor ADD COLUMN company_primary_email VARCHAR(255);
ALTER TABLE vendor ADD COLUMN company_description LONGTEXT;

--changeset 17/08/2023 Sarjerao:Sarjerao-35
ALTER TABLE vendor
MODIFY website varchar(255) null,
MODIFY incorparation_date date null ;

--changeset 21/08/2023 Mansingh:Mansingh-36
Alter table resource_jobs ADD COLUMN resource_inr_rate decimal(19, 2);
Alter table resource_jobs ADD COLUMN resource_usd_rate decimal(19, 2);

update resource_jobs ,resource
set resource_inr_rate=rate , resource_usd_rate=usd_rate
where resource_jobs.resource_id=resource.id and resource_jobs.resource_status in ('SHORTLISTED','HIRED','REJECTED');

--changeset 25/08/2023 Mansingh:Mansingh-37
update resource_jobs ,resource
set resource_inr_rate=rate , resource_usd_rate=usd_rate
where resource_jobs.resource_id=resource.id and resource_jobs.resource_status in ('APPLIED');

--changeset 25/08/2023 Mansingh:Mansingh-38
CREATE TABLE  IF NOT EXISTS registration_enquiry (
  id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  active BIT,
  created_on DATETIME,
  deleted BIT DEFAULT 0,
  status VARCHAR(255),
  updated_on DATETIME,
  created_by BIGINT,
  updated_by BIGINT,
  first_name VARCHAR(255) not null,
  last_name VARCHAR(255)  not null,
  email_id VARCHAR(255)  not null,
  mobile_number VARCHAR(255)  not null,
  time_zone VARCHAR(255)  not null
) ENGINE = InnoDB;

--changeset 25/08/2023 Akash:Akash-39
ALTER TABLE user ADD COLUMN time_zone varchar(255) default null;

--changeset 28/08/2023 Mansingh:Mansingh-40
update vendor ,user
set company_primary_email=email_id
where vendor.user_id=user.id and vendor.company_primary_email is null; 

--changeset 01/09/2023 Mansingh:Mansingh-41
ALTER TABLE registration_enquiry ADD COLUMN country_code_id BIGINT default null;
ALTER TABLE registration_enquiry ADD constraint FKfnv1epc9mnk9dp47le83p754h foreign key (country_code_id) references code_lookup (id);

--changeset 01/09/2023 Sarjerao:Sarjerao-42
UPDATE user SET time_zone='ASIA_KOLKATA' WHERE time_zone IS NULL;

--changeset 01/09/2023 Mansing:Mansingh-43
ALTER TABLE resource 
ADD COLUMN location varchar(500),
ADD COLUMN latitude decimal(19,2),
ADD COLUMN longitude decimal(19,2),
ADD COLUMN country_id BIGINT;
ALTER TABLE resource add constraint FKf03adt1f9vh0gsseb58cmc5fo foreign key (country_id) references code_lookup (id);

ALTER TABLE job 
ADD COLUMN location varchar(500),
ADD COLUMN latitude decimal(19,2),
ADD COLUMN longitude decimal(19,2),
ADD COLUMN country_id BIGINT ;
ALTER TABLE job add constraint FK4fixsgbap19k8icxf7ta5wiq3 foreign key (country_id) references code_lookup (id);

UPDATE  resource , address
set resource.location=CONCAT((SELECT NAME FROM code_lookup WHERE id=address.state_id),', ',(SELECT NAME FROM code_lookup WHERE id=address.country_id)),
resource.country_id=address.country_id
WHERE resource.address_id=address.id AND resource.location IS NULL;

UPDATE  job , address
set job.location=CONCAT((SELECT NAME FROM code_lookup WHERE id=address.state_id),', ',(SELECT NAME FROM code_lookup WHERE id=address.country_id)),
job.country_id=address.country_id
WHERE job.address_id=address.id AND job.location IS NULL;

ALTER TABLE resource MODIFY address_id BIGINT NULL;
ALTER TABLE job MODIFY address_id BIGINT NULL;

INSERT INTO `code_lookup` (`active`, `created_on`, `deleted`, `status`, `updated_on`, `description`, `display_order`, `name`, `created_by`, `updated_by`, `image_id`, `parent_id`, `type_id`) VALUES 
 (b'1', '2023-08-28 17:34:04', b'0', 'VERIFIED', NULL, 'Afghanistan', NULL, 'Afghanistan', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-03-15 14:00:04', b'0', 'VERIFIED', NULL, 'Albania', NULL, 'Albania', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-03-15 14:00:04', b'0', 'VERIFIED', NULL, 'Algeria', NULL, 'Algeria', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-03-15 14:00:04', b'0', 'VERIFIED', NULL, 'Andorra', NULL, 'Andorra', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-03-15 14:00:04', b'0', 'VERIFIED', NULL, 'Angola', NULL, 'Angola', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-03-15 14:00:04', b'0', 'VERIFIED', NULL, 'Antigua and Barbuda', NULL, 'Antigua and Barbuda', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-03-15 14:00:04', b'0', 'VERIFIED', NULL, 'Argentina', NULL, 'Argentina', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-03-15 14:00:04', b'0', 'VERIFIED', NULL, 'Armenia', NULL, 'Armenia', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-03-15 14:00:04', b'0', 'VERIFIED', NULL, 'Austria', NULL, 'Austria', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-03-15 14:00:04', b'0', 'VERIFIED', NULL, 'Azerbaijan', NULL, 'Azerbaijan', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-03-15 14:00:04', b'0', 'VERIFIED', NULL, 'Bahrain', NULL, 'Bahrain', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-03-15 14:00:04', b'0', 'VERIFIED', NULL, 'Bangladesh', NULL, 'Bangladesh', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-03-15 14:00:04', b'0', 'VERIFIED', NULL, 'Barbados', NULL, 'Barbados', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-03-15 14:00:04', b'0', 'VERIFIED', NULL, 'Belarus', NULL, 'Belarus', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-03-15 14:00:04', b'0', 'VERIFIED', NULL, 'Belgium', NULL, 'Belgium', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-03-15 14:00:04', b'0', 'VERIFIED', NULL, 'Belize', NULL, 'Belize', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-03-15 14:00:04', b'0', 'VERIFIED', NULL, 'Benin', NULL, 'Benin', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-03-15 14:00:04', b'0', 'VERIFIED', NULL, 'Bhutan', NULL, 'Bhutan', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-03-15 14:00:04', b'0', 'VERIFIED', NULL, 'Bolivia', NULL, 'Bolivia', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-03-15 14:00:04', b'0', 'VERIFIED', NULL, 'Bosnia and Herzegovina', NULL, 'Bosnia and Herzegovina', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-03-15 14:00:04', b'0', 'VERIFIED', NULL, 'Botswana', NULL, 'Botswana', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-03-15 14:00:04', b'0', 'VERIFIED', NULL, 'Brazil', NULL, 'Brazil', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-03-15 14:00:04', b'0', 'VERIFIED', NULL, 'Brunei', NULL, 'Brunei', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-03-15 14:00:04', b'0', 'VERIFIED', NULL, 'Bulgaria', NULL, 'Bulgaria', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-03-15 14:00:04', b'0', 'VERIFIED', NULL, 'Burkina Faso', NULL, 'Burkina Faso', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-03-15 14:00:04', b'0', 'VERIFIED', NULL, 'Burundi', NULL, 'Burundi', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-03-15 14:00:04', b'0', 'VERIFIED', NULL, 'Cabo Verde', NULL, 'Cabo Verde', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-03-15 14:00:04', b'0', 'VERIFIED', NULL, 'Cambodia', NULL, 'Cambodia', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-03-15 14:00:04', b'0', 'VERIFIED', NULL, 'Cameroon', NULL, 'Cameroon', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-03-15 14:00:04', b'0', 'VERIFIED', NULL, 'Canada', NULL, 'Canada', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-03-15 14:00:04', b'0', 'VERIFIED', NULL, 'Central African Republic', NULL, 'Central African Republic', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-03-15 14:00:04', b'0', 'VERIFIED', NULL, 'Chad', NULL, 'Chad', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-03-15 14:00:04', b'0', 'VERIFIED', NULL, 'Channel Islands', NULL, 'Channel Islands', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-03-15 14:00:04', b'0', 'VERIFIED', NULL, 'Chile', NULL, 'Chile', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-03-15 14:00:04', b'0', 'VERIFIED', NULL, 'China', NULL, 'China', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-03-21 14:00:04', b'0', 'VERIFIED', NULL, 'Colombia', NULL, 'Colombia', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-05-05 15:12:03', b'0', 'VERIFIED', NULL, 'Comoros', NULL, 'Comoros', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-05-05 15:12:20', b'0', 'VERIFIED', NULL, 'Congo', NULL, 'Congo', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-05-05 15:12:41', b'0', 'VERIFIED', NULL, 'Costa Rica', NULL, 'Costa Rica', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-05-05 16:02:24', b'0', 'VERIFIED', NULL, 'Croatia', NULL, 'Croatia', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-05-05 16:02:24', b'0', 'VERIFIED', NULL, 'Cuba', NULL, 'Cuba', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-05-05 16:02:24', b'0', 'VERIFIED', NULL, 'Cyprus', NULL, 'Cyprus', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-05-05 16:02:24', b'0', 'VERIFIED', NULL, 'Czech Republic', NULL, 'Czech Republic', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-05-05 16:02:24', b'0', 'VERIFIED', NULL, 'Denmark', NULL, 'Denmark', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-05-05 16:02:24', b'0', 'VERIFIED', NULL, 'Djibouti', NULL, 'Djibouti', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-05-05 16:08:37', b'0', 'VERIFIED', NULL, 'Dominica', NULL, 'Dominica', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-05-05 16:09:01', b'0', 'VERIFIED', NULL, 'Dominican Republic', NULL, 'Dominican Republic', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-05-05 16:11:06', b'0', 'VERIFIED', NULL, 'DR Congo', NULL, 'DR Congo', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-05-05 16:11:19', b'0', 'VERIFIED', NULL, 'Ecuador', NULL, 'Ecuador', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-05-05 16:22:53', b'0', 'VERIFIED', NULL, 'Egypt', NULL, 'Egypt', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-05-05 16:22:53', b'0', 'VERIFIED', NULL, 'El Salvador', NULL, 'El Salvador', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-05-05 16:22:53', b'0', 'VERIFIED', NULL, 'Equatorial Guinea', NULL, 'Equatorial Guinea', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-05-05 16:22:53', b'0', 'VERIFIED', NULL, 'Eritrea', NULL, 'Eritrea', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-05-05 16:40:48', b'0', 'VERIFIED', NULL, 'Estonia', NULL, 'Estonia', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-05-05 16:40:48', b'0', 'VERIFIED', NULL, 'Eswatini', NULL, 'Eswatini', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-05-05 16:41:04', b'0', 'VERIFIED', NULL, 'Ethiopia', NULL, 'Ethiopia', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-05-05 17:01:24', b'0', 'VERIFIED', NULL, 'Faeroe Islands', NULL, 'Faeroe Islands', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-05-05 17:01:24', b'0', 'VERIFIED', NULL, 'Finland', NULL, 'Finland', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-05-05 17:01:24', b'0', 'VERIFIED', NULL, 'France', NULL, 'France', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-05-05 17:01:24', b'0', 'VERIFIED', NULL, 'French Guiana', NULL, 'French Guiana', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-05-05 17:01:24', b'0', 'VERIFIED', NULL, 'Gabon', NULL, 'Gabon', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-05-05 17:04:07', b'0', 'VERIFIED', NULL, 'Gambia', NULL, 'Gambia', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-05-05 17:04:07', b'0', 'VERIFIED', NULL, 'Georgia', NULL, 'Georgia', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-05-05 17:04:07', b'0', 'VERIFIED', NULL, 'Germany', NULL, 'Germany', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-05-05 17:04:07', b'0', 'VERIFIED', NULL, 'Ghana', NULL, 'Ghana', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-05-05 17:04:07', b'0', 'VERIFIED', NULL, 'Gibraltar', NULL, 'Gibraltar', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-05-05 17:11:03', b'0', 'VERIFIED', NULL, 'Greece', NULL, 'Greece', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-05-05 17:11:03', b'0', 'VERIFIED', NULL, 'Grenada', NULL, 'Grenada', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-05-05 17:11:03', b'0', 'VERIFIED', NULL, 'Guatemala', NULL, 'Guatemala', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-05-05 17:18:03', b'0', 'VERIFIED', NULL, 'Guinea', NULL, 'Guinea', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-05-05 17:32:55', b'0', 'VERIFIED', NULL, 'Guinea-Bissau', NULL, 'Guinea-Bissau', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-05-05 17:32:55', b'0', 'VERIFIED', NULL, 'Guyana', NULL, 'Guyana', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-05-05 17:32:55', b'0', 'VERIFIED', NULL, 'Haiti', NULL, 'Haiti', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-05-05 17:32:55', b'0', 'VERIFIED', NULL, 'Holy See', NULL, 'Holy See', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-05-05 17:37:52', b'0', 'VERIFIED', NULL, 'Honduras', NULL, 'Honduras', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-05-05 17:37:52', b'0', 'VERIFIED', NULL, 'Hong Kong', NULL, 'Hong Kong', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-05-05 17:37:52', b'0', 'VERIFIED', NULL, 'Hungary', NULL, 'Hungary', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-05-05 17:37:52', b'0', 'VERIFIED', NULL, 'Iceland', NULL, 'Iceland', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-05-08 11:26:59', b'0', 'VERIFIED', NULL, 'Indonesia', NULL, 'Indonesia', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-05-08 11:27:42', b'0', 'VERIFIED', NULL, 'Iran', NULL, 'Iran', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-05-08 11:28:20', b'0', 'VERIFIED', NULL, 'Iraq', NULL, 'Iraq', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-05-08 11:28:37', b'0', 'VERIFIED', NULL, 'Ireland', NULL, 'Ireland', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-05-08 11:29:14', b'0', 'VERIFIED', NULL, 'Isle of Man', NULL, 'Isle of Man', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-05-08 11:37:59', b'0', 'VERIFIED', NULL, 'Israel', NULL, 'Israel', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-05-10 11:30:13', b'0', 'VERIFIED', NULL, 'Italy', NULL, 'Italy', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-05-10 12:26:51', b'0', 'VERIFIED', NULL, 'Jamaica', NULL, 'Jamaica', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-05-10 12:28:13', b'0', 'VERIFIED', NULL, 'Japan', NULL, 'Japan', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-05-10 12:47:41', b'0', 'VERIFIED', NULL, 'Jordan', NULL, 'Jordan', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-05-10 13:08:32', b'0', 'VERIFIED', NULL, 'Kazakhstan', NULL, 'Kazakhstan', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-05-10 13:19:29', b'0', 'VERIFIED', NULL, 'Kenya', NULL, 'Kenya', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-05-10 13:20:15', b'0', 'VERIFIED', NULL, 'Kuwait', NULL, 'Kuwait', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-05-11 12:42:25', b'0', 'VERIFIED', NULL, 'Kyrgyzstan', NULL, 'Kyrgyzstan', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-05-17 14:51:43', b'0', 'VERIFIED', NULL, 'Laos', NULL, 'Laos', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-05-17 14:51:43', b'0', 'VERIFIED', NULL, 'Latvia', NULL, 'Latvia', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-05-17 15:00:32', b'0', 'VERIFIED', NULL, 'Lebanon', NULL, 'Lebanon', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-05-19 11:34:21', b'0', 'VERIFIED', NULL, 'Lesotho', NULL, 'Lesotho', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-05-20 21:46:20', b'0', 'VERIFIED', NULL, 'Liberia', NULL, 'Liberia', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-05-22 11:51:09', b'0', 'VERIFIED', NULL, 'Libya', NULL, 'Libya', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-05-30 11:31:41', b'0', 'VERIFIED', NULL, 'Liechtenstein', NULL, 'Liechtenstein', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-05-30 12:24:47', b'0', 'VERIFIED', NULL, 'Lithuania', NULL, 'Lithuania', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-05-31 11:38:18', b'0', 'VERIFIED', NULL, 'Luxembourg', NULL, 'Luxembourg', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-05-31 11:38:18', b'0', 'VERIFIED', NULL, 'Macao', NULL, 'Macao', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-05-31 12:03:36', b'0', 'VERIFIED', NULL, 'Madagascar', NULL, 'Madagascar', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-05-31 12:03:36', b'0', 'VERIFIED', NULL, 'Malawi', NULL, 'Malawi', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-05-31 12:03:36', b'0', 'VERIFIED', NULL, 'Malaysia', NULL, 'Malaysia', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'Maldives', NULL, 'Maldives', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'Mali', NULL, 'Mali', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'Malta', NULL, 'Malta', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'Mauritania', NULL, 'Mauritania', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'Mauritius', NULL, 'Mauritius', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'Mayotte', NULL, 'Mayotte', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'Mexico', NULL, 'Mexico', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'Moldova', NULL, 'Moldova', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'Monaco', NULL, 'Monaco', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'Mongolia', NULL, 'Mongolia', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'Montenegro', NULL, 'Montenegro', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'Morocco', NULL, 'Morocco', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'Mozambique', NULL, 'Mozambique', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'Myanmar', NULL, 'Myanmar', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'Namibia', NULL, 'Namibia', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'Nepal', NULL, 'Nepal', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'Netherlands', NULL, 'Netherlands', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'Nicaragua', NULL, 'Nicaragua', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'Niger', NULL, 'Niger', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'Nigeria', NULL, 'Nigeria', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'North Korea', NULL, 'North Korea', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'North Macedonia', NULL, 'North Macedonia', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'Norway', NULL, 'Norway', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'Oman', NULL, 'Oman', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'Pakistan', NULL, 'Pakistan', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'Panama', NULL, 'Panama', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'Paraguay', NULL, 'Paraguay', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'Peru', NULL, 'Peru', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'Philippines', NULL, 'Philippines', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'Poland', NULL, 'Poland', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'Portugal', NULL, 'Portugal', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'Qatar', NULL, 'Qatar', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'RÃ©union', NULL, 'RÃ©union', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'Romania', NULL, 'Romania', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'Russia', NULL, 'Russia', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'Rwanda', NULL, 'Rwanda', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'Saint Helena', NULL, 'Saint Helena', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'Saint Kitts and Nevis', NULL, 'Saint Kitts and Nevis', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'Saint Lucia', NULL, 'Saint Lucia', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'Saint Vincent and the Grenadines', NULL, 'Saint Vincent and the Grenadines', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'San Marino', NULL, 'San Marino', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'Sao Tome & Principe', NULL, 'Sao Tome & Principe', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'Saudi Arabia', NULL, 'Saudi Arabia', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'Senegal', NULL, 'Senegal', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'Serbia', NULL, 'Serbia', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'Seychelles', NULL, 'Seychelles', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'Sierra Leone', NULL, 'Sierra Leone', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'Singapore', NULL, 'Singapore', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'Slovakia', NULL, 'Slovakia', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'Slovenia', NULL, 'Slovenia', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'Somalia', NULL, 'Somalia', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'South Africa', NULL, 'South Africa', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'South Korea', NULL, 'South Korea', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'South Sudan', NULL, 'South Sudan', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'Spain', NULL, 'Spain', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'Sri Lanka', NULL, 'Sri Lanka', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'State of Palestine', NULL, 'State of Palestine', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'Sudan', NULL, 'Sudan', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'Suriname', NULL, 'Suriname', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'Sweden', NULL, 'Sweden', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'Switzerland', NULL, 'Switzerland', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'Syria', NULL, 'Syria', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'Taiwan', NULL, 'Taiwan', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'Tajikistan', NULL, 'Tajikistan', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'Tanzania', NULL, 'Tanzania', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'Thailand', NULL, 'Thailand', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'The Bahamas', NULL, 'The Bahamas', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'Timor-Leste', NULL, 'Timor-Leste', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'Togo', NULL, 'Togo', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'Trinidad and Tobago', NULL, 'Trinidad and Tobago', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'Tunisia', NULL, 'Tunisia', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'Turkey', NULL, 'Turkey', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'Turkmenistan', NULL, 'Turkmenistan', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'Uganda', NULL, 'Uganda', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'Ukraine', NULL, 'Ukraine', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'United Arab Emirates', NULL, 'United Arab Emirates', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'United Kingdom', NULL, 'United Kingdom', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'United States', NULL, 'United States', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'Uruguay', NULL, 'Uruguay', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'Uzbekistan', NULL, 'Uzbekistan', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'Venezuela', NULL, 'Venezuela', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'Vietnam', NULL, 'Vietnam', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'Western Sahara', NULL, 'Western Sahara', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'Yemen', NULL, 'Yemen', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'Zambia', NULL, 'Zambia', 1, NULL, NULL, NULL, 6),
 (b'1', '2023-08-28 17:37:36', b'0', 'VERIFIED', NULL, 'Zimbabwe', NULL, 'Zimbabwe', 1, NULL, NULL, NULL, 6);

--changeset 11/09/2023 Sarjerao:Sarjerao-44
ALTER TABLE vendor ADD COLUMN country_code_id BIGINT default null;
ALTER TABLE vendor ADD constraint FK_vendor_code_lookup foreign key (country_code_id) references code_lookup (id);
 
--changeset 13/09/2023 Sarjerao:Sarjerao-45
UPDATE vendor,user
SET vendor.country_code_id=user.phone_code_id
WHERE vendor.user_id=user.id AND vendor.country_code_id IS NULL;

--changeset 15/09/2023 Manish:Manish-46
ALTER TABLE job ADD COLUMN close_reason VARCHAR(255);

--changeset 11/09/2023 Sushma:Sushma-47

--
-- Table structure for table `code_lookup_relation`
--

create table code_lookup_relation 
(id bigint not null auto_increment, 
active bit, created_on datetime, 
deleted bit default 0, 
status varchar(255), 
updated_on datetime, 
ref_id bigint not null, 
ref_type varchar(255) not null, 
type varchar(255) not null, 
created_by bigint, 
updated_by bigint, 
code_look_up_id bigint not null, 
primary key (id)) engine=InnoDB;

alter table code_lookup_relation add constraint FKi8n0qjwyn4r842c4cs9niml0g foreign key (created_by) references user (id);
alter table code_lookup_relation add constraint FKffos6bg2chck92pmrul1uiild foreign key (updated_by) references user (id);
alter table code_lookup_relation add constraint FKmrkqju6yd1ots4jhq660hecqp foreign key (code_look_up_id) references code_lookup (id);

--changeset 11/09/2023 Sushma:Sushma-48

INSERT INTO `code_lookup_type` (`id`,`active`, `created_on`, `deleted`, `status`, `code`, `cover_img_require`, `deletable`, `editable`, `name`, `parent_id`)
VALUES (14, true,'2023-09-11 14:00:04', false, 'VERIFIED', 'RESOURCE_REJECT_REASON', false, false, false, 'Resource Reject Reason',  null),
(15, true,'2023-09-11 14:00:04', false, 'VERIFIED', 'JOB_REJECT_REASON', false, false, false, 'Job Reject Reason',  null), 
(16, true, '2023-09-11 14:00:04', false, 'VERIFIED', 'RESOURCE_JOBS_WITHDRAW_REASON', false, false, false, 'Resource Jobs Withdraw Reason', null);
 
INSERT INTO `code_lookup` (`active`, `created_on`, `deleted`, `status`, `updated_on`, `description`, `display_order`, `name`, `created_by`, `updated_by`, `image_id`, `parent_id`, `type_id`)
VALUES (TRUE,'2023-09-11 14:00:04', FALSE, 'VERIFIED', NULL, 'Add Candidate Profile Picture', NULL, 'Add Candidate Profile Picture', 1, NULL, NULL, NULL, 14),
(TRUE, '2023-09-11 14:00:04', FALSE, 'VERIFIED', NULL, 'Experience is not matched as per resume', NULL, 'Experience is not matched as per resume', 1, NULL, NULL, NULL, 14),
(TRUE, '2023-09-11 14:00:04', FALSE, 'VERIFIED', NULL, 'Resume is not matched as per experience', NULL, 'Resume is not matched as per experience', 1, NULL, NULL, NULL, 14),
(TRUE, '2023-09-11 14:00:04', FALSE, 'VERIFIED', NULL, 'Upload proper Detailed resume', NULL, 'Upload proper Detailed resume', 1, NULL, NULL, NULL, 14),
(TRUE, '2023-09-11 14:00:04', FALSE, 'VERIFIED', NULL, 'Duplicate record posted by another Vendor', null, 'Duplicate record posted by another Vendor', 1, NULL, NULL, NULL, 14),
(TRUE, '2023-09-11 14:00:04', FALSE, 'VERIFIED', NULL, 'Profile already exists', NULL, 'Profile already exists', 1, NULL, NULL, NULL, 14),
(TRUE, '2023-09-11 14:00:04', FALSE, 'VERIFIED', NULL, 'Job description is not proper', NULL, 'Job description is not proper', 1, NULL, NULL, NULL, 15),
(TRUE, '2023-09-11 14:00:04', FALSE, 'VERIFIED', NULL, 'Incomplete location', NULL, 'Incomplete location', 1, NULL, NULL, NULL, 15),
(TRUE, '2023-09-11 14:00:04', FALSE, 'VERIFIED', NULL, 'Applied by mistake', NULL, 'Applied by mistake', 1, NULL, NULL, NULL, 16),
(TRUE, '2023-09-11 12:56:28', FALSE, 'VERIFIED', NULL, 'Rate too low', NULL, 'Rate too low', 1, NULL, NULL, NULL, 16),
(TRUE, '2023-09-11 12:56:28', FALSE, 'VERIFIED', NULL, 'Scheduling conflict with client', NULL, 'Scheduling conflict with client', 1, NULL, NULL, NULL, 16),
(TRUE, '2023-09-11 12:56:28', FALSE, 'VERIFIED', NULL, 'Unresponsive client', NULL, 'Unresponsive client', 1, NULL, NULL, NULL, 16),
(TRUE, '2023-09-11 12:56:28', FALSE, 'VERIFIED', NULL, 'Inappropriate client', NULL, 'Inappropriate client', 1, NULL, NULL, NULL, 16);

--changeset 25/09/2023 Sarjerao:Sarjerao-49
UPDATE code_lookup SET deleted= b'1' WHERE id IN (
WITH cte AS (
    SELECT id,NAME,type_id,deleted, ROW_NUMBER() OVER (PARTITION BY NAME,type_id ORDER BY id ASC) AS row_num
    FROM code_lookup  WHERE deleted != b'1'
) SELECT id FROM cte WHERE row_num > 1);

--changeset 25/09/2023 Akash:Akash-50
-- update by name
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Afghanistan (+93)' ,`description` = 'Afghanistan (+93)' WHERE `name` = '+93';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Albania (+355)' ,`description` = 'Albania (+355)' WHERE `name` = '+355';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Algeria (+213)' ,`description` = 'Algeria (+213)' WHERE `name` = '+213';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Andorra (+376)' ,`description` = 'Andorra (+376)' WHERE `name` = '+376';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Angola (+244)' ,`description` = 'Angola (+244)' WHERE `name` = '+244';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Argentina (+54)', `description` = 'Argentina (+54)' WHERE `name` = '+54';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Armenia (+374)' ,`description` = 'Armenia (+374)' WHERE `name` = '+374';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Aruba (+297)' ,`description` = 'Aruba (+297)' WHERE `name` = '+297';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Austria (+43)' ,`description` = 'Austria (+43)' WHERE `name` = '+43';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Azerbaijan (+994)' ,`description` = 'Azerbaijan (+994)' WHERE `name` = '+994';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Bahrain (+973)' ,`description` = 'Bahrain (+973)' WHERE `name` = '+973';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Bangladesh (+880)' ,`description` = 'Bangladesh (+880)' WHERE `name` = '+880';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Belarus (+375)' ,`description` = 'Belarus (+375)' WHERE `name` = '+375';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Belgium (+32)' ,`description` = 'Belgium (+32)' WHERE `name` = '+32';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Belize (+501)' ,`description` = 'Belize (+501)' WHERE `name` = '+501';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Benin (+229)' ,`description` = 'Benin (+229)' WHERE `name` = '+229';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Bhutan (+975)' ,`description` = 'Bhutan (+975)' WHERE `name` = '+975';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Bosnia and Herzegovina (+387)' ,`description` = 'Bosnia and Herzegovina (+387)' WHERE `name` = '+387';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Bolivia (+591)' ,`description` = 'Bolivia (+591)' WHERE `name` = '+591';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Botswana (+267)' ,`description` = 'Botswana (+267)' WHERE `name` = '+267';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Brazil (+55)' ,`description` = 'Brazil (+55)' WHERE `name` = '+55';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='British Indian Ocean Territory (+246)' ,`description` = 'British Indian Ocean Territory (+246)' WHERE `name` = '+246';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Cameroon (+237)' ,`description` = 'Cameroon (+237)' WHERE `name` = '+237';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Brunei (+673)' ,`description` = 'Brunei (+673)' WHERE `name` = '+673';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Bulgaria (+359)' ,`description` = 'Bulgaria (+359)' WHERE `name` = '+359';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Burkina Faso (+226)' ,`description` = 'Burkina Faso (+226)' WHERE `name` = '+226';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Burma-Myanmar (+95)' ,`description` = 'Burma-Myanmar (+95)' WHERE `name` = '+95';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Burundi (+257)' ,`description` = 'Burundi (+257)' WHERE `name` = '+257';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Cambodia (+855)' ,`description` = 'Cambodia (+855)' WHERE `name` = '+855';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Cape Verde (+238)' ,`description` = 'Cape Verde (+238)' WHERE `name` = '+238';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Central African Republic (+236)' ,`description` = 'Central African Republic (+236)' WHERE `name` = '+236';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Chad (+235)' ,`description` = 'Chad (+235)' WHERE `name` = '+235';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Chile (+56)' ,`description` = 'Chile (+56)' WHERE `name` = '+56';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='China (+86)' ,`description` = 'China (+86)' WHERE `name` = '+86';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Christmas Island (+6189)' ,`description` = 'Christmas Island (+6189)' WHERE `name` = '+6189';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Colombia (+57)' ,`description` = 'Colombia (+57)' WHERE `name` = '+57';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Congo (+242)' ,`description` = 'Congo (+242)' WHERE `name` = '+242';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Congo, The Democratic Republic (+243)' ,`description` = 'Congo, The Democratic Republic (+243)' WHERE `name` = '+243';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Cook Islands (+682)' ,`description` = 'Cook Islands (+682)' WHERE `name` = '+682';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Costa Rica (+506)' ,`description` = 'Costa Rica (+506)' WHERE `name` = '+506';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Croatia (+385)' ,`description` = 'Croatia (+385)' WHERE `name` = '+385';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Cyprus (+357)' ,`description` = 'Cyprus (+357)' WHERE `name` = '+357';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Czech Republic (+420)' ,`description` = 'Czech Republic (+420)' WHERE `name` = '+420';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Denmark (+45)' ,`description` = 'Denmark (+45)' WHERE `name` = '+45';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Djibouti (+253)' ,`description` = 'Djibouti (+253)' WHERE `name` = '+253';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Dominican Republic (+1849)' ,`description` = 'Dominican Republic (+1849)' WHERE `name` = '+1849';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Dominican Republic (+1829)' ,`description` = 'Dominican Republic (+1829)' WHERE `name` = '+1829';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Dominican Republic (+1809)' ,`description` = 'Dominican Republic (+1809)' WHERE `name` = '+1809';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='East Timor (+670)' ,`description` = 'East Timor (+670)' WHERE `name` = '+670';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Ecuador (+593)' ,`description` = 'Ecuador (+593)' WHERE `name` = '+593';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Egypt (+20)' ,`description` = 'Egypt (+20)' WHERE `name` = '+20';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='El Salvador (+503)' ,`description` = 'El Salvador (+503)' WHERE `name` = '+503';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Equatorial Guinea (+240)' ,`description` = 'Equatorial Guinea (+240)' WHERE `name` = '+240';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Eritrea (+291)' ,`description` = 'Eritrea (+291)' WHERE `name` = '+291';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Estonia (+372)' ,`description` = 'Estonia (+372)' WHERE `name` = '+372';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Ethiopia (+251)' ,`description` = 'Ethiopia (+251)' WHERE `name` = '+251';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Faroe Islands (+298)' ,`description` = 'Faroe Islands (+298)' WHERE `name` = '+298';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Fiji (+679)' ,`description` = 'Fiji (+679)' WHERE `name` = '+679';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Finland (+358)' ,`description` = 'Finland (+358)' WHERE `name` = '+358';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='France (+33)' ,`description` = 'France (+33)' WHERE `name` = '+33';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='French Guiana (+594)' ,`description` = 'French Guiana (+594)' WHERE `name` = '+594';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='French Polynesia (+689)' ,`description` = 'French Polynesia (+689)' WHERE `name` = '+689';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Gabon (+241)' ,`description` = 'Gabon (+241)' WHERE `name` = '+241';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Gambia (+220)' ,`description` = 'Gambia (+220)' WHERE `name` = '+220';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Georgia (+995)' ,`description` = 'Georgia (+995)' WHERE `name` = '+995';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Germany (+49)' ,`description` = 'Germany (+49)' WHERE `name` = '+49';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Ghana (+233)' ,`description` = 'Ghana (+233)' WHERE `name` = '+233';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Gibraltar (+350)' ,`description` = 'Gibraltar (+350)' WHERE `name` = '+350';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Greece (+30)' ,`description` = 'Greece (+30)' WHERE `name` = '+30';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Greenland (+299)' ,`description` = 'Greenland (+299)' WHERE `name` = '+299';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Guadeloupe (+590)' ,`description` = 'Guadeloupe (+590)' WHERE `name` = '+590';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Guatemala (+502)' ,`description` = 'Guatemala (+502)' WHERE `name` = '+502';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Guinea (+224)' ,`description` = 'Guinea (+224)' WHERE `name` = '+224';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Guinea-Bissau (+245)' ,`description` = 'Guinea-Bissau (+245)' WHERE `name` = '+245';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Guyana (+592)' ,`description` = 'Guyana (+592)' WHERE `name` = '+592';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Haiti (+509)' ,`description` = 'Haiti (+509)' WHERE `name` = '+509';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Honduras (+504)' ,`description` = 'Honduras (+504)' WHERE `name` = '+504';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Hong Kong (+852)' ,`description` = 'Hong Kong (+852)' WHERE `name` = '+852';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Hungary (+36)' ,`description` = 'Hungary (+36)' WHERE `name` = '+36';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Iceland (+354)' ,`description` = 'Iceland (+354)' WHERE `name` = '+354';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='India (+91)' ,`description` = 'India (+91)' WHERE `name` = '+91';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Indonesia (+62)' ,`description` = 'Indonesia (+62)' WHERE `name` = '+62';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Iran (+98)' ,`description` = 'Iran (+98)' WHERE `name` = '+98';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Iraq (+964)' ,`description` = 'Iraq (+964)' WHERE `name` = '+964';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Ireland (+353)' ,`description` = 'Ireland (+353)' WHERE `name` = '+353';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Israel (+972)' ,`description` = 'Israel (+972)' WHERE `name` = '+972';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Italy (+39)' ,`description` = 'Italy (+39)' WHERE `name` = '+39';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Ivory Coast (+225)' ,`description` = 'Ivory Coast (+225)' WHERE `name` = '+225';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Japan (+81)' ,`description` = 'Japan (+81)' WHERE `name` = '+81';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Jordan (+962)' ,`description` = 'Jordan (+962)' WHERE `name` = '+962';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Kenya (+254)' ,`description` = 'Kenya (+254)' WHERE `name` = '+254';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Kiribati (+686)' ,`description` = 'Kiribati (+686)' WHERE `name` = '+686';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Kuwait (+965)' ,`description` = 'Kuwait (+965)' WHERE `name` = '+965';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Kyrgyzstan (+996)' ,`description` = 'Kyrgyzstan (+996)' WHERE `name` = '+996';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Laos (+856)' ,`description` = 'Laos (+856)' WHERE `name` = '+856';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Latvia (+371)' ,`description` = 'Latvia (+371)' WHERE `name` = '+371';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Lebanon (+961)' ,`description` = 'Lebanon (+961)' WHERE `name` = '+961';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Lesotho (+266)' ,`description` = 'Lesotho (+266)' WHERE `name` = '+266';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Liberia (+231)' ,`description` = 'Liberia (+231)' WHERE `name` = '+231';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Libya (+218)' ,`description` = 'Libya (+218)' WHERE `name` = '+218';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Liechtenstein (+423)' ,`description` = 'Liechtenstein (+423)' WHERE `name` = '+423';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Lithuania (+370)' ,`description` = 'Lithuania (+370)' WHERE `name` = '+370';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Luxembourg (+352)' ,`description` = 'Luxembourg (+352)' WHERE `name` = '+352';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Macau (+853)' ,`description` = 'Macau (+853)' WHERE `name` = '+853';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Macedonia (+389)' ,`description` = 'Macedonia (+389)' WHERE `name` = '+389';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Madagascar (+261)' ,`description` = 'Madagascar (+261)' WHERE `name` = '+261';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Malawi (+265)' ,`description` = 'Malawi (+265)' WHERE `name` = '+265';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Malaysia (+60)' ,`description` = 'Malaysia (+60)' WHERE `name` = '+60';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Maldives (+960)' ,`description` = 'Maldives (+960)' WHERE `name` = '+960';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Mali (+223)' ,`description` = 'Mali (+223)' WHERE `name` = '+223';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Malta (+356)' ,`description` = 'Malta (+356)' WHERE `name` = '+356';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Marshall Islands (+692)' ,`description` = 'Marshall Islands (+692)' WHERE `name` = '+692';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Martinique (+596)' ,`description` = 'Martinique (+596)' WHERE `name` = '+596';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Mauritania (+222)' ,`description` = 'Mauritania (+222)' WHERE `name` = '+222';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Mauritius (+230)' ,`description` = 'Mauritius (+230)' WHERE `name` = '+230';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Mayotte (+262)' ,`description` = 'Mayotte (+262)' WHERE `name` = '+262';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Mexico (+52)' ,`description` = 'Mexico (+52)' WHERE `name` = '+52';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Moldova (+373)' ,`description` = 'Moldova (+373)' WHERE `name` = '+373';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Monaco (+377)' ,`description` = 'Monaco (+377)' WHERE `name` = '+377';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Mongolia (+976)' ,`description` = 'Mongolia (+976)' WHERE `name` = '+976';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Montenegro (+382)' ,`description` = 'Montenegro (+382)' WHERE `name` = '+382';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Morocco (+212)' ,`description` = 'Morocco (+212)' WHERE `name` = '+212';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Mozambique (+258)' ,`description` = 'Mozambique (+258)' WHERE `name` = '+258';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Namibia (+264)' ,`description` = 'Namibia (+264)' WHERE `name` = '+264';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Nauru (+674)' ,`description` = 'Nauru (+674)' WHERE `name` = '+674';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Nepal (+977)' ,`description` = 'Nepal (+977)' WHERE `name` = '+977';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Netherlands (+31)' ,`description` = 'Netherlands (+31)' WHERE `name` = '+31';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Curaçao (+599)' ,`description` = 'Curaçao (+599)' WHERE `name` = '+599';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='New Caledonia (+687)' ,`description` = 'New Caledonia (+687)' WHERE `name` = '+687';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='New Zealand (+64)' ,`description` = 'New Zealand (+64)' WHERE `name` = '+64';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Nicaragua (+505)' ,`description` = 'Nicaragua (+505)' WHERE `name` = '+505';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Niger (+227)' ,`description` = 'Niger (+227)' WHERE `name` = '+227';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Nigeria (+234)' ,`description` = 'Nigeria (+234)' WHERE `name` = '+234';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Niue (+683)' ,`description` = 'Niue (+683)' WHERE `name` = '+683';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='North Korea (+850)' ,`description` = 'North Korea (+850)' WHERE `name` = '+850';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Norway (+47)' ,`description` = 'Norway (+47)' WHERE `name` = '+47';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Oman (+968)' ,`description` = 'Oman (+968)' WHERE `name` = '+968';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Pakistan (+92)' ,`description` = 'Pakistan (+92)' WHERE `name` = '+92';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Palau (+680)' ,`description` = 'Palau (+680)' WHERE `name` = '+680';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Palestine (+970)' ,`description` = 'Palestine (+970)' WHERE `name` = '+970';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Panama (+507)' ,`description` = 'Panama (+507)' WHERE `name` = '+507';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Papua New Guinea (+675)' ,`description` = 'Papua New Guinea (+675)'WHERE `name` = '+675';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Paraguay (+595)' ,`description` = 'Paraguay (+595)' WHERE `name` = '+595';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Peru (+51)' ,`description` = 'Peru (+51)' WHERE `name` = '+51';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Philippines (+63)' ,`description` = 'Philippines (+63)' WHERE `name` = '+63';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Pitcairn Islands (+870)' ,`description` = 'Pitcairn Islands (+870)' WHERE `name` = '+870';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Poland (+48)' ,`description` = 'Poland (+48)' WHERE `name` = '+48';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Portugal (+351)' ,`description` = 'Portugal (+351)' WHERE `name` = '+351';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Puerto Rico (+1787)' ,`description` = 'Puerto Rico (+1787)' WHERE `name` = '+1787';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Qatar (+974)' ,`description` = 'Qatar (+974)' WHERE `name` = '974';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Réunion (+262' ,`description` = 'Réunion (+262)' WHERE `name` = '+262';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Romania (+40)' ,`description` = 'Romania (+40)' WHERE `name` = '+40';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Rwanda (+250)' ,`description` = 'Rwanda (+250)'WHERE `name` = '+250';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Saint Helena (+290)' ,`description` = 'Saint Helena (+290)' WHERE `name` = '+290';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Saint Martin (+1599)' ,`description` = 'Saint Martin (+1599)' WHERE `name` = '+1599';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Saint Pierre and Miquelon (+508)' ,`description` = 'Saint Pierre and Miquelon (+508)' WHERE `name` = '+508';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Samoa (+685)' ,`description` = 'Samoa (+685)' WHERE `name` = '+685';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='San Marino (+378)' ,`description` = 'San Marino (+378)' WHERE `name` = '+378';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='São Tomé and Príncipe (+239)' ,`description` = 'São Tomé and Príncipe (+239)' WHERE `name` = '+239';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Saudi Arabia (' ,`description` = 'Saudi Arabia (+966)' WHERE `name` = '+966';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Senegal (+221)' ,`description` = 'Senegal (+221)' WHERE `name` = '+221';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Seychelles (+248)' ,`description` = 'Seychelles (+248)' WHERE `name` = '+248';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Falkland Islands (+500)' ,`description` = 'Falkland Islands (+500)' WHERE `name` = '+500';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Sierra Leone (+232)' ,`description` = 'Sierra Leone (+232)' WHERE `name` = '+232';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Singapore (+65)' ,`description` = 'Singapore (+65)' WHERE `name` = '+65';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Slovakia (+421)' ,`description` = 'Slovakia (+421)' WHERE `name` = '+421';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Slovenia (+386)' ,`description` = 'Slovenia (+386)' WHERE `name` = '+386';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Solomon Islands (+677)' ,`description` = 'Solomon Islands (+677)' WHERE `name` = '+677';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Somalia (+252)' ,`description` = 'Somalia (+252)' WHERE `name` = '+252';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='South Africa (+27)' ,`description` = 'South Africa (+27)' WHERE `name` = '+27';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='South Korea (+82)' ,`description` = 'South Korea (+82)' WHERE `name` = '+82';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='South Sudan (+211)' ,`description` = 'South Sudan (+211)' WHERE `name` = '+211';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Spain (+34)' ,`description` = 'Spain (+34)' WHERE `name` = '+34';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Sri Lanka (+94)' ,`description` = 'Sri Lanka (+94)' WHERE `name` = '+94';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Sudan (+249)' ,`description` = 'Sudan (+249)' WHERE `name` = '+249';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Suriname (+597)' ,`description` = 'Suriname (+597)' WHERE `name` = '+597';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Swaziland (+268)' ,`description` = 'Swaziland (+268)' WHERE `name` = '+268';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Sweden (+46)' ,`description` = 'Sweden (+46)' WHERE `name` = '+46';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Switzerland (+41)' ,`description` = 'Switzerland (+41)' WHERE `name` = '+41';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Syria (+963)' ,`description` = 'Syria (+963)' WHERE `name` = '+963';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Taiwan (+886)' ,`description` = 'Taiwan (+886)' WHERE `name` = '+886';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Tajikistan (+992)' ,`description` = 'Tajikistan (+992)' WHERE `name` = '+992';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Tanzania (+255)' ,`description` = 'Tanzania (+255)' WHERE `name` = '+255';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Thailand (+66)' ,`description` = 'Thailand (+66)' WHERE `name` = '+66';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Togo (+228)' ,`description` = 'Togo (+228)' WHERE `name` = '+228';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Tokelau (+690)' ,`description` = 'Tokelau (+690)' WHERE `name` = '+690';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Tonga (+676)' ,`description` = 'Tonga (+676)' WHERE `name` = '+676';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Tunisia (+216)' ,`description` = 'Tunisia (+216)' WHERE `name` = '+216';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Turkey (+90)' ,`description` = 'Turkey (+90)' WHERE `name` = '+90';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Turkmenistan (+993)' ,`description` = 'Turkmenistan (+993)' WHERE `name` = '+993';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Tuvalu (+688)' ,`description` = 'Tuvalu (+688)' WHERE `name` = '+688';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='United Kingdom (+44)' ,`description` = 'United Kingdom (+44)' WHERE `name` = '+44';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Ukraine (+380)' ,`description` = 'Ukraine (+380)' WHERE `name` = '+380';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='United Arab Emirates (+971)' ,`description` = 'United Arab Emirates (+971)' WHERE `name` = '+971';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Uruguay (+598)' ,`description` = 'Uruguay (+598)' WHERE `name` = '+598';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Uzbekistan (+998)' ,`description` = 'Uzbekistan (+998)' WHERE `name` = '+998';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Vanuatu (+678)' ,`description` = 'Vanuatu (+678)' WHERE `name` = '+678';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Venezuela (+58)' ,`description` = 'Venezuela (+58)' WHERE `name` = '+58';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Vietnam (+84)' ,`description` = 'Vietnam (+84)' WHERE `name` = '+84';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Wallis and Futuna (+681)' ,`description` = 'Wallis and Futuna (+681)' WHERE `name` = '+681';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Yemen (+967)' ,`description` = 'Yemen (+967)' WHERE `name` = '+967';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Zambia (+260)' ,`description` = 'Zambia (+260)' WHERE `name` = '+260';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` = 'North American (+418)', `description` = 'North American (+418)' WHERE `name` = '+418';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` = 'Zimbabwe (+263)' , `description` = 'Zimbabwe (+263)' WHERE `name` = '+263';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` = 'Federated States of Micronesia (+691)' , `description` = 'Federated States of Micronesia (+691)' WHERE `name` = '+691';

--changeset 25/09/2023 Akash:Akash-51
-- update by name with having +1
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` ='Bermuda (+1441)' ,`description` = 'Bermuda (+1441)' WHERE `name` = '+1-441';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` = 'American Samoa (+1684)', `description` = 'American Samoa (+1684)' WHERE `name` = '+1-684';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` = 'Anguilla (+1264)', `description` = 'Anguilla (+1264)' WHERE `name` = '+1-264';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` = 'Antigua and Barbuda (+1268)', `description` = 'Antigua and Barbuda (+1268)'  WHERE `name` = '+1-268';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` = 'Bahamas (+1242)', `description` = 'Bahamas (+1242)' WHERE `name` = '+1-242';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` = 'Barbados (+1246)', `description` = 'Barbados (+1246)' WHERE `name` = '+1-246';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` = 'British Virgin Islands (+1284)', `description` = 'British Virgin Islands (+1284)' WHERE `name` = '+1-284';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` = 'Cayman Islands (+1345)', `description` = 'Cayman Islands (+1345)' WHERE `name` = '+1-345';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` = 'Dominica (+1767)', `description` = 'Dominica (+1767)' WHERE `name` = '+1-767';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` = 'Grenada (+1473)', `description` = 'Grenada (+1473)' WHERE `name` = '+1-473';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` = 'Guam (+1671)', `description` = 'Guam (+1671)' WHERE `name` = '+1-671';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` = 'Jamaica (+1876)', `description` = 'Jamaica (+1876)' WHERE `name` = '+1-876';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` = 'Northern Mariana Islands (+1670)', `description` = 'Northern Mariana Islands (+1670)' WHERE `name` = '+1-670';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` = 'Saint Kitts and Nevis (+1869)', `description` = 'Saint Kitts and Nevis (+1869)' WHERE `name` = '+1-869';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` = 'Saint Vincent and the Grenadines (+1784)', `description` = 'Saint Vincent and the Grenadines (+1784)' WHERE `name` = '+1-784';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` = 'Trinidad and Tobago (+1868)', `description` = 'Trinidad and Tobago (+1868)' WHERE `name` = '+1-868';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` = 'Turks and Caicos Islands (+1649)', `description` = 'Turks and Caicos Islands (+1649)' WHERE `name` = '+1-649';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` = 'Virgin Islands (+1340)', `description` = 'Virgin Islands (+1340)' WHERE `name` = '+1-340';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` = 'Saint Lucia (+1758)', `description` = 'Saint Lucia (+1758)' WHERE `name` = '+1-758';
UPDATE code_lookup SET `updated_on` = '2023-09-19 17:10:38', `name` = 'Montserrat (+1664)', `description` = 'Montserrat (+1664)' WHERE `name` = '+1-664';

--changeset 25/09/2023 Akash:Akash-52
-- insert
INSERT INTO code_lookup  (`active`, `created_on`, `deleted`, `status`, `updated_on`, `description`, `display_order`, `name`, `created_by`, `updated_by`, `image_id`, `parent_id`, `type_id`)
VALUES (1,	'2023-07-19 11:40:00',	0,	'VERIFIED',	'2023-07-19 11:40:00',	'Puerto Rico (+1787) ',	NULL,	'Puerto Rico (+1787) ',	1,	NULL,	NULL,	NULL,9),
(1,	'2023-07-19 11:40:00',	0,	'VERIFIED',	'2023-07-19 11:40:00',	'Saint Martin (+1599) ',	NULL,	'Saint Martin (+1599) ',	1,	NULL,	NULL,	NULL,9),
(1,	'2023-07-19 11:40:00',	0,	'VERIFIED',	'2023-07-19 11:40:00',	'Serbia (+381) ',	NULL,	'Serbia (+381) ',	1,	NULL,	NULL,	NULL,9),
(1,	'2023-07-19 11:40:00',	0,	'VERIFIED',	'2023-07-19 11:40:00',	'South Sudan (+211) ',	NULL,	'South Sudan (+211)' ,	1,	NULL,	NULL,	NULL,9),
(1,	'2023-07-19 11:40:00',	0,	'VERIFIED',	'2023-07-19 11:40:00',	'United States (+1)',	NULL,	'United States (+1)',	1,	NULL,	NULL,	NULL,9),
(1,	'2023-07-19 11:40:00',	0,	'VERIFIED',	'2023-07-19 11:40:00',	'Canada (+1)',	NULL,	'Canada (+1)',	1,	NULL,	NULL,	NULL,9),
(1,	'2023-07-19 11:40:00',	0,	'VERIFIED',	'2023-07-19 11:40:00',	'Kazakhstan (+7)',	NULL,	'Kazakhstan (+7)',	1,	NULL,	NULL,	NULL,9),
(1,	'2023-07-19 11:40:00',	0,	'VERIFIED',	'2023-07-19 11:40:00',	'Russia (+7)',	NULL,	'Russia (+7)',	1,	NULL,	NULL,	NULL,9),
(1,	'2023-07-19 11:40:00',	0,	'VERIFIED',	'2023-07-19 11:40:00',	'Australia (+61)',	NULL,	'Australia (+61)',	1,	NULL,	NULL,	NULL,9),
(1,	'2023-07-19 11:40:00',	0,	'VERIFIED',	'2023-07-19 11:40:00',	'Cuba (+53)',	NULL,	'Cuba (+53)',	1,	NULL,	NULL,	NULL,9),
(1,	'2023-07-19 11:40:00',	0,	'VERIFIED',	'2023-07-19 11:40:00',	'Comoros (+269)',	NULL,	'Comoros (+269)',	1,	NULL,	NULL,	NULL,9),
(1,	'2023-07-19 11:40:00',	0,	'VERIFIED',	'2023-07-19 11:40:00',	'Uganda (+256)',	NULL,	'Uganda (+256)',	1,	NULL,	NULL,	NULL,9),
(1,	'2023-07-19 11:40:00',	0,	'VERIFIED',	'2023-07-19 11:40:00',	'Norfolk Island (+672)',	NULL,	'Norfolk Island (+672)',	1,	NULL,	NULL,	NULL,9);

--changeset 25/09/2023 Akash:Akash-53
-- update in user table
UPDATE user SET `phone_code_id` = (select id from code_lookup WHERE `name` = 'United States (+1)')
where `phone_code_id` in (select id from code_lookup WHERE `name` = '+1');
UPDATE user SET `phone_code_id` = (select id from code_lookup WHERE `name` = 'Russia (+7)')
where `phone_code_id` in (select id from code_lookup WHERE `name` = '+7');
UPDATE user SET `phone_code_id` = (select id from code_lookup WHERE `name` = 'Australia (+61)')
where `phone_code_id` in (select id from code_lookup WHERE `name` = '+61');
UPDATE user SET `phone_code_id` = (select id from code_lookup WHERE `name` = 'Cuba (+53)')
where `phone_code_id` in (select id from code_lookup WHERE `name` = '+53');
UPDATE user SET `phone_code_id` = (select id from code_lookup WHERE `name` = 'Comoros (+269)')
where `phone_code_id` in (select id from code_lookup WHERE `name` = '+269');
UPDATE user SET `phone_code_id` = (select id from code_lookup WHERE `name` = 'Uganda (+256)')
where `phone_code_id` in (select id from code_lookup WHERE `name` = '+256');
UPDATE user SET `phone_code_id` = (select id from code_lookup WHERE `name` = 'Norfolk Island (+672)')
where `phone_code_id` in (select id from code_lookup WHERE `name` = '+672');

-- update in vendor table
UPDATE vendor SET `country_code_id` = (select id from code_lookup WHERE `name` = 'United States (+1)')
where `country_code_id` in (select id from code_lookup WHERE `name` = '+1');
UPDATE vendor SET `country_code_id` = (select id from code_lookup WHERE `name` = 'Russia (+7)')
where `country_code_id` in (select id from code_lookup WHERE `name` = '+7');
UPDATE vendor SET `country_code_id` = (select id from code_lookup WHERE `name` = 'Australia (+61)')
where `country_code_id` in (select id from code_lookup WHERE `name` = '+61');
UPDATE vendor SET `country_code_id` = (select id from code_lookup WHERE `name` = 'Cuba (+53)')
where `country_code_id` in (select id from code_lookup WHERE `name` = '+53');
UPDATE vendor SET `country_code_id` = (select id from code_lookup WHERE `name` = 'Comoros (+269)')
where `country_code_id` in (select id from code_lookup WHERE `name` = '+269');
UPDATE vendor SET `country_code_id` = (select id from code_lookup WHERE `name` = 'Uganda (+256)')
where `country_code_id` in (select id from code_lookup WHERE `name` = '+256');
UPDATE vendor SET `country_code_id` = (select id from code_lookup WHERE `name` = 'Norfolk Island (+672)')
where `country_code_id` in (select id from code_lookup WHERE `name` = '+672');

-- update in registration_enquiry table
UPDATE registration_enquiry SET `country_code_id` = (select id from code_lookup WHERE `name` = 'United States (+1)')
where `country_code_id` in (select id from code_lookup WHERE `name` = '+1');
UPDATE registration_enquiry SET `country_code_id` = (select id from code_lookup WHERE `name` = 'Russia (+7)')
where `country_code_id` in (select id from code_lookup WHERE `name` = '+7');
UPDATE registration_enquiry SET `country_code_id` = (select id from code_lookup WHERE `name` = 'Australia (+61)')
where `country_code_id` in (select id from code_lookup WHERE `name` = '+61');
UPDATE registration_enquiry SET `country_code_id` = (select id from code_lookup WHERE `name` = 'Cuba (+53)')
where `country_code_id` in (select id from code_lookup WHERE `name` = '+53');
UPDATE registration_enquiry SET `country_code_id` = (select id from code_lookup WHERE `name` = 'Comoros (+269)')
where `country_code_id` in (select id from code_lookup WHERE `name` = '+269');
UPDATE registration_enquiry SET `country_code_id` = (select id from code_lookup WHERE `name` = 'Uganda (+256)')
where `country_code_id` in (select id from code_lookup WHERE `name` = '+256');
UPDATE registration_enquiry SET `country_code_id` = (select id from code_lookup WHERE `name` = 'Norfolk Island (+672)')
where `country_code_id` in (select id from code_lookup WHERE `name` = '+672');

--changeset 25/09/2023 Akash:Akash-54
delete from code_lookup where name in ('+1','+7','+61','+53','+269','+256','+672');

--changeset 28/09/2023 Akash:Akash-55
alter table resource add column last_modified_date datetime;

UPDATE resource SET last_modified_date = updated_on;

--changeset 03/10/2023 Mansingh:Mansing-56
ALTER TABLE user ADD COLUMN page_size integer;

--changeset 03/10/2023 Manish:Manish-57
alter table resource_jobs add column applied_by bigint;
alter table resource_jobs add constraint FK2ctsqyjdobpxh80jxubrik3g0 foreign key (applied_by) references user (id);

--changeset 04/10/2023 Mansing:Mansingh-57
DELETE FROM code_lookup_relation;

--changeset 04/10/2023 Mansing:Mansingh-58
ALTER TABLE code_lookup_relation
ADD CONSTRAINT UK_code_lookup_relation_code_lookup UNIQUE (ref_id, ref_type, type,code_look_up_id);

--changeset 08/10/2023 Akash:Akash-59
CREATE TABLE  IF NOT EXISTS `subscribed_users` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `active` bit(1) DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `deleted` bit(1) DEFAULT b'0',
  `status` varchar(255) DEFAULT NULL,
  `updated_on` datetime DEFAULT NULL,
  `agency_name` varchar(255) DEFAULT NULL,
  `email_id` varchar(255) NOT NULL,
  `mobile_number` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `created_by` bigint DEFAULT NULL,
  `updated_by` bigint DEFAULT NULL,
  `country_code_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKph6mlvgycso6ysfy2r01jc5gn` (`created_by`),
  KEY `FKjfyyu5u3ci7h5rh456e1fxlbv` (`updated_by`),
  KEY `FKpkcygmgykys9fd6cincvg41jt` (`country_code_id`),
  CONSTRAINT `FKjfyyu5u3ci7h5rh456e1fxlbv` FOREIGN KEY (`updated_by`) REFERENCES `user` (`id`),
  CONSTRAINT `FKph6mlvgycso6ysfy2r01jc5gn` FOREIGN KEY (`created_by`) REFERENCES `user` (`id`),
  CONSTRAINT `FKpkcygmgykys9fd6cincvg41jt` FOREIGN KEY (`country_code_id`) REFERENCES `code_lookup` (`id`)
) ENGINE=InnoDB;

--changeset 10/13/2023 Manish:Manish-60
INSERT INTO `code_lookup_type` (`id`, `active`, `created_on`, `deleted`, `status`, `code`, `cover_img_require`, `deletable`, `editable`, `name`, `parent_id`)
VALUES (17, true, '2023-09-11 14:00:04', false, 'VERIFIED', 'SUBSCRIBE_FOR_EMAIL_NOTIFICATION', false, false, false, 'Unsubscribe For Email Notification', null);

INSERT INTO `code_lookup` (`active`, `created_on`, `deleted`, `status`, `updated_on`, `description`, `display_order`, `name`, `created_by`, `updated_by`, `image_id`, `parent_id`, `type_id`)
VALUES(TRUE, '2023-09-11 14:00:04', FALSE, 'VERIFIED', NULL, 'Open contract requirements', NULL, 'Open contract requirements', 1, NULL, NULL, NULL, 17),
(TRUE, '2023-09-11 14:00:04', FALSE, 'VERIFIED', NULL, 'New requirements', NULL, 'New requirements', 1, NULL, NULL, NULL, 17);

--changeset 13/10/2023 Akash:Akash-61
alter table resource_jobs add column resource_inr_rate_type varchar(255) DEFAULT NULL;
alter table resource_jobs add column resource_usd_rate_type varchar(255) DEFAULT NULL;

--changeset 16/10/2023 Aditya:Aditya-62
ALTER TABLE vendor ADD COLUMN tagline varchar(255) DEFAULT NULL;

--changeset 17/10/2023 Sushma:Sushma-63
alter table vendor add column banner_id bigint default null;
alter table vendor add constraint FKhplrars7x2hqsjjsmph3nleol foreign key (banner_id) references media (id);

--changeset 26/10/2023 Sarjerao:Sarjerao-64
CREATE TABLE IF NOT EXISTS company (id bigint not null auto_increment,
 active bit default 1, created_on datetime, deleted bit default 0,
 status varchar(255), updated_on datetime,
 name varchar(255) not null,website varchar(255), created_by bigint,
 updated_by bigint, media_id bigint,
 vendor_id bigint, PRIMARY KEY (id))
 engine=InnoDB;

ALTER TABLE company ADD CONSTRAINT FK7seng0b8h1nmiy1u1mah8xrh4 FOREIGN KEY (created_by) REFERENCES user (id);
ALTER TABLE company ADD CONSTRAINT FKc1kxij2udn876unjtnmfbaai1 FOREIGN KEY (updated_by) REFERENCES user (id);
ALTER TABLE company ADD CONSTRAINT FK78c1v4ly079ke4vi5i070mat6 FOREIGN KEY (media_id) REFERENCES media (id);
ALTER TABLE company ADD CONSTRAINT FK7ksogtoaikjt16rh0cj2vhah8 FOREIGN KEY (vendor_id) REFERENCES vendor (id);

--changeset 26/10/2023 Sarjerao:Sarjerao-65
INSERT INTO company(id,name) SELECT id,name FROM code_lookup WHERE type_id IN (SELECT id FROM code_lookup_type WHERE CODE='COMPANY');

--changeset 26/10/2023 Sarjerao:Sarjerao-66
ALTER TABLE experience DROP CONSTRAINT FKn5rfhlucu8qsulxe1vx4ohtpg;

--changeset 26/10/2023 Sarjerao:Sarjerao-67
ALTER TABLE experience ADD CONSTRAINT FK_experience_company FOREIGN KEY (company_id) REFERENCES company (id);

--changeset 04/09/2023 Sarjerao:Sarjerao-68
INSERT INTO company(name,website,media_id,vendor_id) SELECT agency_name,website,vendor_logo,id FROM vendor;

--changeset 26/10/2023 Sarjerao:Sarjerao-69
UPDATE company SET created_by=1, created_on='2023-09-20 17:34:04';

--changeset 01/11/2023 Manish:Manish-70
INSERT INTO `code_lookup` (`active`, `created_on`, `deleted`, `status`, `description`, `display_order`, `name`, `image_id`, `parent_id`, `type_id`)
VALUES (TRUE,'2023-03-15 14:00:04', FALSE, 'VERIFIED', 'American Samoa', null, 'American Samoa', null, null, 6),
(TRUE,'2023-03-15 14:00:04', FALSE, 'VERIFIED', 'Anguilla', null, 'Anguilla', null, null, 6),
(TRUE,'2023-03-15 14:00:04', FALSE, 'VERIFIED', 'Aruba', null, 'Aruba', null, null, 6),
(TRUE,'2023-03-15 14:00:04', FALSE, 'VERIFIED', 'Australia', null, 'Australia', null, null, 6),
(TRUE,'2023-03-15 14:00:04', FALSE, 'VERIFIED', 'Bahamas', null, 'Bahamas', null, null, 6),
(TRUE,'2023-03-15 14:00:04', FALSE, 'VERIFIED', 'Bermuda', null, 'Bermuda', null, null, 6),
(TRUE,'2023-03-15 14:00:04', FALSE, 'VERIFIED', 'British Virgin Islands', null, 'British Virgin Islands', null, null, 6),
(TRUE,'2023-03-15 14:00:04', FALSE, 'VERIFIED', 'Burma-Myanmar', null, 'Burma-Myanmar', null, null, 6),
(TRUE,'2023-03-15 14:00:04', FALSE, 'VERIFIED', 'Cape Verde', null, 'Cape Verde', null, null, 6),
(TRUE,'2023-03-15 14:00:04', FALSE, 'VERIFIED', 'Cayman Islands', null, 'Cayman Islands', null, null, 6),
(TRUE,'2023-03-15 14:00:04', FALSE, 'VERIFIED', 'Congo, The Democratic Republic', null, 'Congo, The Democratic Republic', null, null, 6),
(TRUE,'2023-03-15 14:00:04', FALSE, 'VERIFIED', 'Cook Islands', null, 'Cook Islands', null, null, 6),
(TRUE,'2023-03-15 14:00:04', FALSE, 'VERIFIED', 'Curaçao', null, 'Curaçao', null, null, 6),
(TRUE,'2023-03-15 14:00:04', FALSE, 'VERIFIED', 'East Timor', null, 'East Timor', null, null, 6),
(TRUE,'2023-03-15 14:00:04', FALSE, 'VERIFIED', 'Falkland Islands', null, 'Falkland Islands', null, null, 6),
(TRUE,'2023-03-15 14:00:04', FALSE, 'VERIFIED', 'Faroe Islands', null, 'Faroe Islands', null, null, 6),
(TRUE,'2023-03-15 14:00:04', FALSE, 'VERIFIED', 'Federated States of Micronesia', null, 'Federated States of Micronesia', null, null, 6),
(TRUE,'2023-03-15 14:00:04', FALSE, 'VERIFIED', 'Fiji', null, 'Fiji', null, null, 6),
(TRUE,'2023-03-15 14:00:04', FALSE, 'VERIFIED', 'French Polynesia', null, 'French Polynesia', null, null, 6),
(TRUE,'2023-03-15 14:00:04', FALSE, 'VERIFIED', 'Greenland', null, 'Greenland', null, null, 6),
(TRUE,'2023-03-15 14:00:04', FALSE, 'VERIFIED', 'Guadeloupe', null, 'Guadeloupe', null, null, 6),
(TRUE,'2023-03-15 14:00:04', FALSE, 'VERIFIED', 'Guam', null, 'Guam', null, null, 6),
(TRUE,'2023-03-15 14:00:04', FALSE, 'VERIFIED', 'Ivory Coast', null, 'Ivory Coast', null, null, 6),
(TRUE,'2023-03-15 14:00:04', FALSE, 'VERIFIED', 'Kiribati', null, 'Kiribati', null, null, 6),
(TRUE,'2023-03-15 14:00:04', FALSE, 'VERIFIED', 'Macau', null, 'Macau', null, null, 6),
(TRUE,'2023-03-15 14:00:04', FALSE, 'VERIFIED', 'Macedonia', null, 'Macedonia', null, null, 6),
(TRUE,'2023-03-15 14:00:04', FALSE, 'VERIFIED', 'Marshall Islands', null, 'Marshall Islands', null, null, 6),
(TRUE,'2023-03-15 14:00:04', FALSE, 'VERIFIED', 'Martinique', null, 'Martinique', null, null, 6),
(TRUE,'2023-03-15 14:00:04', FALSE, 'VERIFIED', 'Montserrat', null, 'Montserrat', null, null, 6),
(TRUE,'2023-03-15 14:00:04', FALSE, 'VERIFIED', 'Nauru', null, 'Nauru', null, null, 6),
(TRUE,'2023-03-15 14:00:04', FALSE, 'VERIFIED', 'New Caledonia', null, 'New Caledonia', null, null, 6),
(TRUE,'2023-03-15 14:00:04', FALSE, 'VERIFIED', 'New Zealand', null, 'New Zealand', null, null, 6),
(TRUE,'2023-03-15 14:00:04', FALSE, 'VERIFIED', 'Niue', null, 'Niue', null, null, 6),
(TRUE,'2023-03-15 14:00:04', FALSE, 'VERIFIED', 'Norfolk Island', null, 'Norfolk Island', null, null, 6),
(TRUE,'2023-03-15 14:00:04', FALSE, 'VERIFIED', 'North American', null, 'North American', null, null, 6),
(TRUE,'2023-03-15 14:00:04', FALSE, 'VERIFIED', 'Northern Mariana Islands', null, 'Northern Mariana Islands', null, null, 6),
(TRUE,'2023-03-15 14:00:04', FALSE, 'VERIFIED', 'Palau', null, 'Palau', null, null, 6),
(TRUE,'2023-03-15 14:00:04', FALSE, 'VERIFIED', 'Palestine', null, 'Palestine', null, null, 6),
(TRUE,'2023-03-15 14:00:04', FALSE, 'VERIFIED', 'Papua New Guinea', null, 'Papua New Guinea', null, null, 6),
(TRUE,'2023-03-15 14:00:04', FALSE, 'VERIFIED', 'Puerto Rico', null, 'Puerto Rico', null, null, 6),
(TRUE,'2023-03-15 14:00:04', FALSE, 'VERIFIED', 'Saint Martin', null, 'Saint Martin', null, null, 6),
(TRUE,'2023-03-15 14:00:04', FALSE, 'VERIFIED', 'Saint Pierre and Miquelon', null, 'Saint Pierre and Miquelon', null, null, 6),
(TRUE,'2023-03-15 14:00:04', FALSE, 'VERIFIED', 'Samoa', null, 'Samoa', null, null, 6),
(TRUE,'2023-03-15 14:00:04', FALSE, 'VERIFIED', 'São Tomé and Príncipe', null, 'São Tomé and Príncipe', null, null, 6),
(TRUE,'2023-03-15 14:00:04', FALSE, 'VERIFIED', 'Solomon Islands', null, 'Solomon Islands', null, null, 6),
(TRUE,'2023-03-15 14:00:04', FALSE, 'VERIFIED', 'Swaziland', null, 'Swaziland', null, null, 6),
(TRUE,'2023-03-15 14:00:04', FALSE, 'VERIFIED', 'Tokelau', null, 'Tokelau', null, null, 6),
(TRUE,'2023-03-15 14:00:04', FALSE, 'VERIFIED', 'Tonga', null, 'Tonga', null, null, 6),
(TRUE,'2023-03-15 14:00:04', FALSE, 'VERIFIED', 'Turks and Caicos Islands', null, 'Turks and Caicos Islands', null, null, 6),
(TRUE,'2023-03-15 14:00:04', FALSE, 'VERIFIED', 'Tuvalu', null, 'Tuvalu', null, null, 6),
(TRUE,'2023-03-15 14:00:04', FALSE, 'VERIFIED', 'Vanuatu', null, 'Vanuatu', null, null, 6),
(TRUE,'2023-03-15 14:00:04', FALSE, 'VERIFIED', 'Virgin Islands', null, 'Virgin Islands', null, null, 6),
(TRUE,'2023-03-15 14:00:04', FALSE, 'VERIFIED', 'Wallis and Futuna', null, 'Wallis and Futuna', null, null, 6);

--changeset 01/11/2023 Manish:Manish-71
INSERT INTO code_lookup  (`active`, `created_on`, `deleted`, `status`, `updated_on`, `description`, `display_order`, `name`, `created_by`, `updated_by`, `image_id`, `parent_id`, `type_id`)
VALUES (1,	'2023-07-19 11:40:00',	0,	'VERIFIED',	'2023-07-19 11:40:00',	'Brazil (+55) ',	NULL,	'Brazil (+55) ',	1,	NULL,	NULL,	NULL,9),
(1,	'2023-07-19 11:40:00',	0,	'VERIFIED',	'2023-07-19 11:40:00',	'Channel Islands (+44) ',	NULL,	'Channel Islands (+44) ',	1,	NULL,	NULL,	NULL,9),
(1,	'2023-07-19 11:40:00',	0,	'VERIFIED',	'2023-07-19 11:40:00',	'Dominican Republic (+1849) ',	NULL,	'Dominican Republic (+1849) ',	1,	NULL,	NULL,	NULL,9),
(1,	'2023-07-19 11:40:00',	0,	'VERIFIED',	'2023-07-19 11:40:00',	'Dominican Republic (+1829) ',	NULL,	'Dominican Republic (+1829) ',	1,	NULL,	NULL,	NULL,9),
(1,	'2023-07-19 11:40:00',	0,	'VERIFIED',	'2023-07-19 11:40:00',	'Dominican Republic (+1809) ',	NULL,	'Dominican Republic (+1809) ',	1,	NULL,	NULL,	NULL,9),
(1,	'2023-07-19 11:40:00',	0,	'VERIFIED',	'2023-07-19 11:40:00',	'DR Congo (+243) ',	NULL,	'DR Congo (+243) ',	1,	NULL,	NULL,	NULL,9),
(1,	'2023-07-19 11:40:00',	0,	'VERIFIED',	'2023-07-19 11:40:00',	'Eswatini (+268) ',	NULL,	'Eswatini (+268) ',	1,	NULL,	NULL,	NULL,9),
(1,	'2023-07-19 11:40:00',	0,	'VERIFIED',	'2023-07-19 11:40:00',	'Faeroe Islands (+298) ',	NULL,	'Faeroe Islands (+298) ',	1,	NULL,	NULL,	NULL,9),
(1,	'2023-07-19 11:40:00',	0,	'VERIFIED',	'2023-07-19 11:40:00',	'Holy See (+379) ',	NULL,	'Holy See (+379) ',	1,	NULL,	NULL,	NULL,9),
(1,	'2023-07-19 11:40:00',	0,	'VERIFIED',	'2023-07-19 11:40:00',	'Isle of Man (+44) ',	NULL,	'Isle of Man (+44) ',	1,	NULL,	NULL,	NULL,9),
(1,	'2023-07-19 11:40:00',	0,	'VERIFIED',	'2023-07-19 11:40:00',	'Macao (+853) ',	NULL,	'Macao (+853) ',	1,	NULL,	NULL,	NULL,9),
(1,	'2023-07-19 11:40:00',	0,	'VERIFIED',	'2023-07-19 11:40:00',	'Montenegro (+382) ',	NULL,	'Montenegro (+382) ',	1,	NULL,	NULL,	NULL,9),
(1,	'2023-07-19 11:40:00',	0,	'VERIFIED',	'2023-07-19 11:40:00',	'Myanmar (+95) ',	NULL,	'Myanmar (+95) ',	1,	NULL,	NULL,	NULL,9),
(1,	'2023-07-19 11:40:00',	0,	'VERIFIED',	'2023-07-19 11:40:00',	'North Macedonia (+389) ',	NULL,	'North Macedonia (+389) ',	1,	NULL,	NULL,	NULL,9),
(1,	'2023-07-19 11:40:00',	0,	'VERIFIED',	'2023-07-19 11:40:00',	'RÃ©union (+262) ',	NULL,	'RÃ©union (+262) ',	1,	NULL,	NULL,	NULL,9),
(1,	'2023-07-19 11:40:00',	0,	'VERIFIED',	'2023-07-19 11:40:00',	'Sao Tome & Principe (+239) ',	NULL,	'Sao Tome & Principe (+239) ',	1,	NULL,	NULL,	NULL,9),
(1,	'2023-07-19 11:40:00',	0,	'VERIFIED',	'2023-07-19 11:40:00',	'State of Palestine (+970) ',	NULL,	'State of Palestine (+970) ',	1,	NULL,	NULL,	NULL,9),
(1,	'2023-07-19 11:40:00',	0,	'VERIFIED',	'2023-07-19 11:40:00',	'The Bahamas (+1) ',	NULL,	'The Bahamas (+1) ',	1,	NULL,	NULL,	NULL,9),
(1,	'2023-07-19 11:40:00',	0,	'VERIFIED',	'2023-07-19 11:40:00',	'Timor-Leste (+670) ',	NULL,	'Timor-Leste (+670) ',	1,	NULL,	NULL,	NULL,9),
(1,	'2023-07-19 11:40:00',	0,	'VERIFIED',	'2023-07-19 11:40:00',	'Togo (+228) ',	NULL,	'Togo (+228) ',	1,	NULL,	NULL,	NULL,9),
(1,	'2023-07-19 11:40:00',	0,	'VERIFIED',	'2023-07-19 11:40:00',	'Western Sahara (+212) ',	NULL,	'Western Sahara (+212) ',	1,	NULL,	NULL,	NULL,9);

--changeset 01/11/2023 Manish:Manish-72
delete from code_lookup where name='Cabo Verde';

--changeset 01/11/2023 Manish:Manish-73
UPDATE  code_lookup SET  name='Saudi Arabia (+966)' WHERE name='Saudi Arabia (';

--changeset 11/11/2023 Sushma:Sushma-74
INSERT INTO `code_lookup_type` (`id`,`active`, `created_on`, `deleted`, `status`, `code`, `cover_img_require`, `deletable`, `editable`, `name`, `parent_id`)
VALUES (18, true,'2023-10-05 14:30:45', false, 'VERIFIED', 'SEE_ALL_CATEGORIES', false, false, false, 'See_All_Categories',  null);

INSERT INTO `code_lookup` (`active`, `created_on`, `deleted`, `status`, `updated_on`, `description`, `display_order`, `name`, `created_by`, `updated_by`, `image_id`, `parent_id`, `type_id`)
VALUES(b'1', '2023-10-05 14:30:45', b'0', 'VERIFIED', NULL, 'Full Stack Development', NULL, 'Full Stack Development', 1, NULL, NULL, NULL, 18),
(b'1', '2023-10-05 14:30:45', b'0', 'VERIFIED', NULL, 'Ecommerce Website Development', NULL, 'Ecommerce Website Development', 1, NULL, NULL, NULL, 18),
(b'1', '2023-10-05 14:30:45', b'0', 'VERIFIED', NULL, 'Desktop Software Development', NULL, 'Desktop Software Development', 1, NULL, NULL, NULL, 18),
(b'1', '2023-10-05 14:30:45', b'0', 'VERIFIED', NULL, 'Scripting & Automation', NULL, 'Scripting & Automation', 1, NULL, NULL, NULL, 18),
(b'1', '2023-10-05 14:30:45', b'0', 'VERIFIED', NULL, 'Manual Testing', NULL, 'Manual Testing', 1, NULL, NULL, NULL, 18),
(b'1', '2023-10-05 14:30:45', b'0', 'VERIFIED', NULL, 'Automation Testing', NULL, 'Automation Testing', 1, NULL, NULL, NULL, 18),
(b'1', '2023-10-05 14:30:45', b'0', 'VERIFIED', NULL, 'Prototyping', NULL, 'Prototyping', 1, NULL, NULL, NULL, 18),
(b'1', '2023-10-05 14:30:45', b'0', 'VERIFIED', NULL, 'Mobile Design', NULL, 'Mobile Design', 1, NULL, NULL, NULL, 18),
(b'1', '2023-10-05 14:30:45', b'0', 'VERIFIED', NULL, 'Web Design', NULL, 'Web Design', 1, NULL, NULL, NULL, 18),
(b'1', '2023-10-05 14:30:45', b'0', 'VERIFIED', NULL, 'UX/UI Design', NULL, 'UX/UI Design', 1, NULL, NULL, NULL, 18),
(b'1', '2023-10-05 14:30:45', b'0', 'VERIFIED', NULL, 'Mobile App Development', NULL, 'Mobile App Development', 1, NULL, NULL, NULL, 18),
(b'1', '2023-10-05 14:30:45', b'0', 'VERIFIED', NULL, 'Mobile Game Development', NULL, 'Mobile Game Development', 1, NULL, NULL, NULL, 18),
(b'1', '2023-10-05 14:30:45', b'0', 'VERIFIED', NULL, 'Crypto Coins & Tokens', NULL, 'Crypto Coins & Tokens', 1, NULL, NULL, NULL, 18),
(b'1', '2023-10-05 14:30:45', b'0', 'VERIFIED', NULL, 'Blockchain & NFT Development', NULL, 'Blockchain & NFT Development', 1, NULL, NULL, NULL, 18),
(b'1', '2023-10-05 14:30:45', b'0', 'VERIFIED', NULL, 'Other Blockchain, NFT & Cryptocurrencyselected', NULL, 'Other Blockchain, NFT & Cryptocurrencyselected', 1, NULL, NULL, NULL, 18),
(b'1', '2023-10-05 14:30:45', b'0', 'VERIFIED', NULL, 'Crypto Wallet Development', NULL, 'Crypto Wallet Development', 1, NULL, NULL, NULL, 18),
(b'1', '2023-10-05 14:30:45', b'0', 'VERIFIED', NULL, 'Scrum Leadership', NULL, 'Scrum Leadership', 1, NULL, NULL, NULL, 18),
(b'1', '2023-10-05 14:30:45', b'0', 'VERIFIED', NULL, 'Agile Leadership', NULL, 'Agile Leadership', 1, NULL, NULL, NULL, 18),
(b'1', '2023-10-05 14:30:45', b'0', 'VERIFIED', NULL, 'Firmware Development', NULL, 'Firmware Development', 1, NULL, NULL, NULL, 18),
(b'1', '2023-10-05 14:30:45', b'0', 'VERIFIED', NULL, 'Emerging Tech', NULL, 'Emerging Tech', 1, NULL, NULL, NULL, 18),
(b'1', '2023-10-05 14:30:45', b'0', 'VERIFIED', NULL, 'AR/VR Development', NULL, 'AR/VR Development', 1, NULL, NULL, NULL, 18),
(b'1', '2023-10-05 14:30:45', b'0', 'VERIFIED', NULL, 'Coding Tutoring', NULL, 'Coding Tutoring', 1, NULL, NULL, NULL, 18),
(b'1', '2023-10-05 14:30:45', b'0', 'VERIFIED', NULL, 'Database Development', NULL, 'Database Development', 1, NULL, NULL, NULL, 18),
(b'1', '2023-10-05 14:30:45', b'0', 'VERIFIED', NULL, 'Back-End Development', NULL, 'Back-End Development', 1, NULL, NULL, NULL, 18),
(b'1', '2023-10-05 14:30:45', b'0', 'VERIFIED', NULL, 'Front-End Development', NULL, 'Front-End Development', 1, NULL, NULL, NULL, 18),
(b'1', '2023-10-05 14:30:45', b'0', 'VERIFIED', NULL, 'CMS Development', NULL, 'CMS Development', 1, NULL, NULL, NULL, 18),
(b'1', '2023-10-05 14:30:45', b'0', 'VERIFIED', NULL, 'Video Game Development', NULL, 'Video Game Development', 1, NULL, NULL, NULL, 18);

alter table job add column category_id bigint default null;
alter table job add constraint FKr0manxkoj18d7mflq2a8kxxft foreign key (category_id) references code_lookup (id);

--changeset 02/11/2023 Sushma:Sushma-75
ALTER TABLE job ADD COLUMN time_zone VARCHAR(255);
ALTER TABLE job ADD COLUMN start_time TIME;
ALTER TABLE job ADD COLUMN end_time TIME;

--changeset 11/11/2023 Mansingh:Mansingh-76
ALTER TABLE job
MODIFY start_date datetime NULL;

--changeset 08/11/2023 Akash:Akash-77
UPDATE job SET close_reason = 'NO_AGENCY_FOR_REQUESTED_SKILLS' WHERE close_reason = 'NO_FREELANCER_FOR_REQUESTED_SKILLS';

--changeset 13/12/2023 Mansingh:Mansingh-78
ALTER TABLE experience
MODIFY description longtext;

--changeset 02/11/2023 Sushma:Sushma-79
create table email_log (id bigint not null auto_increment, active bit, created_on datetime, deleted bit default 0, status varchar(255), updated_on datetime, email longtext, result varchar(255), log_msg longtext, subject longtext, created_by bigint, updated_by bigint, vendor_id bigint, primary key (id)) engine=InnoDB;
alter table email_log add constraint FKk8jxvjyaeiqc9y3vrm66p3dwf foreign key (created_by) references user (id);
alter table email_log add constraint FKe5sh2qvuq7gw75inraxjr5v5r foreign key (updated_by) references user (id);
alter table email_log add constraint FKqv013ui9de85x04829xyblmp6 foreign key (vendor_id) references vendor (id);
 
--changeset 08/01/2024 Sushma:Sushma-80 
INSERT INTO `code_lookup` (`active`, `created_on`, `deleted`, `status`, `updated_on`, `description`, `display_order`, `name`, `created_by`, `updated_by`, `image_id`, `parent_id`, `type_id`)
VALUES (TRUE,'2024-02-08 17:00:04', FALSE, 'VERIFIED', NULL, 'REMOVE CONTACT DETAILS FROM RESUME', NULL, 'Remove Contact Details From Resume', 1, NULL, NULL, NULL, 14);
 